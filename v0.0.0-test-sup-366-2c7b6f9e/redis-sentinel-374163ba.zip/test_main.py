#!/usr/bin/env python3
"""Pure-function unit tests for redis-sentinel/main.py.

Run with `python3 -m unittest services/redis-sentinel/test_main.py` from the
repo root, or `python3 -m unittest test_main` from this directory. No cluster,
no podman, no network.
"""

import os
import sys
import unittest
from pathlib import Path
from unittest import mock

# Stub the SDK so importing main.py works without the in-cluster runtime.
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            pass

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            pass

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *a, **k: {}
    stub.read_manifest_version = lambda *a, **k: ""
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402


class NormalizeAddrTests(unittest.TestCase):
    def test_returns_empty_for_none_or_blank(self):
        self.assertEqual(main.normalize_addr(None), "")
        self.assertEqual(main.normalize_addr(""), "")

    def test_strips_whitespace(self):
        self.assertEqual(main.normalize_addr("  10.0.0.1\n"), "10.0.0.1")

    def test_strips_ipv6_brackets(self):
        self.assertEqual(main.normalize_addr("[fd00::1]"), "fd00::1")

    def test_leaves_plain_ipv4_alone(self):
        self.assertEqual(main.normalize_addr("10.0.0.1"), "10.0.0.1")


class DiscoverMasterFromRedisTests(unittest.TestCase):
    """`discover_master_from_redis` must converge on the same answer across all
    sentinels regardless of which order they probe peers in."""

    def _patch_info(self, table):
        """table: {ip: info_dict_or_none}."""

        def fake_info(ip):
            return table.get(ip)

        return mock.patch.object(main, "get_redis_replication_info", side_effect=fake_info)

    def test_returns_none_when_no_peer_responds(self):
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        with self._patch_info({}):
            self.assertIsNone(main.discover_master_from_redis(endpoints))

    def test_returns_none_when_no_peer_is_master(self):
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        table = {
            "10.0.0.1": {"role": "slave", "connected_slaves": "0"},
            "10.0.0.2": {"role": "slave", "connected_slaves": "0"},
        }
        with self._patch_info(table):
            self.assertIsNone(main.discover_master_from_redis(endpoints))

    def test_returns_single_master(self):
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        table = {
            "10.0.0.1": {"role": "master", "connected_slaves": "1"},
            "10.0.0.2": {"role": "slave", "connected_slaves": "0"},
        }
        with self._patch_info(table):
            self.assertEqual(main.discover_master_from_redis(endpoints), "10.0.0.1")

    def test_replica_count_breaks_ties_first(self):
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        table = {
            "10.0.0.1": {"role": "master", "connected_slaves": "0"},
            "10.0.0.2": {"role": "master", "connected_slaves": "2"},
        }
        with self._patch_info(table):
            self.assertEqual(main.discover_master_from_redis(endpoints), "10.0.0.2")

    def test_node_id_breaks_ties_when_replica_counts_match(self):
        # Equal replica counts -> lowest node_id wins. node_id is the
        # load-bearing tie-break since replica counts can flap between snapshots.
        endpoints = [("n2", "10.0.0.2"), ("n1", "10.0.0.1")]
        table = {
            "10.0.0.1": {"role": "master", "connected_slaves": "1"},
            "10.0.0.2": {"role": "master", "connected_slaves": "1"},
        }
        with self._patch_info(table):
            self.assertEqual(main.discover_master_from_redis(endpoints), "10.0.0.1")

    def test_sup7_repro_split_brain_recovers_to_real_master(self):
        # SUP-7 scenario: bootstrap (n0) is the real master with one connected
        # replica; node1 (n1) is a downed replica that an old sentinel
        # (mistakenly) was monitoring. Once we ask Redis directly, n0 wins.
        endpoints = [("n0", "10.7.0.1"), ("n1", "10.7.0.2"), ("n2", "10.7.0.3")]
        table = {
            "10.7.0.1": {"role": "master", "connected_slaves": "1"},
            "10.7.0.2": None,  # unreachable
            "10.7.0.3": {"role": "slave", "connected_slaves": "0"},
        }
        with self._patch_info(table):
            self.assertEqual(main.discover_master_from_redis(endpoints), "10.7.0.1")

    def test_normalizes_ipv6_brackets_in_output(self):
        endpoints = [("n1", "[fd00::1]")]
        table = {"[fd00::1]": {"role": "master", "connected_slaves": "0"}}
        with self._patch_info(table):
            self.assertEqual(main.discover_master_from_redis(endpoints), "fd00::1")


class ChooseMasterIpTests(unittest.TestCase):
    """`choose_master_ip` priority order:
      1. live INFO replication master
      2. first endpoint by node_id (deterministic cold-boot fallback)
    """

    def test_prefers_discovered_master(self):
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        with mock.patch.object(main, "discover_master_from_redis", return_value="10.0.0.2"):
            self.assertEqual(main.choose_master_ip(endpoints, "n1"), "10.0.0.2")

    def test_falls_back_to_first_endpoint_by_node_id(self):
        # Cold boot: no live master — return the lowest node_id so all sentinels
        # pick the same target regardless of leader hint.
        endpoints = [("n1", "10.0.0.1"), ("n2", "10.0.0.2")]
        with mock.patch.object(main, "discover_master_from_redis", return_value=None):
            self.assertEqual(main.choose_master_ip(endpoints, None), "10.0.0.1")
            self.assertEqual(main.choose_master_ip(endpoints, "n2"), "10.0.0.1")


if __name__ == "__main__":
    unittest.main(verbosity=2)
