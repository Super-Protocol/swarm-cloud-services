#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import time
import pwd
import re
from pathlib import Path

from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

# Configuration
REDIS_PORT = 6379
REDIS_SENTINEL_PORT = int(os.environ.get("REDIS_SENTINEL_PORT", "26379"))
REDIS_CONFIG_DIR = Path("/etc/redis")
REDIS_DATA_DIR = Path("/var/lib/redis")
REDIS_CLI = "redis-cli"
PODMAN_BIN = "podman"
VALKEY_IMAGE = os.environ.get("VALKEY_IMAGE", "registry-1.docker.io/valkey/valkey:9.0.3")
VALKEY_UID = 999  # valkey user in image; data dir must be owned by this so container can read/write
VALKEY_GID = 999
SENTINEL_NAME = os.environ.get("REDIS_SENTINEL_NAME", "redis-master")
SENTINEL_CONFIG_FILE = REDIS_CONFIG_DIR / "sentinel.conf"
# Config inside data dir so container can read and write (Sentinel rewrites config at runtime)
SENTINEL_CONFIG_IN_DATA = REDIS_DATA_DIR / "sentinel.conf"
REDIS_MAX_NODES = int(os.environ.get("REDIS_MAX_NODES", "5"))
REDIS_SENTINEL_MAX_NODES = int(os.environ.get("REDIS_SENTINEL_MAX_NODES", "3"))

# Plugin setup
plugin = ProvisionPlugin()


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def count_ready_sentinels(node_props: list) -> int:
    """Count unique sentinel nodes marked ready."""
    ready_nodes: set[str] = set()
    for prop in node_props:
        if prop.get("name") != "redis_sentinel_node_ready":
            continue
        if prop.get("value") != "true":
            continue
        node_id = prop.get("node_id")
        if node_id:
            ready_nodes.add(node_id)
    return len(ready_nodes)


def build_node_endpoints(cluster_nodes: list, wg_props: list) -> list[tuple[str, str]]:
    """Build a list of (node_id, tunnel_ip) for nodes with WG."""
    node_endpoints: list[tuple[str, str]] = []
    for node in cluster_nodes:
        node_id = node.get("node_id")
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            node_endpoints.append((node_id, tunnel_ip))
    return node_endpoints


def calculate_sentinel_quorum(ready_count: int, cluster_size: int) -> int:
    """Derive quorum from current readiness/size, always at least 1."""
    effective = ready_count if ready_count > 0 else cluster_size
    if effective >= 3:
        return (effective // 2) + 1
    return max(1, effective - 1)


def is_sentinel_available() -> bool:
    """Check if required host binaries are available."""
    return shutil.which(REDIS_CLI) is not None and shutil.which(PODMAN_BIN) is not None


def get_container_name(cluster_id: str | None) -> str:
    """Build deterministic Podman container name."""
    raw = cluster_id or "default"
    sanitized = re.sub(r"[^a-zA-Z0-9_.-]+", "-", raw).strip("-_.")
    if not sanitized:
        sanitized = "default"
    return f"valkey-sentinel-{sanitized}"[:120]


def stop_and_remove_container(container_name: str) -> None:
    """Stop gracefully, wait up to 1 min; if stuck in Stopping, force-remove."""
    try:
        subprocess.run(
            [PODMAN_BIN, "stop", container_name],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=20,
        )
    except subprocess.TimeoutExpired:
        pass
    for _ in range(12):
        time.sleep(5)
        try:
            result = subprocess.run(
                [PODMAN_BIN, "inspect", "--format", "{{.State.Status}}", container_name],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except subprocess.TimeoutExpired:
            continue
        if result.returncode != 0:
            return
        status = (result.stdout or "").strip().lower()
        if status in ("exited", "stopped", "configured"):
            subprocess.run([PODMAN_BIN, "rm", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        if status not in ("stopping", "running"):
            subprocess.run([PODMAN_BIN, "rm", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    subprocess.run([PODMAN_BIN, "rm", "-f", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_valkey_sentinel_container(container_name: str) -> None:
    """Run ValKey Sentinel container with host networking; config in /data so Sentinel can write it."""
    stop_and_remove_container(container_name)
    # valkey-sentinel /data/sentinel.conf avoids image default /etc/valkey/sentinel.conf; run as valkey (999)
    cmd = [
        PODMAN_BIN,
        "run",
        "-d",
        "--name",
        container_name,
        "--network",
        "host",
        "--user",
        f"{VALKEY_UID}:{VALKEY_GID}",
        "-v",
        f"{REDIS_DATA_DIR}:/data",
        VALKEY_IMAGE,
        "valkey-sentinel",
        "/data/sentinel.conf",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Podman run timed out after 30s")
    if result.returncode != 0:
        raise RuntimeError(f"Failed to run ValKey Sentinel container: {result.stderr.strip() or result.stdout.strip()}")


def install_redis():
    """Ensure required host dependencies are installed."""
    try:
        if shutil.which(PODMAN_BIN) is None:
            raise Exception("podman is not installed; install podman on the host before using redis-sentinel service")

        if shutil.which(REDIS_CLI) is None:
            raise Exception("redis-cli not found. Ensure redis-tools is pre-installed on the host.")

        ensure_redis_directories()
    except Exception as e:
        print(f"[!] Failed to install Redis: {e}", file=sys.stderr)
        raise


def ensure_redis_directories():
    """Ensure Redis data and log directories exist with correct ownership."""
    REDIS_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    REDIS_DATA_DIR.mkdir(parents=True, exist_ok=True)
    log_dir = Path("/var/log/redis")
    log_dir.mkdir(parents=True, exist_ok=True)

    try:
        redis_user = pwd.getpwnam("redis")
        uid, gid = redis_user.pw_uid, redis_user.pw_gid
    except KeyError:
        uid = gid = None

    if uid is not None:
        for path in (REDIS_CONFIG_DIR, log_dir):
            try:
                os.chown(path, uid, gid)
            except PermissionError:
                pass
    # Data dir must be owned by ValKey container user (999) so valkey-sentinel can read/write /data
    try:
        os.chown(REDIS_DATA_DIR, VALKEY_UID, VALKEY_GID)
        REDIS_DATA_DIR.chmod(0o755)
    except PermissionError:
        pass


def normalize_addr(addr: str | None) -> str:
    """Normalize an IP-ish address: strip whitespace and IPv6 brackets."""
    if not addr:
        return ""
    value = addr.strip()
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    return value


def get_redis_replication_info(ip: str) -> dict[str, str] | None:
    """Fetch `INFO replication` from a Valkey/Redis instance, or None on error."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", ip, "-p", str(REDIS_PORT), "INFO", "replication"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode != 0:
            return None
        info: dict[str, str] = {}
        for raw in result.stdout.splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or ":" not in line:
                continue
            key, value = line.split(":", 1)
            info[key.strip()] = value.strip()
        return info
    except Exception:
        return None


def discover_master_from_redis(
    node_endpoints: list[tuple[str, str]],
) -> str | None:
    """Find the live Redis master IP by asking each instance for its role.

    Preferred over reachability heuristics: if any peer reports `role:master`,
    return its IP. Ties (multiple "masters" — split brain on the Redis side)
    are broken by preferring the instance with the most connected replicas,
    then by lowest node_id, so every sentinel converges on the same answer.
    """
    masters: list[tuple[int, str, str]] = []
    for node_id, ip in node_endpoints:
        info = get_redis_replication_info(ip)
        if not info:
            continue
        if info.get("role") != "master":
            continue
        try:
            replicas = int(info.get("connected_slaves", "0"))
        except ValueError:
            replicas = 0
        masters.append((replicas, node_id, normalize_addr(ip)))

    if not masters:
        return None

    # node_id is the load-bearing tie-break: replica counts can differ across
    # snapshots taken seconds apart by different sentinels (a replica may be
    # connecting/disconnecting), so without the secondary sort sentinels would
    # disagree on the chosen master.
    masters.sort(key=lambda x: (-x[0], x[1]))
    if len(masters) > 1:
        ips = [m[2] for m in masters]
        print(
            f"[!] Multiple Redis masters reported role:master (Redis-side split brain): "
            f"{ips!r}; choosing {masters[0][2]!r} (most replicas, then lowest node_id)",
            file=sys.stderr,
        )
    return masters[0][2]


def choose_master_ip(
    node_endpoints: list[tuple[str, str]],
    leader_node_id: str | None,
) -> str:
    """Choose master IP for `sentinel monitor` — must match on every node.

    Uses a single unambiguous live master when INFO replication reports exactly
    one role:master across reachable peers. Otherwise falls back to the first
    node_id in sorted order (same on all hosts).

    Per-node leader/reachability heuristics caused different sentinels to
    monitor different Redis instances at cold boot.
    """
    _ = leader_node_id
    endpoints = sorted(node_endpoints, key=lambda x: x[0])
    discovered = discover_master_from_redis(endpoints)
    if discovered:
        return discovered
    return endpoints[0][1]


def get_sentinel_monitored_master(local_tunnel_ip: str) -> str | None:
    """Ask the local Sentinel which IP it currently monitors as `redis-master`."""
    try:
        result = subprocess.run(
            [
                REDIS_CLI,
                "-h",
                local_tunnel_ip,
                "-p",
                str(REDIS_SENTINEL_PORT),
                "SENTINEL",
                "get-master-addr-by-name",
                SENTINEL_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode != 0:
            return None
        lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        if not lines:
            return None
        return normalize_addr(lines[0])
    except Exception:
        return None


def write_sentinel_config(local_tunnel_ip: str, master_ip: str, quorum: int) -> None:
    """Write Redis Sentinel configuration file (host copy and container /data copy)."""
    ensure_redis_directories()
    SENTINEL_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    cfg_lines = [
        "daemonize no",
        "supervised no",
        "pidfile /var/run/redis-sentinel.pid",
        "logfile /data/sentinel.log",
        f"port {REDIS_SENTINEL_PORT}",
        f"bind {local_tunnel_ip}",
        "protected-mode no",
        f"dir /data",
        f"sentinel monitor {SENTINEL_NAME} {master_ip} {REDIS_PORT} {quorum}",
        # Cold-boot tolerance: Redis containers can take 10–20s to accept connections,
        # and a stricter window caused premature s_down/o_down on every fresh cluster.
        f"sentinel down-after-milliseconds {SENTINEL_NAME} 15000",
        f"sentinel failover-timeout {SENTINEL_NAME} 180000",
        f"sentinel parallel-syncs {SENTINEL_NAME} 1",
        f"sentinel announce-ip {local_tunnel_ip}",
        f"sentinel announce-port {REDIS_SENTINEL_PORT}",
    ]
    content = "\n".join(cfg_lines) + "\n"
    SENTINEL_CONFIG_FILE.write_text(content)
    SENTINEL_CONFIG_IN_DATA.write_text(content)

    try:
        SENTINEL_CONFIG_FILE.chmod(0o644)
        SENTINEL_CONFIG_IN_DATA.chmod(0o644)
    except PermissionError:
        pass
    try:
        redis_user = pwd.getpwnam("redis")
        os.chown(SENTINEL_CONFIG_FILE, redis_user.pw_uid, redis_user.pw_gid)
    except (KeyError, PermissionError):
        pass
    # Container runs as valkey (999); must be able to read and write sentinel.conf in /data
    try:
        os.chown(SENTINEL_CONFIG_IN_DATA, VALKEY_UID, VALKEY_GID)
    except PermissionError:
        pass


def wait_for_sentinel_ready(local_tunnel_ip: str, timeout_sec: int = 60) -> bool:
    """Wait for Redis Sentinel to become ready."""
    start_time = time.time()
    last_error = None

    while time.time() - start_time < timeout_sec:
        try:
            result = subprocess.run(
                [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_SENTINEL_PORT), "ping"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0 and result.stdout.strip() == "PONG":
                return True

            last_error = f"Sentinel returned: {result.stdout.strip()}"
        except subprocess.TimeoutExpired:
            last_error = "Sentinel ping timed out"
        except Exception as e:
            last_error = f"Sentinel ping error: {str(e)}"

        time.sleep(3)

    print(f"[!] Sentinel did not become ready within {timeout_sec}s. Last error: {last_error}", file=sys.stderr)
    return False


def is_sentinel_running(container_name: str) -> tuple[bool, str | None]:
    """Check if Redis Sentinel is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            [PODMAN_BIN, "inspect", "-f", "{{.State.Running}}", container_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False, f"Container inspect failed: {result.stderr.strip() or result.stdout.strip()}"
        is_active = result.stdout.strip().lower() == "true"
        return is_active, None if is_active else "ValKey Sentinel container is not running"
    except subprocess.TimeoutExpired:
        return False, "Sentinel container inspect timed out"
    except Exception as e:
        return False, f"Failed to check sentinel container status: {str(e)}"


@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize Redis Sentinel: install packages."""
    try:
        if not is_sentinel_available():
            install_redis()
        else:
            ensure_redis_directories()

        Path("/var/log/redis").mkdir(parents=True, exist_ok=True)
        # Best-effort cleanup of legacy host Redis Sentinel service.
        subprocess.run(["systemctl", "stop", "redis-sentinel"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "redis-sentinel"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply Redis Sentinel configuration."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])
    cluster = state_json.get("cluster", {})
    cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
    container_name = get_container_name(cluster_id)

    if len(cluster_nodes) < 1:
        return PluginOutput(
            status='postponed',
            error_message=f'Redis Sentinel requires at least 1 node, currently have {len(cluster_nodes)}',
            local_state=local_state
        )

    if len(cluster_nodes) > REDIS_SENTINEL_MAX_NODES:
        return PluginOutput(
            status='postponed',
            error_message=f'Redis Sentinel supports up to {REDIS_SENTINEL_MAX_NODES} nodes, got {len(cluster_nodes)}',
            local_state=local_state
        )

    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all sentinel nodes',
            local_state=local_state
        )

    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status='error',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state
        )

    redis_cluster_nodes = state_json.get("redisClusterNodes", [])
    redis_wg_props = state_json.get("redisWgNodeProperties", [])
    redis_cluster = state_json.get("redisCluster", {})
    if len(redis_cluster_nodes) < 1:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for Redis cluster nodes to be created',
            local_state=local_state
        )

    if len(redis_cluster_nodes) > REDIS_MAX_NODES:
        return PluginOutput(
            status='postponed',
            error_message=f'Redis supports up to {REDIS_MAX_NODES} nodes, got {len(redis_cluster_nodes)}',
            local_state=local_state
        )

    if not check_all_nodes_have_wg(redis_cluster_nodes, redis_wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on Redis nodes',
            local_state=local_state
        )

    leader_node_id = redis_cluster.get("leader_node")
    node_endpoints = build_node_endpoints(redis_cluster_nodes, redis_wg_props)
    if not node_endpoints:
        return PluginOutput(
            status='postponed',
            error_message='No Redis nodes with WireGuard tunnel IPs found',
            local_state=local_state
        )

    node_endpoints.sort(key=lambda x: x[0])
    master_ip = choose_master_ip(node_endpoints, leader_node_id)

    sentinel_props = state_json.get("sentinelNodeProperties", [])
    ready_sentinels = count_ready_sentinels(sentinel_props)
    quorum = calculate_sentinel_quorum(ready_sentinels, len(cluster_nodes))

    try:
        write_sentinel_config(local_tunnel_ip, master_ip, quorum)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to write sentinel config: {str(e)}', local_state=local_state)

    needs_restart = False
    sentinel_running, _ = is_sentinel_running(container_name)
    if not sentinel_running:
        needs_restart = True
    if (
        local_state.get("sentinel_quorum") != quorum
        or normalize_addr(local_state.get("sentinel_master_ip")) != normalize_addr(master_ip)
    ):
        needs_restart = True

    # Reconcile against Sentinel's live view even when our `local_state` matches
    # what we last wrote. If sentinel.conf was rewritten by a previous apply but
    # the running container is still pointing at a stale master (e.g. it was
    # written before we knew which Redis was real master, or persisted state
    # diverged across restarts), force a restart so it picks up the fresh config.
    if not needs_restart and sentinel_running:
        monitored = get_sentinel_monitored_master(local_tunnel_ip)
        if monitored and monitored != normalize_addr(master_ip):
            print(
                f"[!] Sentinel monitors {monitored!r} but live Redis master is "
                f"{normalize_addr(master_ip)!r}; restarting sentinel to reconcile",
                file=sys.stderr,
            )
            needs_restart = True

    if needs_restart:
        try:
            run_valkey_sentinel_container(container_name)
        except Exception as e:
            return PluginOutput(status='error', error_message=f'Failed to start ValKey Sentinel container: {str(e)}', local_state=local_state)

        sentinel_ready = wait_for_sentinel_ready(local_tunnel_ip, timeout_sec=60)
        if not sentinel_ready:
            return PluginOutput(
                status='postponed',
                error_message='Redis Sentinel did not become ready within timeout',
                local_state=local_state
            )

    node_properties = {
        "redis_sentinel_node_ready": "true",
        "redis_sentinel_quorum": str(quorum),
        "redis_sentinel_master_ip": master_ip,
    }
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    node_properties.update(
        build_image_evidence_props(
            prefix="redis_sentinel",
            image_ref=VALKEY_IMAGE,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )
    local_state["sentinel_quorum"] = quorum
    local_state["sentinel_master_ip"] = master_ip
    local_state["sentinel_container_name"] = container_name

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        local_state=local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check Redis Sentinel health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}
    cluster = state_json.get("cluster", {}) if isinstance(state_json, dict) else {}
    cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
    container_name = local_state.get("sentinel_container_name") or get_container_name(cluster_id)

    sentinel_running, sentinel_error = is_sentinel_running(container_name)
    if not sentinel_running:
        err = (sentinel_error or "").lower()
        not_found = "no such container" in err or "no such object" in err
        if not_found:
            return PluginOutput(
                status='postponed',
                error_message=sentinel_error or 'Redis Sentinel is not running',
                local_state=local_state,
            )
        return PluginOutput(
            status='error',
            error_message=sentinel_error or 'Failed to check Redis Sentinel container status',
            local_state=local_state,
        )

    wg_props = state_json.get("wgNodeProperties", []) if isinstance(state_json, dict) else []
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(status='postponed', error_message='No tunnel IP available', local_state=local_state)

    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_SENTINEL_PORT), "ping"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode != 0 or result.stdout.strip() != "PONG":
            return PluginOutput(status='postponed', error_message='Redis Sentinel is not responding', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='postponed', error_message=f'Failed to ping Redis Sentinel: {e}', local_state=local_state)

    # Detect a stale monitored master so the provisioner schedules a re-apply (after
    # 3 consecutive `error` results swarm-node forces apply to run). If Sentinel
    # monitors an IP that is not the live Redis master, leaving it alone keeps
    # gatekeeper-s3/harbor stuck: they query Sentinel for redis-master, get an
    # s_down,o_down replica, and refuse to start. Apply (with INFO-based master
    # discovery) reconciles by restarting the container with a fresh config.
    redis_cluster_nodes = (
        state_json.get("redisClusterNodes", []) if isinstance(state_json, dict) else []
    )
    redis_wg_props = (
        state_json.get("redisWgNodeProperties", []) if isinstance(state_json, dict) else []
    )
    redis_endpoints = build_node_endpoints(redis_cluster_nodes, redis_wg_props)
    monitored_master = get_sentinel_monitored_master(local_tunnel_ip)
    live_master = discover_master_from_redis(redis_endpoints) if redis_endpoints else None
    if (
        monitored_master
        and live_master
        and normalize_addr(monitored_master) != normalize_addr(live_master)
    ):
        return PluginOutput(
            status='error',
            error_message=(
                f'Sentinel monitors {monitored_master} but live Redis master is '
                f'{live_master}; apply needs to rewrite sentinel.conf'
            ),
            local_state=local_state,
        )

    node_properties = {
        "redis_sentinel_node_ready": "true",
    }
    return PluginOutput(status='completed', node_properties=node_properties, local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal (graceful shutdown)."""
    local_state = input_data.local_state or {}
    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy Redis Sentinel installation and clean up."""
    try:
        state_json = input_data.state or {}
        cluster = state_json.get("cluster", {}) if isinstance(state_json, dict) else {}
        cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
        local_state = input_data.local_state or {}
        container_name = local_state.get("sentinel_container_name") or get_container_name(cluster_id)

        subprocess.run(["systemctl", "stop", "redis-sentinel"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "redis-sentinel"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        stop_and_remove_container(container_name)

        if SENTINEL_CONFIG_FILE.exists():
            SENTINEL_CONFIG_FILE.unlink()
        if SENTINEL_CONFIG_IN_DATA.exists():
            SENTINEL_CONFIG_IN_DATA.unlink()

        node_properties = {
            "redis_sentinel_node_ready": None,
            "redis_sentinel_quorum": None,
            "redis_sentinel_master_ip": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy Redis Sentinel: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
