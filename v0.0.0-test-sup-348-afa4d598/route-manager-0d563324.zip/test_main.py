#!/usr/bin/env python3
"""Unit tests for route-manager/main.py — SUP-206 operator-supplied material.

Covers the two values the fabric cannot mint for itself and used to receive over guest
ssh: the exposed domain's TLS cert (openresty's auto-ssl store) and the metrics scrape
token (swarm-cloud-api's /v1/metrics guard).

    cd services/route-manager && python3 -m unittest test_main -v
"""

import contextlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    sys.modules["provision_plugin_sdk"] = stub

if "redis" not in sys.modules:
    # main imports `redis` / `redis.sentinel` even when it is handed a client. These tests
    # always hand it one; the stubs only have to make the reconnect path fail fast instead
    # of importing the real driver, which is not a dev-host dependency.
    redis_stub = type(sys)("redis")
    sentinel_stub = type(sys)("redis.sentinel")

    class _Unavailable:
        def __init__(self, *args, **kwargs):
            raise RuntimeError("no redis in the test environment")

    redis_stub.Redis = _Unavailable
    sentinel_stub.Sentinel = _Unavailable
    redis_stub.sentinel = sentinel_stub
    sys.modules["redis"] = redis_stub
    sys.modules["redis.sentinel"] = sentinel_stub

import main  # noqa: E402

DOMAIN = "cloud-x.swarm.example.dev"


@contextlib.contextmanager
def _no_retry_delay():
    """Collapse _execute_with_redis's backoff so the failure paths run instantly."""
    original = main.time.sleep
    main.time.sleep = lambda _seconds: None
    try:
        yield
    finally:
        main.time.sleep = original


def _self_signed(days: int = 30) -> tuple[str, str]:
    """A throwaway cert/key pair, generated so no private key is committed."""
    with tempfile.TemporaryDirectory() as tmp:
        crt, key = Path(tmp) / "c.pem", Path(tmp) / "k.pem"
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(key), "-out", str(crt),
                "-days", str(days), "-subj", f"/CN={DOMAIN}",
            ],
            check=True,
            capture_output=True,
        )
        return crt.read_text(), key.read_text()


class _FakeRedis:
    """Records SETs; `fail_on` makes the write raise so retry/postpone paths are reachable."""

    def __init__(self, fail_on: str | None = None):
        self.values: dict[str, str] = {}
        self.fail_on = fail_on

    def set(self, key, value):
        if self.fail_on is not None and self.fail_on in key:
            raise RuntimeError("redis is down")
        self.values[key] = value


def _state(**overrides):
    state = {
        "swarmDomain": DOMAIN,
        "globalId": "abc123",
        "baseDomain": "swarm.example.dev",
        "redisSentinelNodes": [{"id": "s:n1", "node_id": "n1", "ip": "10.1.1.1"}],
        "swarmSecrets": [],
    }
    state.update(overrides)
    return state


class PemHelperTests(unittest.TestCase):
    def test_split_pem_certificates_returns_leaf_first(self):
        leaf, _ = _self_signed()
        intermediate, _ = _self_signed()
        blocks = main.split_pem_certificates(leaf + intermediate)
        self.assertEqual(len(blocks), 2)
        self.assertEqual(blocks[0].strip(), leaf.strip())

    def test_split_pem_certificates_ignores_trailing_garbage(self):
        leaf, _ = _self_signed()
        self.assertEqual(len(main.split_pem_certificates(leaf + "-----BEGIN CERTIFICATE-----\n")), 1)

    def test_split_pem_certificates_on_non_pem(self):
        self.assertEqual(main.split_pem_certificates("not a cert"), [])

    def test_cert_not_after_epoch_reads_openssl_date(self):
        leaf, _ = _self_signed(days=30)
        expiry = main.cert_not_after_epoch(leaf)
        # 30 days out, allowing a day of slack either side of openssl's rounding.
        self.assertGreater(expiry, 0)
        self.assertAlmostEqual(expiry, main.datetime.now(main.timezone.utc).timestamp() + 30 * 86400, delta=86400)

    def test_cert_not_after_epoch_is_zero_for_garbage(self):
        # A parse failure must not be fatal: auto-ssl treats expiry=0 as "due for renewal",
        # which is strictly better than refusing to serve a valid cert.
        self.assertEqual(main.cert_not_after_epoch("not a cert"), 0)


class AutoSslPayloadTests(unittest.TestCase):
    def test_payload_carries_the_fields_auto_ssl_reads(self):
        leaf, key = _self_signed()
        intermediate, _ = _self_signed()
        payload = main.build_auto_ssl_payload(leaf + intermediate, key)

        self.assertEqual(set(payload), {"fullchain_pem", "privkey_pem", "cert_pem", "expiry"})
        self.assertEqual(payload["fullchain_pem"], leaf + intermediate)
        self.assertEqual(payload["privkey_pem"], key)
        # cert_pem is the LEAF only — the evidence JWS is fingerprinted against it.
        self.assertEqual(payload["cert_pem"].strip(), leaf.strip())
        self.assertNotIn(intermediate.strip(), payload["cert_pem"])
        self.assertGreater(payload["expiry"], 0)

    def test_payload_appends_missing_trailing_newline(self):
        leaf, key = _self_signed()
        payload = main.build_auto_ssl_payload(leaf.rstrip("\n"), key.rstrip("\n"))
        self.assertTrue(payload["fullchain_pem"].endswith("\n"))
        self.assertTrue(payload["privkey_pem"].endswith("\n"))

    def test_payload_rejects_material_that_is_not_a_cert(self):
        _, key = _self_signed()
        with self.assertRaises(ValueError):
            main.build_auto_ssl_payload("junk", key)

    def test_payload_rejects_material_that_is_not_a_key(self):
        leaf, _ = _self_signed()
        with self.assertRaises(ValueError):
            main.build_auto_ssl_payload(leaf, "junk")

    def test_auto_ssl_key_is_the_one_openresty_reads(self):
        self.assertEqual(main.build_auto_ssl_key(DOMAIN), f"auto-ssl:{DOMAIN}:latest")


class SeededValueResolutionTests(unittest.TestCase):
    def test_swarm_secret_wins_over_provider_config_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file")
            state = _state(swarmSecrets=[{"id": "metrics_token", "value": "from-secret"}])
            self.assertEqual(
                main.resolve_seeded_value(
                    state, main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-secret",
            )

    def test_provider_config_file_is_the_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file\n")
            self.assertEqual(
                main.resolve_seeded_value(
                    _state(), main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-file",
            )

    def test_missing_everywhere_is_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(
                main.resolve_seeded_value(
                    _state(), main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                )
            )

    def test_blank_secret_falls_through_to_the_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file")
            state = _state(swarmSecrets=[{"id": "metrics_token", "value": "   "}])
            self.assertEqual(
                main.resolve_seeded_value(
                    state, main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-file",
            )


class SyncExposedTlsCertTests(unittest.TestCase):
    def test_publishes_cert_from_provider_config(self):
        leaf, key = _self_signed()
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text(leaf)
            (Path(tmp) / main.EXPOSED_TLS_KEY_FILE).write_text(key)
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok, err)
        self.assertIsNone(err)
        self.assertIsNotNone(fingerprint)
        stored = json.loads(redis_client.values[f"auto-ssl:{DOMAIN}:latest"])
        self.assertEqual(stored["fullchain_pem"], leaf)
        self.assertEqual(stored["privkey_pem"], key)

    def test_publishes_cert_from_swarm_secrets(self):
        leaf, key = _self_signed()
        redis_client = _FakeRedis()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, _ = main.sync_exposed_tls_cert(
                state, redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok, err)
        self.assertIn(f"auto-ssl:{DOMAIN}:latest", redis_client.values)

    def test_no_material_is_not_an_error(self):
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok)
        self.assertIsNone(err)
        self.assertIsNone(fingerprint)
        self.assertEqual(redis_client.values, {})

    def test_half_supplied_material_is_an_error(self):
        leaf, _ = _self_signed()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text(leaf)
            ok, err, _ = main.sync_exposed_tls_cert(
                _state(), redis_client=_FakeRedis(), provider_config_dir=Path(tmp)
            )

        self.assertFalse(ok)
        self.assertIn("exposed_tls_key", err)

    def test_unusable_material_is_an_error_not_a_crash(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text("junk")
            (Path(tmp) / main.EXPOSED_TLS_KEY_FILE).write_text("junk")
            ok, err, _ = main.sync_exposed_tls_cert(
                _state(), redis_client=_FakeRedis(), provider_config_dir=Path(tmp)
            )

        self.assertFalse(ok)
        self.assertIn("unusable", err)

    def test_missing_swarm_domain_is_an_error_not_a_crash(self):
        leaf, key = _self_signed()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        del state["swarmDomain"]
        ok, err, _ = main.sync_exposed_tls_cert(state, redis_client=_FakeRedis())
        self.assertFalse(ok)
        self.assertIn("swarmDomain", err)

    def test_redis_failure_is_reported(self):
        leaf, key = _self_signed()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        with _no_retry_delay():
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                state, redis_client=_FakeRedis(fail_on="auto-ssl")
            )
        self.assertFalse(ok)
        self.assertTrue(err)
        # The fingerprint is still reported so the failure names the cert it was handling.
        self.assertIsNotNone(fingerprint)


class SyncMetricsTokenTests(unittest.TestCase):
    def test_publishes_token_to_the_key_the_api_guard_reads(self):
        redis_client = _FakeRedis()
        state = _state(swarmSecrets=[{"id": "metrics_token", "value": "deadbeef"}])
        ok, err, published = main.sync_metrics_token(state, redis_client=redis_client)

        self.assertTrue(ok, err)
        self.assertTrue(published)
        self.assertEqual(redis_client.values["swarm-metrics-token"], "deadbeef")

    def test_no_token_is_not_an_error(self):
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, published = main.sync_metrics_token(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok)
        self.assertIsNone(err)
        self.assertFalse(published)
        self.assertEqual(redis_client.values, {})

    def test_redis_failure_is_reported(self):
        state = _state(swarmSecrets=[{"id": "metrics_token", "value": "deadbeef"}])
        with _no_retry_delay():
            ok, err, published = main.sync_metrics_token(
                state, redis_client=_FakeRedis(fail_on="swarm-metrics-token")
            )
        self.assertFalse(ok)
        self.assertFalse(published)
        self.assertTrue(err)


class RedactStateTests(unittest.TestCase):
    def test_secret_values_never_reach_the_log(self):
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_key", "value": "-----BEGIN PRIVATE KEY-----"},
                {"id": "metrics_token", "value": "deadbeef"},
            ]
        )
        dumped = json.dumps(main.redact_state(state))
        self.assertNotIn("deadbeef", dumped)
        self.assertNotIn("BEGIN PRIVATE KEY", dumped)
        # ids survive, so the log still says WHICH material the cloud was given.
        self.assertIn("exposed_tls_key", dumped)
        self.assertIn(DOMAIN, dumped)

    def test_non_secret_state_passes_through_untouched(self):
        state = _state()
        self.assertEqual(main.redact_state(state)["redisSentinelNodes"], state["redisSentinelNodes"])


if __name__ == "__main__":
    unittest.main()
