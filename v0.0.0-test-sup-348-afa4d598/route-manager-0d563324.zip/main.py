#!/usr/bin/env python3
"""
Route Manager Service

Centralized service for managing OpenResty routes in Redis.
Collects information about all running services and updates their routes.
"""

import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from provision_plugin_sdk import PluginInput, PluginOutput, ProvisionPlugin

# Service configuration
ROUTE_KEY_PREFIX = "manual-routes"
REDIS_PORT = 6379
REDIS_SENTINEL_PORT = 26379
REDIS_MASTER_NAME = "redis-master"

# Service routes configuration (matches plugin_input.state keys)
SERVICE_ROUTES: Dict[str, Dict[str, Any]] = {
    "auth-service": {
        "nodes_key": "authServiceNodes",
        "paths": ["/api/auth", "/auth"],
        "port": 3002,
    },
    "swarm-cloud-api": {
        "nodes_key": "swarmCloudApiNodes",
        # `/api/v1` is the stable API external products integrate against, and it has to be listed
        # explicitly: the dashboard owns `/` on this domain, and routing is longest-prefix, so
        # without an entry every stable-API call lands on the dashboard as a 404 page.
        "paths": ["/graphql", "/v1", "/api/v1"],
        "port": 3001,
    },
    "swarm-cloud-ui": {
        "nodes_key": "swarmCloudUiNodes",
        "paths": ["/api/config", "/"],
        "port": 3000,
    },
    "swarm-gatekeeper-s3": {
        "nodes_key": "swarmGatekeeperS3Nodes",
        "paths": ["/"],
        "port": 9100,
        "subdomain": "gatekeeper-s3",
        "client_max_body_size": "0",
    },
    "swarm-gatekeeper-harbor": {
        "nodes_key": "swarmGatekeeperHarborNodes",
        "paths": ["/"],
        "port": 9110,
        "subdomain": "gatekeeper-harbor",
        "client_max_body_size": "0",
    },
    # api.<zone> subdomain — direct access to swarm-cloud-api
    "api:auth-service": {
        "nodes_key": "authServiceNodes",
        "paths": ["/api/auth", "/auth"],
        "port": 3002,
        "subdomain": "api",
    },
    "api:swarm-cloud-api": {
        "nodes_key": "swarmCloudApiNodes",
        "paths": ["/graphql", "/v1", "/"],
        "port": 3001,
        "subdomain": "api",
    },
}

PASSTHROUGH_ROUTES: Dict[str, Dict[str, Any]] = {
    "pki_authority": {
        "nodes_key": "pkiAuthorityNodes",
        "domain_key": "pkiDomain",
        "port": 9443,
    },
}

# SUP-206: the exposed domain's TLS cert and the metrics scrape token are both minted
# OUTSIDE the fabric -- by the operator host that owns the public DNS zone and runs
# certbot -- and have to end up in the cloud's own Redis: openresty's auto-ssl store is
# what serves the cert, and swarm-cloud-api's /v1/metrics guard compares the token.
# They used to be pushed in post-boot by ssh-ing into a guest, which only ever worked on
# debug sp-vm images; release images ship no sshd, so every release cloud served
# openresty's self-signed CN=fallback cert (and rejected every scrape). Both now ride the
# provider-config / SwarmDB-secret channel that already carries the auth-service OIDC
# fragment, and this plugin publishes them into Redis from inside the fabric.
AUTO_SSL_KEY_PREFIX = "auto-ssl"
METRICS_TOKEN_KEY = "swarm-metrics-token"

# Provider config as mounted inside the sp-vm guest -- the same channel the pki-authority
# and openresty plugins already read (/sp/swarm/config.yaml, /sp/swarm/openresty.yaml).
PROVIDER_CONFIG_DIR = Path("/sp/swarm")
EXPOSED_TLS_CERT_FILE = "exposed-tls.crt"
EXPOSED_TLS_KEY_FILE = "exposed-tls.key"
METRICS_TOKEN_FILE = "metrics-token"

# SwarmDB secret ids, preferred over the provider-config files: they replicate to nodes
# that join later and let a future sp-vm build seed them in 00-initialize-secrets.sh
# without a services change.
EXPOSED_TLS_CERT_SECRET = "exposed_tls_cert"
EXPOSED_TLS_KEY_SECRET = "exposed_tls_key"
METRICS_TOKEN_SECRET = "metrics_token"

# Keys of the stateExpr output that carry secret material and must never be logged.
SECRET_STATE_KEYS = ("swarmSecrets",)

plugin = ProvisionPlugin()


def _log(msg: str) -> None:
    print(f"[route-manager] {msg}", file=sys.stderr, flush=True)


def _log_error(msg: str, exc: Exception | None = None) -> None:
    if exc is None:
        _log(f"[!] {msg}")
    else:
        _log(f"[!] {msg}: {exc}")


def check_state_dependencies(state_json: Dict[str, Any]) -> Optional[str]:
    """Verify that required state dependencies are present."""
    if not isinstance(state_json.get("redisSentinelNodes"), list):
        return "redisSentinelNodes missing or invalid"

    if not state_json.get("redisSentinelNodes"):
        return "redisSentinelNodes is empty"

    swarm_domain = state_json.get("swarmDomain")
    if not isinstance(swarm_domain, str) or not swarm_domain.strip():
        return "swarmDomain missing or empty"

    for passthrough_name, config in PASSTHROUGH_ROUTES.items():
        domain_key = config.get("domain_key")
        if not isinstance(domain_key, str) or not domain_key.strip():
            return f"{passthrough_name} domain_key missing in PASSTHROUGH_ROUTES"

        route_domain = state_json.get(domain_key)
        if not isinstance(route_domain, str) or not route_domain.strip():
            return f"{domain_key} missing or empty"

    global_id = state_json.get("globalId")
    if not isinstance(global_id, str) or not global_id.strip():
        return "globalId missing or empty"

    base_domain = state_json.get("baseDomain")
    if not isinstance(base_domain, str) or not base_domain.strip():
        return "baseDomain missing or empty"

    return None


def get_redis_sentinel_connection_info(state_json: Dict[str, Any]) -> List[tuple[str, int]]:
    """Build Redis Sentinel endpoints from state_json."""
    nodes = state_json.get("redisSentinelNodes")
    if not isinstance(nodes, list):
        return []

    endpoints: List[tuple[str, int]] = []
    for node in nodes:
        ip = node.get("ip")
        if ip:
            endpoints.append((ip, REDIS_SENTINEL_PORT))

    return sorted(set(endpoints))


def get_redis_master_endpoint(state_json: Dict[str, Any]) -> tuple[Optional[tuple[str, int]], Optional[str]]:
    """Resolve Redis master from Sentinel."""
    sentinel_endpoints = get_redis_sentinel_connection_info(state_json)
    if not sentinel_endpoints:
        return None, "No Redis Sentinel endpoints available"

    try:
        from redis.sentinel import Sentinel
    except ImportError as e:
        return None, f"redis package not available: {e}"

    last_error: Optional[str] = None
    for host, port in sentinel_endpoints:
        try:
            sentinel = Sentinel([(host, port)], socket_connect_timeout=2)
            master_addr = sentinel.discover_master(REDIS_MASTER_NAME)
            return master_addr, None
        except Exception as e:
            last_error = f"Failed to connect to sentinel {host}:{port}: {e}"
            _log_error(last_error)
            continue

    return None, last_error


def get_route_domain(state_json: Dict[str, Any]) -> str:
    """Get route domain from state."""
    swarm_domain = state_json.get("swarmDomain")
    if not isinstance(swarm_domain, str) or not swarm_domain.strip():
        raise ValueError("swarmDomain missing or empty")
    return swarm_domain.strip()


def get_route_domain_by_key(state_json: Dict[str, Any], domain_key: str) -> str:
    """Get route domain from state by key."""
    route_domain = state_json.get(domain_key)
    if not isinstance(route_domain, str) or not route_domain.strip():
        raise ValueError(f"{domain_key} missing or empty")
    return route_domain.strip()


def get_subdomain_zone(state_json: Dict[str, Any]) -> str:
    """Get the canonical subdomain zone: <globalId>.<baseDomain>."""
    global_id = state_json.get("globalId")
    if not isinstance(global_id, str) or not global_id.strip():
        raise ValueError("globalId missing or empty")

    base_domain = state_json.get("baseDomain")
    if not isinstance(base_domain, str) or not base_domain.strip():
        raise ValueError("baseDomain missing or empty")

    return f"{global_id.strip()}.{base_domain.strip()}"


def _connect_with_retry(
    state_json: Dict[str, Any],
    attempts: int = 20,
    delay_seconds: float = 1.0,
) -> tuple[Optional["Any"], Optional[str]]:
    """Establish a connection to Redis master with retry. Returns (client, error)."""
    try:
        import redis
    except ImportError as e:
        return None, f"redis package not available: {e}"

    last_err: Optional[str] = None
    for attempt_no in range(1, max(1, attempts) + 1):
        master_endpoint, resolve_err = get_redis_master_endpoint(state_json)
        if not master_endpoint:
            last_err = resolve_err or "Failed to resolve master"
            if attempt_no < attempts:
                time.sleep(delay_seconds)
            continue

        master_host, master_port = master_endpoint
        try:
            r = redis.Redis(
                host=master_host,
                port=master_port,
                socket_connect_timeout=5,
                socket_timeout=5,
                decode_responses=True,
            )
            r.ping()
            _log(f"Redis connected: {master_host}:{master_port}")
            return r, None
        except Exception as e:
            last_err = f"Cannot connect to Redis master {master_host}:{master_port}: {e}"
            _log_error(last_err)
            if attempt_no < attempts:
                time.sleep(delay_seconds)

    return None, last_err or "Failed to connect to Redis after all attempts"


def _execute_with_redis(
    state_json: Dict[str, Any],
    operation: "Any",  # Callable[[redis.Redis], None] — raises on failure
    context: str,
    attempts: int = 20,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Run `operation(client)` with retry and reconnect on failure.

    If `redis_client` is provided, it is used for the first attempt.
    On any failure the client is reset and the next attempt reconnects.
    Returns (True, None) on success, (False, error_message) after all attempts.
    """
    try:
        import redis
    except ImportError as e:
        return False, f"redis package not available: {e}"

    last_err: Optional[str] = None
    r = redis_client  # start with provided client; None triggers a fresh connect

    for attempt_no in range(1, max(1, attempts) + 1):
        if r is None:
            master_endpoint, resolve_err = get_redis_master_endpoint(state_json)
            if not master_endpoint:
                last_err = resolve_err or "Failed to resolve master"
                if attempt_no < attempts:
                    time.sleep(delay_seconds)
                continue

            master_host, master_port = master_endpoint
            try:
                r = redis.Redis(
                    host=master_host,
                    port=master_port,
                    socket_connect_timeout=5,
                    socket_timeout=5,
                    decode_responses=True,
                )
                r.ping()
            except Exception as e:
                r = None
                last_err = f"Cannot connect to Redis master {master_host}:{master_port}: {e}"
                _log_error(last_err)
                if attempt_no < attempts:
                    time.sleep(delay_seconds)
                continue

        try:
            operation(r)
            return True, None
        except Exception as e:
            r = None  # reset — next attempt will reconnect
            last_err = f"{context}: {e}"
            _log_error(last_err)
            if attempt_no < attempts:
                time.sleep(delay_seconds)

    return False, last_err or f"{context} after all attempts"


def build_route_key(route_domain: str) -> str:
    """Build Redis key for route."""
    return f"{ROUTE_KEY_PREFIX}:{route_domain}"


def build_service_targets(service_nodes: List[Dict[str, Any]], port: int) -> List[Dict[str, Any]]:
    """Build target URLs for a service."""
    urls: set[str] = set()
    for node in service_nodes:
        ip = node.get("ip")
        if isinstance(ip, str) and ip.strip():
            urls.add(f"http://{ip.strip()}:{port}")
    return [{"url": url, "weight": 1} for url in sorted(urls)]


def _is_node_ready(node: Any) -> bool:
    if not isinstance(node, dict):
        return False
    ready = node.get("ready")
    if isinstance(ready, bool):
        return ready
    if isinstance(ready, (int, float)):
        return ready != 0
    if isinstance(ready, str):
        return ready.strip().lower() in {"true", "1", "yes", "y"}
    return False


def get_ready_nodes(state_json: Dict[str, Any], nodes_key: str) -> List[Dict[str, Any]]:
    nodes = state_json.get(nodes_key)
    if not isinstance(nodes, list):
        return []
    ready_nodes: List[Dict[str, Any]] = [n for n in nodes if _is_node_ready(n)]
    # Stable order for deterministic route json
    ready_nodes.sort(key=lambda n: str(n.get("ip") or ""))
    return ready_nodes


def _as_target_map(targets: Any) -> Dict[str, Dict[str, Any]]:
    """Convert targets list to URL->target mapping."""
    result: Dict[str, Dict[str, Any]] = {}
    if not isinstance(targets, list):
        return result

    for t in targets:
        if not isinstance(t, dict):
            continue
        url = t.get("url")
        if isinstance(url, str) and url:
            result[url] = t

    return result


def _merge_targets(existing_targets: Any, desired_targets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Merge existing and desired targets, preserving order and removing duplicates."""
    if not desired_targets:
        return []

    desired_map = _as_target_map(desired_targets)
    merged: List[Dict[str, Any]] = []
    seen_urls: set[str] = set()

    # Keep existing order for targets that are still desired
    if isinstance(existing_targets, list):
        for t in existing_targets:
            if not isinstance(t, dict):
                continue
            url = t.get("url")
            if not isinstance(url, str) or not url:
                continue
            if url in desired_map and url not in seen_urls:
                merged.append(desired_map[url])
                seen_urls.add(url)

    # Add missing desired targets in desired order
    for t in desired_targets:
        if not isinstance(t, dict):
            continue
        url = t.get("url")
        if isinstance(url, str) and url and url not in seen_urls:
            merged.append(t)
            seen_urls.add(url)

    return merged


def merge_route_obj(existing: Optional[Dict[str, Any]], desired: Dict[str, Any]) -> Dict[str, Any]:
    """Merge existing route object with desired changes."""
    base: Dict[str, Any] = dict(existing) if isinstance(existing, dict) else {}

    # Internal helper key, never persist to Redis
    desired_paths = desired.get("_desired_paths")

    desired_targets: List[Dict[str, Any]] = []
    if isinstance(desired.get("targets"), list):
        desired_targets = desired["targets"]
    elif isinstance(desired.get("path_routes"), list):
        for pr in desired["path_routes"]:
            if isinstance(pr, dict) and isinstance(pr.get("targets"), list):
                desired_targets = pr["targets"]
                break

    # Do not modify top-level domain targets
    existing_path_routes = base.get("path_routes") if isinstance(base.get("path_routes"), list) else []

    if not (isinstance(desired_paths, list) and all(isinstance(p, str) and p for p in desired_paths)):
        raise ValueError("_desired_paths must be a non-empty list of strings")

    found_paths: set[str] = set()
    merged_path_routes: List[Any] = []
    seen_existing_paths: set[str] = set()

    # Update existing path routes
    for item in existing_path_routes:
        if not isinstance(item, dict) or "path" not in item:
            merged_path_routes.append(item)
            continue

        path = item["path"]
        if path in seen_existing_paths:
            continue
        seen_existing_paths.add(path)

        if path in desired_paths:
            found_paths.add(path)
            # If service has no ready nodes, we must not write empty targets.
            # Instead, remove route entries for these paths.
            if not desired_targets:
                continue

            existing_targets = item.get("targets")
            new_targets = _merge_targets(existing_targets, desired_targets)
            if not new_targets:
                continue

            merged_item = dict(item)
            merged_item["targets"] = new_targets
            merged_path_routes.append(merged_item)
        else:
            merged_path_routes.append(item)

    # Add new path routes
    if desired_targets:
        for path in desired_paths:
            if path not in found_paths:
                merged_path_routes.append({"path": path, "targets": desired_targets})

    base["path_routes"] = merged_path_routes
    if "client_max_body_size" in desired:
        base["client_max_body_size"] = desired["client_max_body_size"]
    else:
        base.pop("client_max_body_size", None)
    return base


def _extract_targets_urls_for_paths(route_obj: Any, paths: List[str]) -> Dict[str, List[str]]:
    """Return mapping path -> list of target urls (may include duplicates if present)."""
    result: Dict[str, List[str]] = {p: [] for p in paths if isinstance(p, str) and p}
    if not isinstance(route_obj, dict):
        return result
    path_routes = route_obj.get("path_routes")
    if not isinstance(path_routes, list):
        return result

    wanted = set(result.keys())
    for item in path_routes:
        if not isinstance(item, dict):
            continue
        path = item.get("path")
        if path not in wanted:
            continue
        targets = item.get("targets")
        if not isinstance(targets, list):
            continue
        for t in targets:
            if not isinstance(t, dict):
                continue
            url = t.get("url")
            if isinstance(url, str) and url:
                result[path].append(url)

    return result


def ensure_route_in_redis(
    state_json: Dict[str, Any],
    route_key: str,
    desired_route_obj: Dict[str, Any],
    service_name: Optional[str] = None,
    attempts: int = 20,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Ensure route exists in Redis with proper merging."""
    desired_preview = json.dumps(desired_route_obj, separators=(",", ":"))
    desired_preview = desired_preview if len(desired_preview) <= 500 else (desired_preview[:500] + "...")
    _log(f"Updating route: key={route_key} preview={desired_preview}")

    def _operation(r: "Any") -> None:
        existing_str = r.get(route_key)
        existing = None
        if existing_str:
            try:
                existing = json.loads(existing_str)
            except Exception:
                pass

        desired_paths = desired_route_obj.get("_desired_paths")
        desired_paths_list: List[str] = []
        if isinstance(desired_paths, list):
            desired_paths_list = [p for p in desired_paths if isinstance(p, str) and p]

        desired_targets: List[Dict[str, Any]] = []
        if isinstance(desired_route_obj.get("targets"), list):
            desired_targets = desired_route_obj["targets"]
        elif isinstance(desired_route_obj.get("path_routes"), list) and desired_route_obj["path_routes"]:
            first_pr = desired_route_obj["path_routes"][0]
            if isinstance(first_pr, dict) and isinstance(first_pr.get("targets"), list):
                desired_targets = first_pr["targets"]

        desired_urls = [t.get("url") for t in desired_targets if isinstance(t, dict) and isinstance(t.get("url"), str)]
        desired_urls_set = {u for u in desired_urls if u}

        existing_urls_by_path = _extract_targets_urls_for_paths(existing, desired_paths_list)
        existing_urls_all = [u for urls in existing_urls_by_path.values() for u in urls]
        existing_urls_set = set(existing_urls_all)
        existing_dupes_count = len(existing_urls_all) - len(existing_urls_set)

        had_any = bool(existing_urls_set)
        will_have_any = bool(desired_urls_set)

        if service_name:
            if not had_any and will_have_any:
                _log(f"[{service_name}] routes added ({len(desired_urls_set)} target(s))")
            elif had_any and not will_have_any:
                _log(f"[{service_name}] routes removed ({len(existing_urls_set)} target(s))")
            elif existing_dupes_count > 0 and will_have_any:
                _log(f"[{service_name}] deduplicating {existing_dupes_count} duplicate target(s)")

            added = sorted(desired_urls_set - existing_urls_set)
            removed = sorted(existing_urls_set - desired_urls_set)
            if added or removed:
                _log(f"[{service_name}] targets changed: +{len(added)} -{len(removed)}")
                if added:
                    _log(f"[{service_name}] added: {', '.join(added)}")
                if removed:
                    _log(f"[{service_name}] removed: {', '.join(removed)}")

        merged = merge_route_obj(existing, desired_route_obj)
        if isinstance(existing, dict) and existing == merged:
            if service_name:
                _log(f"[{service_name}] no Redis changes required")
            return

        merged_str = json.dumps(merged, separators=(",", ":"))
        r.set(route_key, merged_str)
        _log(f"Redis SET ok: {route_key}")

    return _execute_with_redis(
        state_json, _operation, "Failed to update route in Redis", attempts, delay_seconds, redis_client
    )


def delete_route_key_from_redis(
    state_json: Dict[str, Any],
    route_key: str,
    attempts: int = 20,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Delete route key from Redis (best-effort with retries)."""
    def _operation(r: "Any") -> None:
        deleted = int(r.delete(route_key) or 0)
        if deleted > 0:
            _log(f"Redis DEL ok: {route_key}")
        else:
            _log(f"Redis DEL noop (key not found): {route_key}")

    return _execute_with_redis(
        state_json, _operation, "Failed to delete route key in Redis", attempts, delay_seconds, redis_client
    )


def ensure_passthrough_route_in_redis(
    state_json: Dict[str, Any],
    route_name: str,
    route_domain: str,
    tunnel_ips: List[str],
    port: int,
    attempts: int = 20,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Write or update passthrough route in Redis (manual-routes:<route_domain>)."""
    route_key = f"{ROUTE_KEY_PREFIX}:{route_domain}"
    desired_route = {
        "targets": [{"url": f"https://{ip}:{port}", "weight": 1} for ip in sorted(tunnel_ips)],
        "policy": "rr",
        "preserve_host": True,
        "passthrough": True,
    }
    desired_str = json.dumps(desired_route, separators=(",", ":"), sort_keys=True)

    def _operation(r: "Any") -> None:
        existing_str = r.get(route_key)
        if existing_str == desired_str:
            _log(f"[{route_name}] no Redis changes required for {route_domain}")
            return
        r.set(route_key, desired_str)
        _log(f"[{route_name}] updated route {route_key} -> {len(tunnel_ips)} target(s)")

    return _execute_with_redis(
        state_json, _operation, f"Failed to write {route_name} route to Redis", attempts, delay_seconds, redis_client
    )


def ensure_k8s_route_in_redis(
    state_json: Dict[str, Any],
    k8s_domain: str,
    tunnel_ips: List[str],
    attempts: int = 20,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Write or update a k8s API route in Redis (SSL passthrough to K8s API on port 6443)."""
    return ensure_passthrough_route_in_redis(
        state_json, "k8s", k8s_domain, tunnel_ips, port=6443, attempts=attempts, delay_seconds=delay_seconds,
        redis_client=redis_client,
    )


def sync_passthrough_route(
    state_json: Dict[str, Any],
    route_name: str,
    config: Dict[str, Any],
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str], List[str], str]:
    """Sync dedicated passthrough route by config."""
    domain_key = str(config.get("domain_key") or "")
    nodes_key = str(config.get("nodes_key") or "")
    port = int(config.get("port") or 0)

    route_domain = get_route_domain_by_key(state_json, domain_key)
    route_key = build_route_key(route_domain)

    nodes = state_json.get(nodes_key)
    if not isinstance(nodes, list):
        nodes = []

    tunnel_ips = sorted({
        node["ip"]
        for node in nodes
        if isinstance(node, dict)
        and _is_node_ready(node)
        and isinstance(node.get("ip"), str)
        and node.get("ip", "").strip()
    })

    if not tunnel_ips:
        _log(f"[{route_name}] no ready nodes, removing stale route if present: {route_key}")
        ok, err = delete_route_key_from_redis(state_json, route_key, attempts=3, redis_client=redis_client)
        if not ok:
            return False, err or f"Failed to cleanup stale {route_name} route", [], route_domain
        return True, None, [], route_domain

    ok, err = ensure_passthrough_route_in_redis(
        state_json, route_name, route_domain, tunnel_ips, port, redis_client=redis_client
    )
    if not ok:
        return False, err, tunnel_ips, route_domain
    return True, None, tunnel_ips, route_domain


def sync_k8s_routes(state_json: Dict[str, Any], redis_client: Optional["Any"] = None) -> tuple[bool, Optional[str], set]:
    """Sync k8s API routes to Redis from k8sNodes state.

    Groups k8sNodes by k8s_external_hostname (one rke2 cluster = one domain).
    Only includes ready nodes with a non-empty k8s_external_hostname.
    Returns (success, error, active_k8s_domains).
    """
    k8s_nodes = state_json.get("k8sNodes")
    if not isinstance(k8s_nodes, list):
        return True, None, set()

    # Group ready nodes by k8s_external_hostname
    domain_to_ips: Dict[str, List[str]] = {}
    for node in k8s_nodes:
        if not isinstance(node, dict):
            continue
        if not _is_node_ready(node):
            continue
        domain = node.get("k8s_external_hostname")
        if not isinstance(domain, str) or not domain.strip():
            continue
        ip = node.get("ip")
        if not isinstance(ip, str) or not ip.strip():
            continue
        domain = domain.strip()
        domain_to_ips.setdefault(domain, [])
        if ip.strip() not in domain_to_ips[domain]:
            domain_to_ips[domain].append(ip.strip())

    active_domains: set = set()
    errors = []

    for domain, ips in domain_to_ips.items():
        if not ips:
            continue
        ok, err = ensure_k8s_route_in_redis(state_json, domain, ips, redis_client=redis_client)
        if ok:
            active_domains.add(domain)
        else:
            errors.append(f"{domain}: {err}")

    if errors:
        return False, "; ".join(errors), active_domains

    return True, None, active_domains


def cleanup_stale_k8s_routes(
    state_json: Dict[str, Any],
    active_domains: set,
    prev_domains: set,
    redis_client: Optional["Any"] = None,
) -> set[str]:
    """Delete Redis routes for k8s domains that are no longer active."""
    stale = prev_domains - active_domains
    failed: set[str] = set()
    for domain in stale:
        route_key = f"{ROUTE_KEY_PREFIX}:{domain}"
        ok, err = delete_route_key_from_redis(state_json, route_key, attempts=3, redis_client=redis_client)
        if ok:
            _log(f"[k8s] removed stale route: {route_key}")
        else:
            _log_error(f"[k8s] failed to remove stale route {route_key}: {err}")
            failed.add(domain)
    return failed


def get_service_route_domain(state_json: Dict[str, Any], config: Dict[str, Any]) -> str:
    """Resolve route domain for a service.

    - For services without subdomain -> return swarmDomain as-is (e.g. app.<globalId>.<base_domain>).
    - For services with subdomain -> subdomain.<globalId>.<base_domain>.
    """
    swarm_domain = get_route_domain(state_json)
    subdomain = config.get("subdomain")

    if not isinstance(subdomain, str) or not subdomain.strip():
        return swarm_domain

    zone = get_subdomain_zone(state_json)
    return f"{subdomain.strip()}.{zone}"


def update_service_routes(
    state_json: Dict[str, Any],
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Update routes for all services in Redis. Each service uses its route domain (main or subdomain)."""
    all_updates_successful = True
    errors = []

    for service_name, config in SERVICE_ROUTES.items():
        service_domain = get_service_route_domain(state_json, config)
        route_key = build_route_key(service_domain)

        service_nodes = get_ready_nodes(state_json, config["nodes_key"])
        if not service_nodes:
            _log(f"No ready nodes for service {service_name}, removing its routes")

        targets = build_service_targets(service_nodes, int(config["port"]))
        desired_route_obj: Dict[str, Any] = {"_desired_paths": config["paths"]}
        if "client_max_body_size" in config:
            desired_route_obj["client_max_body_size"] = config["client_max_body_size"]
        if targets:
            desired_route_obj["path_routes"] = [{"path": path, "targets": targets} for path in config["paths"]]

        _log(f"Updating route for {service_name} on domain {service_domain}: {len(targets)} target(s)")
        success, error = ensure_route_in_redis(
            state_json, route_key, desired_route_obj, service_name=service_name, redis_client=redis_client
        )
        if not success:
            all_updates_successful = False
            errors.append(f"{service_name}: {error}")
            _log_error(f"Failed to update route for {service_name}: {error}")
        else:
            _log(f"Successfully updated route for {service_name}")

    if not all_updates_successful:
        return False, "; ".join(errors)

    return True, None



def get_swarm_secret(state_json: Dict[str, Any], secret_id: str) -> Optional[str]:
    """Value of SwarmDB secret `secret_id`, as selected by the manifest's stateExpr."""
    swarm_secrets = state_json.get("swarmSecrets")
    if not isinstance(swarm_secrets, list):
        return None
    for secret in swarm_secrets:
        if not isinstance(secret, dict) or secret.get("id") != secret_id:
            continue
        value = secret.get("value")
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def read_provider_config_file(file_name: str, base_dir: Path = PROVIDER_CONFIG_DIR) -> Optional[str]:
    """Contents of a provider-config file, or None when it was not supplied."""
    try:
        value = (base_dir / file_name).read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError as e:
        _log_error(f"Cannot read provider config file {file_name}", e)
        return None
    return value.strip() or None


def resolve_seeded_value(
    state_json: Dict[str, Any],
    secret_id: str,
    file_name: str,
    base_dir: Path = PROVIDER_CONFIG_DIR,
) -> Optional[str]:
    """Operator-supplied value: SwarmDB secret first, provider-config file as fallback."""
    return get_swarm_secret(state_json, secret_id) or read_provider_config_file(file_name, base_dir)


def split_pem_certificates(bundle: str) -> List[str]:
    """The individual PEM certificate blocks of a bundle, in order (leaf first)."""
    begin = "-----BEGIN CERTIFICATE-----"
    end = "-----END CERTIFICATE-----"
    blocks: List[str] = []
    cursor = 0
    while True:
        start = bundle.find(begin, cursor)
        if start < 0:
            return blocks
        stop = bundle.find(end, start)
        if stop < 0:
            return blocks
        stop += len(end)
        blocks.append(bundle[start:stop] + "\n")
        cursor = stop


def cert_not_after_epoch(cert_pem: str) -> int:
    """notAfter of a PEM certificate as a unix timestamp; 0 when it cannot be read.

    lua-resty-auto-ssl stores `expiry` next to the cert and renews on it. A 0 only makes it
    consider the cert due for renewal (which it then cannot do -- the fabric has no ACME
    path for an operator-supplied domain), so a parse failure must never stop us from
    publishing an otherwise valid cert.
    """
    try:
        result = subprocess.run(
            ["openssl", "x509", "-noout", "-enddate"],
            input=cert_pem,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except (OSError, subprocess.SubprocessError) as e:
        _log_error("Cannot run openssl to read cert notAfter", e)
        return 0
    if result.returncode != 0:
        _log_error(f"openssl could not read cert notAfter: {(result.stderr or '').strip()}")
        return 0

    raw = result.stdout.split("=", 1)[-1].strip()
    for fmt in ("%b %d %H:%M:%S %Y %Z", "%b %d %H:%M:%S %Y"):
        try:
            return int(datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            continue
    _log_error(f"Unparseable cert notAfter: {raw!r}")
    return 0


def build_auto_ssl_key(route_domain: str) -> str:
    """Redis key lua-resty-auto-ssl reads the cert for `route_domain` from."""
    return f"{AUTO_SSL_KEY_PREFIX}:{route_domain}:latest"


def build_auto_ssl_payload(fullchain_pem: str, privkey_pem: str) -> Dict[str, Any]:
    """The record lua-resty-auto-ssl's Redis storage adapter reads back for a domain.

    Field names are the adapter's own: `fullchain_pem` is what gets served, `cert_pem` is
    the leaf alone -- and the leaf is what the deployment-evidence JWS is fingerprinted
    against, so the fabric has to hold the very cert the client observes.
    """
    blocks = split_pem_certificates(fullchain_pem)
    if not blocks:
        raise ValueError("exposed TLS cert holds no PEM certificate block")
    if "PRIVATE KEY" not in privkey_pem:
        raise ValueError("exposed TLS key holds no PEM private key block")

    leaf = blocks[0]
    return {
        "fullchain_pem": fullchain_pem if fullchain_pem.endswith("\n") else fullchain_pem + "\n",
        "privkey_pem": privkey_pem if privkey_pem.endswith("\n") else privkey_pem + "\n",
        "cert_pem": leaf,
        "expiry": cert_not_after_epoch(leaf),
    }


def cert_fingerprint(cert_pem: str) -> str:
    """Short sha256 of a PEM block -- safe to log, enough to tell two certs apart."""
    return hashlib.sha256(cert_pem.encode("utf-8")).hexdigest()[:16]


def ensure_auto_ssl_cert_in_redis(
    state_json: Dict[str, Any],
    route_domain: str,
    payload: Dict[str, Any],
    attempts: int = 5,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Write the auto-ssl record for `route_domain`."""
    key = build_auto_ssl_key(route_domain)
    serialized = json.dumps(payload, separators=(",", ":"))

    def _operation(r: "Any") -> None:
        r.set(key, serialized)

    return _execute_with_redis(
        state_json, _operation, f"Failed to write {key} to Redis", attempts, delay_seconds, redis_client
    )


def ensure_metrics_token_in_redis(
    state_json: Dict[str, Any],
    token: str,
    attempts: int = 5,
    delay_seconds: float = 1.0,
    redis_client: Optional["Any"] = None,
) -> tuple[bool, Optional[str]]:
    """Write the operator's metrics scrape token where swarm-cloud-api's guard reads it."""

    def _operation(r: "Any") -> None:
        r.set(METRICS_TOKEN_KEY, token)

    return _execute_with_redis(
        state_json,
        _operation,
        f"Failed to write {METRICS_TOKEN_KEY} to Redis",
        attempts,
        delay_seconds,
        redis_client,
    )


def sync_exposed_tls_cert(
    state_json: Dict[str, Any],
    redis_client: Optional["Any"] = None,
    provider_config_dir: Path = PROVIDER_CONFIG_DIR,
) -> tuple[bool, Optional[str], Optional[str]]:
    """Publish the operator's TLS cert for the cloud's own domain into the auto-ssl store.

    Returns (ok, error, fingerprint). A cloud that was given no cert yields
    (True, None, None): that is a normal configuration, not a failure.

    Written on every apply rather than diffed against local_state on purpose -- sp-vm wipes
    the state disk on every boot, so a rebooted cloud comes back with an empty Redis AND an
    empty local_state, and the only thing that can be trusted to be authoritative here is
    the provider config.
    """
    cert_pem = resolve_seeded_value(
        state_json, EXPOSED_TLS_CERT_SECRET, EXPOSED_TLS_CERT_FILE, provider_config_dir
    )
    key_pem = resolve_seeded_value(
        state_json, EXPOSED_TLS_KEY_SECRET, EXPOSED_TLS_KEY_FILE, provider_config_dir
    )
    if not cert_pem and not key_pem:
        return True, None, None
    if not cert_pem or not key_pem:
        missing = EXPOSED_TLS_CERT_SECRET if not cert_pem else EXPOSED_TLS_KEY_SECRET
        return False, f"exposed TLS material incomplete: {missing} is missing", None

    try:
        route_domain = get_route_domain(state_json)
        payload = build_auto_ssl_payload(cert_pem, key_pem)
    except ValueError as e:
        return False, f"exposed TLS material unusable: {e}", None

    fingerprint = cert_fingerprint(payload["cert_pem"])
    ok, error = ensure_auto_ssl_cert_in_redis(
        state_json, route_domain, payload, redis_client=redis_client
    )
    if not ok:
        return False, error, fingerprint

    _log(
        f"Published exposed TLS cert for {route_domain} "
        f"(leaf sha256:{fingerprint}, expiry={payload['expiry']})"
    )
    return True, None, fingerprint


def sync_metrics_token(
    state_json: Dict[str, Any],
    redis_client: Optional["Any"] = None,
    provider_config_dir: Path = PROVIDER_CONFIG_DIR,
) -> tuple[bool, Optional[str], bool]:
    """Publish the operator's metrics scrape token. Returns (ok, error, published)."""
    token = resolve_seeded_value(
        state_json, METRICS_TOKEN_SECRET, METRICS_TOKEN_FILE, provider_config_dir
    )
    if not token:
        return True, None, False

    ok, error = ensure_metrics_token_in_redis(state_json, token, redis_client=redis_client)
    if not ok:
        return False, error, False

    _log(f"Published metrics scrape token to Redis key {METRICS_TOKEN_KEY}")
    return True, None, True


def redact_state(state_json: Dict[str, Any]) -> Dict[str, Any]:
    """`state_json` with the secret-bearing keys replaced by their ids, for logging."""
    redacted: Dict[str, Any] = {}
    for key, value in state_json.items():
        if key not in SECRET_STATE_KEYS:
            redacted[key] = value
            continue
        if isinstance(value, list):
            redacted[key] = [
                {"id": item.get("id"), "value": "<redacted>"} if isinstance(item, dict) else "<redacted>"
                for item in value
            ]
        else:
            redacted[key] = "<redacted>"
    return redacted

@plugin.command("apply")
def cmd_apply(plugin_input: PluginInput) -> PluginOutput:
    """Update all service routes in Redis.

    Expected input_data.state example:

            {
                "authServiceNodes": [
                    {
                        "cluster": "auth-service:1770646321644:7w8zd3762",
                        "id": "auth-service:1770646321644:7w8zd3762:test-node-2",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-2",
                        "ready": "true"
                    }
                ],
                "redisSentinelNodes": [
                    {
                        "cluster": "redis-sentinel:1770646301985:gltzzxebh",
                        "id": "redis-sentinel:1770646301985:gltzzxebh:test-node-2",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-2"
                    }
                ],
                "swarmCloudApiNodes": [
                    {
                        "cluster": "swarm-cloud-api:1770646306727:0gba3whoo",
                        "id": "swarm-cloud-api:1770646306727:0gba3whoo:test-node-2",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-2",
                        "ready": "true"
                    }
                ],
                "swarmCloudUiNodes": [
                    {
                        "cluster": "swarm-cloud-ui:1770646311968:f0ryi43rl",
                        "id": "swarm-cloud-ui:1770646311968:f0ryi43rl:test-node-2",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-2",
                        "ready": "true"
                    }
                ],
                "swarmGatekeeperS3Nodes": [
                    {
                        "cluster": "gatekeeper-s3:1770646312000:abc123",
                        "id": "gatekeeper-s3:1770646312000:abc123:test-node-2",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-2",
                        "ready": "true"
                    }
                ],
                "swarmGatekeeperHarborNodes": [
                    {
                        "cluster": "gatekeeper-harbor:1770646312001:def456",
                        "id": "gatekeeper-harbor:1770646312001:def456:test-node-3",
                        "ip": "10.13.151.121",
                        "node_id": "test-node-3",
                        "ready": "true"
                    }
                ],
                "swarmDomain": "swarm.test.superprotocol.io"
            }

    Behavior:
    - If swarmDomain is missing/empty -> returns PluginOutput(status="postponed").
    - Each service is written to its route key (main domain or subdomain); services with
            subdomain use manual-routes:<serviceDomain>, where serviceDomain is derived from state.
            For split gatekeeper services this will be, for example, gatekeeper-s3.<globalId>.<base_domain>
            or gatekeeper-harbor.<globalId>.<base_domain>, without the extra app. prefix level.
    - For each *Nodes array, only nodes with ready=true are used to build targets.
    - local_state keeps a deterministic snapshot of computed routes; Redis is reconciled on each apply and may skip writes if nothing changed.
    """
    state_json = plugin_input.state or {}
    local_state = plugin_input.local_state if isinstance(plugin_input.local_state, dict) else {}

    if not isinstance(state_json, dict):
        return PluginOutput(status="error", error_message="input_data.state must be a JSON object", local_state=local_state)

    # Check dependencies
    dep_error = check_state_dependencies(state_json)
    if dep_error:
        _log_error(f"Dependencies not ready: {dep_error}")
        return PluginOutput(status="postponed", error_message=dep_error, local_state=local_state)

    # Build a deterministic desired routes state for diffing
    route_domain = get_route_domain(state_json)
    desired_routes_state: Dict[str, Any] = {
        "route_domain": route_domain,
        "route_key": build_route_key(route_domain),
        "services": {},
    }
    for service_name, cfg in SERVICE_ROUTES.items():
        ready_nodes = get_ready_nodes(state_json, cfg["nodes_key"])
        targets = build_service_targets(ready_nodes, int(cfg["port"]))
        service_domain = get_service_route_domain(state_json, cfg)
        svc_entry: Dict[str, Any] = {
            "paths": list(cfg["paths"]),
            "port": int(cfg["port"]),
            "targets": targets,
            "route_domain": service_domain,
        }
        if "client_max_body_size" in cfg:
            svc_entry["client_max_body_size"] = cfg["client_max_body_size"]
        desired_routes_state["services"][service_name] = svc_entry

    desired_routes_state["passthrough_routes"] = {}
    for passthrough_name, config in PASSTHROUGH_ROUTES.items():
        domain_key = str(config.get("domain_key") or "")
        nodes_key = str(config.get("nodes_key") or "")
        port = int(config.get("port") or 0)

        route_domain = get_route_domain_by_key(state_json, domain_key)
        nodes = state_json.get(nodes_key)
        if not isinstance(nodes, list):
            nodes = []

        targets = [
            {"url": f"https://{ip}:{port}", "weight": 1}
            for ip in sorted(
                {
                    node["ip"]
                    for node in nodes
                    if isinstance(node, dict)
                    and _is_node_ready(node)
                    and isinstance(node.get("ip"), str)
                    and node.get("ip", "").strip()
                }
            )
        ]
        desired_routes_state["passthrough_routes"][passthrough_name] = {
            "route_domain": route_domain,
            "route_key": build_route_key(route_domain),
            "passthrough": True,
            "port": port,
            "targets": targets,
        }

    prev_routes_state = local_state.get("routes_state") if isinstance(local_state.get("routes_state"), dict) else None
    if prev_routes_state == desired_routes_state:
        _log("Routes unchanged since last apply; reconciling Redis to ensure no duplicates/empty targets")
    else:
        _log("Routes changed since last apply; updating Redis")

    # Establish one Redis connection for all operations
    redis_client, conn_err = _connect_with_retry(state_json)
    if redis_client is None:
        _log_error(f"Failed to connect to Redis: {conn_err}")
        return PluginOutput(status="postponed", error_message=conn_err, local_state=local_state)

    # Update routes for all services (app domain + subdomain services)
    success, error = update_service_routes(state_json, redis_client=redis_client)

    if not success:
        _log_error(f"Failed to update routes: {error}")
        return PluginOutput(status="postponed", error_message=error, local_state=local_state)

    for passthrough_name, config in PASSTHROUGH_ROUTES.items():
        route_ok, route_err, _, _ = sync_passthrough_route(state_json, passthrough_name, config, redis_client=redis_client)
        if not route_ok:
            _log_error(f"Failed to sync {passthrough_name} passthrough route: {route_err}")
            return PluginOutput(
                status="postponed",
                error_message=f"Failed to sync {passthrough_name} passthrough route: {route_err}",
                local_state=local_state,
            )

    _log("All service routes updated successfully")
    local_state["routes_state"] = desired_routes_state

    # Sync k8s API routes grouped by k8s_external_hostname
    prev_k8s_domains: set = set(local_state.get("k8s_domains", []))
    k8s_ok, k8s_err, active_k8s_domains = sync_k8s_routes(state_json, redis_client=redis_client)
    if not k8s_ok:
        _log_error(f"Failed to sync k8s routes: {k8s_err}")
        return PluginOutput(status="postponed", error_message=k8s_err, local_state=local_state)
    failed_stale_domains = cleanup_stale_k8s_routes(state_json, active_k8s_domains, prev_k8s_domains, redis_client=redis_client)
    local_state["k8s_domains"] = sorted(active_k8s_domains | failed_stale_domains)
    if failed_stale_domains:
        return PluginOutput(
            status="postponed",
            error_message="Failed to remove one or more stale k8s routes",
            local_state=local_state,
        )

    # SUP-206: operator-supplied material, published last so a cert problem can never keep
    # the cloud's routes from being reconciled.
    tls_ok, tls_err, tls_fingerprint = sync_exposed_tls_cert(state_json, redis_client=redis_client)
    local_state["exposed_tls_fingerprint"] = tls_fingerprint
    if not tls_ok:
        _log_error(f"Failed to publish exposed TLS cert: {tls_err}")
        return PluginOutput(status="postponed", error_message=tls_err, local_state=local_state)

    token_ok, token_err, token_published = sync_metrics_token(state_json, redis_client=redis_client)
    local_state["metrics_token_published"] = token_published
    if not token_ok:
        _log_error(f"Failed to publish metrics token: {token_err}")
        return PluginOutput(status="postponed", error_message=token_err, local_state=local_state)

    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("destroy")
def cmd_destroy(plugin_input: PluginInput) -> PluginOutput:
    """Destroy - no-op, just log state."""
    state_json = plugin_input.state or {}
    _log(f"Destroy: state={json.dumps(redact_state(state_json), separators=(',', ':'))}")
    return PluginOutput(status="completed", local_state={})


if __name__ == "__main__":
    plugin.run()
