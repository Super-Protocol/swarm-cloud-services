"""OPA authorization webhook: in-cluster stack + kube-apiserver structured authorization (bundled with rke2)."""

from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

RKE2_PLUGIN_DIR = Path(__file__).resolve().parent
ASSETS_DIR = RKE2_PLUGIN_DIR / "configs" / "opa-authz-webhook"
INNER_CONFIG_DIR = ASSETS_DIR / "configs"

RKE2_KUBECONFIG = Path(os.environ.get("RKE2_KUBECONFIG", "/etc/rancher/rke2/rke2.yaml"))
RKE2_CONFIG_FILE = Path(os.environ.get("RKE2_CONFIG_FILE", "/etc/rancher/rke2/config.yaml"))
KUBECTL_BIN = os.environ.get("RKE2_KUBECTL", "/var/lib/rancher/rke2/bin/kubectl")

AUTHZ_CONFIG_DST = Path("/etc/rancher/rke2/authz-config.yaml")
# Must live under /var/lib/rancher/rke2/server (bind-mounted into kube-apiserver); /etc/rancher/rke2/ is only single-file mounts.
AUTHZ_KUBECONFIG_DST = Path("/var/lib/rancher/rke2/server/cred/authz-webhook.kubeconfig")
AUTHZ_APISERVER_ARG = "authorization-config=/etc/rancher/rke2/authz-config.yaml"
WEBHOOK_TLS_SERVER_NAME = "opa-authz-webhook.opa-authz-system.svc"
# Adapter pod uses hostNetwork and listens on host loopback only (see deployment.yaml).
# 18443 avoids collision with openresty SSL termination on 127.0.0.1:8443 (services/openresty).
OPA_AUTHZ_WEBHOOK_LISTEN_PORT = 18443
WEBHOOK_APISERVER_LOCAL_URL = f"https://127.0.0.1:{OPA_AUTHZ_WEBHOOK_LISTEN_PORT}/authorize"
# The serving certificate carries only the in-cluster DNS names (configs/generate-certs.sh), no loopback IP SAN:
# kube-apiserver dials 127.0.0.1 but verifies WEBHOOK_TLS_SERVER_NAME via tls-server-name. The health probe does
# the same with curl --resolve, so it exercises the apiserver's exact TLS path instead of failing SAN checks.
WEBHOOK_HEALTHZ_URL = f"https://{WEBHOOK_TLS_SERVER_NAME}:{OPA_AUTHZ_WEBHOOK_LISTEN_PORT}/healthz"
WEBHOOK_HEALTHZ_RESOLVE = f"{WEBHOOK_TLS_SERVER_NAME}:{OPA_AUTHZ_WEBHOOK_LISTEN_PORT}:127.0.0.1"
HEALTHZ_PROBE_MAX_TIME_SEC = 5
TLS_NAMESPACE = "opa-authz-system"
TLS_SECRET = "opa-authz-webhook-tls"
TENANT_SA_NAME = "ns-editor"
TENANT_NS_PREFIX = "user-"
SAR_NON_SWARM_SECRET_NAME = "opa-health-probe-non-swarm"
OPA_AUTHZ_WORKLOAD = "opa-authz-webhook"
OPA_AUTHZ_WORKLOAD_KIND = "daemonset"


def get_leader_node(state_json: dict) -> str | None:
    cluster = state_json.get("cluster") or {}
    return cluster.get("leader_node")


def kubectl_env() -> dict[str, str]:
    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)
    return env


def kubectl_run(args: list[str], *, input_text: str | None = None, timeout: int = 120) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [KUBECTL_BIN, *args],
        env=kubectl_env(),
        input=input_text,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def rke2_config_has_authorization_config(text: str) -> bool:
    return "authorization-config=" in text


def append_kube_apiserver_authorization_config(path: Path) -> bool:
    """Insert authorization-config arg into kube-apiserver-arg list, or append new block. Returns True if modified."""
    existing = path.read_text() if path.exists() else ""
    if rke2_config_has_authorization_config(existing):
        return False
    arg_line = f'  - "{AUTHZ_APISERVER_ARG}"'
    lines = existing.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "kube-apiserver-arg:":
            j = i + 1
            while j < len(lines) and lines[j].startswith("  -"):
                j += 1
            new_lines = lines[:j] + [arg_line] + lines[j:]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("\n".join(new_lines).rstrip() + "\n")
            return True
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(existing.rstrip() + f"\n\nkube-apiserver-arg:\n{arg_line}\n")
    return True


def install_authorization_config_template() -> None:
    src = INNER_CONFIG_DIR / "authorization-config.yaml"
    AUTHZ_CONFIG_DST.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, AUTHZ_CONFIG_DST)


def render_authz_kubeconfig(ca_pem: str, client_cert_pem: str, client_key_pem: str, dest: Path) -> None:
    ca_b64 = base64.standard_b64encode(ca_pem.encode()).decode().replace("\n", "")
    cc_b64 = base64.standard_b64encode(client_cert_pem.encode()).decode().replace("\n", "")
    ck_b64 = base64.standard_b64encode(client_key_pem.encode()).decode().replace("\n", "")
    lines = [
        "apiVersion: v1",
        "kind: Config",
        "clusters:",
        "  - name: opa-authz-webhook",
        "    cluster:",
        f"      certificate-authority-data: {ca_b64}",
        f"      server: {WEBHOOK_APISERVER_LOCAL_URL}",
        f"      tls-server-name: {WEBHOOK_TLS_SERVER_NAME}",
        "users:",
        "  - name: kube-apiserver",
        "    user:",
        f"      client-certificate-data: {cc_b64}",
        f"      client-key-data: {ck_b64}",
        "contexts:",
        "  - name: webhook",
        "    context:",
        "      cluster: opa-authz-webhook",
        "      user: kube-apiserver",
        "current-context: webhook",
        "preferences: {}",
        "",
    ]
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines), encoding="utf-8")
    os.chmod(dest, 0o600)


def fetch_tls_material_from_cluster() -> tuple[str, str, str] | None:
    """Return (ca.crt PEM, apiserver-client.crt PEM, apiserver-client.key PEM) from Secret or None."""
    r = kubectl_run(
        ["get", "secret", TLS_SECRET, "-n", TLS_NAMESPACE, "-ojsonpath={.data.ca\\.crt}"],
        timeout=30,
    )
    if r.returncode != 0:
        return None
    ca_b64 = (r.stdout or "").strip()
    if not ca_b64:
        return None
    r5 = kubectl_run(
        ["get", "secret", TLS_SECRET, "-n", TLS_NAMESPACE, "-ojsonpath={.data.apiserver-client\\.crt}"],
        timeout=30,
    )
    r6 = kubectl_run(
        ["get", "secret", TLS_SECRET, "-n", TLS_NAMESPACE, "-ojsonpath={.data.apiserver-client\\.key}"],
        timeout=30,
    )
    if r5.returncode != 0 or r6.returncode != 0:
        return None
    acc_b64 = (r5.stdout or "").strip()
    ack_b64 = (r6.stdout or "").strip()
    if not acc_b64 or not ack_b64:
        return None
    ca_pem = base64.standard_b64decode(ca_b64).decode()
    acc_pem = base64.standard_b64decode(acc_b64).decode()
    ack_pem = base64.standard_b64decode(ack_b64).decode()
    return ca_pem, acc_pem, ack_pem


def _create_tls_secret_from_dir(cert_dir: Path) -> tuple[bool, str | None]:
    r = kubectl_run(
        [
            "create",
            "secret",
            "generic",
            TLS_SECRET,
            "-n",
            TLS_NAMESPACE,
            f"--from-file=tls.crt={cert_dir / 'tls.crt'}",
            f"--from-file=tls.key={cert_dir / 'tls.key'}",
            f"--from-file=client-ca.crt={cert_dir / 'client-ca.crt'}",
            f"--from-file=ca.crt={cert_dir / 'ca.crt'}",
            f"--from-file=apiserver-client.crt={cert_dir / 'apiserver-client.crt'}",
            f"--from-file=apiserver-client.key={cert_dir / 'apiserver-client.key'}",
        ],
        timeout=60,
    )
    if r.returncode != 0 and "AlreadyExists" not in (r.stderr or ""):
        return False, (r.stderr or "").strip()
    return True, None


def ensure_tls_secret_leader() -> tuple[bool, str | None]:
    chk = kubectl_run(["get", "secret", TLS_SECRET, "-n", TLS_NAMESPACE], timeout=30)
    if chk.returncode == 0:
        return True, None

    gen_script = INNER_CONFIG_DIR / "generate-certs.sh"
    if not gen_script.exists():
        return False, f"missing {gen_script}"

    tmp_path = Path(tempfile.mkdtemp(prefix="opa-authz-certs-"))
    try:
        subprocess.run(
            ["bash", str(gen_script), str(tmp_path)],
            check=True,
            capture_output=True,
            text=True,
            timeout=120,
        )
        return _create_tls_secret_from_dir(tmp_path)
    finally:
        shutil.rmtree(tmp_path, ignore_errors=True)


def apply_namespace_only() -> tuple[bool, str | None]:
    ns_file = ASSETS_DIR / "namespace.yaml"
    if not ns_file.exists():
        return False, "missing opa-authz-webhook namespace.yaml"
    r = subprocess.run(
        [KUBECTL_BIN, "apply", "-f", str(ns_file)],
        env=kubectl_env(),
        capture_output=True,
        text=True,
        timeout=60,
    )
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()
    return True, None


def remove_legacy_opa_deployment() -> None:
    """Drop pre-HA Deployment if present; workload is now a DaemonSet on every control-plane node."""
    kubectl_run(
        ["delete", "deployment", OPA_AUTHZ_WORKLOAD, "-n", TLS_NAMESPACE, "--ignore-not-found"],
        timeout=60,
    )


def apply_kustomize() -> tuple[bool, str | None]:
    if not RKE2_KUBECONFIG.exists():
        return False, "RKE2 kubeconfig not found"
    r = subprocess.run(
        [KUBECTL_BIN, "apply", "-k", str(ASSETS_DIR)],
        env=kubectl_env(),
        capture_output=True,
        text=True,
        timeout=180,
    )
    if r.returncode != 0:
        return False, (r.stderr or r.stdout or "kubectl apply -k opa-authz-webhook failed").strip()
    return True, None


def wait_opa_authz_workload_ready(timeout_sec: int = 300) -> tuple[bool, str | None]:
    r = kubectl_run(
        [
            "rollout",
            "status",
            f"{OPA_AUTHZ_WORKLOAD_KIND}/{OPA_AUTHZ_WORKLOAD}",
            "-n",
            TLS_NAMESPACE,
            f"--timeout={timeout_sec}s",
        ],
        timeout=timeout_sec + 30,
    )
    if r.returncode != 0:
        return False, (r.stderr or r.stdout or "rollout timeout").strip()
    return True, None


def wait_deployment_ready(timeout_sec: int = 300) -> tuple[bool, str | None]:
    """Backward-compatible alias; OPA authz runs as a DaemonSet on every control-plane node."""
    return wait_opa_authz_workload_ready(timeout_sec)


def _authz_kubeconfig_server_url(path: Path) -> str | None:
    if not path.exists():
        return None
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("server:"):
            return stripped.split(":", 1)[1].strip()
    return None


def _local_rke2_node_name() -> str | None:
    if not RKE2_CONFIG_FILE.is_file():
        return None
    for line in RKE2_CONFIG_FILE.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("node-name:"):
            return stripped.split(":", 1)[1].strip()
    return None


def _local_opa_authz_pod_ready() -> tuple[bool, str | None]:
    """True when the OPA authz DaemonSet pod on this node is ready (adapter on 127.0.0.1:18443)."""
    node_name = _local_rke2_node_name()
    if not node_name:
        return False, "local node-name not found in RKE2 config"
    r = kubectl_run(
        [
            "get",
            "pods",
            "-n",
            TLS_NAMESPACE,
            "-l",
            "app.kubernetes.io/name=opa-authz-webhook",
            "--field-selector",
            f"spec.nodeName={node_name}",
            "-o",
            "jsonpath={.items[0].status.containerStatuses[*].ready}",
        ],
        timeout=30,
    )
    if r.returncode != 0 or "true" not in (r.stdout or ""):
        return False, f"OPA authz pod not ready on local node {node_name}"
    probe = subprocess.run(
        ["bash", "-c", f"echo >/dev/tcp/127.0.0.1/{OPA_AUTHZ_WEBHOOK_LISTEN_PORT}"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if probe.returncode != 0:
        return False, f"OPA authz adapter not listening on 127.0.0.1:{OPA_AUTHZ_WEBHOOK_LISTEN_PORT}"
    return True, None


def wire_rke2_apiserver_if_needed(local_state: dict) -> tuple[str | None, dict]:
    """Install authz files and merge RKE2 config; restart rke2-server when newly enabled."""
    new_state = {**local_state}
    material = fetch_tls_material_from_cluster()
    if not material:
        return "TLS secret not available yet", new_state

    ca_pem, client_crt, client_key = material
    install_authorization_config_template()
    prior_server = _authz_kubeconfig_server_url(AUTHZ_KUBECONFIG_DST)
    try:
        render_authz_kubeconfig(ca_pem, client_crt, client_key, AUTHZ_KUBECONFIG_DST)
    except Exception as e:
        return f"render kubeconfig: {e}", new_state

    kubeconfig_changed = prior_server is not None and prior_server != WEBHOOK_APISERVER_LOCAL_URL
    modified = append_kube_apiserver_authorization_config(RKE2_CONFIG_FILE)
    needs_restart = modified or kubeconfig_changed or local_state.get("opa_authz_force_restart")
    if needs_restart:
        pod_ok, pod_err = _local_opa_authz_pod_ready()
        if not pod_ok:
            return pod_err or "local OPA authz adapter not ready before apiserver wire", new_state
        subprocess.run(
            ["systemctl", "restart", "rke2-server"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        print("[*] rke2-server restarted for authorization-config", file=sys.stderr)

    return None, new_state


def _local_k8s_node_ready(rke2_props: list, node_id: str, local_state: dict | None = None) -> bool:
    if local_state and local_state.get("api_ready"):
        return True
    for prop in rke2_props:
        if prop.get("node_id") == node_id and prop.get("name") == "k8s_node_ready" and prop.get("value") == "true":
            return True
    return False


def _reconcile_opa_authz_follower(
    rke2_props: list,
    leader_node_id: str,
    local_state: dict,
    *,
    require_swarm_k8s_node_ready: bool,
) -> tuple[str | None, dict[str, str], dict]:
    """Wait for leader-deployed OPA stack, then wire local kube-apiserver (secondary control-plane)."""
    leader_ready = _local_k8s_node_ready(rke2_props, leader_node_id)
    if require_swarm_k8s_node_ready and not leader_ready:
        return "Waiting for leader k8s_node_ready (OPA authz)", {}, {}

    if not RKE2_KUBECONFIG.exists():
        return "RKE2 kubeconfig not found (OPA authz)", {}, {}

    chk = kubectl_run(["get", "secret", TLS_SECRET, "-n", TLS_NAMESPACE], timeout=30)
    if chk.returncode != 0:
        return "Waiting for opa-authz TLS secret from leader", {}, {}

    ready_ok, ready_err = wait_opa_authz_workload_ready()
    if not ready_ok:
        return ready_err or "OPA authz DaemonSet not ready", {}, {}

    pod_ok, pod_err = _local_opa_authz_pod_ready()
    if not pod_ok:
        return pod_err or "Waiting for local OPA authz pod", {}, {}

    wire_err, merged = wire_rke2_apiserver_if_needed(local_state)
    if wire_err:
        return wire_err, {}, merged

    return None, {"opa_authz_webhook_ready": "true"}, merged


def _reconcile_opa_authz_leader(local_state: dict) -> tuple[str | None, dict[str, str], dict]:
    """Bootstrap TLS, apply manifests, wait for rollout, wire kube-apiserver on leader control-plane."""
    ns_ok, ns_err = apply_namespace_only()
    if not ns_ok:
        return ns_err or "namespace apply failed (OPA authz)", {}, {}

    tls_ok, tls_err = ensure_tls_secret_leader()
    if not tls_ok:
        return tls_err or "TLS bootstrap failed (OPA authz)", {}, {}

    remove_legacy_opa_deployment()
    ok, msg = apply_kustomize()
    if not ok:
        return msg or "kubectl apply -k failed (OPA authz)", {}, {}

    ready_ok, ready_err = wait_opa_authz_workload_ready()
    if not ready_ok:
        return ready_err or "OPA authz DaemonSet not ready", {}, {}

    pod_ok, pod_err = _local_opa_authz_pod_ready()
    if not pod_ok:
        return pod_err or "Waiting for local OPA authz pod", {}, {}

    wire_err, merged = wire_rke2_apiserver_if_needed(local_state)
    if wire_err:
        return wire_err, {}, merged

    return None, {"opa_authz_webhook_ready": "true"}, merged


def reconcile_opa_authz_webhook(
    state_json: dict,
    local_node_id: str,
    local_state: dict,
    *,
    is_leader: bool,
    is_bootstrap: bool,
    require_swarm_k8s_node_ready: bool,
) -> tuple[str | None, dict[str, str], dict]:
    """Deploy OPA webhook stack and wire apiserver. Returns (postpone_reason, node_properties_delta, local_state_delta)."""
    _ = is_bootstrap  # passed from main for API symmetry; leader/follower routing uses is_leader
    if os.environ.get("OPA_AUTHZ_DISABLED", "").strip() in ("1", "true", "yes"):
        return None, {}, {}

    leader_node_id = get_leader_node(state_json)
    rke2_props = state_json.get("rke2NodeProperties") or []

    if require_swarm_k8s_node_ready:
        if not _local_k8s_node_ready(rke2_props, local_node_id, local_state):
            return "Waiting for k8s_node_ready on this node (OPA authz)", {}, {}
    if not leader_node_id:
        return "Missing cluster leader_node (OPA authz)", {}, {}

    if is_leader:
        return _reconcile_opa_authz_leader(local_state)

    return _reconcile_opa_authz_follower(
        rke2_props,
        leader_node_id,
        local_state,
        require_swarm_k8s_node_ready=require_swarm_k8s_node_ready,
    )


def _opa_authz_workload_exists() -> tuple[bool, str | None]:
    r = kubectl_run(
        ["get", OPA_AUTHZ_WORKLOAD_KIND, OPA_AUTHZ_WORKLOAD, "-n", TLS_NAMESPACE],
        timeout=30,
    )
    if r.returncode != 0:
        return False, (r.stderr or "").strip() or "OPA authz DaemonSet missing"
    return True, None


def _deployment_exists() -> tuple[bool, str | None]:
    return _opa_authz_workload_exists()


def _opa_authz_workload_ready_quick() -> tuple[bool, str | None]:
    r = kubectl_run(
        [
            "rollout",
            "status",
            f"{OPA_AUTHZ_WORKLOAD_KIND}/{OPA_AUTHZ_WORKLOAD}",
            "-n",
            TLS_NAMESPACE,
            "--timeout=15s",
        ],
        timeout=25,
    )
    if r.returncode != 0:
        return False, (r.stderr or r.stdout or "OPA authz DaemonSet not ready").strip()
    return True, None


def _deployment_ready_quick() -> tuple[bool, str | None]:
    return _opa_authz_workload_ready_quick()


def _probe_adapter_healthz_mtls() -> tuple[bool, str | None]:
    material = fetch_tls_material_from_cluster()
    if not material:
        return False, "OPA authz TLS secret not available for adapter health probe"
    ca_pem, client_crt, client_key = material
    tmp_path = Path(tempfile.mkdtemp(prefix="opa-authz-health-"))
    try:
        ca_file = tmp_path / "ca.crt"
        cert_file = tmp_path / "apiserver-client.crt"
        key_file = tmp_path / "apiserver-client.key"
        ca_file.write_text(ca_pem, encoding="utf-8")
        cert_file.write_text(client_crt, encoding="utf-8")
        key_file.write_text(client_key, encoding="utf-8")
        r = subprocess.run(
            [
                "curl",
                "-fsS",
                # Dial host loopback, but present and verify the DNS name the serving cert carries.
                "--resolve",
                WEBHOOK_HEALTHZ_RESOLVE,
                # Ask the adapter to close the connection: end-of-body is then EOF, so an adapter
                # that answers without Content-Length cannot hang the probe (SUP-664). Keeps this
                # probe working against pods still running a pre-fix adapter.py.
                "-H",
                "Connection: close",
                # Bound the request inside the subprocess timeout, so a stall is a readable health
                # message rather than a TimeoutExpired from under the health command.
                "--max-time",
                str(HEALTHZ_PROBE_MAX_TIME_SEC),
                "--cert",
                str(cert_file),
                "--key",
                str(key_file),
                "--cacert",
                str(ca_file),
                WEBHOOK_HEALTHZ_URL,
            ],
            capture_output=True,
            text=True,
            timeout=HEALTHZ_PROBE_MAX_TIME_SEC + 5,
        )
        if r.returncode != 0:
            return False, (r.stderr or r.stdout or "adapter healthz mTLS probe failed").strip()
        if (r.stdout or "").strip() != "ok":
            return False, f"adapter healthz unexpected body: {(r.stdout or '').strip()!r}"
        return True, None
    finally:
        shutil.rmtree(tmp_path, ignore_errors=True)


def _subject_access_review(
    *,
    user: str,
    namespace: str,
    verb: str,
    resource: str,
    name: str | None = None,
) -> tuple[dict | None, str | None]:
    attrs: dict[str, str] = {
        "namespace": namespace,
        "verb": verb,
        "group": "",
        "resource": resource,
    }
    if name is not None:
        attrs["name"] = name
    body = {
        "apiVersion": "authorization.k8s.io/v1",
        "kind": "SubjectAccessReview",
        "spec": {"user": user, "resourceAttributes": attrs},
    }
    r = kubectl_run(
        ["create", "--raw", "/apis/authorization.k8s.io/v1/subjectaccessreviews"],
        input_text=json.dumps(body),
        timeout=30,
    )
    if r.returncode != 0:
        return None, (r.stderr or r.stdout or "SubjectAccessReview request failed").strip()
    try:
        return json.loads(r.stdout), None
    except json.JSONDecodeError:
        return None, "SubjectAccessReview response is not valid JSON"


def _find_tenant_namespace() -> str | None:
    r = kubectl_run(["get", "ns", "-o", "jsonpath={range .items[*]}{.metadata.name}{\"\\n\"}{end}"], timeout=30)
    if r.returncode != 0:
        return None
    for ns in (r.stdout or "").splitlines():
        if not ns.startswith(TENANT_NS_PREFIX):
            continue
        chk = kubectl_run(["get", "sa", TENANT_SA_NAME, "-n", ns], timeout=15)
        if chk.returncode == 0:
            return ns
    return None


def _sar_status_allowed(status: dict) -> bool:
    return bool(status.get("allowed"))


def _sar_status_denied(status: dict) -> bool:
    return bool(status.get("denied"))


def _check_sar_policy() -> tuple[bool, str | None]:
    tenant_ns = _find_tenant_namespace()
    if not tenant_ns:
        return False, "no tenant namespace with ns-editor SA for authz SAR health probe"
    user = f"system:serviceaccount:{tenant_ns}:{TENANT_SA_NAME}"

    swarm_get_review, swarm_get_err = _subject_access_review(
        user=user,
        namespace=tenant_ns,
        verb="get",
        resource="secrets",
        name="swarm-pull",
    )
    if swarm_get_err:
        return False, swarm_get_err
    if not swarm_get_review:
        return False, "empty SubjectAccessReview response for swarm-pull get"
    swarm_get_status = swarm_get_review.get("status") or {}
    if _sar_status_denied(swarm_get_status):
        return False, "authz SAR health: unexpected deny on get secret swarm-pull for tenant SA"
    if not _sar_status_allowed(swarm_get_status):
        return False, "authz SAR health: expected allow on get secret swarm-pull for tenant SA"

    swarm_patch_review, swarm_patch_err = _subject_access_review(
        user=user,
        namespace=tenant_ns,
        verb="patch",
        resource="secrets",
        name="swarm-pull",
    )
    if swarm_patch_err:
        return False, swarm_patch_err
    if not swarm_patch_review:
        return False, "empty SubjectAccessReview response for swarm-pull patch"
    swarm_patch_status = swarm_patch_review.get("status") or {}
    if not _sar_status_denied(swarm_patch_status):
        return False, "authz SAR health: expected deny on patch secret swarm-pull for tenant SA"

    non_swarm_review, non_swarm_err = _subject_access_review(
        user=user,
        namespace=tenant_ns,
        verb="get",
        resource="secrets",
        name=SAR_NON_SWARM_SECRET_NAME,
    )
    if non_swarm_err:
        return False, non_swarm_err
    if not non_swarm_review:
        return False, f"empty SubjectAccessReview response for {SAR_NON_SWARM_SECRET_NAME}"
    non_swarm_status = non_swarm_review.get("status") or {}
    if _sar_status_denied(non_swarm_status):
        return False, f"authz SAR health: unexpected deny on get secret {SAR_NON_SWARM_SECRET_NAME}"
    if not _sar_status_allowed(non_swarm_status):
        return False, f"authz SAR health: expected allow on get secret {SAR_NON_SWARM_SECRET_NAME}"
    return True, None


def _check_leader_authorization_config() -> tuple[bool, str | None]:
    if not AUTHZ_CONFIG_DST.is_file():
        return False, f"missing {AUTHZ_CONFIG_DST}"
    if not RKE2_CONFIG_FILE.is_file():
        return False, f"missing {RKE2_CONFIG_FILE}"
    if not rke2_config_has_authorization_config(RKE2_CONFIG_FILE.read_text(encoding="utf-8")):
        return False, "RKE2 config missing authorization-config kube-apiserver-arg"
    return True, None


def health_check_opa_authz_webhook(*, deep: bool = False) -> tuple[bool, str | None]:
    """Returns (ok, postpone_or_error_message). deep=True runs SAR/mTLS/authz-config on control-plane nodes."""
    if os.environ.get("OPA_AUTHZ_DISABLED", "").strip() in ("1", "true", "yes"):
        return True, None
    if not RKE2_KUBECONFIG.exists():
        return False, "kubeconfig missing"

    exists_ok, exists_err = _deployment_exists()
    if not exists_ok:
        return False, exists_err
    if not deep:
        return True, None

    ready_ok, ready_err = _deployment_ready_quick()
    if not ready_ok:
        return False, ready_err

    mtls_ok, mtls_err = _probe_adapter_healthz_mtls()
    if not mtls_ok:
        return False, mtls_err

    sar_ok, sar_err = _check_sar_policy()
    if not sar_ok:
        return False, sar_err

    authz_ok, authz_err = _check_leader_authorization_config()
    if not authz_ok:
        return False, authz_err

    return True, None
