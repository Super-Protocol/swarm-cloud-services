#!/usr/bin/env python3
"""Unit tests for swarm-cloud-api/main.py — the rendered /etc/swarm-cloud-api/config.yaml.

A real node never reads `conf/api.yaml`; it reads what `create_config_file` renders here.
SUP-368: `kubeEventSync` was added to the compose config and to the Zod schema (whose
default is `enabled: false`) but not to this renderer, so the worker logged "disabled by
config" on every cluster and `clusterSpaceEvents` could only ever answer from the API
server's own 1h window. The drift test below is the guard: any worker the schema knows
about must appear in the rendered block.

    cd services/swarm-cloud-api && python3 -m unittest test_main -v
"""

import re
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent
WORKERS_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/workers/workers.config.ts"
DB_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/db/config.ts"

sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    # main.py imports the plugin SDK at module scope and instantiates a ProvisionPlugin.
    # None of the config rendering needs it, so a stub keeps the SDK off the test host.
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0-test"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

LOCAL_NODE_ID = "node-1"
PEER_NODE_ID = "node-2"


def build_state(leader_node_id: str) -> dict:
    return {
        "cluster": {"leader_node": leader_node_id},
        "wgNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.1"},
            {"node_id": PEER_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.2"},
        ],
        "cockroachClusterNodes": [{"node_id": LOCAL_NODE_ID}, {"node_id": PEER_NODE_ID}],
        "cockroachNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"},
        ],
        "globalId": "abc123",
        "baseDomain": "swarm.superprotocol.dev",
    }


def render_config(leader_node_id: str) -> dict:
    """Render config.yaml the way the plugin does on a node and parse it back."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "swarm-cloud-api" / "config.yaml"
        original = main.API_CONFIG_FILE
        original_probe = main.is_cockroach_endpoint_reachable
        main.API_CONFIG_FILE = config_path
        # The renderer TCP-probes CockroachDB candidates; no test host answers on 26257.
        main.is_cockroach_endpoint_reachable = lambda *_args, **_kwargs: True
        try:
            main.create_config_file(
                LOCAL_NODE_ID, build_state(leader_node_id), "http://10.10.0.1:3002"
            )
            return yaml.safe_load(config_path.read_text())
        finally:
            main.API_CONFIG_FILE = original
            main.is_cockroach_endpoint_reachable = original_probe


def schema_worker_keys() -> set[str]:
    """The worker names WorkersConfigSchema declares, read straight off the Zod schema."""
    source = WORKERS_CONFIG_TS.read_text()
    body = re.search(
        r"export const WorkersConfigSchema = BaseConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find WorkersConfigSchema in {WORKERS_CONFIG_TS}"
    return set(re.findall(r"^  (\w+):", body.group(1), re.MULTILINE))


class RenderedWorkersTest(unittest.TestCase):
    def test_every_worker_in_the_schema_is_rendered(self):
        """A worker the renderer forgets defaults to enabled:false and silently never runs."""
        rendered = render_config(LOCAL_NODE_ID)["workers"]
        missing = schema_worker_keys() - set(rendered)
        self.assertEqual(
            set(),
            missing,
            f"workers declared in workers.config.ts but absent from the rendered config: {sorted(missing)}",
        )

    def test_kube_event_sync_runs_on_the_leader(self):
        workers = render_config(LOCAL_NODE_ID)["workers"]
        self.assertEqual(
            {"enabled": True, "checkInterval": 30000, "retentionHours": 48},
            workers["kubeEventSync"],
        )

    def test_workers_are_leader_gated(self):
        """Every worker — kubeEventSync included — is off on a follower node."""
        workers = render_config(PEER_NODE_ID)["workers"]
        self.assertFalse(workers["kubeEventSync"]["enabled"])
        for name, worker in workers.items():
            self.assertFalse(worker["enabled"], f"{name} must not run on a follower")


def postgres_timeout_keys() -> set[str]:
    """The `*TimeoutMs` bounds PostgresqlConfigSchema declares, read off the Zod schema."""
    source = DB_CONFIG_TS.read_text()
    body = re.search(
        r"export const PostgresqlConfigSchema = BaseDbConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find PostgresqlConfigSchema in {DB_CONFIG_TS}"
    return {name for name in re.findall(r"^  (\w+):", body.group(1), re.MULTILINE) if name.endswith("TimeoutMs")}


class RenderedDbBoundsTest(unittest.TestCase):
    """SUP-759: an unbounded primary-database pool turns an unreachable CockroachDB into an
    indefinite hang on every request that touches it, authenticated or not."""

    def test_every_timeout_the_schema_declares_is_rendered(self):
        rendered = render_config(LOCAL_NODE_ID)["db"]["config"]
        for key in postgres_timeout_keys():
            self.assertIn(key, rendered, f"{key} is declared by the schema but not rendered")

    def test_the_rendered_timeouts_are_positive(self):
        rendered = render_config(LOCAL_NODE_ID)["db"]["config"]
        for key in ("connectTimeoutMs", "queryTimeoutMs"):
            # 0 is how node-postgres spells "wait forever", which is the defect.
            self.assertGreater(rendered[key], 0, f"{key} must bound the wait")


class CockroachEndpointSelectionTest(unittest.TestCase):
    """The rendered host is never re-resolved while the container runs, so picking one that
    does not answer wedges the API until the next provision run."""

    def select(self, state: dict, answers: dict[str, bool]) -> tuple[dict | None, list[tuple[str, int]]]:
        probed: list[tuple[str, int]] = []

        def probe(host: str, port: int) -> bool:
            probed.append((host, port))
            return answers.get(host, False)

        return main.get_cockroach_connection_info(LOCAL_NODE_ID, state, probe=probe), probed

    def test_prefers_the_local_node_when_it_answers(self):
        info, probed = self.select(build_state(LOCAL_NODE_ID), {"10.10.0.1": True})

        self.assertEqual(info["host"], "10.10.0.1")
        self.assertEqual(info["port"], main.COCKROACH_SQL_PORT)
        self.assertEqual(probed, [("10.10.0.1", main.COCKROACH_SQL_PORT)])

    def test_skips_a_ready_node_that_does_not_answer(self):
        """A node rebuilt onto a new WireGuard IP leaves `cockroachdb_node_ready` behind on its
        old identity; that stale row is what must not be rendered."""
        state = build_state(LOCAL_NODE_ID)
        state["cockroachNodeProperties"].append(
            {"node_id": PEER_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"}
        )

        info, probed = self.select(state, {"10.10.0.2": True})

        self.assertEqual(info["host"], "10.10.0.2")
        self.assertEqual(
            probed,
            [("10.10.0.1", main.COCKROACH_SQL_PORT), ("10.10.0.2", main.COCKROACH_SQL_PORT)],
        )

    def test_falls_back_to_the_preferred_candidate_when_nothing_answers(self):
        """The probe may itself be wrong — a mesh still settling — so provisioning continues on
        the preferred host rather than failing the plugin."""
        info, _ = self.select(build_state(LOCAL_NODE_ID), {})

        self.assertEqual(info["host"], "10.10.0.1")

    def test_ignores_a_node_that_is_not_ready(self):
        state = build_state(LOCAL_NODE_ID)
        state["cockroachNodeProperties"] = []

        info, probed = self.select(state, {"10.10.0.1": True, "10.10.0.2": True})

        self.assertIsNone(info)
        self.assertEqual(probed, [])

    def test_ignores_a_ready_node_with_no_tunnel_ip(self):
        state = build_state(LOCAL_NODE_ID)
        state["wgNodeProperties"] = []

        info, probed = self.select(state, {"10.10.0.1": True})

        self.assertIsNone(info)
        self.assertEqual(probed, [])

    def test_probes_each_candidate_once(self):
        state = build_state(LOCAL_NODE_ID)
        state["cockroachClusterNodes"].append({"node_id": LOCAL_NODE_ID})

        _, probed = self.select(state, {})

        self.assertEqual(probed.count(("10.10.0.1", main.COCKROACH_SQL_PORT)), 1)


if __name__ == "__main__":
    unittest.main()
