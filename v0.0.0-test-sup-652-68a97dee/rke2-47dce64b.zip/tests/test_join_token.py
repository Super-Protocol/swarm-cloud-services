"""Unit tests for the RKE2 cluster join token (SUP-652).

The token used to be a hardcoded default in main.py. It now comes from the
`rke2_join_token` SwarmSecret, and a node that is already configured keeps the
token its etcd bootstrap data was sealed with.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from unittest.mock import patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"

for _path in (str(RKE2_DIR), str(SDK_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from provision_plugin_sdk import PluginInput  # noqa: E402  (needs the paths above)

# Stands in for whatever token a cluster was already bootstrapped with,
# including the hardcoded default this change removed.
BOOTSTRAPPED_TOKEN = "already-bootstrapped-with-this-one"
SECRET_TOKEN = "f0d1e2c3b4a5968778695a4b3c2d1e0ff0d1e2c3b4a5968778695a4b3c2d1e0f"


def _load_main_module():
    spec = importlib.util.spec_from_file_location("rke2_main_join_token", RKE2_DIR / "main.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _state(*, with_secret: bool = True) -> dict:
    """Minimal state for one bootstrap node, shaped like the manifest projection."""
    secrets = [{"id": "base_domain", "value": "example.test"}]
    if with_secret:
        secrets.append({"id": "rke2_join_token", "value": SECRET_TOKEN})
    return {
        "globalId": "g1",
        "cluster": {"id": "cluster-1", "cluster_policy": "rke2", "leader_node": "node-1"},
        "clusterNodes": [{"id": "cluster-1:node-1", "node_id": "node-1", "cluster": "cluster-1"}],
        "rke2NodeProperties": [],
        "wgNodeProperties": [
            {"cluster_node": "wg-1:node-1", "name": "tunnel_ip", "value": "10.10.0.1", "node_id": "node-1"}
        ],
        "clusterProperties": [],
        "swarmSecrets": secrets,
    }


def _config_file(tmp_path: Path, token: str | None) -> Path:
    config = tmp_path / "config.yaml"
    if token is not None:
        config.write_text(f"token: {token}\nnode-ip: 10.10.0.1\ncni: canal\n")
    return config


def test_no_hardcoded_default_token():
    """Nothing in the module stands in for a missing token."""
    module = _load_main_module()
    assert not hasattr(module, "RKE2_TOKEN")

    with (
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "read_existing_rke2_token", return_value=None),
    ):
        token, source = module.resolve_join_token(_state(with_secret=False))

    assert token is None
    assert source == "unavailable"


def test_token_from_swarm_secret_is_written_to_config(tmp_path):
    """Token present in shared state → it lands in the RKE2 config."""
    module = _load_main_module()
    config = _config_file(tmp_path, None)

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        token, source = module.resolve_join_token(_state())
        assert token == SECRET_TOKEN
        assert source == "SwarmSecrets.rke2_join_token"

        module.write_rke2_config(
            local_node_id="node-1",
            local_tunnel_ip="10.10.0.1",
            is_bootstrap=True,
            leader_tunnel_ip=None,
            all_tunnel_ips=["10.10.0.1"],
            join_token=token,
            k8s_domain=None,
        )

    assert config.read_text().splitlines()[0] == f"token: {SECRET_TOKEN}"


def test_missing_token_postpones_apply(tmp_path):
    """Token absent → postponed apply, never a fallback value."""
    module = _load_main_module()
    config = _config_file(tmp_path, None)

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        output = module.handle_apply(
            PluginInput(
                command="apply",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            )
        )

    assert output.status == "postponed"
    assert "rke2_join_token" in (output.error_message or "")
    assert not config.exists()


def test_existing_config_token_wins_and_keeps_install_hash_stable(tmp_path):
    """A configured node keeps its token, so moving to SwarmSecrets reinstalls nothing."""
    module = _load_main_module()
    config = _config_file(tmp_path, BOOTSTRAPPED_TOKEN)
    state = _state()

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        token, source = module.resolve_join_token(state)

    assert token == BOOTSTRAPPED_TOKEN
    assert source == "local config"
    assert module.compute_install_hash(state, module.RKE2_VERSION, token) == module.compute_install_hash(
        state, module.RKE2_VERSION, BOOTSTRAPPED_TOKEN
    )


def test_env_override_used_only_when_no_config_token(tmp_path):
    module = _load_main_module()
    config_with_token = _config_file(tmp_path, BOOTSTRAPPED_TOKEN)

    with (
        patch.object(module, "RKE2_CONFIG_FILE", config_with_token),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", "from-env"),
    ):
        assert module.resolve_join_token(_state())[0] == BOOTSTRAPPED_TOKEN

    with (
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "absent.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", "from-env"),
    ):
        token, source = module.resolve_join_token(_state())

    assert token == "from-env"
    assert source == "RKE2_TOKEN environment override"


def test_read_existing_rke2_token(tmp_path):
    module = _load_main_module()

    assert module.read_existing_rke2_token(tmp_path / "absent.yaml") is None
    assert module.read_existing_rke2_token(_config_file(tmp_path, BOOTSTRAPPED_TOKEN)) == BOOTSTRAPPED_TOKEN

    without_token = tmp_path / "no-token.yaml"
    without_token.write_text("node-ip: 10.10.0.1\ncni: canal\n")
    assert module.read_existing_rke2_token(without_token) is None

    # A token line with an empty value is as good as no token at all.
    blank = tmp_path / "blank.yaml"
    blank.write_text("token:\ncni: canal\n")
    assert module.read_existing_rke2_token(blank) is None


def test_write_rke2_config_refuses_an_empty_token(tmp_path):
    module = _load_main_module()
    config = tmp_path / "config.yaml"

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
    ):
        try:
            module.write_rke2_config("node-1", "10.10.0.1", True, None, ["10.10.0.1"], "", None)
        except ValueError as exc:
            assert "join token" in str(exc)
        else:  # pragma: no cover - the guard must fire
            raise AssertionError("write_rke2_config accepted an empty token")

    assert not config.exists()
