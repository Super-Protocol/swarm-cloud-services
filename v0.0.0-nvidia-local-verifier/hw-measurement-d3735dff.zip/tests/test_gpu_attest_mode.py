"""GPU attestation mode is taken from the node certificate extension."""

import base64

from test_gpu_labels import _load_main_module


def _extension(mode: int) -> bytes:
    oid = bytes((0x2B, 0x06, 0x01, 0x03, 0xC5, 0x38, 0x01, 0x04, 0x01))
    payload = bytes((0x10, mode))
    return oid + bytes((0x04, len(payload))) + payload


def test_local_and_remote_modes():
    m = _load_main_module()
    assert m.gpu_attest_mode_from_der(_extension(2)) == "local"
    assert m.gpu_attest_mode_from_der(_extension(1)) == "remote"
    assert m.gpu_attest_mode_from_der(_extension(0)) is None


def test_nested_gpu_fields_do_not_hide_the_mode():
    m = _load_main_module()
    nested = bytes((0x0A, 0x04, 0x12, 0x02, 0x61, 0x62, 0x10, 0x02))
    assert m.gpu_attest_mode_from_extension(nested) == "local"


def test_read_gpu_attest_mode_from_pem(tmp_path):
    m = _load_main_module()
    der = _extension(2)
    pem = "-----BEGIN CERTIFICATE-----\n" + base64.b64encode(der).decode() + "\n-----END CERTIFICATE-----\n"
    cert = tmp_path / "node_cert.pem"
    cert.write_text(pem)
    assert m.read_gpu_attest_mode([str(tmp_path)]) == "local"
