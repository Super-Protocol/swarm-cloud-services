#!/usr/bin/env python3
"""Unit tests for harbor/main.py teardown helpers (SUP-672)."""

import sys
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda **_kwargs: {}
    stub.read_manifest_version = lambda _path: "1.0.0"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

from provision_plugin_sdk import PluginInput  # noqa: E402


def _completed(returncode: int = 0, stdout: str = "", stderr: str = ""):
    return mock.Mock(returncode=returncode, stdout=stdout, stderr=stderr)


# `systemctl is-active` on a unit systemd does not know about.
_NOT_LOADED = _completed(returncode=4, stderr="Unit harbor.service could not be found.\n", stdout="inactive\n")
_ACTIVE = _completed(returncode=0, stdout="active\n")
_INACTIVE = _completed(returncode=3, stdout="inactive\n")
# `systemctl stop` on a unit that was never installed.
_STOP_NOT_LOADED = _completed(returncode=5, stderr="Failed to stop harbor.service: Unit harbor.service not loaded.\n")


class _Systemctl:
    """Records systemctl invocations and answers them from a per-verb script."""

    def __init__(self, **by_verb):
        self.calls: list[tuple[str, ...]] = []
        self._by_verb = by_verb

    def __call__(self, *args, **_kwargs):
        self.calls.append(args)
        answer = self._by_verb.get(args[0], _completed())
        if isinstance(answer, list):
            return answer.pop(0) if answer else _completed()
        return answer

    def verbs(self) -> list[str]:
        return [call[0] for call in self.calls]


class HarborUnitInstalledTests(unittest.TestCase):
    def test_true_when_unit_file_present(self):
        with mock.patch.object(main.Path, "exists", return_value=True):
            self.assertTrue(main.harbor_unit_installed())

    def test_false_when_unit_file_absent(self):
        with mock.patch.object(main.Path, "exists", return_value=False):
            self.assertFalse(main.harbor_unit_installed())


class HarborIsActiveTests(unittest.TestCase):
    def test_true_only_on_exact_active(self):
        with mock.patch.object(main, "systemctl", return_value=_ACTIVE):
            self.assertTrue(main.harbor_is_active())

    def test_false_when_inactive(self):
        with mock.patch.object(main, "systemctl", return_value=_INACTIVE):
            self.assertFalse(main.harbor_is_active())

    def test_false_when_unit_unknown(self):
        with mock.patch.object(main, "systemctl", return_value=_NOT_LOADED):
            self.assertFalse(main.harbor_is_active())

    def test_activating_is_not_active(self):
        # `"active" in "activating"` is true, so a substring check would misreport this.
        with mock.patch.object(main, "systemctl", return_value=_completed(returncode=0, stdout="activating\n")):
            self.assertFalse(main.harbor_is_active())


class StopAndDisableHarborTests(unittest.TestCase):
    def test_noop_when_unit_never_installed(self):
        """SUP-672: a node that never became leader has nothing to stop."""
        systemctl = _Systemctl(**{"is-active": _NOT_LOADED, "stop": _STOP_NOT_LOADED})
        with mock.patch.object(main, "harbor_unit_installed", return_value=False):
            with mock.patch.object(main, "systemctl", systemctl):
                main._stop_and_disable_harbor()
        self.assertEqual(systemctl.verbs(), ["is-active"])

    def test_stops_and_disables_when_unit_installed(self):
        systemctl = _Systemctl()
        with mock.patch.object(main, "harbor_unit_installed", return_value=True):
            with mock.patch.object(main, "systemctl", systemctl):
                main._stop_and_disable_harbor()
        self.assertEqual(systemctl.verbs(), ["stop", "disable"])

    def test_raises_when_stop_fails_on_an_installed_unit(self):
        systemctl = _Systemctl(stop=_completed(returncode=1, stderr="podman-compose down failed"))
        with mock.patch.object(main, "harbor_unit_installed", return_value=True):
            with mock.patch.object(main, "systemctl", systemctl):
                with self.assertRaises(RuntimeError) as raised:
                    main._stop_and_disable_harbor()
        self.assertIn("systemctl stop harbor failed", str(raised.exception))
        self.assertIn("podman-compose down failed", str(raised.exception))
        self.assertNotIn("disable", systemctl.verbs())

    def test_raises_when_disable_fails_on_an_installed_unit(self):
        systemctl = _Systemctl(disable=_completed(returncode=1, stderr="Failed to disable unit"))
        with mock.patch.object(main, "harbor_unit_installed", return_value=True):
            with mock.patch.object(main, "systemctl", systemctl):
                with self.assertRaises(RuntimeError) as raised:
                    main._stop_and_disable_harbor()
        self.assertIn("systemctl disable harbor failed", str(raised.exception))

    def test_stops_stale_service_whose_unit_file_is_gone(self):
        systemctl = _Systemctl(**{"is-active": [_ACTIVE, _INACTIVE]})
        with mock.patch.object(main, "harbor_unit_installed", return_value=False):
            with mock.patch.object(main, "systemctl", systemctl):
                main._stop_and_disable_harbor()
        self.assertEqual(systemctl.verbs(), ["is-active", "stop", "is-active"])

    def test_raises_when_stale_service_will_not_stop(self):
        systemctl = _Systemctl(**{"is-active": _ACTIVE, "stop": _STOP_NOT_LOADED})
        with mock.patch.object(main, "harbor_unit_installed", return_value=False):
            with mock.patch.object(main, "systemctl", systemctl):
                with self.assertRaises(RuntimeError) as raised:
                    main._stop_and_disable_harbor()
        self.assertIn("unit file is gone", str(raised.exception))


class LeavePathCommandTests(unittest.TestCase):
    """finalize and destroy must both report success on a node that never ran Harbor."""

    def _input(self) -> PluginInput:
        return PluginInput(local_node_id="node-1", state={}, local_state={})

    def test_finalize_completed_when_unit_not_loaded(self):
        systemctl = _Systemctl(**{"is-active": _NOT_LOADED, "stop": _STOP_NOT_LOADED})
        with mock.patch.object(main, "harbor_unit_installed", return_value=False):
            with mock.patch.object(main, "systemctl", systemctl):
                out = main.handle_finalize(self._input())
        self.assertEqual(out.status, "completed")

    def test_destroy_completed_when_unit_not_loaded(self):
        systemctl = _Systemctl(**{"is-active": _NOT_LOADED, "stop": _STOP_NOT_LOADED})
        with mock.patch.object(main, "harbor_unit_installed", return_value=False):
            with mock.patch.object(main, "systemctl", systemctl):
                out = main.handle_destroy(self._input())
        self.assertEqual(out.status, "completed")

    def test_finalize_errors_when_harbor_cannot_be_stopped(self):
        systemctl = _Systemctl(stop=_completed(returncode=1, stderr="stop failed"))
        with mock.patch.object(main, "harbor_unit_installed", return_value=True):
            with mock.patch.object(main, "systemctl", systemctl):
                out = main.handle_finalize(self._input())
        self.assertEqual(out.status, "error")
        self.assertIn("systemctl stop harbor failed", out.error_message)


if __name__ == "__main__":
    unittest.main()
