#!/usr/bin/env python3
"""
Harbor provision plugin: generates config files and podman-compose from embedded
templates, manages stack via systemd (podman-compose up/down).
"""

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

sys.path.insert(0, str(Path(__file__).parent))
from helpers import (
    HARBOR_ADMIN_PASSWORD,
    HARBOR_ADMIN_USERNAME,
    HARBOR_IMAGE_TAG,
    HARBOR_PROXY_PORT,
    get_local_tunnel_ip,
    get_sentinel_tunnel_ips,
    write_embedded_files,
)

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------
HARBOR_INSTALL_DIR = Path("/opt/harbor")
SYSTEMD_UNIT_PATH = "/etc/systemd/system/harbor.service"
IMAGE_REGISTRY = "docker.io"
# UID/GID of postgres user in goharbor/harbor-db (data/database)
POSTGRES_DATA_UID = 999
POSTGRES_DATA_GID = 999
# UID/GID of harbor user in goharbor/registry-photon (so registry can write to data/registry)
REGISTRY_DATA_UID = 10000
REGISTRY_DATA_GID = 10000


plugin = ProvisionPlugin()


def get_leader_node(state: dict) -> str | None:
    """Get leader node ID from cluster."""
    cluster = state.get("cluster", {}) if state else {}
    return cluster.get("leader_node")


def is_local_node_leader(local_node_id: str | None, state: dict) -> bool:
    """Return True if local node is the cluster leader."""
    leader = get_leader_node(state)
    return leader is not None and local_node_id == leader


def check_podman() -> str | None:
    """Check for podman and podman-compose in PATH; verify podman-compose runs. Return error message or None."""
    if not shutil.which("podman"):
        return "podman not found in PATH"
    if not shutil.which("podman-compose"):
        return "podman-compose not found in PATH"
    result = subprocess.run(
        ["podman-compose", "version"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if result.returncode != 0:
        return "podman-compose version failed (run: podman-compose version)"
    return None


# Data dirs owned by 999:999 (postgres)
_DATA_DIRS_UID_999 = ("data/database",)
# Data dirs owned by 10000:10000 (registry, core, jobservice)
_DATA_DIRS_UID_10000 = (
    "data/registry",
    "data/ca_download",
    "data/job_logs",
    "data/secret/core",
    "data/secret/keys",
)


def ensure_dirs(install_dir: Path) -> None:
    """Create install and data directories and set ownership for container writable dirs."""
    install_dir.mkdir(parents=True, exist_ok=True)
    for sub in ("data/registry", "data/database", "data/ca_download",
                "data/job_logs", "data/secret/core", "data/secret/keys"):
        (install_dir / sub).mkdir(parents=True, exist_ok=True)
    for rel in _DATA_DIRS_UID_999:
        path = install_dir / rel
        if path.exists():
            r = subprocess.run(
                ["chown", "-R", f"{POSTGRES_DATA_UID}:{POSTGRES_DATA_GID}", str(path)],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
            if r.returncode != 0:
                raise RuntimeError(
                    f"chown failed for {path} (uid:gid={POSTGRES_DATA_UID}:{POSTGRES_DATA_GID}): "
                    f"{r.stderr or r.stdout or 'unknown error'}"
                )
    for rel in _DATA_DIRS_UID_10000:
        path = install_dir / rel
        if path.exists():
            r = subprocess.run(
                ["chown", "-R", f"{REGISTRY_DATA_UID}:{REGISTRY_DATA_GID}", str(path)],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
            if r.returncode != 0:
                raise RuntimeError(
                    f"chown failed for {path} (uid:gid={REGISTRY_DATA_UID}:{REGISTRY_DATA_GID}): "
                    f"{r.stderr or r.stdout or 'unknown error'}"
                )


def write_systemd_unit(install_dir: Path) -> None:
    """Write harbor.service unit file."""
    unit_content = f"""[Unit]
Description=Harbor (podman-compose)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory={install_dir}
ExecStart=podman-compose up -d
ExecStop=podman-compose down
User=root
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    Path(SYSTEMD_UNIT_PATH).write_text(unit_content, encoding="utf-8")


def systemctl(*args: str, timeout: int = 60) -> subprocess.CompletedProcess:
    """Run systemctl with given args."""
    return subprocess.run(
        ["systemctl", *args],
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def wait_for_harbor_ready(local_tunnel_ip: str, timeout_sec: int = 600) -> bool:
    """Wait for Harbor to be ready (systemd active and HTTP health on WireGuard tunnel IP)."""
    start = time.time()
    while time.time() - start < timeout_sec:
        r = systemctl("is-active", "harbor", timeout=5)
        if r.returncode == 0 and r.stdout and "active" in r.stdout:
            try:
                check = subprocess.run(
                    ["curl", "-sf", f"http://{local_tunnel_ip}:{HARBOR_PROXY_PORT}/api/v2.0/health"],
                    capture_output=True,
                    timeout=10,
                )
                if check.returncode == 0:
                    return True
            except FileNotFoundError:
                raise RuntimeError("curl not available for readiness check")
            except subprocess.TimeoutExpired:
                pass
        time.sleep(5)
    return False


@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Create directories and verify podman is available."""
    try:
        err = check_podman()
        if err:
            return PluginOutput(status="error", error_message=err)
        ensure_dirs(HARBOR_INSTALL_DIR)
        return PluginOutput(status="completed", local_state={"initialized": True})
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e))


@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Generate files from embedded templates and start Harbor via systemd (leader only)."""
    try:
        state = input_data.state or {}
        if not is_local_node_leader(input_data.local_node_id, state):
            return PluginOutput(status="completed")

        local_tunnel_ip = get_local_tunnel_ip(state, input_data.local_node_id)
        if not local_tunnel_ip:
            return PluginOutput(
                status="postponed",
                error_message="Waiting for WireGuard to be configured on local node",
            )

        err = check_podman()
        if err:
            return PluginOutput(status="error", error_message=err)

        sentinel_ips = get_sentinel_tunnel_ips(state)
        if not sentinel_ips:
            return PluginOutput(
                status="postponed",
                error_message=(
                    "Harbor Redis: no Sentinel endpoints (need redis_sentinel_node_ready on sentinel nodes "
                    "and matching tunnel_ip in sentinelWgNodeProperties)"
                ),
            )

        ensure_dirs(HARBOR_INSTALL_DIR)
        write_embedded_files(
            HARBOR_INSTALL_DIR,
            input_data,
            local_tunnel_ip,
            sentinel_ips,
            IMAGE_REGISTRY,
        )
        write_systemd_unit(HARBOR_INSTALL_DIR)

        r = systemctl("daemon-reload")
        if r.returncode != 0:
            return PluginOutput(
                status="error",
                error_message=f"systemctl daemon-reload failed: {r.stderr or r.stdout}",
            )
        r = systemctl("enable", "harbor")
        if r.returncode != 0:
            return PluginOutput(
                status="error",
                error_message=f"systemctl enable harbor failed: {r.stderr or r.stdout}",
            )
        r = systemctl("start", "harbor", timeout=900)
        if r.returncode != 0:
            return PluginOutput(
                status="error",
                error_message=f"systemctl start harbor failed: {r.stderr or r.stdout}",
            )
        if not wait_for_harbor_ready(local_tunnel_ip, 600):
            return PluginOutput(status="error", error_message="Harbor did not become ready within 600s")

        # SP-7700: publish image identity for the control-plane evidence aggregator.
        # Harbor is a multi-image stack run via podman-compose; we report the
        # core image as the canonical reference — every other Harbor image
        # uses the same tag (`HARBOR_IMAGE_TAG`) and changing it republishes
        # the digest in the next aggregator tick.
        node_properties = {"harbor_ready": "true"}
        node_properties.update(
            build_image_evidence_props(
                prefix="harbor",
                image_ref=f"{IMAGE_REGISTRY}/goharbor/harbor-core:{HARBOR_IMAGE_TAG}",
                manifest_version=read_manifest_version(Path(__file__).parent),
            )
        )
        return PluginOutput(
            status="completed",
            node_properties=node_properties,
            cluster_properties={
                "harbor_endpoint": f"http://{local_tunnel_ip}:{HARBOR_PROXY_PORT}",
                "harbor_admin_username": HARBOR_ADMIN_USERNAME,
                "harbor_admin_password": HARBOR_ADMIN_PASSWORD,
            },
            local_state={"last_applied": str(int(time.time()))},
        )
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e))


@plugin.command("health")
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check Harbor service and HTTP health on WireGuard tunnel IP (same style as Redis/CockroachDB)."""
    try:
        state = input_data.state or {}
        if not is_local_node_leader(input_data.local_node_id, state):
            return PluginOutput(status="completed")

        local_tunnel_ip = get_local_tunnel_ip(state, input_data.local_node_id)
        if not local_tunnel_ip:
            return PluginOutput(
                status="postponed",
                error_message="Local node has no WireGuard tunnel IP",
            )

        r = systemctl("is-active", "harbor", timeout=10)
        if r.returncode != 0 or not (r.stdout and "active" in r.stdout):
            return PluginOutput(
                status="error",
                error_message=f"harbor service not active: {r.stdout or r.stderr}",
            )
        try:
            check = subprocess.run(
                ["curl", "-sf", f"http://{local_tunnel_ip}:{HARBOR_PROXY_PORT}/api/v2.0/health"],
                capture_output=True,
                timeout=10,
            )
            if check.returncode != 0:
                return PluginOutput(status="error", error_message="Harbor health endpoint returned non-zero")
        except FileNotFoundError:
            return PluginOutput(
                status="error",
                error_message="curl not available for health check",
            )
        return PluginOutput(status="completed")
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e))


def harbor_unit_installed() -> bool:
    """Return True if this host has the harbor systemd unit file.

    `apply` writes it on the cluster leader only, so on any other node there has never
    been anything for the leave path to stop.
    """
    return Path(SYSTEMD_UNIT_PATH).exists()


def harbor_is_active() -> bool:
    """Return True if systemd reports harbor.service as running."""
    r = systemctl("is-active", "harbor", timeout=10)
    return r.returncode == 0 and (r.stdout or "").strip() == "active"


def _stop_and_disable_harbor() -> None:
    """Stop Harbor service and disable the systemd unit. Shared teardown for finalize and destroy.

    Idempotent on purpose. `apply` installs the unit on the cluster leader only, so on every
    other node there is nothing to stop and `systemctl stop` exits non-zero with "Unit
    harbor.service not loaded". That used to fail finalize and then the last-resort destroy,
    leaving the leave path unable to reach a terminal state (SUP-672). A host without the
    unit is therefore already torn down; where the unit does exist, a failing stop or disable
    is still a hard failure.
    """
    if not harbor_unit_installed():
        if not harbor_is_active():
            return
        # Unit file gone while systemd still has the service loaded (manual intervention):
        # systemctl cannot act on a unit it cannot read, so judge by the post-condition.
        systemctl("stop", "harbor", timeout=120)
        if harbor_is_active():
            raise RuntimeError("harbor is still active but its systemd unit file is gone")
        return

    stop = systemctl("stop", "harbor", timeout=120)
    if stop.returncode != 0:
        raise RuntimeError(f"systemctl stop harbor failed: {stop.stderr or stop.stdout or 'unknown error'}")
    disable = systemctl("disable", "harbor")
    if disable.returncode != 0:
        raise RuntimeError(
            f"systemctl disable harbor failed: {disable.stderr or disable.stdout or 'unknown error'}"
        )


@plugin.command("finalize")
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize: stop Harbor and disable unit (same teardown as destroy; called earlier in lifecycle)."""
    try:
        _stop_and_disable_harbor()
        return PluginOutput(status="completed")
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e))


@plugin.command("destroy")
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy: stop Harbor and disable unit (same teardown as finalize)."""
    try:
        _stop_and_disable_harbor()
        return PluginOutput(status="completed")
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e))


if __name__ == "__main__":
    plugin.run()
