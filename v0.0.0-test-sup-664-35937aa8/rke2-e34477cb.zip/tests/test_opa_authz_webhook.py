"""Unit tests for OPA authz webhook reconcile (leader vs follower)."""

from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

RKE2_DIR = Path(__file__).resolve().parents[1]


def _load_opa_module():
    mod_path = RKE2_DIR / "opa_authz_webhook.py"
    spec = importlib.util.spec_from_file_location("opa_authz_webhook", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _base_state(*, leader_id: str = "leader-1", local_id: str = "worker-1") -> dict:
    return {
        "cluster": {"leader_node": leader_id},
        "rke2NodeProperties": [
            {"node_id": leader_id, "name": "k8s_node_ready", "value": "true"},
            {"node_id": local_id, "name": "k8s_node_ready", "value": "true"},
        ],
    }


def test_follower_reconcile_wires_without_apply():
    module = _load_opa_module()
    state = _base_state()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "apply_namespace_only") as mock_ns,
        patch.object(module, "apply_kustomize") as mock_apply,
        patch.object(module, "wire_rke2_apiserver_if_needed", return_value=(None, {"wired": True})) as mock_wire,
        patch.object(module, "kubectl_run") as mock_kubectl,
        patch.object(module, "wait_opa_authz_workload_ready", return_value=(True, None)) as mock_wait,
        patch.object(module, "_local_opa_authz_pod_ready", return_value=(True, None)),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        mock_kubectl.return_value = MagicMock(returncode=0)

        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "worker-1",
            {"api_ready": True},
            is_leader=False,
            is_bootstrap=False,
            require_swarm_k8s_node_ready=True,
        )

    assert msg is None
    assert props == {"opa_authz_webhook_ready": "true"}
    assert st == {"wired": True}
    mock_ns.assert_not_called()
    mock_apply.assert_not_called()
    mock_wire.assert_called_once()
    mock_wait.assert_called_once()


def test_leader_reconcile_applies_and_wires():
    module = _load_opa_module()
    state = _base_state(local_id="leader-1")

    with (
        patch.object(module, "apply_namespace_only", return_value=(True, None)),
        patch.object(module, "ensure_tls_secret_leader", return_value=(True, None)),
        patch.object(module, "remove_legacy_opa_deployment"),
        patch.object(module, "apply_kustomize", return_value=(True, None)) as mock_apply,
        patch.object(module, "wait_opa_authz_workload_ready", return_value=(True, None)),
        patch.object(module, "_local_opa_authz_pod_ready", return_value=(True, None)),
        patch.object(module, "wire_rke2_apiserver_if_needed", return_value=(None, {"wired": True})) as mock_wire,
    ):
        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "leader-1",
            {},
            is_leader=True,
            is_bootstrap=True,
            require_swarm_k8s_node_ready=True,
        )

    assert msg is None
    assert props == {"opa_authz_webhook_ready": "true"}
    assert st == {"wired": True}
    mock_apply.assert_called_once()
    mock_wire.assert_called_once()


def test_follower_postpones_until_tls_secret_exists():
    module = _load_opa_module()
    state = _base_state()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "kubectl_run") as mock_kubectl,
        patch.object(module, "wait_opa_authz_workload_ready") as mock_wait,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        mock_kubectl.return_value = MagicMock(returncode=1)

        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "worker-1",
            {},
            is_leader=False,
            is_bootstrap=False,
            require_swarm_k8s_node_ready=True,
        )

    assert msg == "Waiting for opa-authz TLS secret from leader"
    assert props == {}
    assert st == {}
    mock_wait.assert_not_called()


def test_health_check_light_only_requires_deploy():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)) as mock_exists,
        patch.object(module, "_deployment_ready_quick") as mock_ready,
        patch.object(module, "_probe_adapter_healthz_mtls") as mock_mtls,
        patch.object(module, "_check_sar_policy") as mock_sar,
        patch.object(module, "_check_leader_authorization_config") as mock_authz,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=False)

    assert ok is True
    assert err is None
    mock_exists.assert_called_once()
    mock_ready.assert_not_called()
    mock_mtls.assert_not_called()
    mock_sar.assert_not_called()
    mock_authz.assert_not_called()


def test_health_check_deep_runs_all_probes():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)) as mock_ready,
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)) as mock_mtls,
        patch.object(module, "_check_sar_policy", return_value=(True, None)) as mock_sar,
        patch.object(module, "_check_leader_authorization_config", return_value=(True, None)) as mock_authz,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is True
    assert err is None
    mock_ready.assert_called_once()
    mock_mtls.assert_called_once()
    mock_sar.assert_called_once()
    mock_authz.assert_called_once()


def test_health_check_deep_postpones_when_sar_policy_fails():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)),
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)),
        patch.object(
            module,
            "_check_sar_policy",
            return_value=(False, "authz SAR health: expected deny on patch secret swarm-pull for tenant SA"),
        ),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert "swarm-pull" in (err or "")


def test_health_check_deep_postpones_when_adapter_not_ready():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(False, "deployment not ready")),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert err == "deployment not ready"


def test_append_kube_apiserver_authorization_config_inserts_into_existing_block(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text("kube-apiserver-arg:\n  - \"feature-gates=Foo=true\"\n")

    modified = module.append_kube_apiserver_authorization_config(cfg)

    assert modified is True
    text = cfg.read_text()
    assert 'authorization-config=/etc/rancher/rke2/authz-config.yaml' in text
    assert text.index("feature-gates") < text.index("authorization-config")


def test_append_kube_apiserver_authorization_config_appends_new_block(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text("write-kubeconfig-mode: 0644\n")

    modified = module.append_kube_apiserver_authorization_config(cfg)

    assert modified is True
    assert "kube-apiserver-arg:" in cfg.read_text()
    assert "authorization-config=" in cfg.read_text()


def test_append_kube_apiserver_authorization_config_idempotent(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text('kube-apiserver-arg:\n  - "authorization-config=/etc/rancher/rke2/authz-config.yaml"\n')

    assert module.append_kube_apiserver_authorization_config(cfg) is False


def test_health_check_skipped_when_opa_authz_disabled():
    module = _load_opa_module()

    with patch.dict("os.environ", {"OPA_AUTHZ_DISABLED": "true"}):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is True
    assert err is None


def test_health_check_deep_postpones_when_authz_config_missing():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)),
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)),
        patch.object(module, "_check_sar_policy", return_value=(True, None)),
        patch.object(
            module,
            "_check_leader_authorization_config",
            return_value=(False, "RKE2 config missing authorization-config kube-apiserver-arg"),
        ),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert "authorization-config" in (err or "")


def test_probe_adapter_healthz_verifies_certificate_dns_name_over_loopback():
    """The serving cert has no 127.0.0.1 IP SAN: curl must dial loopback but verify the DNS name (SUP-664)."""
    module = _load_opa_module()

    with (
        patch.object(module, "fetch_tls_material_from_cluster", return_value=("ca", "crt", "key")),
        patch.object(module.subprocess, "run", return_value=MagicMock(returncode=0, stdout="ok", stderr="")) as mock_run,
    ):
        ok, err = module._probe_adapter_healthz_mtls()

    assert ok is True
    assert err is None
    argv = mock_run.call_args.args[0]
    name = module.WEBHOOK_TLS_SERVER_NAME
    port = module.OPA_AUTHZ_WEBHOOK_LISTEN_PORT
    assert argv[-1] == f"https://{name}:{port}/healthz"
    assert argv[argv.index("--resolve") + 1] == f"{name}:{port}:127.0.0.1"


def test_probe_adapter_healthz_verified_name_matches_apiserver_kubeconfig(tmp_path):
    """Probe and kube-apiserver must verify the same name, or one of them trusts a cert the other rejects."""
    module = _load_opa_module()
    dest = tmp_path / "authz-webhook.kubeconfig"
    module.render_authz_kubeconfig("ca", "crt", "key", dest)

    assert f"tls-server-name: {module.WEBHOOK_TLS_SERVER_NAME}" in dest.read_text(encoding="utf-8")
    assert module.WEBHOOK_HEALTHZ_URL.startswith(f"https://{module.WEBHOOK_TLS_SERVER_NAME}:")


def test_webhook_serving_cert_carries_the_verified_dns_name():
    """generate-certs.sh must keep a DNS SAN for the name both the apiserver and the probe verify."""
    module = _load_opa_module()
    script = (RKE2_DIR / "configs" / "opa-authz-webhook" / "configs" / "generate-certs.sh").read_text(encoding="utf-8")
    sans = re.findall(r"^DNS\.\d+\s*=\s*(\S+)$", script, re.MULTILINE)

    assert module.WEBHOOK_TLS_SERVER_NAME in sans


def test_probe_adapter_healthz_reports_curl_failure():
    module = _load_opa_module()

    with (
        patch.object(module, "fetch_tls_material_from_cluster", return_value=("ca", "crt", "key")),
        patch.object(
            module.subprocess,
            "run",
            return_value=MagicMock(returncode=7, stdout="", stderr="curl: (7) Failed to connect\n"),
        ),
    ):
        ok, err = module._probe_adapter_healthz_mtls()

    assert ok is False
    assert "Failed to connect" in (err or "")
