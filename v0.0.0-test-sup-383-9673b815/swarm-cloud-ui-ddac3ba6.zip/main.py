#!/usr/bin/env python3

import os
import subprocess
import sys
import time
from pathlib import Path
import yaml

from provision_plugin_sdk import (
    PluginInput, PluginOutput, ProvisionPlugin,
    build_image_evidence_props, read_manifest_version,
)

UI_SERVICE_NAME = "swarm-cloud-ui"
UI_CONTAINER_NAME = "swarm-cloud-ui"
UI_HOST_PORT = 3000
UI_CONTAINER_PORT = 3000
UI_IMAGE_REGISTRY = "ghcr.io"
UI_IMAGE_REPO = "super-protocol/swarm-cloud/swarm-cloud-ui"
DEFAULT_UI_IMAGE_TAG = "latest"

NODE_READY_PROPERTY = "swarm_cloud_ui_node_ready"

plugin = ProvisionPlugin()


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _log_error(msg: str, exc: Exception | None = None) -> None:
    if exc is None:
        log(f"[!] {msg}")
        return
    log(f"[!] {msg}: {exc}")


def _node_ready_props(value: str | None) -> dict:
    return {NODE_READY_PROPERTY: value}


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def get_leader_node(state_json: dict) -> str | None:
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node") if isinstance(cluster, dict) else None


def is_local_node_leader(local_node_id: str, state_json: dict) -> bool:
    return get_leader_node(state_json) == local_node_id


def _normalize_domain(domain: str) -> str:
    d = domain.strip()
    if d.startswith("https://"):
        d = d[len("https://") :]
    elif d.startswith("http://"):
        d = d[len("http://") :]
    return d.strip().strip("/")


def get_swarm_domain_from_state(state_json: dict) -> str:
    swarm_domain = state_json.get("swarmDomain")
    if not isinstance(swarm_domain, str) or not swarm_domain.strip():
        raise ValueError("swarmDomain is missing")
    return swarm_domain.strip()


def build_graphql_endpoints_from_swarm_domain(swarm_domain: str) -> tuple[str, str]:
    host = _normalize_domain(swarm_domain)
    if not host:
        raise ValueError("domain is empty")
    return f"https://{host}/graphql", f"wss://{host}/graphql"


def build_auth_service_url_from_swarm_domain(swarm_domain: str) -> str:
    host = _normalize_domain(swarm_domain)
    if not host:
        raise ValueError("domain is empty")
    return f"https://{host}/api/auth"


def build_gatekeeper_url(service_name: str, global_id: str, base_domain: str) -> str:
    normalized_global_id = global_id.strip()
    normalized_base_domain = _normalize_domain(base_domain)
    if not normalized_global_id:
        raise ValueError("globalId is missing")
    if not normalized_base_domain:
        raise ValueError("baseDomain is missing")
    return f"https://gatekeeper-{service_name}.{normalized_global_id}.{normalized_base_domain}"


def get_image_tag_from_env() -> str:
    tag = os.environ.get("SWARM_CLOUD_UI_TAG")
    if tag:
        return tag

    try:
        manifest_path = Path(__file__).parent / "manifest.yaml"
        if manifest_path.exists():
            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            return manifest.get("version", DEFAULT_UI_IMAGE_TAG)
    except Exception as e:
        print(f"[!] Failed to read manifest version: {e}", file=sys.stderr)

    return DEFAULT_UI_IMAGE_TAG


def get_image_ref_from_tag(tag_or_image: str) -> str:
    if "/" in tag_or_image and ":" in tag_or_image:
        return tag_or_image
    return f"{UI_IMAGE_REGISTRY}/{UI_IMAGE_REPO}:{tag_or_image}"


def pull_ui_image(image_ref: str) -> None:
    log(f"[*] Pulling Docker image: {image_ref}")
    result = subprocess.run(
        ["podman", "pull", image_ref],
        capture_output=True,
        text=True,
        timeout=600,
        check=False,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "podman pull failed").strip()
        raise RuntimeError(err)
    log("[*] Docker image pulled successfully")


def create_systemd_service(
    image_ref: str,
    hostname: str,
    graphql_http: str | None = None,
    graphql_ws: str | None = None,
    auth_service_url: str | None = None,
    s3_gatekeeper_url: str | None = None,
    registry_gatekeeper_url: str | None = None,
    host_port: int = UI_HOST_PORT,
    container_port: int = UI_CONTAINER_PORT,
) -> None:
    if not isinstance(hostname, str) or not hostname.strip():
        raise ValueError("hostname is required (local WireGuard tunnel IP)")

    host_bind_ip = hostname.strip()

    env_args = [
        "-e NODE_ENV=production",
        "-e HOSTNAME=0.0.0.0",
        f"-e PORT={container_port}",
    ]
    if graphql_http:
        env_args.append(f"-e GRAPHQL_HTTP={graphql_http}")
    if graphql_ws:
        env_args.append(f"-e GRAPHQL_WS={graphql_ws}")
    if auth_service_url:
        env_args.append(f"-e NEXT_PUBLIC_AUTH_SERVICE_URL={auth_service_url}")
    if s3_gatekeeper_url:
        env_args.append(f"-e S3_GATEKEEPER_URL={s3_gatekeeper_url}")
    if registry_gatekeeper_url:
        env_args.append(f"-e REGISTRY_GATEKEEPER_URL={registry_gatekeeper_url}")

    env_lines = " \\\n    ".join(env_args)

    service_content = f"""[Unit]
Description=Swarm Cloud UI Service (Podman Container)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=-/usr/bin/podman stop {UI_CONTAINER_NAME}
ExecStartPre=-/usr/bin/podman rm {UI_CONTAINER_NAME}
ExecStart=/usr/bin/podman run \
    --name {UI_CONTAINER_NAME} \
    --rm \
    --network=host \
    {env_lines} \
    {image_ref}
ExecStop=/usr/bin/podman stop {UI_CONTAINER_NAME}
Restart=always
RestartSec=10
User=root
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    service_path = f"/etc/systemd/system/{UI_SERVICE_NAME}.service"
    with open(service_path, "w", encoding="utf-8") as f:
        f.write(service_content)
    subprocess.run(["systemctl", "daemon-reload"], check=True)


def restart_service_unit(service_name: str) -> tuple[bool, str | None]:
    subprocess.run(["systemctl", "enable", service_name], check=False)
    result = subprocess.run(
        ["systemctl", "restart", service_name],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "failed to restart service").strip()
        return False, err
    return True, None


def wait_for_ui_ready(host: str, port: int = UI_HOST_PORT, timeout_sec: int = 60) -> bool:
    start_time = time.time()
    last_error = None
    while time.time() - start_time < timeout_sec:
        try:
            status = subprocess.run(
                ["systemctl", "is-active", UI_SERVICE_NAME],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if status.stdout.strip() != "active":
                last_error = f"Service not active: {status.stdout.strip()}"
                time.sleep(3)
                continue

            probe = subprocess.run(
                ["nc", "-z", host, str(port)],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if probe.returncode == 0:
                log(f"[*] Swarm-cloud-ui is ready and listening on {host}:{port}")
                return True
            last_error = "Port not yet listening"
        except subprocess.TimeoutExpired:
            last_error = "Port check timed out"
        except Exception as e:
            last_error = f"Port check error: {e}"
        time.sleep(3)

    log(f"[!] Swarm-cloud-ui did not become ready within {timeout_sec}s. Last error: {last_error}")
    return False


def is_ui_running() -> tuple[bool, str | None]:
    try:
        result = subprocess.run(
            ["systemctl", "is-active", UI_SERVICE_NAME],
            capture_output=True,
            text=True,
            check=False,
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {e}"


@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}
    try:
        image_tag = get_image_tag_from_env()
        image_ref = get_image_ref_from_tag(image_tag)
        pull_ui_image(image_ref)
        local_state["image_ref"] = image_ref
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e), local_state=local_state)

    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}
    node_properties: dict[str, str | None] = {}

    def out(status: str, error_message: str | None = None) -> PluginOutput:
        return PluginOutput(
            status=status,
            error_message=error_message,
            local_state=local_state,
            node_properties=node_properties,
        )

    if not isinstance(state_json, dict):
        return out(status="error", error_message="Invalid state format")

    try:
        swarm_domain = get_swarm_domain_from_state(state_json)
        graphql_http, graphql_ws = build_graphql_endpoints_from_swarm_domain(swarm_domain)
        auth_service_url = build_auth_service_url_from_swarm_domain(swarm_domain)
        global_id = state_json.get("globalId")
        base_domain = state_json.get("baseDomain")
        if not isinstance(global_id, str) or not global_id.strip():
            raise ValueError("globalId is missing")
        if not isinstance(base_domain, str) or not base_domain.strip():
            raise ValueError("baseDomain is missing")
        s3_gatekeeper_url = build_gatekeeper_url("s3", global_id, base_domain)
        registry_gatekeeper_url = build_gatekeeper_url("harbor", global_id, base_domain)
    except Exception as e:
        return out(status="postponed", error_message=str(e))

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)

    if not (isinstance(cluster_nodes, list) and cluster_nodes):
        return out(status="postponed", error_message="Waiting for dependency clusterNodes")
    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return out(status="postponed", error_message="Waiting for WireGuard to be configured on all nodes")
    if not isinstance(local_tunnel_ip, str) or not local_tunnel_ip.strip():
        return out(status="postponed", error_message="Waiting for WireGuard tunnel IP on local node")

    desired_image_ref = get_image_ref_from_tag(get_image_tag_from_env())
    current_image_ref = local_state.get("image_ref") if isinstance(local_state.get("image_ref"), str) else None

    try:
        if current_image_ref != desired_image_ref:
            pull_ui_image(desired_image_ref)
            local_state["image_ref"] = desired_image_ref

        create_systemd_service(
            image_ref=desired_image_ref,
            hostname=local_tunnel_ip,
            graphql_http=graphql_http,
            graphql_ws=graphql_ws,
            auth_service_url=auth_service_url,
            s3_gatekeeper_url=s3_gatekeeper_url,
            registry_gatekeeper_url=registry_gatekeeper_url,
            host_port=UI_HOST_PORT,
            container_port=UI_CONTAINER_PORT,
        )

        restart_ok, restart_err = restart_service_unit(UI_SERVICE_NAME)
        if not restart_ok:
            return out(status="error", error_message=restart_err)
    except Exception as e:
        return out(status="error", error_message=f"Failed to start swarm-cloud-ui: {e}")

    if not wait_for_ui_ready(host=local_tunnel_ip, port=UI_HOST_PORT, timeout_sec=60):
        return out(status="postponed", error_message="Swarm-cloud-ui did not become ready within timeout")

    node_properties.update(_node_ready_props("true"))
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    node_properties.update(
        build_image_evidence_props(
            prefix="swarm_cloud_ui",
            image_ref=desired_image_ref,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )
    return out(status="completed")


@plugin.command("health")
def handle_health(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}

    def fail(status: str, error_message: str) -> PluginOutput:
        return PluginOutput(
            status=status,
            error_message=error_message,
            local_state=local_state,
            node_properties=_node_ready_props("false"),
        )

    ui_running, ui_error = is_ui_running()
    if not ui_running:
        if ui_error and "Failed to" in ui_error:
            return fail("error", ui_error)
        return fail("postponed", ui_error or "Swarm-cloud-ui service is not running")

    if isinstance(state_json, dict):
        wg_props = state_json.get("wgNodeProperties", [])
        local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
        if not isinstance(local_tunnel_ip, str) or not local_tunnel_ip.strip():
            return fail("postponed", "Waiting for WireGuard tunnel IP on local node")

        try:
            probe = subprocess.run(
                ["nc", "-z", local_tunnel_ip, str(UI_HOST_PORT)],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if probe.returncode != 0:
                return fail("postponed", f"UI is not listening on {local_tunnel_ip}:{UI_HOST_PORT}")
        except subprocess.TimeoutExpired:
            return fail("postponed", f"UI port probe timed out on {local_tunnel_ip}:{UI_HOST_PORT}")
        except Exception as e:
            return fail("postponed", f"UI port probe failed on {local_tunnel_ip}:{UI_HOST_PORT}: {e}")

    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("finalize")
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}
    node_properties = _node_ready_props("false")
    try:
        subprocess.run(["systemctl", "stop", UI_SERVICE_NAME], check=False)
    except Exception as e:
        _log_error("Failed to stop swarm-cloud-ui", e)
    return PluginOutput(status="completed", local_state=local_state, node_properties=node_properties)


@plugin.command("destroy")
def handle_destroy(_input_data: PluginInput) -> PluginOutput:
    try:
        subprocess.run(["systemctl", "stop", UI_SERVICE_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", UI_SERVICE_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        subprocess.run(["podman", "stop", UI_CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["podman", "rm", UI_CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        service_path = f"/etc/systemd/system/{UI_SERVICE_NAME}.service"
        if os.path.exists(service_path):
            os.remove(service_path)
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        return PluginOutput(status="completed", node_properties=_node_ready_props(None), local_state={})
    except Exception as e:
        return PluginOutput(status="error", error_message=f"Failed to destroy swarm-cloud-ui: {e}", local_state={})


if __name__ == "__main__":
    plugin.run()
