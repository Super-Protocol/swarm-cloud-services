#!/usr/bin/env python3

import sys
import os
import fcntl
import shutil
import subprocess
import socket
import time
import traceback
from pathlib import Path
from typing import Optional

SWARM_APT_LOCK_FILE = "/run/lock/swarm-apt.lock"

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput
import pwd
import grp

# Configuration
NATS_VERSION = os.environ.get("NATS_VERSION", "2")  # informational
NATS_CLIENT_PORT = 4222
NATS_CLUSTER_PORT = 6222
NATS_MONITOR_PORT = 8222
NATS_CONFIG_FILE = Path("/etc/nats-server.conf")
NATS_DATA_DIR = Path("/var/lib/nats")
NATS_SERVICE_NAME = "nats-server"
NATS_BIN = "nats-server"
CLUSTER_NAME = os.environ.get("NATS_CLUSTER_NAME", "swarm-nats")

# Plugin setup
plugin = ProvisionPlugin()


# Helpers
def _log_error(command: str, message: str, *, local_node_id: Optional[str] = None) -> None:
    prefix = f"[nats-plugin][{command}]"
    if local_node_id:
        prefix += f"[{local_node_id}]"
    print(f"{prefix} {message}", file=sys.stderr)


def _log_exception(command: str, exc: Exception, *, local_node_id: Optional[str] = None) -> None:
    _log_error(command, f"Exception: {exc}", local_node_id=local_node_id)
    print(traceback.format_exc(), file=sys.stderr)


def _get_uid_gid(user: str, group: str) -> tuple[int, int]:
    """Return uid,gid for user/group, fallback to 0 if not found."""
    try:
        uid = pwd.getpwnam(user).pw_uid
    except KeyError:
        uid = 0
    try:
        gid = grp.getgrnam(group).gr_gid
    except KeyError:
        gid = 0
    return uid, gid


def _ensure_dir_owned(path: Path, user: str, group: str, mode: int = 0o750) -> None:
    """Ensure directory exists with given owner and mode."""
    path.mkdir(parents=True, exist_ok=True)
    uid, gid = _get_uid_gid(user, group)
    try:
        os.chown(path.as_posix(), uid, gid)
    except PermissionError:
        # Not fatal; service may still have access if perms allow
        pass
    try:
        os.chmod(path.as_posix(), mode)
    except PermissionError:
        pass


def get_node_tunnel_ip(node_id: str, wg_props: list) -> Optional[str]:
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def get_leader_node(state_json: dict) -> Optional[str]:
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")


def is_nats_available() -> bool:
    return shutil.which(NATS_BIN) is not None


def _apt_env() -> dict:
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    env.setdefault("NEEDRESTART_MODE", "a")
    return env


class _SwarmAptLock:
    """Serialize apt/dpkg on one host across concurrent service plugin inits."""

    def __init__(self, timeout_sec: int = 300) -> None:
        self._timeout_sec = timeout_sec
        self._fd: int | None = None

    def __enter__(self) -> "_SwarmAptLock":
        lock_dir = os.path.dirname(SWARM_APT_LOCK_FILE) or "/run/lock"
        os.makedirs(lock_dir, exist_ok=True)
        self._fd = os.open(SWARM_APT_LOCK_FILE, os.O_CREAT | os.O_RDWR, 0o644)
        deadline = time.time() + self._timeout_sec
        while time.time() < deadline:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except BlockingIOError:
                time.sleep(1)
        raise Exception(f"Timed out waiting for {SWARM_APT_LOCK_FILE}")

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._fd is not None:
            fcntl.flock(self._fd, fcntl.LOCK_UN)
            os.close(self._fd)
            self._fd = None


def _run_apt(cmd: list[str], *, err_msg: str) -> None:
    result = subprocess.run(cmd, capture_output=True, text=True, env=_apt_env())
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise Exception(f"{err_msg}: {detail}")


def disable_nats_service() -> None:
    """Stop and disable the unit so it only runs after apply enables it."""
    subprocess.run(
        ["systemctl", "disable", "--now", NATS_SERVICE_NAME],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def _run_apt_install(packages: list[str], *, err_msg: str) -> None:
    cmd = [
        "apt-get",
        "install",
        "-y",
        "--no-install-recommends",
        "-o",
        "Dpkg::Options::=--force-confdef",
        "-o",
        "Dpkg::Options::=--force-confold",
        *packages,
    ]
    _run_apt(cmd, err_msg=err_msg)


def ensure_nats_package() -> None:
    """Install nats-server via apt only when the binary is missing."""
    if is_nats_available():
        disable_nats_service()
        return

    with _SwarmAptLock():
        _run_apt(["apt-get", "update"], err_msg="apt-get update failed")
        _run_apt_install(["nats-server"], err_msg="Failed to install nats-server package")
        if not is_nats_available():
            raise Exception("nats-server package installed but binary not found on PATH")
    disable_nats_service()


def enable_nats_service() -> None:
    """Enable and restart NATS (apply only)."""
    enable = subprocess.run(
        ["systemctl", "enable", NATS_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if enable.returncode != 0:
        raise Exception(f"Failed to enable {NATS_SERVICE_NAME}: {(enable.stderr or enable.stdout or '').strip()}")

    restart = subprocess.run(
        ["systemctl", "restart", NATS_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if restart.returncode != 0:
        raise Exception(f"Failed to start {NATS_SERVICE_NAME}: {(restart.stderr or restart.stdout or '').strip()}")


def write_nats_config(local_node_id: str, local_tunnel_ip: str, cluster_nodes: list, wg_props: list):
    # Ensure data dir is owned by nats so JetStream can create subdirs
    _ensure_dir_owned(NATS_DATA_DIR, user="nats", group="nats", mode=0o750)

    # Build routes for all peers except self
    routes = []
    for node in cluster_nodes:
        nid = node.get("node_id")
        t_ip = get_node_tunnel_ip(nid, wg_props)
        if not t_ip:
            continue
        if nid == local_node_id:
            continue
        routes.append(f"nats://{t_ip}:{NATS_CLUSTER_PORT}")

    cfg_lines = [
        f"port: {NATS_CLIENT_PORT}",
        f"http: {NATS_MONITOR_PORT}",
        f"host: {local_tunnel_ip}",
        "",
        "jetstream: {",
        f"  store_dir: \"{(NATS_DATA_DIR / 'jetstream').as_posix()}\"",
        "}",
        f"server_name: {local_node_id}",
    ]
    # Only enable clustering when there are peers to route to.
    if routes:
        cfg_lines += [
            "",
            "cluster: {",
            f"  name: {CLUSTER_NAME},",
            f"  host: {local_tunnel_ip},",
            f"  port: {NATS_CLUSTER_PORT},",
            "  routes: [",
        ]
        for r in routes:
            cfg_lines.append(f'    "{r}",')
        cfg_lines += [
            "  ]",
            "}",
        ]
    cfg_lines += [
        "",
        "resolver: memory",
        "no_auth_user: ''",
    ]

    NATS_CONFIG_FILE.write_text("\n".join(cfg_lines) + "\n")


def wait_for_tcp(ip: str, port: int, timeout_sec: int = 60) -> bool:
    start = time.time()
    last_err = None
    while time.time() - start < timeout_sec:
        try:
            with socket.create_connection((ip, port), timeout=3):
                return True
        except Exception as e:
            last_err = str(e)
            time.sleep(2)
    print(f"[!] Port {ip}:{port} not reachable within {timeout_sec}s. Last error: {last_err}", file=sys.stderr)
    return False


def is_service_active(service: str) -> tuple[bool, Optional[str]]:
    try:
        result = subprocess.run(["systemctl", "is-active", service], capture_output=True, text=True)
        active = result.stdout.strip() == "active"
        return active, None if active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def is_cluster_initialized(nats_props: list) -> bool:
    for prop in nats_props:
        if prop.get("name") == "nats_cluster_initialized" and prop.get("value") == "true":
            return True
    return False


def mark_node_ready() -> dict:
    return {"nats_node_ready": "true"}


# Commands
@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    try:
        ensure_nats_package()
        # Ensure runtime dirs exist and owned by nats
        _ensure_dir_owned(Path("/var/log/nats"), user="nats", group="nats", mode=0o750)
        _ensure_dir_owned(NATS_DATA_DIR, user="nats", group="nats", mode=0o750)
        return PluginOutput(status="completed", local_state=input_data.local_state)
    except Exception as e:
        _log_exception("init", e, local_node_id=getattr(input_data, "local_node_id", None))
        return PluginOutput(status="error", error_message=str(e), local_state=input_data.local_state)


@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    if not isinstance(state_json, dict):
        _log_error("apply", "Invalid state format", local_node_id=local_node_id)
        return PluginOutput(status="error", error_message="Invalid state format", local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])
    nats_props = state_json.get("natsNodeProperties", [])

    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status="postponed",
            error_message="Waiting for WireGuard to be configured on all nodes",
            local_state=local_state,
        )

    leader_node_id = get_leader_node(state_json)
    is_leader = (leader_node_id == local_node_id)
    cluster_initialized = is_cluster_initialized(nats_props)

    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        _log_error("apply", "Local node has no WireGuard tunnel IP", local_node_id=local_node_id)
        return PluginOutput(status="error", error_message="Local node has no WireGuard tunnel IP", local_state=local_state)

    # Write NATS config based on current cluster view
    try:
        write_nats_config(local_node_id, local_tunnel_ip, cluster_nodes, wg_props)
    except Exception as e:
        _log_exception("apply", e, local_node_id=local_node_id)
        return PluginOutput(status="error", error_message=f"Failed to write NATS config: {e}", local_state=local_state)

    try:
        enable_nats_service()
    except Exception as e:
        _log_exception("apply", e, local_node_id=local_node_id)
        return PluginOutput(status="error", error_message=f"Failed to start NATS: {e}", local_state=local_state)

    # Wait for client port to be ready
    if not wait_for_tcp(local_tunnel_ip, NATS_CLIENT_PORT, timeout_sec=60):
        return PluginOutput(
            status="postponed",
            error_message="NATS did not become ready within timeout",
            node_properties=mark_node_ready(),
            local_state=local_state,
        )

    # Leader marks cluster initialized (NATS clustering forms via routes automatically)
    if is_leader and not cluster_initialized:
        node_properties = {"nats_cluster_initialized": "true", "nats_node_ready": "true"}
        return PluginOutput(status="completed", node_properties=node_properties, local_state=local_state)

    if cluster_initialized:
        # Already initialized — ensure this node is marked ready
        return PluginOutput(status="completed", node_properties=mark_node_ready(), local_state=local_state)

    # Non-leader: mark ready and wait for leader
    return PluginOutput(
        status="postponed",
        error_message=f"Waiting for leader node {leader_node_id} to mark cluster initialized",
        node_properties=mark_node_ready(),
        local_state=local_state,
    )


@plugin.command("health")
def handle_health(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    active, err = is_service_active(NATS_SERVICE_NAME)
    if not active:
        if err and "Failed to" in err:
            return PluginOutput(status="error", error_message=err, local_state=local_state)
        return PluginOutput(status="postponed", error_message=err or "NATS service is not running", local_state=local_state)

    wg_props = state_json.get("wgNodeProperties", []) if isinstance(state_json, dict) else []
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(status="postponed", error_message="No tunnel IP available", local_state=local_state)

    # Check TCP connectivity to client port
    if not wait_for_tcp(local_tunnel_ip, NATS_CLIENT_PORT, timeout_sec=5):
        return PluginOutput(status="postponed", error_message="NATS not accepting connections yet", local_state=local_state)

    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("finalize")
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    # No-op for now; could implement graceful cluster changes if needed
    return PluginOutput(status="completed", local_state=input_data.local_state or {})


@plugin.command("destroy")
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    try:
        disable_nats_service()
        if NATS_CONFIG_FILE.exists():
            NATS_CONFIG_FILE.unlink(missing_ok=True)
        if NATS_DATA_DIR.exists():
            shutil.rmtree(NATS_DATA_DIR, ignore_errors=True)
        node_properties = {
            "nats_node_ready": None,
            "nats_cluster_initialized": None,
        }
        return PluginOutput(status="completed", node_properties=node_properties, local_state={})
    except Exception as e:
        return PluginOutput(status="error", error_message=f"Failed to destroy NATS: {e}", local_state={})


if __name__ == "__main__":
    plugin.run()
