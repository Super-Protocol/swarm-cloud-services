"""Kernel command line parsing for the sp-vm image version and rootfs hash."""

from test_gpu_labels import _load_main_module

HASH = "a" * 64


def test_parse_sp_vm_cmdline_both_tokens():
    m = _load_main_module()
    cmdline = (
        f"root=LABEL=rootfs ro rootfs_verity.scheme=dm-verity "
        f"rootfs_verity.hash={HASH} build=build-42-release console=ttyS0"
    )
    assert m.parse_sp_vm_cmdline(cmdline) == {
        "sp_vm_image_version": "build-42-release",
        "sp_vm_image_hash": HASH,
    }


def test_parse_sp_vm_cmdline_version_only():
    m = _load_main_module()
    assert m.parse_sp_vm_cmdline("ro build=build-7-debug") == {
        "sp_vm_image_version": "build-7-debug",
    }


def test_parse_sp_vm_cmdline_empty():
    m = _load_main_module()
    assert m.parse_sp_vm_cmdline("") == {}


def test_parse_sp_vm_cmdline_ignores_unrelated_args():
    m = _load_main_module()
    assert m.parse_sp_vm_cmdline("root=LABEL=rootfs ro quiet splash notbuild=nope") == {}
