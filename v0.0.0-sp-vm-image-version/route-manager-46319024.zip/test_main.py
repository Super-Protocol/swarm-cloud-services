#!/usr/bin/env python3
"""Unit tests for route-manager/main.py.

Covers SUP-206 (the two values the fabric cannot mint for itself and used to receive over
guest ssh: the exposed domain's TLS cert for openresty's auto-ssl store and the metrics
scrape token for swarm-cloud-api's /v1/metrics guard) and SUP-581 (the cluster-membership
filter that keeps a cloud's k8s API route off a node running an rke2 cluster of its own).

    cd services/route-manager && python3 -m unittest test_main -v
"""

import contextlib
import json
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    sys.modules["provision_plugin_sdk"] = stub

if "redis" not in sys.modules:
    # main imports `redis` / `redis.sentinel` even when it is handed a client. These tests
    # always hand it one; the stubs only have to make the reconnect path fail fast instead
    # of importing the real driver, which is not a dev-host dependency.
    redis_stub = type(sys)("redis")
    sentinel_stub = type(sys)("redis.sentinel")

    class _Unavailable:
        def __init__(self, *args, **kwargs):
            raise RuntimeError("no redis in the test environment")

    redis_stub.Redis = _Unavailable
    sentinel_stub.Sentinel = _Unavailable
    redis_stub.sentinel = sentinel_stub
    sys.modules["redis"] = redis_stub
    sys.modules["redis.sentinel"] = sentinel_stub

import main  # noqa: E402

DOMAIN = "cloud-x.swarm.example.dev"


@contextlib.contextmanager
def _no_retry_delay():
    """Collapse _execute_with_redis's backoff so the failure paths run instantly."""
    original = main.time.sleep
    main.time.sleep = lambda _seconds: None
    try:
        yield
    finally:
        main.time.sleep = original


def _free_port() -> int:
    """A port nothing is listening on, for the TLS probe tests."""
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]


def _self_signed(days: int = 30) -> tuple[str, str]:
    """A throwaway cert/key pair, generated so no private key is committed."""
    with tempfile.TemporaryDirectory() as tmp:
        crt, key = Path(tmp) / "c.pem", Path(tmp) / "k.pem"
        subprocess.run(
            [
                "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                "-keyout", str(key), "-out", str(crt),
                "-days", str(days), "-subj", f"/CN={DOMAIN}",
            ],
            check=True,
            capture_output=True,
        )
        return crt.read_text(), key.read_text()


class _FakeRedis:
    """Records SETs; `fail_on` makes the write raise so retry/postpone paths are reachable."""

    def __init__(self, fail_on: str | None = None):
        self.values: dict[str, str] = {}
        self.fail_on = fail_on

    def get(self, key):
        return self.values.get(key)

    def delete(self, key):
        self.values.pop(key, None)

    def set(self, key, value):
        if self.fail_on is not None and self.fail_on in key:
            raise RuntimeError("redis is down")
        self.values[key] = value


def _state(**overrides):
    state = {
        "swarmDomain": DOMAIN,
        "globalId": "abc123",
        "baseDomain": "swarm.example.dev",
        "redisSentinelNodes": [{"id": "s:n1", "node_id": "n1", "ip": "10.1.1.1"}],
        "swarmSecrets": [],
    }
    state.update(overrides)
    return state


class PemHelperTests(unittest.TestCase):
    def test_split_pem_certificates_returns_leaf_first(self):
        leaf, _ = _self_signed()
        intermediate, _ = _self_signed()
        blocks = main.split_pem_certificates(leaf + intermediate)
        self.assertEqual(len(blocks), 2)
        self.assertEqual(blocks[0].strip(), leaf.strip())

    def test_split_pem_certificates_ignores_trailing_garbage(self):
        leaf, _ = _self_signed()
        self.assertEqual(len(main.split_pem_certificates(leaf + "-----BEGIN CERTIFICATE-----\n")), 1)

    def test_split_pem_certificates_on_non_pem(self):
        self.assertEqual(main.split_pem_certificates("not a cert"), [])

    def test_cert_not_after_epoch_reads_openssl_date(self):
        leaf, _ = _self_signed(days=30)
        expiry = main.cert_not_after_epoch(leaf)
        # 30 days out, allowing a day of slack either side of openssl's rounding.
        self.assertGreater(expiry, 0)
        self.assertAlmostEqual(expiry, main.datetime.now(main.timezone.utc).timestamp() + 30 * 86400, delta=86400)

    def test_cert_not_after_epoch_is_zero_for_garbage(self):
        # A parse failure must not be fatal: auto-ssl treats expiry=0 as "due for renewal",
        # which is strictly better than refusing to serve a valid cert.
        self.assertEqual(main.cert_not_after_epoch("not a cert"), 0)


class AutoSslPayloadTests(unittest.TestCase):
    def test_payload_carries_the_fields_auto_ssl_reads(self):
        leaf, key = _self_signed()
        intermediate, _ = _self_signed()
        payload = main.build_auto_ssl_payload(leaf + intermediate, key)

        self.assertEqual(set(payload), {"fullchain_pem", "privkey_pem", "cert_pem", "expiry"})
        self.assertEqual(payload["fullchain_pem"], leaf + intermediate)
        self.assertEqual(payload["privkey_pem"], key)
        # cert_pem is the LEAF only — the evidence JWS is fingerprinted against it.
        self.assertEqual(payload["cert_pem"].strip(), leaf.strip())
        self.assertNotIn(intermediate.strip(), payload["cert_pem"])
        self.assertGreater(payload["expiry"], 0)

    def test_payload_appends_missing_trailing_newline(self):
        leaf, key = _self_signed()
        payload = main.build_auto_ssl_payload(leaf.rstrip("\n"), key.rstrip("\n"))
        self.assertTrue(payload["fullchain_pem"].endswith("\n"))
        self.assertTrue(payload["privkey_pem"].endswith("\n"))

    def test_payload_rejects_material_that_is_not_a_cert(self):
        _, key = _self_signed()
        with self.assertRaises(ValueError):
            main.build_auto_ssl_payload("junk", key)

    def test_payload_rejects_material_that_is_not_a_key(self):
        leaf, _ = _self_signed()
        with self.assertRaises(ValueError):
            main.build_auto_ssl_payload(leaf, "junk")

    def test_auto_ssl_key_is_the_one_openresty_reads(self):
        self.assertEqual(main.build_auto_ssl_key(DOMAIN), f"auto-ssl:{DOMAIN}:latest")


class SeededValueResolutionTests(unittest.TestCase):
    def test_swarm_secret_wins_over_provider_config_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file")
            state = _state(swarmSecrets=[{"id": "metrics_token", "value": "from-secret"}])
            self.assertEqual(
                main.resolve_seeded_value(
                    state, main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-secret",
            )

    def test_provider_config_file_is_the_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file\n")
            self.assertEqual(
                main.resolve_seeded_value(
                    _state(), main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-file",
            )

    def test_missing_everywhere_is_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(
                main.resolve_seeded_value(
                    _state(), main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                )
            )

    def test_blank_secret_falls_through_to_the_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.METRICS_TOKEN_FILE).write_text("from-file")
            state = _state(swarmSecrets=[{"id": "metrics_token", "value": "   "}])
            self.assertEqual(
                main.resolve_seeded_value(
                    state, main.METRICS_TOKEN_SECRET, main.METRICS_TOKEN_FILE, Path(tmp)
                ),
                "from-file",
            )


class SyncExposedTlsCertTests(unittest.TestCase):
    def test_publishes_cert_from_provider_config(self):
        leaf, key = _self_signed()
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text(leaf)
            (Path(tmp) / main.EXPOSED_TLS_KEY_FILE).write_text(key)
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok, err)
        self.assertIsNone(err)
        self.assertIsNotNone(fingerprint)
        stored = json.loads(redis_client.values[f"auto-ssl:{DOMAIN}:latest"])
        self.assertEqual(stored["fullchain_pem"], leaf)
        self.assertEqual(stored["privkey_pem"], key)

    def test_publishes_cert_from_swarm_secrets(self):
        leaf, key = _self_signed()
        redis_client = _FakeRedis()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, _ = main.sync_exposed_tls_cert(
                state, redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok, err)
        self.assertIn(f"auto-ssl:{DOMAIN}:latest", redis_client.values)

    def test_no_material_is_not_an_error(self):
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok)
        self.assertIsNone(err)
        self.assertIsNone(fingerprint)
        self.assertEqual(redis_client.values, {})

    def test_half_supplied_material_is_an_error(self):
        leaf, _ = _self_signed()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text(leaf)
            ok, err, _ = main.sync_exposed_tls_cert(
                _state(), redis_client=_FakeRedis(), provider_config_dir=Path(tmp)
            )

        self.assertFalse(ok)
        self.assertIn("exposed_tls_key", err)

    def test_unusable_material_is_an_error_not_a_crash(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / main.EXPOSED_TLS_CERT_FILE).write_text("junk")
            (Path(tmp) / main.EXPOSED_TLS_KEY_FILE).write_text("junk")
            ok, err, _ = main.sync_exposed_tls_cert(
                _state(), redis_client=_FakeRedis(), provider_config_dir=Path(tmp)
            )

        self.assertFalse(ok)
        self.assertIn("unusable", err)

    def test_missing_swarm_domain_is_an_error_not_a_crash(self):
        leaf, key = _self_signed()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        del state["swarmDomain"]
        ok, err, _ = main.sync_exposed_tls_cert(state, redis_client=_FakeRedis())
        self.assertFalse(ok)
        self.assertIn("swarmDomain", err)

    def test_redis_failure_is_reported(self):
        leaf, key = _self_signed()
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_cert", "value": leaf},
                {"id": "exposed_tls_key", "value": key},
            ]
        )
        with _no_retry_delay():
            ok, err, fingerprint = main.sync_exposed_tls_cert(
                state, redis_client=_FakeRedis(fail_on="auto-ssl")
            )
        self.assertFalse(ok)
        self.assertTrue(err)
        # The fingerprint is still reported so the failure names the cert it was handling.
        self.assertIsNotNone(fingerprint)


class SyncMetricsTokenTests(unittest.TestCase):
    def test_publishes_token_to_the_key_the_api_guard_reads(self):
        redis_client = _FakeRedis()
        state = _state(swarmSecrets=[{"id": "metrics_token", "value": "deadbeef"}])
        ok, err, published = main.sync_metrics_token(state, redis_client=redis_client)

        self.assertTrue(ok, err)
        self.assertTrue(published)
        self.assertEqual(redis_client.values["swarm-metrics-token"], "deadbeef")

    def test_no_token_is_not_an_error(self):
        redis_client = _FakeRedis()
        with tempfile.TemporaryDirectory() as tmp:
            ok, err, published = main.sync_metrics_token(
                _state(), redis_client=redis_client, provider_config_dir=Path(tmp)
            )

        self.assertTrue(ok)
        self.assertIsNone(err)
        self.assertFalse(published)
        self.assertEqual(redis_client.values, {})

    def test_redis_failure_is_reported(self):
        state = _state(swarmSecrets=[{"id": "metrics_token", "value": "deadbeef"}])
        with _no_retry_delay():
            ok, err, published = main.sync_metrics_token(
                state, redis_client=_FakeRedis(fail_on="swarm-metrics-token")
            )
        self.assertFalse(ok)
        self.assertFalse(published)
        self.assertTrue(err)


class RedactStateTests(unittest.TestCase):
    def test_secret_values_never_reach_the_log(self):
        state = _state(
            swarmSecrets=[
                {"id": "exposed_tls_key", "value": "-----BEGIN PRIVATE KEY-----"},
                {"id": "metrics_token", "value": "deadbeef"},
            ]
        )
        dumped = json.dumps(main.redact_state(state))
        self.assertNotIn("deadbeef", dumped)
        self.assertNotIn("BEGIN PRIVATE KEY", dumped)
        # ids survive, so the log still says WHICH material the cloud was given.
        self.assertIn("exposed_tls_key", dumped)
        self.assertIn(DOMAIN, dumped)

    def test_non_secret_state_passes_through_untouched(self):
        state = _state()
        self.assertEqual(main.redact_state(state)["redisSentinelNodes"], state["redisSentinelNodes"])


class ApiserverCertIssuerTests(unittest.TestCase):
    """SUP-581: the probe that tells one rke2 cluster's apiserver from another's."""

    def test_reads_the_issuer_of_a_live_handshake(self):
        with tempfile.TemporaryDirectory() as tmp:
            crt, key = Path(tmp) / "c.pem", Path(tmp) / "k.pem"
            subprocess.run(
                [
                    "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                    "-keyout", str(key), "-out", str(crt),
                    "-days", "1", "-subj", "/CN=rke2-server-ca@1792403832",
                ],
                check=True,
                capture_output=True,
            )
            port = _free_port()
            server = subprocess.Popen(
                [
                    "openssl", "s_server", "-quiet", "-accept", str(port),
                    "-cert", str(crt), "-key", str(key),
                ],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                issuer = None
                for _attempt in range(20):
                    issuer = main.read_apiserver_cert_issuer("127.0.0.1", port=port, timeout_seconds=5)
                    if issuer is not None:
                        break
                    time.sleep(0.2)
            finally:
                server.terminate()
                server.wait(timeout=10)

        self.assertIsNotNone(issuer, "openssl s_client did not report an issuer for a live TLS server")
        self.assertIn("rke2-server-ca@1792403832", issuer)

    def test_returns_none_when_nothing_listens(self):
        self.assertIsNone(main.read_apiserver_cert_issuer("127.0.0.1", port=_free_port(), timeout_seconds=5))

    def test_returns_none_when_the_peer_never_answers(self):
        """A blackholed peer must not hold the apply open — it is just unreadable."""
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        try:
            port = listener.getsockname()[1]
            self.assertIsNone(main.read_apiserver_cert_issuer("127.0.0.1", port=port, timeout_seconds=0.5))
        finally:
            listener.close()

    def test_a_missing_openssl_is_not_fatal(self):
        original = main.subprocess.run

        def _no_openssl(*_args, **_kwargs):
            raise OSError("openssl not found")

        main.subprocess.run = _no_openssl
        try:
            self.assertIsNone(main.read_apiserver_cert_issuer("10.13.89.147"))
        finally:
            main.subprocess.run = original


class _IssuerReader:
    """Serves canned issuers and records which peers were probed."""

    def __init__(self, issuers: dict[str, str | None]):
        self.issuers = issuers
        self.probed: list[str] = []

    def __call__(self, ip, port=main.K8S_API_PORT, timeout_seconds=main.K8S_APISERVER_PROBE_TIMEOUT_SECONDS):
        self.probed.append(ip)
        return self.issuers.get(ip)


CLUSTER_CA = "CN = rke2-server-ca@1792403832"
FORK_CA = "CN = rke2-server-ca@1792404647"

# The azure-test node set of SUP-581: four members and node-5-vg31, which bootstrapped an
# rke2 cluster of its own two minutes after joining the swarm.
AZURE_TEST_IPS = ["10.13.74.102", "10.13.180.9", "10.13.70.77", "10.13.186.75", "10.13.89.147"]
AZURE_TEST_ISSUERS = {
    "10.13.74.102": CLUSTER_CA,
    "10.13.180.9": CLUSTER_CA,
    "10.13.70.77": CLUSTER_CA,
    "10.13.186.75": CLUSTER_CA,
    "10.13.89.147": FORK_CA,
}
K8S_DOMAIN = f"k8s-du19cq0rja6f.{DOMAIN}"


class ClusterMemberSelectionTests(unittest.TestCase):
    def test_excludes_the_node_running_a_cluster_of_its_own(self):
        reader = _IssuerReader(AZURE_TEST_ISSUERS)
        members = main.select_cluster_member_ips(K8S_DOMAIN, AZURE_TEST_IPS, issuer_reader=reader)
        self.assertEqual(members, AZURE_TEST_IPS[:4])
        self.assertEqual(sorted(reader.probed), sorted(AZURE_TEST_IPS))

    def test_keeps_a_peer_that_cannot_be_read(self):
        """An apiserver that is down says nothing about membership; dropping it would
        narrow a route on a transport failure."""
        issuers = dict(AZURE_TEST_ISSUERS)
        issuers["10.13.186.75"] = None
        members = main.select_cluster_member_ips(
            K8S_DOMAIN, AZURE_TEST_IPS, issuer_reader=_IssuerReader(issuers)
        )
        self.assertEqual(members, AZURE_TEST_IPS[:4])

    def test_keeps_every_node_when_no_issuer_holds_a_majority(self):
        split = {ip: (CLUSTER_CA if index < 2 else FORK_CA) for index, ip in enumerate(AZURE_TEST_IPS[:4])}
        members = main.select_cluster_member_ips(
            K8S_DOMAIN, AZURE_TEST_IPS[:4], issuer_reader=_IssuerReader(split)
        )
        self.assertEqual(members, AZURE_TEST_IPS[:4])

    def test_a_readable_minority_may_not_narrow_the_route(self):
        """Two confirmations out of five are not evidence of who the cluster is — the two
        that answered could as easily be the fork as the cluster."""
        issuers = {ip: None for ip in AZURE_TEST_IPS}
        issuers["10.13.74.102"] = CLUSTER_CA
        issuers["10.13.180.9"] = CLUSTER_CA
        members = main.select_cluster_member_ips(
            K8S_DOMAIN, AZURE_TEST_IPS, issuer_reader=_IssuerReader(issuers)
        )
        self.assertEqual(members, AZURE_TEST_IPS)

    def test_keeps_every_node_when_nothing_could_be_probed(self):
        reader = _IssuerReader({ip: None for ip in AZURE_TEST_IPS})
        self.assertEqual(
            main.select_cluster_member_ips(K8S_DOMAIN, AZURE_TEST_IPS, issuer_reader=reader),
            AZURE_TEST_IPS,
        )

    def test_a_single_node_cloud_is_never_probed(self):
        reader = _IssuerReader({})
        self.assertEqual(
            main.select_cluster_member_ips(K8S_DOMAIN, ["10.13.74.102"], issuer_reader=reader),
            ["10.13.74.102"],
        )
        self.assertEqual(reader.probed, [])

    def test_a_healthy_cluster_keeps_every_node(self):
        issuers = {ip: CLUSTER_CA for ip in AZURE_TEST_IPS}
        self.assertEqual(
            main.select_cluster_member_ips(K8S_DOMAIN, AZURE_TEST_IPS, issuer_reader=_IssuerReader(issuers)),
            AZURE_TEST_IPS,
        )


class SyncK8sRoutesTests(unittest.TestCase):
    """The written route is what a tenant's kubectl actually reaches."""

    @staticmethod
    def _k8s_nodes(domain=K8S_DOMAIN):
        return [
            {
                "id": f"rke2:1792403829048:z2yapqetx:node-{index}",
                "node_id": f"azure-test-node-{index}",
                "cluster": "rke2:1792403829048:z2yapqetx",
                "ip": ip,
                "ready": "true",
                "k8s_external_hostname": domain,
            }
            for index, ip in enumerate(AZURE_TEST_IPS, start=1)
        ]

    def _written_route(self, redis_client):
        return json.loads(redis_client.values[f"{main.ROUTE_KEY_PREFIX}:{K8S_DOMAIN}"])

    def test_the_foreign_cluster_is_not_a_target(self):
        redis_client = _FakeRedis()
        ok, err, domains = main.sync_k8s_routes(
            _state(k8sNodes=self._k8s_nodes()),
            redis_client=redis_client,
            issuer_reader=_IssuerReader(AZURE_TEST_ISSUERS),
        )
        self.assertTrue(ok, err)
        self.assertEqual(domains, {K8S_DOMAIN})
        route = self._written_route(redis_client)
        self.assertTrue(route["passthrough"])
        self.assertEqual(
            [target["url"] for target in route["targets"]],
            sorted(f"https://{ip}:{main.K8S_API_PORT}" for ip in AZURE_TEST_IPS[:4]),
        )
        self.assertNotIn("10.13.89.147", json.dumps(route))

    def test_an_unprobeable_cloud_routes_exactly_as_before(self):
        redis_client = _FakeRedis()
        ok, err, domains = main.sync_k8s_routes(
            _state(k8sNodes=self._k8s_nodes()),
            redis_client=redis_client,
            issuer_reader=_IssuerReader({}),
        )
        self.assertTrue(ok, err)
        self.assertEqual(domains, {K8S_DOMAIN})
        self.assertEqual(
            [target["url"] for target in self._written_route(redis_client)["targets"]],
            sorted(f"https://{ip}:{main.K8S_API_PORT}" for ip in AZURE_TEST_IPS),
        )

    def test_a_node_that_is_not_ready_is_still_left_out(self):
        nodes = self._k8s_nodes()
        nodes[0]["ready"] = "false"
        redis_client = _FakeRedis()
        reader = _IssuerReader(AZURE_TEST_ISSUERS)
        ok, err, _domains = main.sync_k8s_routes(
            _state(k8sNodes=nodes), redis_client=redis_client, issuer_reader=reader
        )
        self.assertTrue(ok, err)
        self.assertEqual(
            [target["url"] for target in self._written_route(redis_client)["targets"]],
            sorted(f"https://{ip}:{main.K8S_API_PORT}" for ip in AZURE_TEST_IPS[1:4]),
        )
        self.assertNotIn("10.13.74.102", reader.probed)


if __name__ == "__main__":
    unittest.main()
