"""Kernel command line and pki-vm-measurements parsing."""

from test_gpu_labels import _load_main_module

MRENCLAVE = "ab" * 32


def test_parse_sp_vm_cmdline_version():
    m = _load_main_module()
    cmdline = "root=LABEL=rootfs ro rootfs_verity.hash=aa build=build-42-release console=ttyS0"
    assert m.parse_sp_vm_cmdline(cmdline) == {"sp_vm_image_version": "build-42-release"}


def test_parse_sp_vm_cmdline_empty():
    m = _load_main_module()
    assert m.parse_sp_vm_cmdline("") == {}


def test_parse_sp_vm_cmdline_ignores_unrelated_args():
    m = _load_main_module()
    assert m.parse_sp_vm_cmdline("root=LABEL=rootfs ro quiet splash notbuild=nope") == {}


def test_parse_measure_response_tdx_azure():
    m = _load_main_module()
    assert m.parse_measure_response({"type": "tdx-azure", "mrenclaveHex": MRENCLAVE.upper(), "evidence": "qq"}) == {
        "sp_vm_evidence_type": "tdx-azure",
        "sp_vm_mrenclave": MRENCLAVE,
    }


def test_parse_measure_response_untrusted_has_no_mrenclave():
    m = _load_main_module()
    assert m.parse_measure_response({"type": "untrusted", "mrenclaveHex": "", "evidence": ""}) == {
        "sp_vm_evidence_type": "untrusted",
    }


def test_parse_measure_response_rejects_unknown_type():
    m = _load_main_module()
    assert m.parse_measure_response({"type": "sgx", "mrenclaveHex": MRENCLAVE}) == {}


def test_build_measurement_output_fetches_measure_once(monkeypatch):
    m = _load_main_module()
    calls = {"n": 0}

    def fetch():
        calls["n"] += 1
        return {"sp_vm_evidence_type": "tdx-google", "sp_vm_mrenclave": MRENCLAVE}

    monkeypatch.setattr(m, "measure_hardware", lambda: ({"cpu_total": "4"}, {}))
    monkeypatch.setattr(m, "fetch_sp_vm_measure", fetch)

    first = m.build_measurement_output("node-a", {})
    assert calls["n"] == 1
    assert m.MEASURE_STATE_KEY in first.local_state
    values = {item["type"]: item["value"] for item in first.measurements}
    assert values["sp_vm_mrenclave"] == MRENCLAVE
    assert values["sp_vm_evidence_type"] == "tdx-google"

    second = m.build_measurement_output("node-a", first.local_state)
    assert calls["n"] == 1
    values = {item["type"]: item["value"] for item in second.measurements}
    assert values["sp_vm_mrenclave"] == MRENCLAVE
