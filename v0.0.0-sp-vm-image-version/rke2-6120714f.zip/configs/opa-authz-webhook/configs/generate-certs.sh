#!/usr/bin/env bash
set -euo pipefail
# Generates CA + webhook server TLS + apiserver client cert for mTLS authorization webhook.
# Usage: generate-certs.sh <output_directory>

OUT="${1:?output directory}"
DAYS="${CERT_VALIDITY_DAYS:-4000}"
mkdir -p "${OUT}"

openssl genrsa -out "${OUT}/ca.key" 4096
openssl req -x509 -new -nodes -key "${OUT}/ca.key" -sha256 -days "${DAYS}" \
  -subj "/CN=opa-authz-webhook-ca/O=webhook-authorization" \
  -out "${OUT}/ca.crt"

openssl genrsa -out "${OUT}/webhook-server.key" 2048

SERVER_CSR="${OUT}/webhook-server.csr.cnf"
cat >"${SERVER_CSR}" <<'EOF'
[ req ]
default_bits       = 2048
prompt             = no
default_md         = sha256
distinguished_name = dn
req_extensions     = v3_req

[ dn ]
CN = opa-authz-webhook.opa-authz-system.svc

[ v3_req ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[ alt_names ]
DNS.1 = opa-authz-webhook
DNS.2 = opa-authz-webhook.opa-authz-system
DNS.3 = opa-authz-webhook.opa-authz-system.svc
DNS.4 = opa-authz-webhook.opa-authz-system.svc.cluster.local
EOF

openssl req -new -key "${OUT}/webhook-server.key" -out "${OUT}/webhook-server.csr" -config "${SERVER_CSR}"
openssl x509 -req -in "${OUT}/webhook-server.csr" -CA "${OUT}/ca.crt" -CAkey "${OUT}/ca.key" -CAcreateserial \
  -out "${OUT}/webhook-server.crt" -days "${DAYS}" -sha256 \
  -extensions v3_req -extfile "${SERVER_CSR}"

openssl genrsa -out "${OUT}/apiserver-client.key" 2048
openssl req -new -key "${OUT}/apiserver-client.key" -out "${OUT}/apiserver-client.csr" \
  -subj "/CN=kube-apiserver/O=opa-authz-webhook-client"

CLIENT_CSR_CONF="${OUT}/apiserver-client.cnf"
cat >"${CLIENT_CSR_CONF}" <<'EOF'
[ v3_client ]
basicConstraints = CA:FALSE
keyUsage = digitalSignature
extendedKeyUsage = clientAuth
EOF

openssl x509 -req -in "${OUT}/apiserver-client.csr" -CA "${OUT}/ca.crt" -CAkey "${OUT}/ca.key" -CAcreateserial \
  -out "${OUT}/apiserver-client.crt" -days "${DAYS}" -sha256 \
  -extensions v3_client -extfile "${CLIENT_CSR_CONF}"

install -m 0640 "${OUT}/webhook-server.crt" "${OUT}/tls.crt"
install -m 0640 "${OUT}/webhook-server.key" "${OUT}/tls.key"
install -m 0644 "${OUT}/ca.crt" "${OUT}/client-ca.crt"

rm -f "${OUT}/webhook-server.csr" "${OUT}/apiserver-client.csr" "${OUT}/ca.srl" "${SERVER_CSR}" "${CLIENT_CSR_CONF}" || true
