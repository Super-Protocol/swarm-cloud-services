#!/usr/bin/env python3
"""
Kubernetes Authorization Webhook handler with in-process policy evaluation.

Maps policy decisions to SubjectAccessReviewStatus:
  deny       -> allowed=false, denied=true
  no_opinion -> allowed=false, denied=false (delegated to other authorizers)
  allow      -> allowed=true
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from policy import PolicyConfig, evaluate, evaluate_degraded, load_config  # noqa: E402

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
logging.basicConfig(level=LOG_LEVEL, format="%(asctime)s %(levelname)s %(message)s")
LOG = logging.getLogger("authz-webhook-adapter")

POLICY_DATA_FILE = os.environ.get("POLICY_DATA_FILE", "/app/data.json")
TLS_CERT_FILE = os.environ["TLS_CERT_FILE"]
TLS_KEY_FILE = os.environ["TLS_KEY_FILE"]
CLIENT_CA_FILE = os.environ["CLIENT_CA_FILE"]
LISTEN_ADDR = os.environ.get("LISTEN_ADDR", "127.0.0.1")
LISTEN_PORT = int(os.environ.get("LISTEN_PORT", "18443"))

POLICY_CONFIG: PolicyConfig = load_config(POLICY_DATA_FILE)


def request_path(raw_path: str) -> str:
    """Strip query string; kube-apiserver calls POST /authorize?timeout=30s."""
    return urlparse(raw_path).path


def build_status(decision: str, review: dict[str, Any]) -> dict[str, Any]:
    spec = review.get("spec") or {}
    user = spec.get("user", "")
    attrs = spec.get("resourceAttributes") or {}
    verb = attrs.get("verb")
    resource = attrs.get("resource")
    ns = attrs.get("namespace")
    name = attrs.get("name")

    if decision == "deny":
        return {
            "allowed": False,
            "denied": True,
            "reason": (
                f"authz webhook: forbidden for user={user!r} "
                f"verb={verb!r} resource={resource!r} namespace={ns!r} name={name!r}"
            ),
        }
    if decision == "allow":
        return {"allowed": True, "denied": False, "reason": "authz webhook: allowed"}
    return {
        "allowed": False,
        "denied": False,
        "reason": "authz webhook: no opinion (delegated to other authorizers)",
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG.info("%s - %s", self.address_string(), fmt % args)

    def do_GET(self) -> None:
        path = request_path(self.path)
        if path in ("/healthz", "/health"):
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"ok\n")
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self) -> None:
        path = request_path(self.path)
        if path not in ("/authorize", "/authorize/"):
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            review_obj = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            self.send_response(400)
            self.end_headers()
            return

        if review_obj.get("kind") != "SubjectAccessReview":
            self.send_response(400)
            self.end_headers()
            return

        try:
            decision = evaluate(review_obj, POLICY_CONFIG)
        except Exception:
            LOG.exception("policy evaluation failed; using degraded fallback")
            decision = evaluate_degraded(review_obj, POLICY_CONFIG)

        status = build_status(decision, review_obj)

        review_obj["status"] = status
        review_obj["kind"] = "SubjectAccessReview"
        review_obj["apiVersion"] = review_obj.get("apiVersion") or "authorization.k8s.io/v1"

        out = json.dumps(review_obj).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)


class ReuseAddrHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


def main() -> None:
    server = ReuseAddrHTTPServer((LISTEN_ADDR, LISTEN_PORT), Handler)
    server.daemon_threads = True
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=TLS_CERT_FILE, keyfile=TLS_KEY_FILE)
    context.verify_mode = ssl.CERT_REQUIRED
    context.load_verify_locations(cafile=CLIENT_CA_FILE)
    server.socket = context.wrap_socket(server.socket, server_side=True)

    LOG.info(
        "Listening on https://%s:%s/authorize (mTLS required, policy=%s)",
        LISTEN_ADDR,
        LISTEN_PORT,
        POLICY_DATA_FILE,
    )
    server.serve_forever()


if __name__ == "__main__":
    main()
