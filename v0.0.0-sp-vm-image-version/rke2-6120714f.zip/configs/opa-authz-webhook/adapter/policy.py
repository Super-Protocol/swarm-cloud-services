"""In-process authorization policy for tenant secret protection."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

Decision = Literal["allow", "deny", "no_opinion"]

READ_VERBS = frozenset({"get", "watch"})
COLLECTION_VERBS = frozenset({"list", "watch"})
ENFORCEMENT_VERBS = frozenset({"update", "patch", "delete"})
DEFAULT_PROTECTED_SECRET_NAME = "swarm-pull"


@dataclass(frozen=True)
class PolicyConfig:
    protected_namespaces: frozenset[str]
    protected_namespace_prefixes: tuple[str, ...]
    protected_secret_name: str
    tenant_service_account_name: str
    bypass_groups: frozenset[str]
    bypass_users: frozenset[str]
    bypass_user_prefixes: tuple[str, ...]


def load_config(path: str | Path) -> PolicyConfig:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    policies = raw.get("policies") or {}
    protected = policies.get("protected") or {}
    tenant = policies.get("tenant") or {}
    bypass = policies.get("bypass") or {}

    tenant_sa = str(tenant.get("service_account_name") or "ns-editor").strip()
    if not tenant_sa:
        raise ValueError("policies.tenant.service_account_name must be non-empty")

    secret_name = str(protected.get("secret_name") or DEFAULT_PROTECTED_SECRET_NAME).strip()
    if not secret_name:
        raise ValueError("policies.protected.secret_name must be non-empty")

    return PolicyConfig(
        protected_namespaces=frozenset(protected.get("namespaces") or []),
        protected_namespace_prefixes=tuple(protected.get("namespace_prefixes") or []),
        protected_secret_name=secret_name,
        tenant_service_account_name=tenant_sa,
        bypass_groups=frozenset(bypass.get("groups") or []),
        bypass_users=frozenset(bypass.get("users") or []),
        bypass_user_prefixes=tuple(bypass.get("user_prefixes") or []),
    )


def is_credentials_namespace(ns: str) -> bool:
    return ns.endswith("-secret")


def protected_namespace(ns: str, config: PolicyConfig) -> bool:
    if not ns or is_credentials_namespace(ns):
        return False
    if ns in config.protected_namespaces:
        return True
    return any(ns.startswith(pref) for pref in config.protected_namespace_prefixes)


def is_bypass(user: str, groups: list[str], config: PolicyConfig) -> bool:
    if user in config.bypass_users:
        return True
    if any(g in config.bypass_groups for g in groups):
        return True
    return any(user.startswith(pref) for pref in config.bypass_user_prefixes)


def sa_namespace_from_user(user: str, tenant_sa_name: str) -> str | None:
    parts = user.split(":")
    if len(parts) != 4:
        return None
    if parts[0] != "system" or parts[1] != "serviceaccount" or parts[3] != tenant_sa_name:
        return None
    return parts[2]


def is_tenant_ns_editor_sa(user: str, config: PolicyConfig) -> bool:
    sa_ns = sa_namespace_from_user(user, config.tenant_service_account_name)
    if sa_ns is None:
        return False
    return protected_namespace(sa_ns, config)


def is_tenant_editor(user: str, req_ns: str, config: PolicyConfig) -> bool:
    sa_ns = sa_namespace_from_user(user, config.tenant_service_account_name)
    if sa_ns is None or sa_ns != req_ns:
        return False
    return protected_namespace(req_ns, config)


def is_protected_secret(name: str, config: PolicyConfig) -> bool:
    return bool(name) and name == config.protected_secret_name


def evaluate_degraded(review: dict[str, Any], config: PolicyConfig) -> Decision:
    """Conservative fallback when evaluate() raises: deny mutations on the protected secret only."""
    spec = review.get("spec") or {}
    user = str(spec.get("user") or "")
    attrs = spec.get("resourceAttributes") or {}
    if attrs.get("resource") != "secrets":
        return "no_opinion"
    if attrs.get("group", "") not in ("", None):
        return "no_opinion"
    req_ns = str(attrs.get("namespace") or "")
    verb = str(attrs.get("verb") or "")
    name = str(attrs.get("name") or "")
    if not is_tenant_editor(user, req_ns, config):
        return "no_opinion"
    if is_protected_secret(name, config) and verb in ENFORCEMENT_VERBS | {"create"}:
        return "deny"
    return "no_opinion"


def evaluate(review: dict[str, Any], config: PolicyConfig) -> Decision:
    spec = review.get("spec") or {}
    user = str(spec.get("user") or "")
    groups = list(spec.get("groups") or [])

    if is_bypass(user, groups, config):
        return "no_opinion"

    attrs = spec.get("resourceAttributes")
    if not isinstance(attrs, dict):
        return "no_opinion"

    if attrs.get("resource") != "secrets":
        return "no_opinion"
    if attrs.get("group", "") not in ("", None):
        return "no_opinion"

    req_ns = str(attrs.get("namespace") or "")
    if not req_ns or not is_tenant_editor(user, req_ns, config):
        return "no_opinion"

    verb = str(attrs.get("verb") or "")
    name = str(attrs.get("name") or "")

    if verb in COLLECTION_VERBS and name == "":
        return "allow"

    if verb in READ_VERBS and name != "":
        return "allow"

    if verb == "create":
        if name == "":
            return "no_opinion"
        if is_protected_secret(name, config):
            return "deny"
        return "allow"

    if verb in ENFORCEMENT_VERBS and name != "":
        if is_protected_secret(name, config):
            return "deny"
        return "allow"

    if verb == "deletecollection":
        return "no_opinion"

    return "no_opinion"
