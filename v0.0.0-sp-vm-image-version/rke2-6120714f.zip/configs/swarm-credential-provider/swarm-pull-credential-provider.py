#!/usr/bin/env python3
"""Kubelet image credential provider: fetch swarm-regcred from companion credentials namespace."""

from __future__ import annotations

import base64
import json
import os
import subprocess
import sys

API_VERSION = "credentialprovider.kubelet.k8s.io/v1"
SECRET_NAME = "swarm-regcred"
CREDENTIALS_NS_SUFFIX = "-secret"
CREDENTIALS_NS_LABEL = "swarm-cloud/credentials-ns"
KUBECONFIG = os.environ.get(
    "SWARM_PULL_CREDENTIAL_PROVIDER_KUBECONFIG",
    "/var/lib/rancher/rke2/agent/kubelet.kubeconfig",
)
KUBECTL_BIN = os.environ.get("RKE2_KUBECTL", "/var/lib/rancher/rke2/bin/kubectl")
CACHE_DURATION = os.environ.get("SWARM_PULL_CREDENTIAL_PROVIDER_CACHE_DURATION", "5m")


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def _kubectl_json(args: list[str]) -> dict:
    env = os.environ.copy()
    env["KUBECONFIG"] = KUBECONFIG
    result = subprocess.run(
        [KUBECTL_BIN, *args, "-o", "json"],
        env=env,
        capture_output=True,
        text=True,
        timeout=15,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "kubectl failed").strip())
    return json.loads(result.stdout)


def _namespace_from_sa_token(token: str) -> str | None:
    if not token:
        return None
    parts = token.split(".")
    if len(parts) < 2:
        return None
    payload = parts[1]
    padding = "=" * (-len(payload) % 4)
    try:
        raw = base64.urlsafe_b64decode(payload + padding)
        data = json.loads(raw)
    except (ValueError, json.JSONDecodeError):
        return None
    k8s = data.get("kubernetes.io") or {}
    if isinstance(k8s, dict):
        ns = k8s.get("namespace")
        if ns:
            return ns
        sa = k8s.get("serviceaccount")
        if isinstance(sa, dict) and sa.get("namespace"):
            return sa["namespace"]
    return data.get("kubernetes.io/serviceaccount/namespace")


def _credentials_namespace(workspace_ns: str) -> str:
    return f"{workspace_ns}{CREDENTIALS_NS_SUFFIX}"


def _namespace_is_credentials_vault(ns: str) -> bool:
    try:
        obj = _kubectl_json(["get", "namespace", ns])
    except RuntimeError:
        return False
    labels = (obj.get("metadata") or {}).get("labels") or {}
    return labels.get(CREDENTIALS_NS_LABEL) == "true"


def _fetch_docker_auth(secret_namespace: str) -> dict[str, dict[str, str]]:
    obj = _kubectl_json(["get", "secret", SECRET_NAME, "-n", secret_namespace])
    data = obj.get("data") or {}
    raw_b64 = data.get(".dockerconfigjson")
    if not raw_b64:
        raise RuntimeError(f"secret {SECRET_NAME} missing .dockerconfigjson in {secret_namespace}")
    docker_config = json.loads(base64.b64decode(raw_b64).decode())
    auths = docker_config.get("auths") or {}
    auth: dict[str, dict[str, str]] = {}
    for host, entry in auths.items():
        username = entry.get("username", "")
        password = entry.get("password", "")
        if not username and entry.get("auth"):
            try:
                decoded = base64.b64decode(entry["auth"]).decode()
                username, _, password = decoded.partition(":")
            except (ValueError, UnicodeDecodeError):
                pass
        if username or password:
            auth[host] = {"username": username, "password": password}
    if not auth:
        raise RuntimeError(f"no registry auth entries in {secret_namespace}/{SECRET_NAME}")
    return auth


def _empty_response() -> dict:
    return {
        "apiVersion": API_VERSION,
        "kind": "CredentialProviderResponse",
        "cacheKeyType": "Registry",
        "cacheDuration": CACHE_DURATION,
        "auth": {},
    }


def main() -> int:
    try:
        request = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        _log(f"invalid CredentialProviderRequest JSON: {exc}")
        json.dump(_empty_response(), sys.stdout)
        return 1

    if request.get("apiVersion") != API_VERSION:
        _log(f"unexpected apiVersion: {request.get('apiVersion')}")
        json.dump(_empty_response(), sys.stdout)
        return 1

    image = request.get("image") or ""
    sa_token = request.get("serviceAccountToken") or ""
    workspace_ns = _namespace_from_sa_token(sa_token)
    if not workspace_ns:
        _log(f"cannot resolve pod namespace from service account token (image={image})")
        json.dump(_empty_response(), sys.stdout)
        return 1

    secret_ns = _credentials_namespace(workspace_ns)
    if not _namespace_is_credentials_vault(secret_ns):
        _log(f"companion namespace {secret_ns} is not a credentials vault for workspace {workspace_ns}")
        json.dump(_empty_response(), sys.stdout)
        return 1

    try:
        auth = _fetch_docker_auth(secret_ns)
    except RuntimeError as exc:
        _log(str(exc))
        json.dump(_empty_response(), sys.stdout)
        return 1

    response = {
        "apiVersion": API_VERSION,
        "kind": "CredentialProviderResponse",
        "cacheKeyType": "Registry",
        "cacheDuration": CACHE_DURATION,
        "auth": auth,
    }
    json.dump(response, sys.stdout)
    return 0


if __name__ == "__main__":
    sys.exit(main())
