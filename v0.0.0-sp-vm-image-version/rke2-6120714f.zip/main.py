#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import hashlib
import time
import re
import json
from datetime import datetime, timezone
from pathlib import Path

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

from opa_authz_webhook import health_check_opa_authz_webhook, reconcile_opa_authz_webhook
from swarm_credential_provider import (
    health_check_swarm_credential_provider,
    reconcile_swarm_credential_provider,
)
from etcd_member import (
    capture_local_etcd_member_id,
    etcd_tls_ready,
    find_local_etcd_member,
    find_stale_etcd_members,
    list_etcd_members,
    remove_etcd_member,
)

# Configuration
RKE2_VERSION = os.environ.get("RKE2_VERSION", "v1.33.4+rke2r1")
RKE2_TOKEN = os.environ.get("RKE2_TOKEN", "DefaultRke2ClusterToken12345")
RKE2_CONFIG_DIR = Path("/etc/rancher/rke2")
RKE2_CONFIG_FILE = RKE2_CONFIG_DIR / "config.yaml"
RKE2_SERVER_DB = Path("/var/lib/rancher/rke2/server/db")
RKE2_ETCD_DATA_DIR = RKE2_SERVER_DB / "etcd"
RKE2_SERVER_PORT = 9345
KUBECTL_BIN = os.environ.get("RKE2_KUBECTL", "/var/lib/rancher/rke2/bin/kubectl")
RKE2_KUBECONFIG = Path("/etc/rancher/rke2/rke2.yaml")
SERVICE_DIR = Path(__file__).resolve().parent
CONFIGS_DIR = SERVICE_DIR / "configs"
# Do not kubectl-delete freshly joined nodes (heartbeat blip / expired ADD can drop
# ClusterNodes while the join is still in progress; delete → etcd member remove → orphan).
STALE_NODE_MIN_AGE_SEC = int(os.environ.get("RKE2_STALE_NODE_MIN_AGE_SEC", "600"))
# Do not wipe leftover etcd on the first tick etcd/API look down — that is also a
# normal first-time join (TLS/etcd/API still starting). Same window as API wait.
ORPHANED_JOIN_GRACE_SEC = int(os.environ.get("RKE2_ORPHANED_JOIN_GRACE_SEC", "600"))

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions

def read_config_file(name: str) -> str:
    return (CONFIGS_DIR / name).read_text()


def hash_node_id(node_id: str) -> str:
    """Create hex MD5 hash of node ID for k8s node name compatibility."""
    return hashlib.md5(node_id.encode()).hexdigest()


def generate_hostname_from_id(cluster_id: str) -> str:
    """Generate a valid hostname from cluster ID using base36 of MD5 hash."""
    md5_hash = hashlib.md5(cluster_id.encode()).digest()
    # Convert first 8 bytes of MD5 to integer
    hash_int = int.from_bytes(md5_hash[:8], byteorder='big')
    # Convert to base36
    chars = '0123456789abcdefghijklmnopqrstuvwxyz'
    if hash_int == 0:
        return '0'
    result = []
    while hash_int:
        hash_int, remainder = divmod(hash_int, 36)
        result.append(chars[remainder])
    return ''.join(reversed(result))


def compute_install_hash(state_json: dict, version: str, token: str) -> str:
    """Compute hash of cluster configuration to detect changes."""
    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])

    # Build payload from node IDs and their WG addresses
    node_ids = sorted([n["node_id"] for n in cluster_nodes])
    wg_addresses = []

    # Build map of node_id -> tunnel_ip
    tunnel_ip_map = {}
    for prop in wg_props:
        if prop.get("name") == "tunnel_ip":
            tunnel_ip_map[prop.get("node_id")] = prop.get("value")

    for node_id in node_ids:
        hashed_id = hash_node_id(node_id)
        tunnel_ip = tunnel_ip_map.get(node_id, "unknown")
        wg_addresses.append(f"{hashed_id}={tunnel_ip}")

    payload = "|".join(node_ids) + "|" + "|".join(wg_addresses) + "|" + str(RKE2_SERVER_PORT) + "|" + token + "|" + version
    return hashlib.sha256(payload.encode()).hexdigest()


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def is_bootstrap_done(rke2_props: list) -> bool:
    """Check if bootstrap is already done by any node."""
    for prop in rke2_props:
        if prop.get("name") == "k8s_bootstrap_done" and prop.get("value") == "true":
            return True
    return False


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")


def is_bootstrap_node(state_json: dict, local_node_id: str) -> bool:
    leader_node_id = get_leader_node(state_json)
    return leader_node_id == local_node_id


def rke2_systemd_unit(_is_bootstrap: bool = True) -> str:
    """Every cluster node runs rke2-server (embedded control-plane for HA)."""
    return "rke2-server"


def build_core_node_properties(
    *,
    api_ready: bool,
    is_bootstrap: bool,
    bootstrap_done: bool,
    opa_np: dict[str, str] | None = None,
) -> dict[str, str]:
    """Publish cluster coordination flags even when OPA reconcile is still pending."""
    node_properties = dict(opa_np or {})
    if api_ready:
        node_properties["k8s_node_ready"] = "true"
    if is_bootstrap and api_ready and not bootstrap_done:
        node_properties["k8s_bootstrap_done"] = "true"
    return node_properties


def stop_rke2_agent_if_active() -> None:
    """Disable rke2-agent when upgrading nodes from the single-CP worker model."""
    result = subprocess.run(
        ["systemctl", "is-active", "rke2-agent"],
        capture_output=True,
        text=True,
    )
    if result.stdout.strip() != "active":
        return
    print("[*] Stopping rke2-agent before switching node to rke2-server", file=sys.stderr)
    subprocess.run(["systemctl", "disable", "rke2-agent"], capture_output=True, text=True)
    subprocess.run(["systemctl", "stop", "rke2-agent"], capture_output=True, text=True)


def is_rke2_available() -> bool:
    """Check if RKE2 is installed: rke2-server.service unit is known to systemd.

    We rely only on the systemd unit presence, not on the rke2 binary. If the unit
    is missing (e.g. partial install or manual binary copy), the installer will be run.
    """
    try:
        result = subprocess.run(
            ["systemctl", "cat", "rke2-server.service"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def ensure_kernel_settings():
    """Configure kernel settings for RKE2."""
    errors = []
    try:
        result = subprocess.run(["modprobe", "br_netfilter"], capture_output=True, text=True)
        if result.returncode != 0:
            errors.append(f'Failed to load br_netfilter: {result.stderr}')
    except Exception as e:
        errors.append(f'Failed to load br_netfilter: {str(e)}')

    sysctls = [
        ("net.bridge.bridge-nf-call-iptables", "1"),
        ("net.bridge.bridge-nf-call-ip6tables", "1"),
        ("net.ipv4.ip_forward", "1"),
        ("net.ipv4.conf.all.rp_filter", "2"),
        ("net.ipv4.conf.default.rp_filter", "2"),
    ]

    for k, v in sysctls:
        try:
            result = subprocess.run(["sysctl", "-w", f"{k}={v}"], capture_output=True, text=True)
            if result.returncode != 0:
                errors.append(f'Failed to set {k}={v}: {result.stderr}')
        except Exception as e:
            errors.append(f'Failed to set {k}={v}: {str(e)}')

    if errors:
        raise Exception('; '.join(errors))


def install_rke2():
    """Install RKE2 using the official installation script."""
    try:
        env = os.environ.copy()
        env["INSTALL_RKE2_VERSION"] = RKE2_VERSION
        result = subprocess.run(
            ["/bin/sh", "-c", "curl -sfL https://get.rke2.io | sh -"],
            env=env,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise Exception(f'Installation script failed: {result.stderr}')
    except Exception as e:
        print(f"[!] Failed to install RKE2: {e}", file=sys.stderr)
        raise


def read_existing_rke2_arg_block(config_path: Path, block_key: str) -> list[str]:
    """Preserve a top-level list arg block (e.g. kube-apiserver-arg) across RKE2 config rewrites."""
    if not config_path.exists():
        return []
    lines = config_path.read_text().splitlines()
    for i, line in enumerate(lines):
        if line.strip() == f"{block_key}:":
            block = [line]
            j = i + 1
            while j < len(lines) and lines[j].startswith("  -"):
                block.append(lines[j])
                j += 1
            return block
    return []


def read_existing_kube_apiserver_arg_block(config_path: Path) -> list[str]:
    """Preserve kube-apiserver-arg lines (e.g. authorization-config) across RKE2 config rewrites."""
    return read_existing_rke2_arg_block(config_path, "kube-apiserver-arg")


def read_existing_kubelet_arg_block(config_path: Path) -> list[str]:
    """Preserve kubelet-arg lines (e.g. credential provider settings) across RKE2 config rewrites."""
    return read_existing_rke2_arg_block(config_path, "kubelet-arg")


def write_rke2_config(local_node_id: str, local_tunnel_ip: str, is_bootstrap: bool, leader_tunnel_ip: str | None, all_tunnel_ips: list, k8s_domain: str | None = None):
    """Write RKE2 configuration file.

    Args:
        local_node_id: Local node ID
        local_tunnel_ip: Local tunnel IP
        is_bootstrap: Whether this is bootstrap node
        leader_tunnel_ip: Leader tunnel IP (for non-bootstrap nodes)
        all_tunnel_ips: All cluster node tunnel IPs
        k8s_domain: Optional external k8s domain for TLS SAN
    """
    RKE2_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    local_hashed_id = hash_node_id(local_node_id)

    cfg_lines = [
        f"token: {RKE2_TOKEN}",
        f"node-ip: {local_tunnel_ip}",
        f"node-name: {local_hashed_id}",
        "cni: canal"
    ]

    # Add TLS SANs for all tunnel IPs and optional external domain
    tls_sans = []
    if all_tunnel_ips:
        tls_sans.extend(sorted(set(all_tunnel_ips)))
    if k8s_domain:
        tls_sans.append(k8s_domain)

    if tls_sans:
        cfg_lines.append("tls-san:")
        for san in tls_sans:
            cfg_lines.append(f"  - {san}")

    # Add server parameter for non-bootstrap nodes
    if not is_bootstrap and leader_tunnel_ip:
        cfg_lines.append(f"server: https://{leader_tunnel_ip}:{RKE2_SERVER_PORT}")

    preserved_apiserver_args = read_existing_kube_apiserver_arg_block(RKE2_CONFIG_FILE)
    if preserved_apiserver_args:
        cfg_lines.append("")
        cfg_lines.extend(preserved_apiserver_args)

    preserved_kubelet_args = read_existing_kubelet_arg_block(RKE2_CONFIG_FILE)
    if preserved_kubelet_args:
        cfg_lines.append("")
        cfg_lines.extend(preserved_kubelet_args)

    RKE2_CONFIG_FILE.write_text("\n".join(cfg_lines) + "\n")


def write_canal_cni_config():
    """Write Canal CNI configuration for WireGuard."""
    manifests_dir = Path("/var/lib/rancher/rke2/server/manifests")
    manifests_dir.mkdir(parents=True, exist_ok=True)

    (manifests_dir / "rke2-canal-config.yaml").write_text(
        read_config_file("rke2-canal-config.yaml")
    )


def write_ingress_nginx_config():
    """Write ingress-nginx configuration for NodePort."""
    manifests_dir = Path("/var/lib/rancher/rke2/server/manifests")
    manifests_dir.mkdir(parents=True, exist_ok=True)

    (manifests_dir / "rke2-ingress-nginx-config.yaml").write_text(
        read_config_file("rke2-ingress-nginx-config.yaml")
    )


def write_local_path_provisioner_config():
    """Write local-path-provisioner configuration as default storage class."""
    manifests_dir = Path("/var/lib/rancher/rke2/server/manifests")
    manifests_dir.mkdir(parents=True, exist_ok=True)

    (manifests_dir / "local-path-provisioner.yaml").write_text(
        read_config_file("local-path-provisioner.yaml")
    )
    print("[*] Local path provisioner configuration written as default storage class", file=sys.stderr)


def ensure_tenant_editor_cluster_role() -> tuple[bool, str | None]:
    """Create or refresh the tenant-editor ClusterRole."""
    if not RKE2_KUBECONFIG.exists():
        return False, "Kubeconfig not found"

    tenant_editor_role = read_config_file("tenant-editor-clusterrole.yaml")

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    try:
        apply_result = subprocess.run(
            [KUBECTL_BIN, "apply", "-f", "-"],
            env=env,
            input=tenant_editor_role,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if apply_result.returncode != 0:
            return False, f"Failed to apply tenant-editor ClusterRole: {apply_result.stderr.strip()}"

        return True, None
    except Exception as e:
        return False, str(e)


def has_gpu() -> bool:
    """Check if this node has NVIDIA GPU available."""
    # Check if GPU environment file exists (created by cloud-init)
    gpu_env_file = Path("/etc/rancher/rke2/gpu.env")
    if gpu_env_file.exists():
        return True

    # Use nvidia-smi as the definitive check — /proc/driver/nvidia/version
    # can exist on nodes without working GPUs (e.g. module loaded but no hardware),
    # leading to false positives and incorrect node labeling.
    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def write_nvidia_containerd_config():
    """Write containerd config.toml.tmpl for NVIDIA runtime support in RKE2.

    RKE2 generates containerd's config.toml from this template on startup.
    Adding the nvidia runtime handler here enables pods with runtimeClassName=nvidia
    to use the NVIDIA container runtime (required for GPU workloads like Ollama).

    Note: nvidia-container-runtime must already be installed on the host
    (provided by nvidia-container-toolkit, either in the base image or via setup script).
    """
    containerd_dir = Path("/var/lib/rancher/rke2/agent/etc/containerd")
    containerd_dir.mkdir(parents=True, exist_ok=True)

    tmpl_path = containerd_dir / "config.toml.tmpl"

    # Check if already configured to avoid unnecessary writes
    if tmpl_path.exists() and "nvidia" in tmpl_path.read_text():
        return False  # already configured, no restart needed

    tmpl_content = read_config_file("containerd-nvidia-config.toml.tmpl")

    tmpl_path.write_text(tmpl_content)
    print("[*] Containerd nvidia runtime config.toml.tmpl written", file=sys.stderr)
    return True  # newly written, RKE2 restart needed to apply


def write_nvidia_device_plugin_config():
    """Write NVIDIA Device Plugin DaemonSet manifest for Kubernetes.

    The device plugin:
    - Advertises GPU resources to Kubernetes (nvidia.com/gpu)
    - Enables GPU scheduling for pods requesting nvidia.com/gpu
    - Only runs on nodes with nvidia.com/gpu.present=true label
    - Uses NVML directly to discover GPUs (device-discovery-strategy=nvml)
      and mounts the host libnvidia-ml.so.1 into the container

    Note: The nvidia RuntimeClass is already managed by rke2-runtimeclasses.yaml.
    """
    manifests_dir = Path("/var/lib/rancher/rke2/server/manifests")
    manifests_dir.mkdir(parents=True, exist_ok=True)

    (manifests_dir / "nvidia-device-plugin.yaml").write_text(
        read_config_file("nvidia-device-plugin.yaml")
    )
    print("[*] NVIDIA Device Plugin manifest written", file=sys.stderr)


def label_node_with_gpu(local_node_id: str) -> bool:
    """Label the node with nvidia.com/gpu.present=true if it has GPU.

    Returns True on success, False on failure.
    """
    if not RKE2_KUBECONFIG.exists():
        print("[!] Cannot label GPU node: kubeconfig not found", file=sys.stderr)
        return False

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    node_name = hash_node_id(local_node_id)

    try:
        result = subprocess.run(
            [
                KUBECTL_BIN, "label", "node", node_name,
                "nvidia.com/gpu.present=true",
                "--overwrite"
            ],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0:
            print(f"[!] Failed to label GPU node: {result.stderr}", file=sys.stderr)
            return False

        print(f"[*] Labeled node {node_name} with nvidia.com/gpu.present=true", file=sys.stderr)
        return True
    except Exception as e:
        print(f"[!] Failed to label GPU node: {e}", file=sys.stderr)
        return False


_K8S_LABEL_VALUE_RE = re.compile(r"^[A-Za-z0-9]([-A-Za-z0-9_.]*[A-Za-z0-9])?$")
_SWARM_DEVICE_LABEL_PREFIX = "label.device.swarm.io/"
_K8S_DEVICE_LABEL_PREFIX = "device.swarm.io/"


def k8s_label_value(raw: str) -> str | None:
    """Return a valid Kubernetes label value, or None if it cannot be sanitized."""
    if raw is None:
        return None
    s = str(raw)
    if s == "":
        return ""
    if len(s) <= 63 and _K8S_LABEL_VALUE_RE.fullmatch(s):
        return s

    sanitized = s.replace(" ", "-").replace("/", "-")
    sanitized = re.sub(r"-{2,}", "-", sanitized)
    sanitized = sanitized.strip("-_.")
    if len(sanitized) > 63:
        sanitized = sanitized[:63].rstrip("-_.")
    if not sanitized or not _K8S_LABEL_VALUE_RE.fullmatch(sanitized):
        return None
    return sanitized


def desired_device_labels_by_node(
    state: dict,
    cluster_nodes: list,
) -> dict[str, dict[str, str]]:
    """Map member node_id → raw Swarm device.swarm.io label values (k8s keys).

    Members with no Swarm rows get an empty dict (desired empty).
    """
    member_ids = {n.get("node_id") for n in cluster_nodes if n.get("node_id")}
    result: dict[str, dict[str, str]] = {nid: {} for nid in member_ids}

    for row in state.get("deviceNodeLabels") or []:
        node = row.get("node")
        name = row.get("name") or ""
        if node not in member_ids or not name.startswith(_SWARM_DEVICE_LABEL_PREFIX):
            continue
        # Strip leading "label." → device.swarm.io/...
        k8s_key = name[len("label.") :]
        if not k8s_key.startswith(_K8S_DEVICE_LABEL_PREFIX):
            continue
        value = row.get("value")
        if value is None:
            continue
        result[node][k8s_key] = str(value)
    return result


def _device_display_annotation_key(label_key: str) -> str:
    return f"{label_key}-display"


def _kubectl_all_nodes_metadata(
    env: dict,
) -> dict[str, tuple[dict[str, str], dict[str, str]]] | None:
    """Labels and annotations for every Node, keyed by name. None if the list is unreadable."""
    try:
        result = subprocess.run(
            [KUBECTL_BIN, "get", "nodes", "-o", "json"],
            env=env,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            print(f"[!] Failed to list nodes: {result.stderr}", file=sys.stderr)
            return None
        data = json.loads(result.stdout)
        listed: dict[str, tuple[dict[str, str], dict[str, str]]] = {}
        for item in data.get("items") or []:
            meta = item.get("metadata") or {}
            name = meta.get("name")
            if not name:
                continue
            labels = {str(k): str(v) for k, v in (meta.get("labels") or {}).items()}
            annotations = {str(k): str(v) for k, v in (meta.get("annotations") or {}).items()}
            listed[str(name)] = (labels, annotations)
        return listed
    except Exception as e:
        print(f"[!] Failed to list nodes: {e}", file=sys.stderr)
        return None


def _kubectl_label_node(node_name: str, specs: list[str], env: dict) -> bool:
    if not specs:
        return True
    try:
        result = subprocess.run(
            [KUBECTL_BIN, "label", "node", node_name, *specs, "--overwrite"],
            env=env,
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            print(f"[!] Failed to label node {node_name}: {result.stderr}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"[!] Failed to label node {node_name}: {e}", file=sys.stderr)
        return False


def _kubectl_annotate_node(node_name: str, specs: list[str], env: dict) -> bool:
    if not specs:
        return True
    try:
        result = subprocess.run(
            [KUBECTL_BIN, "annotate", "node", node_name, *specs, "--overwrite"],
            env=env,
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            print(f"[!] Failed to annotate node {node_name}: {result.stderr}", file=sys.stderr)
            return False
        return True
    except Exception as e:
        print(f"[!] Failed to annotate node {node_name}: {e}", file=sys.stderr)
        return False


def sync_device_labels_to_k8s(
    state: dict,
    cluster_nodes: list,
    local_node_id: str,
) -> None:
    """Mirror device.swarm.io/* Swarm labels onto k8s Nodes (leader/bootstrap only).

    Never raises / never fails the caller: missing Nodes are skipped for health retry.
    """
    if get_leader_node(state) != local_node_id:
        return
    if not RKE2_KUBECONFIG.exists():
        return

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    desired_raw = desired_device_labels_by_node(state, cluster_nodes)
    listed = _kubectl_all_nodes_metadata(env)
    if listed is None:
        return

    for node_id, raw_labels in desired_raw.items():
        node_name = hash_node_id(node_id)
        meta = listed.get(node_name)
        if meta is None:
            print(
                f"[*] device labels: k8s Node {node_name} missing, will retry on health",
                file=sys.stderr,
            )
            continue

        current_labels, current_anns = meta

        desired_labels: dict[str, str] = {}
        desired_display: dict[str, str] = {}
        for key, raw in raw_labels.items():
            sanitized = k8s_label_value(raw)
            if sanitized is None:
                print(
                    f"[!] device labels: skip invalid value for {key} on {node_name}: {raw!r}",
                    file=sys.stderr,
                )
                continue
            desired_labels[key] = sanitized
            if sanitized != raw:
                desired_display[_device_display_annotation_key(key)] = raw

        label_specs: list[str] = []
        for key, value in desired_labels.items():
            if current_labels.get(key) != value:
                label_specs.append(f"{key}={value}")

        for key, value in current_labels.items():
            if not key.startswith(_K8S_DEVICE_LABEL_PREFIX):
                continue
            if key not in desired_labels:
                label_specs.append(f"{key}-")

        ann_specs: list[str] = []
        for key, value in desired_display.items():
            if current_anns.get(key) != value:
                ann_specs.append(f"{key}={value}")

        # Drop stale display annotations for managed keys (or removed labels).
        managed_display_keys = {
            _device_display_annotation_key(k) for k in desired_labels
        }
        # Also consider display anns for device labels we are removing.
        for key in list(current_anns):
            if not key.startswith(_K8S_DEVICE_LABEL_PREFIX) or not key.endswith("-display"):
                continue
            if key in desired_display:
                continue
            # Remove if no longer needed for a desired label, or label gone.
            base = key[: -len("-display")]
            if base.startswith(_K8S_DEVICE_LABEL_PREFIX) and key not in managed_display_keys:
                if current_anns.get(key) is not None:
                    ann_specs.append(f"{key}-")

        if not label_specs and not ann_specs:
            continue

        if label_specs:
            _kubectl_label_node(node_name, label_specs, env)
            print(f"[*] device labels: patched labels on {node_name}: {label_specs}", file=sys.stderr)
        if ann_specs:
            _kubectl_annotate_node(node_name, ann_specs, env)
            print(f"[*] device labels: patched annotations on {node_name}: {ann_specs}", file=sys.stderr)


def wait_for_api_ready(timeout_sec: int = 600) -> bool:
    """Wait for RKE2 API server to become ready."""
    if not RKE2_KUBECONFIG.exists():
        print("[!] Kubeconfig not found, waiting for API ready", file=sys.stderr)
        return False

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    start_time = time.time()
    last_error = None

    while time.time() - start_time < timeout_sec:
        try:
            result = subprocess.run(
                [KUBECTL_BIN, "get", "--raw", "/healthz"],
                env=env,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode == 0 and result.stdout.strip() == "ok":
                return True

            last_error = f"API returned: {result.stdout.strip()}"
        except subprocess.TimeoutExpired:
            last_error = "API health check timed out"
        except Exception as e:
            last_error = f"API health check error: {str(e)}"

        time.sleep(3)

    print(f"[!] API did not become ready within {timeout_sec}s. Last error: {last_error}", file=sys.stderr)
    return False


def wait_for_rke2_ready(_is_bootstrap: bool = True, timeout_sec: int = 600) -> bool:
    """Wait until the local RKE2 API is ready (all nodes run rke2-server)."""
    return wait_for_api_ready(timeout_sec)


def is_rke2_reconcile_ready(is_bootstrap: bool, local_state: dict) -> bool:
    """Whether steady-state RKE2 reconcile (OPA, credential provider, etc.) may run.

    Never trust ``api_ready`` alone: destroy for another cluster on this host runs the
    global uninstall and clears only that cluster's plugin state, so a sibling cluster
    can keep ``api_ready=true`` while the systemd unit is gone.
    """
    if not is_rke2_available():
        return False
    running, _ = is_rke2_running(is_bootstrap)
    return running


def is_rke2_running(is_bootstrap: bool = True) -> tuple[bool, str | None]:
    """Check if the local RKE2 systemd unit is running."""
    unit = rke2_systemd_unit(is_bootstrap)
    try:
        result = subprocess.run(
            ["systemctl", "is-active", unit],
            capture_output=True,
            text=True
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"{unit} status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def check_node_ready(local_node_id: str) -> tuple[bool, str | None]:
    """Check if local node is Ready in Kubernetes.
    Returns (is_ready, error_message)
    """
    if not RKE2_KUBECONFIG.exists():
        return False, "Kubeconfig not found"

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    node_name = hash_node_id(local_node_id)

    try:
        result = subprocess.run(
            [KUBECTL_BIN, "get", "node", node_name, "-o", "jsonpath={.status.conditions[?(@.type=='Ready')].status}"],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            return False, f'Failed to get node status: {result.stderr}'
        is_ready = result.stdout.strip() == "True"
        return is_ready, None if is_ready else f'Node status: {result.stdout.strip()}'
    except Exception as e:
        return False, f'Failed to check node readiness: {str(e)}'


def get_kubeconfig_with_wireguard_server(local_tunnel_ip: str, k8s_domain: str | None = None) -> str | None:
    """Read kubeconfig and replace server URL with {{ ip }} placeholder for swarm-cloud-api.
    Returns modified kubeconfig as string or None on error.

    Args:
        local_tunnel_ip: WireGuard tunnel IP for internal access (unused, kept for compatibility)
        k8s_domain: Optional external k8s domain (unused, kept for compatibility)
    """
    if not RKE2_KUBECONFIG.exists():
        return None

    try:
        kubeconfig_content = RKE2_KUBECONFIG.read_text()

        # Replace server URL with {{ ip }} placeholder so swarm-cloud-api
        # can substitute the actual node IP at runtime via nunjucks
        modified_kubeconfig = re.sub(
            r'(\s+server:\s+https://)([^:]+)(:\d+)',
            r'\g<1>{{ ip }}\g<3>',
            kubeconfig_content
        )

        return modified_kubeconfig
    except Exception as e:
        print(f"[!] Failed to read/modify kubeconfig: {e}", file=sys.stderr)
        return None


def get_k8s_nodes() -> list[str]:
    """Get list of all node names in the Kubernetes cluster.
    Returns empty list on error (logs to stderr).
    """
    if not RKE2_KUBECONFIG.exists():
        print("[!] Kubeconfig not found", file=sys.stderr)
        return []

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    # Retry with exponential backoff
    last_error = None
    for attempt in range(3):
        try:
            result = subprocess.run(
                [KUBECTL_BIN, "get", "nodes", "-o", "jsonpath={.items[*].metadata.name}", "--request-timeout=30s"],
                env=env,
                capture_output=True,
                text=True,
                timeout=45
            )
            if result.returncode == 0:
                nodes = result.stdout.strip().split()
                return [n for n in nodes if n]  # Filter empty strings

            # On error, wait before retry
            last_error = f"kubectl failed: {result.stderr}"
            if attempt < 2:
                time.sleep(2 ** attempt)
        except subprocess.TimeoutExpired as e:
            last_error = f"kubectl timed out: {str(e)}"
            if attempt < 2:
                time.sleep(2 ** attempt)
        except Exception as e:
            last_error = f"kubectl error: {str(e)}"
            if attempt < 2:
                time.sleep(2 ** attempt)

    print(f"[!] Failed to get k8s nodes after 3 attempts: {last_error}", file=sys.stderr)
    return []


def cordon_node(node_name: str) -> bool:
    """Cordon a node to prevent new pods from being scheduled."""
    if not RKE2_KUBECONFIG.exists():
        return False

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    try:
        result = subprocess.run(
            [KUBECTL_BIN, "cordon", node_name, "--request-timeout=30s"],
            env=env,
            capture_output=True,
            text=True,
            timeout=45
        )
        return result.returncode == 0
    except Exception as e:
        print(f"[!] Cordon failed: {e}", file=sys.stderr)
        return False


def drain_node(node_name: str) -> bool:
    """Drain a node to evict all pods."""
    if not RKE2_KUBECONFIG.exists():
        return False

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    try:
        result = subprocess.run(
            [
                KUBECTL_BIN, "drain", node_name,
                "--ignore-daemonsets",
                "--delete-emptydir-data",
                "--force",
                "--grace-period=30",
                "--timeout=60s",
                "--request-timeout=60s"
            ],
            env=env,
            capture_output=True,
            text=True,
            timeout=90
        )
        if result.returncode != 0:
            print(f"[!] Drain stderr: {result.stderr}", file=sys.stderr)
        return result.returncode == 0
    except Exception as e:
        print(f"[!] Drain exception: {e}", file=sys.stderr)
        return False


def delete_node(node_name: str) -> bool:
    """Delete a node from the Kubernetes cluster."""
    if not RKE2_KUBECONFIG.exists():
        return False

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    try:
        result = subprocess.run(
            [KUBECTL_BIN, "delete", "node", node_name, "--request-timeout=30s"],
            env=env,
            capture_output=True,
            text=True,
            timeout=45
        )
        if result.returncode != 0:
            print(f"[!] Delete node stderr: {result.stderr}", file=sys.stderr)
        return result.returncode == 0
    except Exception as e:
        print(f"[!] Delete node exception: {e}", file=sys.stderr)
        return False


def get_secret_from_swarmdb(state_json: dict, secret_id: str) -> str | None:
    """Get secret value from SwarmSecrets table."""
    secrets = state_json.get("swarmSecrets", [])
    for secret in secrets:
        if secret.get("id") == secret_id:
            return secret.get("value")
    return None


def get_cluster_property(state_json: dict, name: str) -> str | None:
    """Get cluster property value from state."""
    props = state_json.get("clusterProperties", [])
    if not isinstance(props, list):
        return None
    for prop in props:
        if prop.get("name") == name:
            return prop.get("value")
    return None


def compute_k8s_domain(cluster_id: str | None, global_id: str | None, base_domain: str | None) -> str | None:
    """Compute external k8s domain for the k8s_external_hostname cluster property."""
    if not cluster_id or not global_id or not base_domain:
        return None
    full_zone_name = f"{global_id}.{base_domain}"
    cluster_hostname = generate_hostname_from_id(cluster_id)
    return f"k8s-{cluster_hostname}.{full_zone_name}"


# Kubernetes control-plane evidence (SP-7701)
#
# The leader RKE2 node periodically snapshots the cluster's kube-system surface
# so the swarm-cloud-api aggregator (k8s-control-plane-evidence-worker) can
# bundle it into the JWS served at `/.well-known/swarm-evidence` for the
# cluster's external hostname. We publish into `clusternodeproperties` rather
# than directly into Redis because SwarmDB is the cross-node source of truth —
# the API node may differ from the RKE2 leader.
#
# Property names map 1:1 to the SP-7701 spec:
#   rke2_version, rke2_install_hash, rke2_image_digests (JSON object),
#   kube_system_snapshot_digest (sha256/<base64url>),
#   kube_system_snapshot_json   (canonical JSON of the snapshot body)
#
# Snapshot stability: the digest is recomputed every leader reconcile (cheap),
# but the full JSON body is only republished when the digest changes. This
# matches the "evidence is dancing" guard in the issue — RKE2 minor bumps that
# rev Canal will flip the digest, but a steady cluster produces idempotent
# writes.
KUBE_SYSTEM_NAMESPACES = ("kube-system", "kube-public", "kube-node-lease")
KUBE_SYSTEM_KINDS = ("deployments", "daemonsets", "statefulsets")
KUBE_SYSTEM_COMPONENT_PATTERNS: list[tuple[str, str]] = [
    # Order matters — first match wins.
    ("canal", "canal"),
    ("ingress-nginx-controller", "ingress-nginx"),
    ("rke2-ingress-nginx", "ingress-nginx"),
    ("local-path-provisioner", "local-path-provisioner"),
    ("nvidia-device-plugin", "nvidia-device-plugin"),
    ("metrics-server", "metrics-server"),
    ("coredns", "coredns"),
]


def _canonical_json(value) -> str:
    """Serialise to canonical JSON: sorted keys, no whitespace.

    Used both to compute the snapshot digest and to publish the JSON body so
    the digest is reproducible from the published value. Trailing newline is
    intentionally omitted to keep `sha256(canonical_json) == digest`.
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _sha256_b64url(data: bytes) -> str:
    """Wire-format digest used across the unified attestation contract."""
    import base64
    return "sha256/" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode("ascii")


def _kubectl_json(args: list[str], timeout: int = 30) -> dict | None:
    """Run a kubectl command and parse stdout as JSON. Returns None on any error.

    Failures are intentionally non-fatal — evidence collection must never
    break cluster reconcile, so the caller treats absence of evidence as
    "skip publishing this tick" rather than as an error.
    """
    if not RKE2_KUBECONFIG.exists():
        return None
    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)
    try:
        result = subprocess.run(
            [KUBECTL_BIN, *args, "--request-timeout=30s"],
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            return None
        return json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError):
        return None


def collect_kube_system_image_digests() -> dict:
    """Return component name → unique image-id list for the kube-system surface.

    Image IDs come from `pod.status.containerStatuses[].imageID`, which the
    kubelet writes once it has resolved an image to a digest reference (the
    value typically looks like `<repo>@sha256:<hex>`). Components that haven't
    finished pulling yet have an empty `imageID` — those are skipped on this
    reconcile and will be filled in on the next one.
    """
    digests: dict[str, set[str]] = {}
    for namespace in KUBE_SYSTEM_NAMESPACES:
        pods = _kubectl_json(["get", "pods", "-n", namespace, "-o", "json"])
        if not pods or "items" not in pods:
            continue
        for pod in pods.get("items", []):
            pod_name = pod.get("metadata", {}).get("name", "")
            statuses = (pod.get("status", {}) or {}).get("containerStatuses", []) or []
            for cs in statuses:
                image_id = cs.get("imageID") or ""
                if not image_id:
                    continue
                component = _component_for_pod(pod_name, cs.get("image") or "")
                if not component:
                    continue
                digests.setdefault(component, set()).add(image_id)
    # Convert sets to sorted lists for deterministic JSON.
    return {k: sorted(v) for k, v in digests.items()}


def _component_for_pod(pod_name: str, image: str) -> str | None:
    haystack = f"{pod_name} {image}".lower()
    for needle, component in KUBE_SYSTEM_COMPONENT_PATTERNS:
        if needle in haystack:
            return component
    return None


def collect_kube_system_workload_snapshot() -> dict:
    """Return the kube-system workload surface used to compute the snapshot.

    Each entry is a minimal projection of a Deployment / DaemonSet /
    StatefulSet — name, namespace, kind, replica intent, and the container
    image references resolved from spec.template.spec.containers[].image.
    The shape is intentionally narrow: image *digests* live in a separate
    field (rke2_image_digests) sourced from running pods, while this snapshot
    captures the *intent* recorded in the apiserver. Together they cover both
    "what was scheduled" and "what is actually running".
    """
    workloads: list[dict] = []
    for namespace in KUBE_SYSTEM_NAMESPACES:
        for kind in KUBE_SYSTEM_KINDS:
            data = _kubectl_json(["get", kind, "-n", namespace, "-o", "json"])
            if not data:
                continue
            for item in data.get("items", []) or []:
                meta = item.get("metadata", {}) or {}
                spec = item.get("spec", {}) or {}
                template_spec = ((spec.get("template", {}) or {}).get("spec", {})) or {}
                containers = template_spec.get("containers", []) or []
                init_containers = template_spec.get("initContainers", []) or []
                workloads.append({
                    "namespace": meta.get("namespace") or namespace,
                    "kind": kind,
                    "name": meta.get("name"),
                    "generation": meta.get("generation"),
                    "replicas": spec.get("replicas"),
                    "containers": [
                        {"name": c.get("name"), "image": c.get("image")}
                        for c in containers if isinstance(c, dict)
                    ],
                    "initContainers": [
                        {"name": c.get("name"), "image": c.get("image")}
                        for c in init_containers if isinstance(c, dict)
                    ],
                })
    workloads.sort(key=lambda w: (w.get("namespace") or "", w.get("kind") or "", w.get("name") or ""))
    return {"namespaces": list(KUBE_SYSTEM_NAMESPACES), "workloads": workloads}


def build_kube_system_evidence_properties(local_state: dict, install_hash: str) -> tuple[dict, dict]:
    """Compute evidence-related node properties for the leader RKE2 node.

    Returns (properties, new_local_state_fragment). On any kubectl failure,
    returns ({}, {}) — never propagates an error, since evidence collection is
    advisory and must not block the apply path.
    """
    snapshot = collect_kube_system_workload_snapshot()
    if not snapshot.get("workloads"):
        # Empty workload list means kubectl failed for every namespace — skip
        # publishing rather than overwriting a known-good snapshot with an
        # empty one.
        return {}, {}

    image_digests = collect_kube_system_image_digests()
    snapshot_with_digests = {**snapshot, "imageDigests": image_digests}
    snapshot_json = _canonical_json(snapshot_with_digests)
    snapshot_digest = _sha256_b64url(snapshot_json.encode("utf-8"))

    properties: dict[str, str] = {
        "rke2_version": RKE2_VERSION,
        "rke2_install_hash": install_hash,
        "rke2_image_digests": _canonical_json(image_digests),
        "kube_system_snapshot_digest": snapshot_digest,
    }

    # Only republish the (potentially large) JSON body when the digest moves —
    # avoids "evidence is dancing" on a steady cluster.
    if local_state.get("kube_system_snapshot_digest") != snapshot_digest:
        properties["kube_system_snapshot_json"] = snapshot_json

    return properties, {"kube_system_snapshot_digest": snapshot_digest}


def get_k8s_node_age_seconds(node_name: str) -> float | None:
    """Return age of a Kubernetes Node object in seconds, or None if unknown."""
    try:
        result = subprocess.run(
            [
                KUBECTL_BIN,
                "--kubeconfig",
                str(RKE2_KUBECONFIG),
                "get",
                "node",
                node_name,
                "-o",
                "jsonpath={.metadata.creationTimestamp}",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return None
        raw = result.stdout.strip()
        # RFC3339, e.g. 2026-08-07T12:34:56Z
        if raw.endswith("Z"):
            created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        else:
            created = datetime.fromisoformat(raw)
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - created).total_seconds())
    except Exception:
        return None


def is_k8s_node_ready(node_name: str) -> bool | None:
    """Return True/False for Node Ready condition, or None if unknown."""
    try:
        result = subprocess.run(
            [
                KUBECTL_BIN,
                "--kubeconfig",
                str(RKE2_KUBECONFIG),
                "get",
                "node",
                node_name,
                "-o",
                'jsonpath={.status.conditions[?(@.type=="Ready")].status}',
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if result.returncode != 0:
            return None
        status = result.stdout.strip()
        if status == "True":
            return True
        if status in ("False", "Unknown"):
            return False
        return None
    except Exception:
        return None


def is_local_apiserver_up(*, timeout_sec: float = 3.0) -> bool:
    """Cheap probe: local kube-apiserver answering on 6443 (or via kubectl)."""
    try:
        result = subprocess.run(
            [
                KUBECTL_BIN,
                "--kubeconfig",
                str(RKE2_KUBECONFIG),
                "get",
                "--raw",
                "/readyz",
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
        return result.returncode == 0
    except Exception:
        return False


def is_orphaned_joining_server(*, is_bootstrap: bool) -> bool:
    """Detect join leftover after peers removed our etcd member via kubectl delete node.

    Joining servers keep ``server:`` in config and local etcd data under
    ``initial-cluster-state: existing``. After the member is gone remotely, local
    etcd never comes up (no 2379/6443) while rke2-server may still run — classic
    Canal/CNI CrashLoop with only 9345 listening.

    TLS missing, etcd not listed, and API down also happen during a healthy
    first-time join. Callers must wait ``ORPHANED_JOIN_GRACE_SEC`` before wipe.
    """
    if is_bootstrap:
        return False
    if not RKE2_CONFIG_FILE.exists():
        return False
    try:
        cfg = RKE2_CONFIG_FILE.read_text()
    except OSError:
        return False
    if not re.search(r"(?m)^server:\s", cfg):
        return False
    if not RKE2_ETCD_DATA_DIR.exists():
        return False
    if not etcd_tls_ready():
        return False
    members, _err = list_etcd_members()
    if members is not None:
        return False
    if is_local_apiserver_up():
        return False
    return True


def reset_orphaned_joining_server() -> None:
    """Wipe local etcd DB so the next start can rejoin as a fresh member."""
    print(
        "[*] Orphaned etcd join detected (local DB present, etcd/API down) — "
        "wiping server/db for clean rejoin",
        file=sys.stderr,
    )
    subprocess.run(
        ["systemctl", "stop", "rke2-server"],
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )
    if RKE2_SERVER_DB.exists():
        shutil.rmtree(RKE2_SERVER_DB, ignore_errors=True)


def clear_orphaned_join_local_state(local_state: dict) -> dict:
    """Force apply to reinstall/rejoin after wiping orphaned etcd data."""
    return {
        **local_state,
        "api_ready": False,
        "install_hash": None,
        "etcd_member_id": None,
        "etcd_member_name": None,
        "etcd_member_remove_started": False,
        "orphaned_join_detected_at": None,
    }


def reconcile_orphaned_joining_server(
    *, is_bootstrap: bool, local_state: dict, now: float | None = None
) -> dict:
    """Wipe leftover etcd DB only after orphan symptoms persist past grace."""
    now = time.time() if now is None else now
    if not is_orphaned_joining_server(is_bootstrap=is_bootstrap):
        if local_state.get("orphaned_join_detected_at") is None:
            return local_state
        return {**local_state, "orphaned_join_detected_at": None}

    detected_at = local_state.get("orphaned_join_detected_at")
    try:
        detected_at_f = float(detected_at) if detected_at is not None else None
    except (TypeError, ValueError):
        detected_at_f = None

    if detected_at_f is None:
        print(
            "[*] Possible orphaned etcd join (local DB present, etcd/API down) — "
            f"waiting {ORPHANED_JOIN_GRACE_SEC}s before wipe so in-progress joins can finish",
            file=sys.stderr,
        )
        return {**local_state, "orphaned_join_detected_at": now}

    elapsed = now - detected_at_f
    if elapsed < ORPHANED_JOIN_GRACE_SEC:
        return local_state

    reset_orphaned_joining_server()
    return clear_orphaned_join_local_state(local_state)


def remove_stale_nodes(
    cluster_nodes: list, local_state: dict
) -> tuple[bool, list[str], list[str]]:
    """Remove Kubernetes Nodes that are not in current Swarm membership.

    Compares live ``kubectl get nodes`` to hashed ``clusterNodes`` (not only
    ``known_node_ids`` deltas). That way a node that left for another RKE2
    cluster cannot leave a permanent NotReady ghost after ``known_node_ids``
    was overwritten.

    Ready + young orphans keep a short grace (heartbeat blip / join race).
    NotReady/Unknown orphans are deleted immediately.

    Returns ``(success, removed_k8s_names, known_node_ids_to_persist)``.
    Persisted ids are current members plus any still-pending grace/failed deletes
    so the next tick retries instead of forgetting them.
    """
    current_node_ids = {
        node.get("node_id") for node in cluster_nodes if node.get("node_id")
    }
    previous_node_ids = {
        nid for nid in (local_state.get("known_node_ids") or []) if nid
    }
    expected_names = {hash_node_id(nid) for nid in current_node_ids}
    name_to_node_id = {
        hash_node_id(nid): nid for nid in (current_node_ids | previous_node_ids)
    }

    k8s_nodes = set(get_k8s_nodes())
    if not k8s_nodes and (previous_node_ids or current_node_ids):
        print("[!] Cannot retrieve k8s nodes - API server may be unhealthy", file=sys.stderr)
        # Keep previous tracking so we retry when API recovers.
        return True, [], sorted(current_node_ids | previous_node_ids)

    orphan_names = k8s_nodes - expected_names
    if not orphan_names:
        return True, [], sorted(current_node_ids)

    print(
        f"[*] Detected {len(orphan_names)} k8s node(s) not in Swarm membership",
        file=sys.stderr,
    )

    removed_nodes: list[str] = []
    pending_stale_ids: set[str] = set()

    for node_name in sorted(orphan_names):
        node_id = name_to_node_id.get(node_name)
        ready = is_k8s_node_ready(node_name)
        age_sec = get_k8s_node_age_seconds(node_name)

        # Only Ready+young gets grace (avoid deleting a briefly missing member).
        if ready is True and age_sec is not None and age_sec < STALE_NODE_MIN_AGE_SEC:
            print(
                f"[*] Skipping stale remove for {node_name}: Ready, age "
                f"{int(age_sec)}s < {STALE_NODE_MIN_AGE_SEC}s grace "
                f"(avoid etcd orphan during join / heartbeat blip)",
                file=sys.stderr,
            )
            if node_id:
                pending_stale_ids.add(node_id)
            continue

        reason = (
            "NotReady/Unknown" if ready is not True else f"age>={STALE_NODE_MIN_AGE_SEC}s"
        )
        print(
            f"[*] Removing stale k8s node {node_name}"
            f"{f' (node_id: {node_id})' if node_id else ''} [{reason}]",
            file=sys.stderr,
        )

        if cordon_node(node_name):
            print(f"[*] Cordoned node {node_name}", file=sys.stderr)
        else:
            print(f"[!] Failed to cordon node {node_name}, continuing...", file=sys.stderr)

        # NotReady/Unknown nodes are typically unreachable (already in another
        # cluster). kubectl drain waits on eviction and exceeds health's 30s
        # timeout, so the plugin is killed before delete. Skip drain there.
        if ready is True:
            if drain_node(node_name):
                print(f"[*] Drained node {node_name}", file=sys.stderr)
            else:
                print(f"[!] Failed to drain node {node_name}, continuing...", file=sys.stderr)
        else:
            print(
                f"[*] Skipping drain for {node_name} ({reason}); deleting Node object",
                file=sys.stderr,
            )

        if delete_node(node_name):
            print(f"[*] Deleted node {node_name}", file=sys.stderr)
            removed_nodes.append(node_name)
        else:
            print(
                f"[!] Failed to delete node {node_name}, will retry on next reconcile",
                file=sys.stderr,
            )
            if node_id:
                pending_stale_ids.add(node_id)

    known_to_persist = sorted(current_node_ids | pending_stale_ids)
    return True, removed_nodes, known_to_persist


def remove_stale_etcd_members(
    cluster_nodes: list,
    wg_props: list,
    local_node_id: str,
) -> list[str]:
    """Remove etcd members that are not in current Swarm membership.

    Leaving-node finalize cannot do this after a cross-cluster move: the VM
    now talks to a different etcd. Stale members (same peer IP, old member id)
    leave the survivor cluster unhealthy so new joiners cannot add.
    """
    members, err = list_etcd_members()
    if members is None:
        print(f"[!] etcd stale-member scan skipped: {err}", file=sys.stderr)
        return []

    expected_hashes: set[str] = set()
    expected_peer_ips: set[str] = set()
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not node_id:
            continue
        expected_hashes.add(hash_node_id(node_id))
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            expected_peer_ips.add(tunnel_ip)

    local_hash = hash_node_id(local_node_id) if local_node_id else None
    stale = find_stale_etcd_members(
        members,
        expected_hashes=expected_hashes,
        expected_peer_ips=expected_peer_ips,
        local_hash=local_hash,
    )
    if not stale:
        return []

    print(
        f"[*] Detected {len(stale)} etcd member(s) not in Swarm membership",
        file=sys.stderr,
    )
    removed: list[str] = []
    for member in stale:
        name = member.get("name") or ""
        k8s_name = name.split("-", 1)[0] if name else ""
        if k8s_name:
            ready = is_k8s_node_ready(k8s_name)
            age_sec = get_k8s_node_age_seconds(k8s_name)
            if ready is True and age_sec is not None and age_sec < STALE_NODE_MIN_AGE_SEC:
                print(
                    f"[*] Skipping etcd member remove for {name}: K8s node Ready, "
                    f"age {int(age_sec)}s < {STALE_NODE_MIN_AGE_SEC}s grace",
                    file=sys.stderr,
                )
                continue
        member_id = member.get("id") or ""
        print(
            f"[*] Removing stale etcd member {name or member_id} id={member_id}",
            file=sys.stderr,
        )
        ok, remove_err = remove_etcd_member(member_id)
        if ok:
            print(f"[*] Removed etcd member {member_id}", file=sys.stderr)
            removed.append(name or member_id)
        else:
            print(f"[!] Failed to remove etcd member {member_id}: {remove_err}", file=sys.stderr)
    return removed


# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize RKE2: install packages and configure kernel."""
    try:
        # Install RKE2 if not present
        if not is_rke2_available():
            install_rke2()

        # Configure kernel settings
        ensure_kernel_settings()

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply RKE2 configuration and start the cluster."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    rke2_props = state_json.get("rke2NodeProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])
    cluster = state_json.get("cluster", {})

    # Check if all nodes have WireGuard configured
    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all nodes',
            local_state=local_state
        )

    # Determine if this is bootstrap node (leader_node from cluster)
    leader_node_id = get_leader_node(state_json)
    is_bootstrap = (leader_node_id == local_node_id)
    bootstrap_done = is_bootstrap_done(rke2_props)

    # For non-bootstrap nodes: wait for bootstrap to complete
    if not is_bootstrap and not bootstrap_done:
        return PluginOutput(
            status='postponed',
            error_message=f'Waiting for bootstrap node {leader_node_id} to complete initialization',
            local_state=local_state
        )

    # For non-bootstrap nodes: also wait for leader's k8s_node_ready flag
    if not is_bootstrap:
        leader_ready = False
        for prop in rke2_props:
            node_id = prop.get("node_id")
            if node_id == leader_node_id and prop.get("name") == "k8s_node_ready" and prop.get("value") == "true":
                leader_ready = True
                break

        if not leader_ready:
            return PluginOutput(
                status='postponed',
                error_message=f'Waiting for bootstrap node {leader_node_id} to become ready',
                local_state=local_state
            )

    # Self-heal orphaned join: peer kubectl-delete removed our etcd member while
    # local server/db remained (initial-cluster-state=existing → no API / CNI flap).
    # Wait out grace so a first-time join (TLS/etcd/API still coming up) is not wiped.
    local_state = reconcile_orphaned_joining_server(
        is_bootstrap=is_bootstrap, local_state=local_state
    )

    # Get local tunnel IP
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status='error',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state
        )

    # Get leader tunnel IP (for non-bootstrap nodes)
    leader_tunnel_ip = None
    if not is_bootstrap and leader_node_id:
        leader_tunnel_ip = get_node_tunnel_ip(leader_node_id, wg_props)
        if not leader_tunnel_ip:
            return PluginOutput(
                status='postponed',
                error_message='Bootstrap node has no WireGuard tunnel IP yet',
                local_state=local_state
            )

    # Collect all tunnel IPs for TLS SANs
    all_tunnel_ips = []
    for node in cluster_nodes:
        tunnel_ip = get_node_tunnel_ip(node.get("node_id"), wg_props)
        if tunnel_ip:
            all_tunnel_ips.append(tunnel_ip)

    # Get cluster ID and global ID for k8s domain
    cluster_id = cluster.get("id")
    global_id = state_json.get("globalId")
    base_domain = get_secret_from_swarmdb(state_json, "base_domain")

    desired_k8s_domain = compute_k8s_domain(cluster_id, global_id, base_domain)
    current_k8s_external_hostname = get_cluster_property(state_json, "k8s_external_hostname")

    # Compute install hash to detect config changes (include desired_k8s_domain in hash)
    install_hash = compute_install_hash(state_json, RKE2_VERSION, RKE2_TOKEN)
    if desired_k8s_domain:
        import hashlib
        install_hash = hashlib.sha256(f"{install_hash}|{desired_k8s_domain}".encode()).hexdigest()

    # Track known node IDs for stale node detection
    current_node_ids = [node.get("node_id") for node in cluster_nodes if node.get("node_id")]

    # If this is the leader node and API is ready, remove stale nodes
    if is_bootstrap and local_state.get("api_ready"):
        print(f"[*] Leader node checking for stale nodes to remove", file=sys.stderr)
        success, removed_nodes, known_node_ids = remove_stale_nodes(cluster_nodes, local_state)
        if not success:
            print(f"[!] Failed to remove stale nodes from cluster", file=sys.stderr)
            return PluginOutput(
                status='postponed',
                error_message='Failed to remove stale nodes from cluster',
                local_state={**local_state, "known_node_ids": known_node_ids}
            )
        current_node_ids = known_node_ids
        local_state = {**local_state, "known_node_ids": known_node_ids}
        if removed_nodes:
            print(f"[*] Apply: Successfully removed {len(removed_nodes)} stale node(s): {', '.join(removed_nodes)}", file=sys.stderr)
        removed_etcd = remove_stale_etcd_members(cluster_nodes, wg_props, local_node_id)
        if removed_etcd:
            print(
                f"[*] Apply: Removed {len(removed_etcd)} stale etcd member(s): {', '.join(removed_etcd)}",
                file=sys.stderr,
            )

    # Check if we need to reconfigure
    prev_install_hash = local_state.get("install_hash")
    if prev_install_hash == install_hash and is_rke2_reconcile_ready(is_bootstrap, local_state):
        if is_bootstrap:
            tenant_editor_ok, tenant_editor_error = ensure_tenant_editor_cluster_role()
            if not tenant_editor_ok:
                return PluginOutput(
                    status='postponed',
                    error_message=f'Failed to ensure tenant-editor ClusterRole: {tenant_editor_error}',
                    local_state={**local_state, "known_node_ids": current_node_ids}
                )

        opa_msg, opa_np, opa_st = reconcile_opa_authz_webhook(
            state_json,
            local_node_id,
            local_state,
            is_leader=is_bootstrap,
            is_bootstrap=is_bootstrap,
            require_swarm_k8s_node_ready=True,
        )
        cp_msg, cp_np, cp_st = reconcile_swarm_credential_provider(
            is_bootstrap=is_bootstrap,
            local_state={**local_state, **opa_st},
        )
        node_properties = build_core_node_properties(
            api_ready=True,
            is_bootstrap=is_bootstrap,
            bootstrap_done=bootstrap_done,
            opa_np={**opa_np, **cp_np},
        )
        if opa_msg:
            return PluginOutput(
                status='postponed',
                error_message=opa_msg,
                node_properties=node_properties,
                local_state={**local_state, **opa_st, "known_node_ids": current_node_ids},
            )
        if cp_msg:
            return PluginOutput(
                status='postponed',
                error_message=cp_msg,
                node_properties=node_properties,
                local_state={**local_state, **opa_st, **cp_st, "known_node_ids": current_node_ids},
            )

        # No changes, skip reconfiguration but still publish node properties
        # This is important for worker nodes that may be waiting for bootstrap properties

        # Label GPU node if not already labeled
        node_has_gpu = has_gpu()
        if node_has_gpu and not local_state.get("gpu_labeled"):
            if label_node_with_gpu(local_node_id):
                local_state["gpu_labeled"] = True
                print(f"[*] GPU node labeled during reconcile", file=sys.stderr)

        # Mirror Swarm device.swarm.io/* onto k8s Nodes (leader only; skip if unchanged).
        sync_device_labels_to_k8s(state_json, cluster_nodes, local_node_id)

        # Ensure NVIDIA configs are present — may have been missed on initial setup
        # (e.g. GPU driver not ready yet when apply first ran, or first-time code fix).
        if node_has_gpu:
            manifest_path = Path("/var/lib/rancher/rke2/server/manifests/nvidia-device-plugin.yaml")
            if not manifest_path.exists():
                write_nvidia_device_plugin_config()
                print("[*] NVIDIA Device Plugin manifest written during reconcile", file=sys.stderr)

            containerd_newly_written = write_nvidia_containerd_config()
            if containerd_newly_written:
                # Containerd config was missing — restart RKE2 so it picks up the nvidia runtime.
                print("[*] Restarting rke2-server to apply nvidia containerd runtime config", file=sys.stderr)
                subprocess.run(["systemctl", "restart", "rke2-server"], capture_output=True, text=True)
                if not wait_for_api_ready(timeout_sec=300):
                    print("[!] RKE2 API did not recover after restart", file=sys.stderr)
                else:
                    print("[*] RKE2 restarted successfully", file=sys.stderr)

        cluster_properties = None
        if is_bootstrap and desired_k8s_domain and current_k8s_external_hostname != desired_k8s_domain:
            cluster_properties = {"k8s_external_hostname": desired_k8s_domain}
            current_k8s_external_hostname = desired_k8s_domain

        # Generate kubeconfig
        stored_k8s_domain = current_k8s_external_hostname
        kubeconfig = get_kubeconfig_with_wireguard_server(local_tunnel_ip, stored_k8s_domain)
        if kubeconfig:
            node_properties["k8s_kubeconfig"] = kubeconfig

        evidence_state_fragment: dict = {}
        if is_bootstrap:
            evidence_props, evidence_state_fragment = build_kube_system_evidence_properties(local_state, install_hash)
            node_properties.update(evidence_props)

        reconcile_local_state = {
            **local_state,
            **opa_st,
            **cp_st,
            "known_node_ids": current_node_ids,
            **evidence_state_fragment,
        }
        reconcile_local_state = capture_local_etcd_member_id(
            reconcile_local_state,
            node_hash=hash_node_id(local_node_id),
            tunnel_ip=local_tunnel_ip,
        )

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            cluster_properties=cluster_properties,
            local_state=reconcile_local_state,
        )

    rke2_unit = rke2_systemd_unit(is_bootstrap)

    # Write RKE2 configuration
    try:
        write_rke2_config(local_node_id, local_tunnel_ip, is_bootstrap, leader_tunnel_ip, all_tunnel_ips, desired_k8s_domain)

        write_canal_cni_config()
        write_ingress_nginx_config()
        if is_bootstrap:
            write_local_path_provisioner_config()

        # Write NVIDIA configs on any node that has GPU.
        # write_nvidia_containerd_config must run BEFORE systemctl start rke2-server
        # so that RKE2 picks up the nvidia runtime handler on first boot.
        node_has_gpu = has_gpu()
        if node_has_gpu:
            write_nvidia_containerd_config()
            write_nvidia_device_plugin_config()
            print("[*] Node has GPU, NVIDIA containerd runtime and Device Plugin configured", file=sys.stderr)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to write config: {str(e)}', local_state=local_state)

    # Ensure RKE2 is fully installed (binary + systemd unit). Re-run installer if unit is missing
    # (e.g. partial install, or binary copied without unit file).
    if not is_rke2_available():
        try:
            install_rke2()
        except Exception as e:
            return PluginOutput(
                status='error',
                error_message=f'RKE2 systemd unit rke2-server.service not found; re-install failed: {e}',
                local_state=local_state,
            )

    # Start RKE2 server (every node is a control-plane member)
    try:
        stop_rke2_agent_if_active()
        result = subprocess.run(["systemctl", "enable", rke2_unit], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(status='error', error_message=f'Failed to enable {rke2_unit}: {result.stderr}', local_state=local_state)

        result = subprocess.run(["systemctl", "start", rke2_unit], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(status='error', error_message=f'Failed to start {rke2_unit}: {result.stderr}', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to start {rke2_unit}: {str(e)}', local_state=local_state)

    # Wait for the local RKE2 API to become ready.
    api_ready = wait_for_rke2_ready(is_bootstrap, timeout_sec=600)

    if not api_ready:
        return PluginOutput(
            status='postponed',
            error_message='RKE2 API did not become ready within timeout',
            local_state={**local_state, "install_hash": install_hash, "api_ready": False}
        )

    if is_bootstrap:
        tenant_editor_ok, tenant_editor_error = ensure_tenant_editor_cluster_role()
        if not tenant_editor_ok:
            return PluginOutput(
                status='postponed',
                error_message=f'Failed to ensure tenant-editor ClusterRole: {tenant_editor_error}',
                local_state={**local_state, "install_hash": install_hash, "api_ready": api_ready}
            )

    opa_msg, opa_np, opa_st = reconcile_opa_authz_webhook(
        state_json,
        local_node_id,
        local_state,
        is_leader=is_bootstrap,
        is_bootstrap=is_bootstrap,
        require_swarm_k8s_node_ready=False,
    )
    cp_msg, cp_np, cp_st = reconcile_swarm_credential_provider(
        is_bootstrap=is_bootstrap,
        local_state={**local_state, **opa_st, "install_hash": install_hash, "api_ready": api_ready},
    )
    node_properties = build_core_node_properties(
        api_ready=api_ready,
        is_bootstrap=is_bootstrap,
        bootstrap_done=bootstrap_done,
        opa_np={**opa_np, **cp_np},
    )
    if opa_msg:
        return PluginOutput(
            status='postponed',
            error_message=opa_msg,
            node_properties=node_properties,
            local_state={**local_state, **opa_st, "install_hash": install_hash, "api_ready": api_ready},
        )
    if cp_msg:
        return PluginOutput(
            status='postponed',
            error_message=cp_msg,
            node_properties=node_properties,
            local_state={**local_state, **opa_st, **cp_st, "install_hash": install_hash, "api_ready": api_ready},
        )

    # Label node with GPU if present (need to wait a bit for node to register)
    node_has_gpu = has_gpu()
    gpu_labeled = False
    if node_has_gpu:
        time.sleep(5)  # Wait for node to register
        if label_node_with_gpu(local_node_id):
            print(f"[*] Successfully labeled GPU node", file=sys.stderr)
            gpu_labeled = True
        else:
            print(f"[!] Failed to label GPU node, will retry on next reconcile", file=sys.stderr)

    # Mirror Swarm device.swarm.io/* onto k8s Nodes (leader only; skip if unchanged).
    sync_device_labels_to_k8s(state_json, cluster_nodes, local_node_id)

    # Update local state
    new_local_state = {
        **local_state,
        **opa_st,
        **cp_st,
        "install_hash": install_hash,
        "api_ready": api_ready,
        "role": "server",
        "is_bootstrap": is_bootstrap,
        "known_node_ids": current_node_ids,
        "has_gpu": node_has_gpu,
        "gpu_labeled": gpu_labeled
    }

    # Generate and publish kubeconfig
    stored_k8s_domain = current_k8s_external_hostname
    kubeconfig = get_kubeconfig_with_wireguard_server(local_tunnel_ip, stored_k8s_domain)
    if kubeconfig:
        node_properties["k8s_kubeconfig"] = kubeconfig
    else:
        print("[!] Failed to generate kubeconfig, skipping k8s_kubeconfig property", file=sys.stderr)

    if is_bootstrap:
        evidence_props, evidence_state_fragment = build_kube_system_evidence_properties(new_local_state, install_hash)
        node_properties.update(evidence_props)
        new_local_state = {**new_local_state, **evidence_state_fragment}

    if api_ready:
        new_local_state = capture_local_etcd_member_id(
            new_local_state,
            node_hash=hash_node_id(local_node_id),
            tunnel_ip=local_tunnel_ip,
        )

    # Export cluster properties if bootstrap node has a domain to publish
    cluster_properties = None
    if is_bootstrap and desired_k8s_domain and current_k8s_external_hostname != desired_k8s_domain:
        cluster_properties = {"k8s_external_hostname": desired_k8s_domain}

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        cluster_properties=cluster_properties,
        local_state=new_local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check RKE2 health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    is_bootstrap = local_state.get("is_bootstrap")
    if is_bootstrap is None and isinstance(state_json, dict):
        is_bootstrap = is_bootstrap_node(state_json, local_node_id)
    if is_bootstrap is None:
        is_bootstrap = True

    # Check if RKE2 is running
    rke2_running, rke2_error = is_rke2_running(is_bootstrap=is_bootstrap)
    if not rke2_running:
        if rke2_error and 'Failed to' in rke2_error:
            # Real error checking status
            return PluginOutput(status='error', error_message=rke2_error, local_state=local_state)
        else:
            # Service not running yet
            return PluginOutput(status='postponed', error_message=rke2_error or 'RKE2 service is not running', local_state=local_state)

    # Check API health
    if not RKE2_KUBECONFIG.exists():
        return PluginOutput(status='postponed', error_message='Kubeconfig not found', local_state=local_state)

    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)

    try:
        result = subprocess.run(
            [KUBECTL_BIN, "get", "--raw", "/healthz"],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0 or result.stdout.strip() != "ok":
            return PluginOutput(status='postponed', error_message='API server is not healthy', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='postponed', error_message=f'Failed to check API: {e}', local_state=local_state)

    # Stale Node cleanup must run before OPA/credential probes. Those can
    # postpone every tick (e.g. curl SAN mismatch on 127.0.0.1) while apply
    # is skipped because the plan hash has not changed — leaving a ghost Node
    # that breaks DaemonSet rollout (desired=N+1, ready=N).
    if isinstance(state_json, dict) and get_leader_node(state_json) == local_node_id:
        cluster_nodes = state_json.get("clusterNodes", [])
        success, removed_nodes, known_node_ids = remove_stale_nodes(cluster_nodes, local_state)
        local_state = {**local_state, "known_node_ids": known_node_ids}
        if not success:
            return PluginOutput(
                status='postponed',
                error_message='Failed to remove stale nodes from cluster',
                local_state=local_state,
            )
        if removed_nodes:
            print(
                f"[*] Health check: Successfully removed {len(removed_nodes)} stale node(s)",
                file=sys.stderr,
            )
        wg_props = state_json.get("wgNodeProperties") or []
        removed_etcd = remove_stale_etcd_members(cluster_nodes, wg_props, local_node_id)
        if removed_etcd:
            print(
                f"[*] Health check: Removed {len(removed_etcd)} stale etcd member(s)",
                file=sys.stderr,
            )
        # Retry device label mirror when Nodes appear after apply skipped a missing Node.
        sync_device_labels_to_k8s(state_json, cluster_nodes, local_node_id)

    # Check node readiness
    node_ready, node_error = check_node_ready(local_node_id)
    if not node_ready:
        if node_error and 'Failed to' in node_error:
            # Real error, not just not ready yet
            return PluginOutput(status='error', error_message=node_error, local_state=local_state)
        else:
            # Node not ready yet, postpone
            return PluginOutput(status='postponed', error_message=node_error or 'Node is not ready', local_state=local_state)

    # Every node runs rke2-server with a local kube-apiserver wired to the OPA adapter.
    opa_ok, opa_err = health_check_opa_authz_webhook(deep=True)
    if not opa_ok:
        return PluginOutput(status='postponed', error_message=opa_err or 'OPA authz webhook not healthy', local_state=local_state)

    cp_ok, cp_err = health_check_swarm_credential_provider()
    if not cp_ok:
        return PluginOutput(
            status='postponed',
            error_message=cp_err or 'swarm credential provider not healthy',
            local_state=local_state,
        )

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Remove this server from the etcd member list before destroy/uninstall.

    Mirrors CockroachDB leave-path: leaving VM owns decommission. Without this step,
    survivors keep stale voters and can lose quorum after multi-member removes.
    """
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = dict(input_data.local_state or {})

    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    # Already uninstalled / never joined etcd — nothing to remove.
    if not is_rke2_available() or not etcd_tls_ready():
        print("[*] RKE2/etcd not present, skipping etcd member remove", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)

    running, _ = is_rke2_running(True)
    if not running and not local_state.get("etcd_member_remove_started"):
        print("[*] rke2-server not running and member remove not started; skip to destroy", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)

    wg_props = state_json.get("wgNodeProperties", [])
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    node_hash = hash_node_id(local_node_id)
    member_id = local_state.get("etcd_member_id")

    members, list_err = list_etcd_members()
    if members is not None:
        local_member = find_local_etcd_member(members, node_hash=node_hash, tunnel_ip=local_tunnel_ip)
        if local_member:
            member_id = local_member["id"]
            local_state = {
                **local_state,
                "etcd_member_id": member_id,
                "etcd_member_name": local_member.get("name") or "",
            }
        elif member_id and not any(m.get("id") == member_id for m in members):
            print(f"[*] etcd member {member_id} already absent, proceed to destroy", file=sys.stderr)
            return PluginOutput(status='completed', local_state=local_state)
        elif not member_id:
            # Not in member list and no cached id — treat as already removed.
            print("[*] Local etcd member not in list, proceed to destroy", file=sys.stderr)
            return PluginOutput(status='completed', local_state=local_state)
    elif local_state.get("etcd_member_remove_started"):
        # Local etcd may already be shutting down after a successful remove.
        print(f"[*] etcd member list unavailable after remove started ({list_err}); assuming success", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)
    else:
        return PluginOutput(
            status='postponed',
            error_message=f'Cannot list etcd members yet: {list_err}',
            local_state=local_state,
        )

    if not member_id:
        return PluginOutput(
            status='postponed',
            error_message='etcd member id unknown; waiting for capture',
            local_state=local_state,
        )

    if not local_state.get("etcd_member_remove_started"):
        ok, remove_err = remove_etcd_member(member_id)
        if not ok:
            return PluginOutput(
                status='postponed',
                error_message=remove_err or f'Failed to remove etcd member {member_id}',
                local_state=local_state,
            )
        local_state = {**local_state, "etcd_member_remove_started": True}
        print(f"[*] Started etcd member remove {member_id}", file=sys.stderr)

    # Confirm absence on next poll (or same tick if list still works).
    members_after, after_err = list_etcd_members()
    if members_after is None:
        print(f"[*] etcd list after remove unavailable ({after_err}); proceed to destroy", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)
    if any(m.get("id") == member_id for m in members_after):
        return PluginOutput(
            status='postponed',
            error_message=f'Waiting for etcd member {member_id} to leave the member list',
            local_state=local_state,
        )

    print(f"[*] etcd member {member_id} removed from cluster", file=sys.stderr)
    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy RKE2 installation and clean up."""
    try:
        # Stop and disable RKE2 (both units; only one is enabled per node)
        for unit in ("rke2-server", "rke2-agent"):
            subprocess.run(["systemctl", "stop", unit], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["systemctl", "disable", unit], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Run uninstall script if it exists
        if Path("/usr/local/bin/rke2-uninstall.sh").exists():
            subprocess.run(["/usr/local/bin/rke2-uninstall.sh"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Remove config directory
        if RKE2_CONFIG_DIR.exists():
            shutil.rmtree(RKE2_CONFIG_DIR, ignore_errors=True)

        # Request deletion of node properties
        node_properties = {
            "k8s_node_ready": None,
            "k8s_bootstrap_done": None,
            "k8s_kubeconfig": None,
            "rke2_version": None,
            "rke2_install_hash": None,
            "rke2_image_digests": None,
            "kube_system_snapshot_digest": None,
            "kube_system_snapshot_json": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy RKE2: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
