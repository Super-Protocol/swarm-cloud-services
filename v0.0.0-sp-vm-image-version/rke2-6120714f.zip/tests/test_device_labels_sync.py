"""Unit tests for device.swarm.io → k8s Node label mirroring."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("rke2_main_device_labels", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_k8s_label_value_space_to_hyphen():
    module = _load_main_module()
    assert module.k8s_label_value("NVIDIA A100-SXM4-40GB") == "NVIDIA-A100-SXM4-40GB"


def test_k8s_label_value_valid_unchanged():
    module = _load_main_module()
    assert module.k8s_label_value("A100") == "A100"
    assert module.k8s_label_value("true") == "true"


def test_k8s_label_value_too_long_truncated():
    module = _load_main_module()
    raw = "a" * 80
    out = module.k8s_label_value(raw)
    assert out is not None
    assert len(out) <= 63
    assert out == "a" * 63


def test_desired_device_labels_by_node_membership_and_strip_prefix():
    module = _load_main_module()
    state = {
        "deviceNodeLabels": [
            {
                "node": "node-a",
                "name": "label.device.swarm.io/gpu-product",
                "value": "NVIDIA A100",
            },
            {
                "node": "node-a",
                "name": "label.device.swarm.io/gpu-present",
                "value": "true",
            },
            {
                "node": "node-outsider",
                "name": "label.device.swarm.io/gpu-product",
                "value": "H100",
            },
            {
                "node": "node-b",
                "name": "label.other/key",
                "value": "x",
            },
        ]
    }
    cluster_nodes = [
        {"node_id": "node-a"},
        {"node_id": "node-b"},
    ]
    desired = module.desired_device_labels_by_node(state, cluster_nodes)
    assert desired == {
        "node-a": {
            "device.swarm.io/gpu-product": "NVIDIA A100",
            "device.swarm.io/gpu-present": "true",
        },
        "node-b": {},
    }


def test_sync_empty_labels_removes_managed_keys():
    module = _load_main_module()
    node_id = "node-cpu"
    node_name = module.hash_node_id(node_id)
    state = {
        "cluster": {"leader_node": "leader"},
        "deviceNodeLabels": [],
    }
    cluster_nodes = [{"node_id": node_id}]

    node_json = {
        "metadata": {
            "name": node_name,
            "labels": {
                "device.swarm.io/gpu-product": "A100",
                "kubernetes.io/hostname": node_name,
            },
            "annotations": {
                "device.swarm.io/gpu-product-display": "NVIDIA A100",
            },
        }
    }

    label_calls: list[list[str]] = []
    annotate_calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        if len(cmd) >= 3 and cmd[1] == "get" and cmd[2] == "nodes":
            result.stdout = json.dumps({"items": [node_json]})
        elif len(cmd) >= 2 and cmd[1] == "label":
            label_calls.append(list(cmd))
        elif len(cmd) >= 2 and cmd[1] == "annotate":
            annotate_calls.append(list(cmd))
        return result

    with (
        patch.object(module, "RKE2_KUBECONFIG", MagicMock(exists=lambda: True)),
        patch.object(module.subprocess, "run", side_effect=fake_run),
    ):
        module.sync_device_labels_to_k8s(state, cluster_nodes, "leader")

    assert label_calls, "expected kubectl label to remove managed keys"
    joined = " ".join(label_calls[0])
    assert "device.swarm.io/gpu-product-" in joined
    assert annotate_calls, "expected display annotation removal"
    assert any("device.swarm.io/gpu-product-display-" in " ".join(c) for c in annotate_calls)


def test_sync_follower_noop():
    module = _load_main_module()
    state = {
        "cluster": {"leader_node": "leader"},
        "deviceNodeLabels": [
            {
                "node": "node-a",
                "name": "label.device.swarm.io/gpu-present",
                "value": "true",
            }
        ],
    }
    cluster_nodes = [{"node_id": "node-a"}]

    with (
        patch.object(module, "RKE2_KUBECONFIG", MagicMock(exists=lambda: True)),
        patch.object(module.subprocess, "run") as run_mock,
    ):
        module.sync_device_labels_to_k8s(state, cluster_nodes, "follower")

    run_mock.assert_not_called()


def test_sync_skip_if_unchanged():
    module = _load_main_module()
    node_id = "node-a"
    node_name = module.hash_node_id(node_id)
    state = {
        "cluster": {"leader_node": "leader"},
        "deviceNodeLabels": [
            {
                "node": node_id,
                "name": "label.device.swarm.io/gpu-present",
                "value": "true",
            },
            {
                "node": node_id,
                "name": "label.device.swarm.io/gpu-product",
                "value": "NVIDIA A100",
            },
        ],
    }
    cluster_nodes = [{"node_id": node_id}]

    node_json = {
        "metadata": {
            "name": node_name,
            "labels": {
                "device.swarm.io/gpu-present": "true",
                "device.swarm.io/gpu-product": "NVIDIA-A100",
                "kubernetes.io/hostname": node_name,
            },
            "annotations": {
                "device.swarm.io/gpu-product-display": "NVIDIA A100",
            },
        }
    }

    mutate_cmds: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        result.stderr = ""
        if len(cmd) >= 3 and cmd[1] == "get" and cmd[2] == "nodes":
            result.stdout = json.dumps({"items": [node_json]})
        else:
            mutate_cmds.append(list(cmd))
            result.stdout = ""
        return result

    with (
        patch.object(module, "RKE2_KUBECONFIG", MagicMock(exists=lambda: True)),
        patch.object(module.subprocess, "run", side_effect=fake_run),
    ):
        module.sync_device_labels_to_k8s(state, cluster_nodes, "leader")

    assert mutate_cmds == [], f"expected no mutate kubectl calls, got {mutate_cmds}"


def test_sync_lists_nodes_once():
    module = _load_main_module()
    state = {
        "cluster": {"leader_node": "leader"},
        "deviceNodeLabels": [
            {
                "node": "node-a",
                "name": "label.device.swarm.io/gpu-present",
                "value": "true",
            },
            {
                "node": "node-b",
                "name": "label.device.swarm.io/gpu-present",
                "value": "false",
            },
        ],
    }
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
    items = []
    for node_id, present in (("node-a", "true"), ("node-b", "false")):
        items.append(
            {
                "metadata": {
                    "name": module.hash_node_id(node_id),
                    "labels": {"device.swarm.io/gpu-present": present},
                    "annotations": {},
                }
            }
        )

    get_cmds: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        result.stderr = ""
        result.stdout = ""
        if len(cmd) >= 3 and cmd[1] == "get" and cmd[2] == "nodes":
            get_cmds.append(list(cmd))
            result.stdout = json.dumps({"items": items})
        return result

    with (
        patch.object(module, "RKE2_KUBECONFIG", MagicMock(exists=lambda: True)),
        patch.object(module.subprocess, "run", side_effect=fake_run),
    ):
        module.sync_device_labels_to_k8s(state, cluster_nodes, "leader")

    assert get_cmds == [[module.KUBECTL_BIN, "get", "nodes", "-o", "json"]]
