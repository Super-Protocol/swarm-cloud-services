"""Unit tests for is_rke2_reconcile_ready (stale api_ready after cross-cluster destroy)."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from unittest.mock import patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("rke2_main_reconcile_ready", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_reconcile_ready_false_when_api_ready_but_unit_missing():
    """Regression: sibling-cluster destroy uninstalled rke2; B still had api_ready=true."""
    module = _load_main_module()
    with (
        patch.object(module, "is_rke2_available", return_value=False),
        patch.object(module, "is_rke2_running", return_value=(False, "missing")),
    ):
        assert module.is_rke2_reconcile_ready(True, {"api_ready": True, "install_hash": "abc"}) is False


def test_reconcile_ready_false_when_unit_present_but_inactive():
    module = _load_main_module()
    with (
        patch.object(module, "is_rke2_available", return_value=True),
        patch.object(module, "is_rke2_running", return_value=(False, "inactive")),
    ):
        assert module.is_rke2_reconcile_ready(True, {"api_ready": True}) is False


def test_reconcile_ready_true_when_unit_active():
    module = _load_main_module()
    with (
        patch.object(module, "is_rke2_available", return_value=True),
        patch.object(module, "is_rke2_running", return_value=(True, None)),
    ):
        assert module.is_rke2_reconcile_ready(True, {"api_ready": False}) is True
        assert module.is_rke2_reconcile_ready(True, {"api_ready": True}) is True
