"""Orphaned join self-heal and stale-node grace (kubectl-delete during join)."""

from __future__ import annotations

import importlib.util
import sys
from contextlib import ExitStack, contextmanager
from pathlib import Path
from unittest.mock import MagicMock, patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("rke2_main_orphaned_join", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@contextmanager
def _orphan_symptoms(module, tmp_path, *, tls_ready=True, members=(None, "refused"), api_up=False):
    cfg = tmp_path / "config.yaml"
    cfg.write_text("token: x\nserver: https://10.0.0.1:9345\n")
    etcd = tmp_path / "db" / "etcd"
    etcd.mkdir(parents=True)
    with ExitStack() as stack:
        stack.enter_context(patch.object(module, "RKE2_CONFIG_FILE", cfg))
        stack.enter_context(patch.object(module, "RKE2_ETCD_DATA_DIR", etcd))
        stack.enter_context(patch.object(module, "etcd_tls_ready", return_value=tls_ready))
        stack.enter_context(patch.object(module, "list_etcd_members", return_value=members))
        stack.enter_context(patch.object(module, "is_local_apiserver_up", return_value=api_up))
        yield


def test_orphaned_joining_server_true_when_server_cfg_etcd_db_and_apis_down(tmp_path):
    module = _load_main_module()
    with _orphan_symptoms(module, tmp_path):
        assert module.is_orphaned_joining_server(is_bootstrap=False) is True


def test_orphaned_joining_server_false_when_tls_not_ready(tmp_path):
    """First-time join: etcd data may exist before TLS/API are up — do not wipe."""
    module = _load_main_module()
    with _orphan_symptoms(module, tmp_path, tls_ready=False):
        assert module.is_orphaned_joining_server(is_bootstrap=False) is False


def test_orphaned_joining_server_false_for_bootstrap():
    module = _load_main_module()
    assert module.is_orphaned_joining_server(is_bootstrap=True) is False


def test_orphaned_joining_server_false_when_etcd_lists():
    module = _load_main_module()
    cfg = MagicMock()
    cfg.exists.return_value = True
    cfg.read_text.return_value = "server: https://10.0.0.1:9345\n"
    etcd = MagicMock()
    etcd.exists.return_value = True

    with (
        patch.object(module, "RKE2_CONFIG_FILE", cfg),
        patch.object(module, "RKE2_ETCD_DATA_DIR", etcd),
        patch.object(module, "etcd_tls_ready", return_value=True),
        patch.object(module, "list_etcd_members", return_value=([{"ID": "1"}], None)),
        patch.object(module, "is_local_apiserver_up", return_value=False),
    ):
        assert module.is_orphaned_joining_server(is_bootstrap=False) is False


def test_clear_orphaned_join_local_state_forces_rejoin():
    module = _load_main_module()
    out = module.clear_orphaned_join_local_state(
        {
            "api_ready": True,
            "install_hash": "abc",
            "etcd_member_id": "deadbeef",
            "known_node_ids": ["n1"],
            "orphaned_join_detected_at": 123.0,
        }
    )
    assert out["api_ready"] is False
    assert out["install_hash"] is None
    assert out["etcd_member_id"] is None
    assert out["known_node_ids"] == ["n1"]
    assert out["orphaned_join_detected_at"] is None


def test_reconcile_orphaned_join_records_timestamp_without_wipe(tmp_path):
    module = _load_main_module()
    with (
        _orphan_symptoms(module, tmp_path),
        patch.object(module, "reset_orphaned_joining_server") as reset,
        patch.object(module, "ORPHANED_JOIN_GRACE_SEC", 600),
    ):
        out = module.reconcile_orphaned_joining_server(
            is_bootstrap=False, local_state={"install_hash": "abc"}, now=1_000.0
        )
        reset.assert_not_called()
        assert out["install_hash"] == "abc"
        assert out["orphaned_join_detected_at"] == 1_000.0


def test_reconcile_orphaned_join_does_not_wipe_inside_grace(tmp_path):
    module = _load_main_module()
    with (
        _orphan_symptoms(module, tmp_path),
        patch.object(module, "reset_orphaned_joining_server") as reset,
        patch.object(module, "ORPHANED_JOIN_GRACE_SEC", 600),
    ):
        out = module.reconcile_orphaned_joining_server(
            is_bootstrap=False,
            local_state={"install_hash": "abc", "orphaned_join_detected_at": 1_000.0},
            now=1_599.0,
        )
        reset.assert_not_called()
        assert out["install_hash"] == "abc"
        assert out["orphaned_join_detected_at"] == 1_000.0


def test_reconcile_orphaned_join_wipes_after_grace(tmp_path):
    module = _load_main_module()
    with (
        _orphan_symptoms(module, tmp_path),
        patch.object(module, "reset_orphaned_joining_server") as reset,
        patch.object(module, "ORPHANED_JOIN_GRACE_SEC", 600),
    ):
        out = module.reconcile_orphaned_joining_server(
            is_bootstrap=False,
            local_state={"install_hash": "abc", "orphaned_join_detected_at": 1_000.0},
            now=1_600.0,
        )
        reset.assert_called_once()
        assert out["install_hash"] is None
        assert out["orphaned_join_detected_at"] is None


def test_reconcile_orphaned_join_clears_timestamp_when_symptoms_gone(tmp_path):
    module = _load_main_module()
    with (
        _orphan_symptoms(module, tmp_path, members=([{"ID": "1"}], None)),
        patch.object(module, "reset_orphaned_joining_server") as reset,
    ):
        out = module.reconcile_orphaned_joining_server(
            is_bootstrap=False,
            local_state={"orphaned_join_detected_at": 1_000.0},
            now=2_000.0,
        )
        reset.assert_not_called()
        assert out["orphaned_join_detected_at"] is None


def test_remove_stale_nodes_skips_young_ready_and_retains_id():
    """Ready+young orphan: grace skip, keep id in known_node_ids for retry."""
    module = _load_main_module()
    node_id = "node-young"
    node_name = module.hash_node_id(node_id)
    cluster_nodes = [{"node_id": "other"}]
    local_state = {"known_node_ids": [node_id, "other"]}

    with (
        patch.object(module, "get_k8s_nodes", return_value=[node_name]),
        patch.object(module, "is_k8s_node_ready", return_value=True),
        patch.object(module, "get_k8s_node_age_seconds", return_value=60.0),
        patch.object(module, "STALE_NODE_MIN_AGE_SEC", 600),
        patch.object(module, "delete_node") as delete_node,
        patch.object(module, "cordon_node") as cordon_node,
        patch.object(module, "drain_node") as drain_node,
    ):
        ok, removed, known = module.remove_stale_nodes(cluster_nodes, local_state)
        assert ok is True
        assert removed == []
        assert node_id in known
        assert "other" in known
        delete_node.assert_not_called()
        cordon_node.assert_not_called()
        drain_node.assert_not_called()


def test_remove_stale_nodes_deletes_notready_even_if_young():
    """Ghost after cross-cluster leave: NotReady orphan must not wait for age grace."""
    module = _load_main_module()
    node_id = "node-ghost"
    node_name = module.hash_node_id(node_id)
    cluster_nodes = [{"node_id": "other"}]
    local_state = {"known_node_ids": ["other"]}

    with (
        patch.object(module, "get_k8s_nodes", return_value=[node_name]),
        patch.object(module, "is_k8s_node_ready", return_value=False),
        patch.object(module, "get_k8s_node_age_seconds", return_value=60.0),
        patch.object(module, "STALE_NODE_MIN_AGE_SEC", 600),
        patch.object(module, "cordon_node", return_value=True),
        patch.object(module, "drain_node") as drain_node,
        patch.object(module, "delete_node", return_value=True) as delete_node,
    ):
        ok, removed, known = module.remove_stale_nodes(cluster_nodes, local_state)
        assert ok is True
        assert removed == [node_name]
        assert known == ["other"]
        drain_node.assert_not_called()
        delete_node.assert_called_once_with(node_name)


def test_remove_stale_nodes_deletes_orphan_absent_from_known_ids():
    """Membership-vs-k8s reconcile: ghost need not have been in known_node_ids."""
    module = _load_main_module()
    ghost_name = "f9bba852eb8576ddc08233e0136486dc"
    member = "bootstrap"
    member_name = module.hash_node_id(member)
    cluster_nodes = [{"node_id": member}]
    local_state = {"known_node_ids": [member]}

    with (
        patch.object(module, "get_k8s_nodes", return_value=[member_name, ghost_name]),
        patch.object(module, "is_k8s_node_ready", return_value=False),
        patch.object(module, "get_k8s_node_age_seconds", return_value=3600.0),
        patch.object(module, "cordon_node", return_value=True),
        patch.object(module, "drain_node") as drain_node,
        patch.object(module, "delete_node", return_value=True) as delete_node,
    ):
        ok, removed, known = module.remove_stale_nodes(cluster_nodes, local_state)
        assert ok is True
        assert removed == [ghost_name]
        assert known == [member]
        drain_node.assert_not_called()
        delete_node.assert_called_once_with(ghost_name)


def test_remove_stale_nodes_deletes_old_ready_orphan():
    module = _load_main_module()
    node_id = "node-old"
    node_name = module.hash_node_id(node_id)
    cluster_nodes = [{"node_id": "other"}]
    local_state = {"known_node_ids": [node_id, "other"]}

    with (
        patch.object(module, "get_k8s_nodes", return_value=[node_name]),
        patch.object(module, "is_k8s_node_ready", return_value=True),
        patch.object(module, "get_k8s_node_age_seconds", return_value=3600.0),
        patch.object(module, "STALE_NODE_MIN_AGE_SEC", 600),
        patch.object(module, "cordon_node", return_value=True),
        patch.object(module, "drain_node", return_value=True),
        patch.object(module, "delete_node", return_value=True) as delete_node,
    ):
        ok, removed, known = module.remove_stale_nodes(cluster_nodes, local_state)
        assert ok is True
        assert removed == [node_name]
        assert known == ["other"]
        delete_node.assert_called_once_with(node_name)
