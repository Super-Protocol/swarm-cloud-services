"""Unit tests for rke2 etcd member leave-path helpers and finalize."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load(name: str, path: Path):
    for p in (str(RKE2_DIR), str(SDK_DIR)):
        if p not in sys.path:
            sys.path.insert(0, p)
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def etcd_member():
    return _load("rke2_etcd_member", RKE2_DIR / "etcd_member.py")


@pytest.fixture(scope="module")
def main_mod():
    return _load("rke2_main_finalize", RKE2_DIR / "main.py")


def test_parse_etcd_members_json_hex_ids(etcd_member):
    payload = json.dumps(
        {
            "members": [
                {
                    "ID": 5877649432894746248,
                    "name": "abc123-deadbeef",
                    "peerURLs": ["https://10.13.1.1:2380"],
                    "clientURLs": ["https://10.13.1.1:2379"],
                }
            ]
        }
    )
    members = etcd_member.parse_etcd_members_json(payload)
    assert len(members) == 1
    assert members[0]["id"] == format(5877649432894746248, "x")
    assert members[0]["name"] == "abc123-deadbeef"


def test_find_local_etcd_member_by_hash_prefix(etcd_member):
    members = [
        {"id": "aaa", "name": "other-1", "peer_urls": ["https://10.0.0.1:2380"], "client_urls": []},
        {"id": "bbb", "name": "deadbeef-cafebabe", "peer_urls": ["https://10.0.0.2:2380"], "client_urls": []},
    ]
    found = etcd_member.find_local_etcd_member(members, node_hash="deadbeef", tunnel_ip=None)
    assert found is not None
    assert found["id"] == "bbb"


def test_find_local_etcd_member_by_tunnel_ip(etcd_member):
    members = [
        {"id": "aaa", "name": "x", "peer_urls": ["https://10.13.9.9:2380"], "client_urls": []},
    ]
    found = etcd_member.find_local_etcd_member(members, node_hash="nomatch", tunnel_ip="10.13.9.9")
    assert found is not None
    assert found["id"] == "aaa"


def test_finalize_skips_when_rke2_absent(main_mod):
    with patch.object(main_mod, "is_rke2_available", return_value=False):
        result = main_mod.handle_finalize(
            SimpleNamespace(local_node_id="node-a", state={}, local_state={"etcd_member_id": "abc"})
        )
    assert result.status == "completed"


def test_finalize_completes_when_member_already_absent(main_mod):
    members = [{"id": "other", "name": "x", "peer_urls": [], "client_urls": []}]
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(main_mod, "list_etcd_members", return_value=(members, None)),
        patch.object(main_mod, "find_local_etcd_member", return_value=None),
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={"etcd_member_id": "gone"},
            )
        )
    assert result.status == "completed"


def test_finalize_removes_member_and_completes(main_mod):
    local = {"id": "abc123", "name": "deadbeef-1", "peer_urls": [], "client_urls": []}
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(
            main_mod,
            "list_etcd_members",
            side_effect=[
                ([local], None),  # before remove
                ([], None),  # after remove
            ],
        ),
        patch.object(main_mod, "find_local_etcd_member", return_value=local),
        patch.object(main_mod, "remove_etcd_member", return_value=(True, None)) as rem,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={},
            )
        )
    assert result.status == "completed"
    assert result.local_state.get("etcd_member_remove_started") is True
    rem.assert_called_once_with("abc123")


def test_finalize_postpones_while_member_still_listed(main_mod):
    local = {"id": "abc123", "name": "deadbeef-1", "peer_urls": [], "client_urls": []}
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(main_mod, "list_etcd_members", return_value=([local], None)),
        patch.object(main_mod, "find_local_etcd_member", return_value=local),
        patch.object(main_mod, "remove_etcd_member", return_value=(True, None)),
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={},
            )
        )
    assert result.status == "postponed"
    assert "Waiting for etcd member" in (result.error_message or "")


def test_find_stale_etcd_members_cross_cluster_leftover(etcd_member):
    """node3 still listed in cluster B etcd after moving to cluster A."""
    node4 = "05045b5b6e8e6e098d73173ba0b5a4ae"
    node5 = "69ad44fa57036fe852ade0e0c96bf34e"
    node3 = "69f70ef901f2413b3435fc0d11503836"
    members = [
        {"id": "a", "name": f"{node4}-a9b1a8ff", "peer_urls": ["https://10.13.44.185:2380"], "client_urls": []},
        {"id": "b", "name": f"{node5}-6d6c4642", "peer_urls": ["https://10.13.175.160:2380"], "client_urls": []},
        {"id": "c", "name": f"{node3}-0d5ffb0a", "peer_urls": ["https://10.13.161.210:2380"], "client_urls": []},
    ]
    stale = etcd_member.find_stale_etcd_members(
        members,
        expected_hashes={node4, node5},
        expected_peer_ips={"10.13.44.185", "10.13.175.160"},
        local_hash=node4,
    )
    assert [m["id"] for m in stale] == ["c"]


def test_find_stale_etcd_members_keeps_unnamed_learner(etcd_member):
    members = [
        {"id": "self", "name": "aaaa-1", "peer_urls": ["https://10.0.0.1:2380"], "client_urls": []},
        {"id": "join", "name": "", "peer_urls": ["https://10.0.0.99:2380"], "client_urls": []},
    ]
    stale = etcd_member.find_stale_etcd_members(
        members,
        expected_hashes={"aaaa"},
        expected_peer_ips={"10.0.0.1"},
        local_hash="aaaa",
    )
    assert stale == []


def test_remove_stale_etcd_members_removes_unmatched(main_mod):
    ghost = {
        "id": "e6a8113f4cb15c19",
        "name": "69f70ef901f2413b3435fc0d11503836-0d5ffb0a",
        "peer_urls": ["https://10.13.161.210:2380"],
        "client_urls": [],
    }
    live = {
        "id": "live",
        "name": f"{main_mod.hash_node_id('node4')}-ffff",
        "peer_urls": ["https://10.13.44.185:2380"],
        "client_urls": [],
    }
    cluster_nodes = [{"node_id": "node4"}]
    wg_props = [{"node_id": "node4", "name": "tunnel_ip", "value": "10.13.44.185"}]
    with (
        patch.object(main_mod, "list_etcd_members", return_value=([live, ghost], None)),
        patch.object(main_mod, "is_k8s_node_ready", return_value=False),
        patch.object(main_mod, "get_k8s_node_age_seconds", return_value=3600.0),
        patch.object(main_mod, "remove_etcd_member", return_value=(True, None)) as rem,
    ):
        removed = main_mod.remove_stale_etcd_members(cluster_nodes, wg_props, "node4")
    assert ghost["name"] in removed
    rem.assert_called_once_with(ghost["id"])
