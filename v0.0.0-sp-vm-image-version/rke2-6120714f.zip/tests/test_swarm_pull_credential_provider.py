"""Unit tests for swarm-pull-credential-provider helpers."""

from __future__ import annotations

import base64
import importlib.util
import json
import sys
from pathlib import Path

PROVIDER_PATH = (
    Path(__file__).resolve().parents[1] / "configs" / "swarm-credential-provider" / "swarm-pull-credential-provider.py"
)


def _load_provider_module():
    spec = importlib.util.spec_from_file_location("swarm_pull_credential_provider", PROVIDER_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _fake_sa_token(namespace: str) -> str:
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode()).decode().rstrip("=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"kubernetes.io/serviceaccount/namespace": namespace}).encode(),
    ).decode().rstrip("=")
    return f"{header}.{payload}.signature"


def _fake_sa_token_v1(namespace: str, sa_name: str = "default") -> str:
    header = base64.urlsafe_b64encode(json.dumps({"alg": "RS256", "typ": "JWT"}).encode()).decode().rstrip("=")
    payload = base64.urlsafe_b64encode(
        json.dumps(
            {
                "kubernetes.io": {
                    "namespace": namespace,
                    "serviceaccount": {"name": sa_name, "uid": "uid-1"},
                },
                "sub": f"system:serviceaccount:{namespace}:{sa_name}",
            },
        ).encode(),
    ).decode().rstrip("=")
    return f"{header}.{payload}.signature"


def test_namespace_from_sa_token():
    module = _load_provider_module()
    token = _fake_sa_token("user-abc-123")
    assert module._namespace_from_sa_token(token) == "user-abc-123"
    assert module._namespace_from_sa_token(_fake_sa_token_v1("user-abc-123")) == "user-abc-123"
    assert module._namespace_from_sa_token("") is None


def test_credentials_namespace_suffix():
    module = _load_provider_module()
    assert module._credentials_namespace("user-abc-123") == "user-abc-123-secret"


def _load_swarm_credential_provider_module():
    mod_path = Path(__file__).resolve().parents[1] / "swarm_credential_provider.py"
    spec = importlib.util.spec_from_file_location("swarm_credential_provider", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_parse_rke2_list_arg_line():
    module = _load_swarm_credential_provider_module()
    parse = module._parse_rke2_list_arg_line
    assert parse('  - "authorization-config=/etc/rancher/rke2/authz-config.yaml"') == (
        "authorization-config=/etc/rancher/rke2/authz-config.yaml"
    )
    assert parse('  - "feature-gates=Foo=true"') == "feature-gates=Foo=true"


def test_credential_provider_match_images_cover_gatekeeper_harbor_fqdn():
    """Kubelet glob patterns match one DNS label per *; FQDNs need stacked patterns."""
    text = PROVIDER_PATH.with_name("credential-provider-config.yaml").read_text()
    patterns = [
        line.strip().strip("- ").strip('"')
        for line in text.splitlines()
        if line.strip().startswith("- ") and "gatekeeper-harbor" in line
    ]
    sample = "gatekeeper-harbor.b6jj29p9xrmu8mi6.swarm.anthrax63.fun"
    labels = sample.split(".")
    assert any(
        len(pattern.split(".")) == len(labels)
        and pattern.split(".")[0] == "gatekeeper-harbor"
        for pattern in patterns
    ), f"no matchImages pattern covers {sample!r}: {patterns}"


def test_strip_cache_type_from_credential_config():
    module = _load_swarm_credential_provider_module()
    _strip = module._strip_unsupported_credential_config_fields

    raw = """providers:
  - name: test
    tokenAttributes:
      cacheType: "ServiceAccount"
      requireServiceAccount: true
"""
    out = _strip(raw)
    assert "cacheType" not in out
    assert "requireServiceAccount: true" in out
