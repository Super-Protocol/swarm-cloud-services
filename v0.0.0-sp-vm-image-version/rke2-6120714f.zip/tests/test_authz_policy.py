"""Unit tests for in-process authz policy (policy.py)."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

POLICIES_DIR = Path(__file__).resolve().parents[1] / "configs" / "opa-authz-webhook"
ADAPTER_DIR = POLICIES_DIR / "adapter"
DATA_JSON = POLICIES_DIR / "policies" / "data.json"
TENANT_NS = "user-test-abc"
OTHER_TENANT_NS = "user-test-bob"
TENANT_USER = f"system:serviceaccount:{TENANT_NS}:ns-editor"


def _load_policy_module():
    spec = importlib.util.spec_from_file_location("authz_policy", ADAPTER_DIR / "policy.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def policy():
    mod = _load_policy_module()
    return mod, mod.load_config(DATA_JSON)


def _sar_review(*, verb: str, name: str | None = None, namespace: str = TENANT_NS) -> dict:
    attrs: dict[str, str] = {
        "namespace": namespace,
        "verb": verb,
        "group": "",
        "resource": "secrets",
    }
    if name is not None:
        attrs["name"] = name
    return {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": attrs,
        },
    }


@pytest.mark.parametrize(
    ("case_id", "review", "expected"),
    [
        (
            "allow_get_swarm_pull",
            _sar_review(verb="get", name="swarm-pull"),
            "allow",
        ),
        (
            "allow_get_non_swarm_secret",
            _sar_review(verb="get", name="opa-health-probe-non-swarm"),
            "allow",
        ),
        (
            "cross_tenant_update_custom_secret_no_opinion",
            _sar_review(verb="update", name="authz-victim-custom", namespace=OTHER_TENANT_NS),
            "no_opinion",
        ),
        (
            "cross_tenant_delete_custom_secret_no_opinion",
            _sar_review(verb="delete", name="authz-victim-custom", namespace=OTHER_TENANT_NS),
            "no_opinion",
        ),
        (
            "deny_patch_swarm_pull",
            _sar_review(verb="patch", name="swarm-pull"),
            "deny",
        ),
        (
            "allow_patch_swarm_foo",
            _sar_review(verb="patch", name="swarm-foo"),
            "allow",
        ),
        (
            "deny_create_swarm_pull",
            _sar_review(verb="create", name="swarm-pull"),
            "deny",
        ),
        (
            "allow_create_my_secret",
            _sar_review(verb="create", name="my-secret"),
            "allow",
        ),
        (
            "create_without_name_no_opinion",
            _sar_review(verb="create", name=""),
            "no_opinion",
        ),
        (
            "deny_update_swarm_pull",
            _sar_review(verb="update", name="swarm-pull"),
            "deny",
        ),
        (
            "allow_patch_non_swarm_secret",
            _sar_review(verb="patch", name="my-secret"),
            "allow",
        ),
        (
            "deletecollection_no_opinion",
            _sar_review(verb="deletecollection", name=None),
            "no_opinion",
        ),
        (
            "allow_list_secrets_collection",
            _sar_review(verb="list", name=""),
            "allow",
        ),
        (
            "allow_watch_secrets_collection",
            _sar_review(verb="watch", name=""),
            "allow",
        ),
    ],
    ids=lambda x: x if isinstance(x, str) else "",
)
def test_authz_policy_sar_table(case_id: str, review: dict, expected: str, policy):
    mod, config = policy
    assert mod.evaluate(review, config) == expected, case_id


def test_bypass_system_masters_is_no_opinion(policy):
    mod, config = policy
    review = {
        "spec": {
            "user": "admin",
            "groups": ["system:masters"],
            "resourceAttributes": {
                "namespace": TENANT_NS,
                "verb": "patch",
                "group": "",
                "resource": "secrets",
                "name": "swarm-pull",
            },
        },
    }
    assert mod.evaluate(review, config) == "no_opinion"


def test_non_tenant_sa_is_no_opinion(policy):
    mod, config = policy
    review = {
        "spec": {
            "user": f"system:serviceaccount:{TENANT_NS}:default",
            "groups": [],
            "resourceAttributes": {
                "namespace": TENANT_NS,
                "verb": "patch",
                "group": "",
                "resource": "secrets",
                "name": "swarm-pull",
            },
        },
    }
    assert mod.evaluate(review, config) == "no_opinion"


def test_kube_system_ns_is_no_opinion(policy):
    mod, config = policy
    review = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": "kube-system",
                "verb": "patch",
                "group": "",
                "resource": "secrets",
                "name": "swarm-pull",
            },
        },
    }
    assert mod.evaluate(review, config) == "no_opinion"


def test_credentials_namespace_is_no_opinion(policy):
    mod, config = policy
    review = _sar_review(verb="patch", name="swarm-pull", namespace=f"{TENANT_NS}-secret")
    assert mod.evaluate(review, config) == "no_opinion"


def test_cross_tenant_namespace_is_no_opinion(policy):
    """Tenant ns-editor must not get webhook allow in another tenant namespace."""
    mod, config = policy
    cross_get = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "get",
                "group": "",
                "resource": "secrets",
                "name": "swarm-pull",
            },
        },
    }
    cross_list = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "list",
                "group": "",
                "resource": "secrets",
                "name": "",
            },
        },
    }
    cross_patch_other = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "patch",
                "group": "",
                "resource": "secrets",
                "name": "bob-secret",
            },
        },
    }
    cross_patch_swarm_pull = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "patch",
                "group": "",
                "resource": "secrets",
                "name": "swarm-pull",
            },
        },
    }
    cross_deletecollection = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "deletecollection",
                "group": "",
                "resource": "secrets",
            },
        },
    }

    assert mod.evaluate(cross_get, config) == "no_opinion"
    assert mod.evaluate(cross_list, config) == "no_opinion"
    assert mod.evaluate(cross_patch_other, config) == "no_opinion"
    assert mod.evaluate(cross_patch_swarm_pull, config) == "no_opinion"
    assert mod.evaluate(cross_deletecollection, config) == "no_opinion"


def test_is_tenant_editor_requires_matching_namespace(policy):
    mod, config = policy
    assert mod.is_tenant_editor(TENANT_USER, TENANT_NS, config) is True
    assert mod.is_tenant_editor(TENANT_USER, OTHER_TENANT_NS, config) is False


@pytest.mark.parametrize(
    "resource",
    ["pods", "configmaps"],
)
def test_non_secret_resources_are_no_opinion_even_cross_tenant(policy, resource: str):
    mod, config = policy
    review = {
        "spec": {
            "user": TENANT_USER,
            "groups": [],
            "resourceAttributes": {
                "namespace": OTHER_TENANT_NS,
                "verb": "patch",
                "group": "",
                "resource": resource,
                "name": "victim-marker",
            },
        },
    }
    assert mod.evaluate(review, config) == "no_opinion"


def test_degraded_fallback_denies_secret_mutation(policy):
    mod, config = policy
    review = _sar_review(verb="patch", name="swarm-pull")
    assert mod.evaluate_degraded(review, config) == "deny"


def test_degraded_fallback_denies_create_swarm_pull(policy):
    mod, config = policy
    review = _sar_review(verb="create", name="swarm-pull")
    assert mod.evaluate_degraded(review, config) == "deny"


def test_degraded_fallback_no_opinion_for_reads(policy):
    mod, config = policy
    review = _sar_review(verb="get", name="swarm-pull")
    assert mod.evaluate_degraded(review, config) == "no_opinion"


def test_degraded_fallback_allows_other_secret_mutations(policy):
    mod, config = policy
    review = _sar_review(verb="patch", name="my-secret")
    assert mod.evaluate_degraded(review, config) == "no_opinion"
