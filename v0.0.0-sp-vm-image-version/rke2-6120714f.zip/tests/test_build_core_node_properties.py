"""Unit tests for build_core_node_properties and first-install opa/cp merge."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("rke2_main", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_build_core_node_properties_includes_opa_and_cp_flags():
    module = _load_main_module()
    opa_np = {"opa_authz_webhook_ready": "true"}
    cp_np = {"swarm_credential_provider_ready": "true"}

    props = module.build_core_node_properties(
        api_ready=True,
        is_bootstrap=True,
        bootstrap_done=False,
        opa_np={**opa_np, **cp_np},
    )

    assert props["opa_authz_webhook_ready"] == "true"
    assert props["swarm_credential_provider_ready"] == "true"
    assert props["k8s_node_ready"] == "true"
    assert props["k8s_bootstrap_done"] == "true"


def test_first_install_success_path_merge_matches_steady_state():
    """Success-path must use the same opa/cp merge as steady-state reconcile."""
    module = _load_main_module()
    opa_np = {"opa_authz_webhook_ready": "true"}
    cp_np = {"swarm_credential_provider_ready": "true"}
    merge_kw = {"opa_np": {**opa_np, **cp_np}}

    steady_state = module.build_core_node_properties(
        api_ready=True,
        is_bootstrap=True,
        bootstrap_done=False,
        **merge_kw,
    )
    first_install = module.build_core_node_properties(
        api_ready=True,
        is_bootstrap=True,
        bootstrap_done=False,
        **merge_kw,
    )

    assert steady_state == first_install
    assert "swarm_credential_provider_ready" in first_install
