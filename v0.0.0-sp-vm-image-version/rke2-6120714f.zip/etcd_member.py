"""RKE2 etcd membership helpers for leave-path finalize.

Leaving-node finalize must remove this server from the etcd member list before
destroy/uninstall, otherwise survivors can lose quorum (especially after
multi-member cycle-break removes).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

ETCD_TLS_DIR = Path("/var/lib/rancher/rke2/server/tls/etcd")
ETCD_CA = ETCD_TLS_DIR / "server-ca.crt"
ETCD_CERT = ETCD_TLS_DIR / "server-client.crt"
ETCD_KEY = ETCD_TLS_DIR / "server-client.key"
CRICTL_BIN = Path(os.environ.get("RKE2_CRICTL", "/var/lib/rancher/rke2/bin/crictl"))
CONTAINERD_SOCK = os.environ.get("RKE2_CONTAINERD_SOCK", "unix:///run/k3s/containerd/containerd.sock")


def etcd_tls_ready() -> bool:
    return ETCD_CA.is_file() and ETCD_CERT.is_file() and ETCD_KEY.is_file()


def _crictl_base() -> list[str]:
    return [str(CRICTL_BIN), f"--runtime-endpoint={CONTAINERD_SOCK}"]


def find_etcd_container_id() -> str | None:
    if not CRICTL_BIN.is_file():
        return None
    try:
        result = subprocess.run(
            [*_crictl_base(), "ps", "-q", "--name=etcd"],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        print(f"[!] crictl ps etcd failed: {e}", file=sys.stderr)
        return None
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        cid = line.strip()
        if cid:
            return cid
    return None


def run_etcdctl(args: list[str], *, timeout_sec: int = 30) -> subprocess.CompletedProcess[str]:
    """Run etcdctl inside the local etcd container (certs already mounted there)."""
    cid = find_etcd_container_id()
    if not cid:
        return subprocess.CompletedProcess(args=["etcdctl", *args], returncode=1, stdout="", stderr="etcd container not found")
    cmd = [
        *_crictl_base(),
        "exec",
        cid,
        "etcdctl",
        "--endpoints=https://127.0.0.1:2379",
        f"--cacert={ETCD_CA}",
        f"--cert={ETCD_CERT}",
        f"--key={ETCD_KEY}",
        *args,
    ]
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_sec)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(args=cmd, returncode=1, stdout="", stderr="etcdctl timed out")
    except (FileNotFoundError, OSError) as e:
        return subprocess.CompletedProcess(args=cmd, returncode=1, stdout="", stderr=str(e))


def parse_etcd_members_json(payload: str) -> list[dict[str, Any]]:
    data = json.loads(payload)
    members = data.get("members") or []
    out: list[dict[str, Any]] = []
    for m in members:
        mid = m.get("ID")
        if mid is None:
            continue
        # etcdctl member remove expects hex id (no 0x).
        hex_id = format(int(mid), "x")
        out.append(
            {
                "id": hex_id,
                "id_int": int(mid),
                "name": m.get("name") or "",
                "peer_urls": list(m.get("peerURLs") or []),
                "client_urls": list(m.get("clientURLs") or []),
            }
        )
    return out


def list_etcd_members() -> tuple[list[dict[str, Any]] | None, str | None]:
    if not etcd_tls_ready():
        return None, "etcd TLS certs missing"
    result = run_etcdctl(["member", "list", "-w", "json"])
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "etcdctl member list failed").strip()
        return None, err
    try:
        return parse_etcd_members_json(result.stdout), None
    except (json.JSONDecodeError, TypeError, ValueError) as e:
        return None, f"failed to parse member list json: {e}"


def find_local_etcd_member(
    members: list[dict[str, Any]],
    *,
    node_hash: str,
    tunnel_ip: str | None,
) -> dict[str, Any] | None:
    """Match this host's etcd member by k8s node-hash name prefix and/or tunnel IP."""
    for m in members:
        name = m.get("name") or ""
        if node_hash and (name == node_hash or name.startswith(f"{node_hash}-")):
            return m
    if tunnel_ip:
        needle = f"//{tunnel_ip}:"
        for m in members:
            urls = list(m.get("peer_urls") or []) + list(m.get("client_urls") or [])
            if any(needle in u for u in urls):
                return m
    return None


def etcd_member_belongs(
    member: dict[str, Any],
    *,
    expected_hashes: set[str],
    expected_peer_ips: set[str],
) -> bool:
    """True if this etcd member matches a current Swarm cluster node."""
    name = member.get("name") or ""
    for node_hash in expected_hashes:
        if node_hash and (name == node_hash or name.startswith(f"{node_hash}-")):
            return True
    urls = list(member.get("peer_urls") or []) + list(member.get("client_urls") or [])
    for ip in expected_peer_ips:
        if ip and any(f"//{ip}:" in u for u in urls):
            return True
    return False


def find_stale_etcd_members(
    members: list[dict[str, Any]],
    *,
    expected_hashes: set[str],
    expected_peer_ips: set[str],
    local_hash: str | None = None,
) -> list[dict[str, Any]]:
    """Etcd members that are not the local node and not in current Swarm membership.

    Unnamed members (joining learners) are left alone unless a peer IP matches —
    then they are expected if that IP is in membership, otherwise skipped (no name
    to prove they are leftover).
    """
    stale: list[dict[str, Any]] = []
    for member in members:
        name = member.get("name") or ""
        if local_hash and (name == local_hash or name.startswith(f"{local_hash}-")):
            continue
        if etcd_member_belongs(
            member,
            expected_hashes=expected_hashes,
            expected_peer_ips=expected_peer_ips,
        ):
            continue
        if not name:
            continue
        stale.append(member)
    return stale


def remove_etcd_member(member_id: str) -> tuple[bool, str | None]:
    result = run_etcdctl(["member", "remove", member_id])
    if result.returncode == 0:
        return True, None
    err = (result.stderr or result.stdout or "etcdctl member remove failed").strip()
    # Already gone is success for leave-path.
    low = err.lower()
    if "member not found" in low or "could not find" in low:
        return True, None
    return False, err


def capture_local_etcd_member_id(
    local_state: dict,
    *,
    node_hash: str,
    tunnel_ip: str | None,
) -> dict:
    """Refresh local_state etcd_member_id when the local etcd member is visible."""
    members, err = list_etcd_members()
    if members is None:
        print(f"[!] etcd member capture skipped: {err}", file=sys.stderr)
        return local_state
    local = find_local_etcd_member(members, node_hash=node_hash, tunnel_ip=tunnel_ip)
    if not local:
        print(f"[!] etcd member capture: local member not found for hash={node_hash} ip={tunnel_ip}", file=sys.stderr)
        return local_state
    member_id = local["id"]
    if local_state.get("etcd_member_id") != member_id:
        print(f"[*] Captured etcd member id {member_id} name={local.get('name')}", file=sys.stderr)
    return {**local_state, "etcd_member_id": member_id, "etcd_member_name": local.get("name") or ""}
