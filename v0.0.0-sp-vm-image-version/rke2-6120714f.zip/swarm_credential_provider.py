"""Kubelet swarm-pull credential provider: node binary, kubelet config, and cluster RBAC."""

from __future__ import annotations

import os
import re
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path

from opa_authz_webhook import RKE2_CONFIG_FILE, RKE2_KUBECONFIG, kubectl_run

RKE2_PLUGIN_DIR = Path(__file__).resolve().parent
ASSETS_DIR = RKE2_PLUGIN_DIR / "configs" / "swarm-credential-provider"

PROVIDER_SRC = ASSETS_DIR / "swarm-pull-credential-provider.py"
PROVIDER_BIN_DIR = Path("/usr/local/bin")
PROVIDER_BIN = PROVIDER_BIN_DIR / "swarm-pull-credential-provider"
KUBELET_CONFIG_DST = Path("/var/lib/rancher/rke2/agent/etc/swarm-credential-provider-config.yaml")
KUBELET_CONFIG_SRC = ASSETS_DIR / "credential-provider-config.yaml"
RBAC_MANIFEST = ASSETS_DIR / "rbac.yaml"

KUBELET_ARG_CONFIG = f"image-credential-provider-config={KUBELET_CONFIG_DST}"
KUBELET_ARG_BIN_DIR = "image-credential-provider-bin-dir=/usr/local/bin"
APISERVER_CREDENTIAL_PROVIDER_GATE = "KubeletServiceAccountTokenForCredentialProviders=true"
KUBELET_LOG = Path("/var/lib/rancher/rke2/agent/logs/kubelet.log")

# tokenAttributes.cacheType is rejected by kubelet in RKE2 1.33.x (strict decode).
_UNSUPPORTED_CONFIG_MARKERS = (
    "tokenAttributes.cacheType",
    "unknown field \"providers[0].tokenAttributes.cacheType\"",
)


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)


def install_provider_binary() -> tuple[bool, str | None]:
    if not PROVIDER_SRC.is_file():
        return False, f"missing provider source at {PROVIDER_SRC}"
    PROVIDER_BIN_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(PROVIDER_SRC, PROVIDER_BIN)
    os.chmod(PROVIDER_BIN, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
    return True, None


def _strip_unsupported_credential_config_fields(text: str) -> str:
    """Remove YAML fields that crash kubelet on RKE2 1.33.x."""
    lines: list[str] = []
    skip_indent: int | None = None
    for line in text.splitlines():
        if re.match(r"^\s*cacheType:\s*", line):
            continue
        if line.strip().startswith("#") and "cacheType" in line:
            continue
        stripped = line.lstrip()
        indent = len(line) - len(stripped)
        if skip_indent is not None:
            if stripped and indent > skip_indent:
                continue
            skip_indent = None
        lines.append(line)
    return "\n".join(lines).rstrip() + "\n"


def install_kubelet_credential_config() -> tuple[bool, str | None, bool]:
    if not KUBELET_CONFIG_SRC.is_file():
        return False, f"missing credential provider config at {KUBELET_CONFIG_SRC}", False
    KUBELET_CONFIG_DST.parent.mkdir(parents=True, exist_ok=True)
    rendered = _strip_unsupported_credential_config_fields(KUBELET_CONFIG_SRC.read_text())
    if "cacheType:" in rendered:
        return False, "credential provider config still contains cacheType after sanitization", False
    prior = KUBELET_CONFIG_DST.read_text() if KUBELET_CONFIG_DST.is_file() else ""
    changed = prior != rendered
    KUBELET_CONFIG_DST.write_text(rendered)
    return True, None, changed


def validate_kubelet_credential_config() -> tuple[bool, str | None]:
    """Best-effort check that kubelet accepted the credential provider config."""
    if not KUBELET_LOG.is_file():
        return True, None
    try:
        tail = "\n".join(
            KUBELET_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-50:]
        )
    except OSError as exc:
        return False, f"cannot read kubelet log: {exc}"
    for marker in _UNSUPPORTED_CONFIG_MARKERS:
        if marker in tail:
            return False, f"kubelet rejected credential provider config ({marker})"
    return True, None


def _parse_rke2_list_arg_line(line: str) -> str:
    """Parse a single `  - "value"` line from an RKE2 config list block."""
    stripped = line.strip()
    if stripped.startswith("- "):
        stripped = stripped[2:].strip()
    return stripped.strip('"')


def _merge_feature_gate_arg(existing_gates: str | None, gate: str) -> str:
    gate_name, _, gate_value = gate.partition("=")
    gates: dict[str, str] = {}
    if existing_gates:
        for part in existing_gates.split(","):
            part = part.strip()
            if not part:
                continue
            name, _, value = part.partition("=")
            gates[name.strip()] = value.strip() or "true"
    gates[gate_name.strip()] = gate_value.strip() or "true"
    return "feature-gates=" + ",".join(f"{name}={value}" for name, value in sorted(gates.items()))


def ensure_kube_apiserver_feature_gate_in_rke2_config() -> tuple[bool, str | None, bool]:
    """Enable credential-provider feature gate on kube-apiserver (required by node authorizer)."""
    required_gate = APISERVER_CREDENTIAL_PROVIDER_GATE
    existing = RKE2_CONFIG_FILE.read_text() if RKE2_CONFIG_FILE.exists() else ""
    apiserver_lines: list[str] = []
    other_lines: list[str] = []
    in_apiserver = False
    for line in existing.splitlines():
        if line.strip() == "kube-apiserver-arg:":
            in_apiserver = True
            continue
        if in_apiserver:
            if line.startswith("  -"):
                apiserver_lines.append(_parse_rke2_list_arg_line(line))
                continue
            in_apiserver = False
        other_lines.append(line)

    existing_gate_line = next((line for line in apiserver_lines if line.startswith("feature-gates=")), None)
    merged_gate_line = _merge_feature_gate_arg(
        existing_gate_line.split("=", 1)[1] if existing_gate_line else None,
        required_gate,
    )
    if existing_gate_line == merged_gate_line:
        return True, None, False

    new_apiserver_lines = [line for line in apiserver_lines if line != existing_gate_line]
    new_apiserver_lines.append(merged_gate_line)
    new_block = ["kube-apiserver-arg:", *[f'  - "{arg}"' for arg in new_apiserver_lines]]
    merged_text = "\n".join([*other_lines, "", *new_block, ""]).rstrip() + "\n"
    RKE2_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    RKE2_CONFIG_FILE.write_text(merged_text)
    return True, None, True


def ensure_kubelet_args_in_rke2_config() -> tuple[bool, str | None, bool]:
    """Ensure kubelet-arg block contains credential provider settings. Returns (ok, err, changed)."""
    required_simple = {KUBELET_ARG_CONFIG, KUBELET_ARG_BIN_DIR}
    required_gate = "KubeletServiceAccountTokenForCredentialProviders=true"
    existing = RKE2_CONFIG_FILE.read_text() if RKE2_CONFIG_FILE.exists() else ""
    kubelet_lines: list[str] = []
    other_lines: list[str] = []
    in_kubelet = False
    for line in existing.splitlines():
        if line.strip() == "kubelet-arg:":
            in_kubelet = True
            continue
        if in_kubelet:
            if line.startswith("  -"):
                kubelet_lines.append(_parse_rke2_list_arg_line(line))
                continue
            in_kubelet = False
        other_lines.append(line)

    present = set(kubelet_lines)
    existing_gate_line = next((line for line in kubelet_lines if line.startswith("feature-gates=")), None)
    merged_gate_line = _merge_feature_gate_arg(
        existing_gate_line.split("=", 1)[1] if existing_gate_line else None,
        required_gate,
    )

    desired = sorted(required_simple | {merged_gate_line})
    if sorted(kubelet_lines) == desired:
        return True, None, False

    new_block = ["kubelet-arg:", *[f'  - "{arg}"' for arg in desired]]
    merged_text = "\n".join([*other_lines, "", *new_block, ""]).rstrip() + "\n"
    RKE2_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    RKE2_CONFIG_FILE.write_text(merged_text)
    return True, None, True


def apply_rbac() -> tuple[bool, str | None]:
    if not RBAC_MANIFEST.is_file():
        return False, f"missing RBAC manifest at {RBAC_MANIFEST}"
    r = kubectl_run(["apply", "-f", str(RBAC_MANIFEST)], timeout=60)
    if r.returncode != 0:
        return False, (r.stderr or r.stdout or "kubectl apply rbac failed").strip()
    return True, None


def restart_rke2_if_needed(changed_config: bool, _is_bootstrap: bool = True) -> None:
    if not changed_config:
        return
    _log("[*] Restarting rke2-server to apply kubelet credential provider config")
    subprocess.run(["systemctl", "restart", "rke2-server"], capture_output=True, text=True)


def reconcile_swarm_credential_provider(
    *,
    is_bootstrap: bool,
    local_state: dict,
) -> tuple[str | None, dict[str, str], dict]:
    """Install credential provider on every node. Returns (postpone_reason, node_properties_delta, local_state_delta)."""
    if os.environ.get("SWARM_CREDENTIAL_PROVIDER_DISABLED", "").strip() in ("1", "true", "yes"):
        return None, {}, {}

    ok, err = install_provider_binary()
    if not ok:
        return err or "provider binary install failed", {}, {}

    ok, err, cred_config_changed = install_kubelet_credential_config()
    if not ok:
        return err or "kubelet credential config install failed", {}, {}

    ok, err, kubelet_args_changed = ensure_kubelet_args_in_rke2_config()
    if not ok:
        return err or "rke2 kubelet-arg update failed", {}, {}

    apiserver_args_changed = False
    ok, err, apiserver_args_changed = ensure_kube_apiserver_feature_gate_in_rke2_config()
    if not ok:
        return err or "rke2 kube-apiserver-arg update failed", {}, {}

    if RKE2_KUBECONFIG.exists():
        rbac_ok, rbac_err = apply_rbac()
        if not rbac_ok:
            return rbac_err or "credential provider RBAC apply failed", {}, {}

    needs_restart = cred_config_changed or kubelet_args_changed or apiserver_args_changed
    rke2_running = subprocess.run(
        ["systemctl", "is-active", "rke2-server"],
        capture_output=True,
        text=True,
    ).stdout.strip() == "active"
    if needs_restart and (local_state.get("api_ready") or rke2_running):
        restart_rke2_if_needed(True, is_bootstrap)
        time.sleep(10)
        ok, err = validate_kubelet_credential_config()
        if not ok:
            return err or "kubelet credential provider config invalid after restart", {}, {}

    merged = {**local_state, "swarm_credential_provider_configured": True}
    return None, {"swarm_credential_provider_ready": "true"}, merged


def health_check_swarm_credential_provider() -> tuple[bool, str | None]:
    if os.environ.get("SWARM_CREDENTIAL_PROVIDER_DISABLED", "").strip() in ("1", "true", "yes"):
        return True, None
    if not PROVIDER_BIN.is_file():
        return False, f"credential provider binary missing at {PROVIDER_BIN}"
    if not KUBELET_CONFIG_DST.is_file():
        return False, f"credential provider kubelet config missing at {KUBELET_CONFIG_DST}"
    if not os.access(PROVIDER_BIN, os.X_OK):
        return False, f"credential provider binary not executable: {PROVIDER_BIN}"
    if KUBELET_CONFIG_DST.is_file():
        cfg = KUBELET_CONFIG_DST.read_text()
        if re.search(r"^\s*cacheType:\s*", cfg, re.MULTILINE):
            return False, "credential provider config contains unsupported cacheType field"
    ok, err = validate_kubelet_credential_config()
    if not ok:
        return False, err
    return True, None
