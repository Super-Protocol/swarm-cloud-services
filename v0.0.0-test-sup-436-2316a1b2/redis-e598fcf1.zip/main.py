#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import time
import pwd
import re
from pathlib import Path

from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

# Configuration
REDIS_PORT = 6379
REDIS_CONFIG_DIR = Path("/etc/redis")
REDIS_CONFIG_FILE = REDIS_CONFIG_DIR / "redis.conf"
REDIS_DATA_DIR = Path("/var/lib/redis")
REDIS_CLI = "redis-cli"
VALKEY_CHECK_AOF = "valkey-check-aof"
PODMAN_BIN = "podman"
AOF_CORRUPTION_LOG_MARKERS = (
    "Bad file format reading the append only file",
)
VALKEY_IMAGE = os.environ.get("VALKEY_IMAGE", "registry-1.docker.io/valkey/valkey:9.0.3")
# valkey-server in the official image runs as this uid/gid; /var/lib/redis is mounted as /data
VALKEY_UID = 999
VALKEY_GID = 999
REDIS_MAX_NODES = int(os.environ.get("REDIS_MAX_NODES", "5"))

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def count_ready_sentinels(node_props: list) -> int:
    """Count unique sentinel nodes marked ready."""
    ready_nodes: set[str] = set()
    for prop in node_props:
        if prop.get("name") != "redis_sentinel_node_ready":
            continue
        if prop.get("value") != "true":
            continue
        node_id = prop.get("node_id")
        if node_id:
            ready_nodes.add(node_id)
    return len(ready_nodes)


def build_node_endpoints(cluster_nodes: list, wg_props: list) -> list[tuple[str, str]]:
    """Build a list of (node_id, tunnel_ip) for nodes with WG."""
    node_endpoints: list[tuple[str, str]] = []
    for node in cluster_nodes:
        node_id = node.get("node_id")
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            node_endpoints.append((node_id, tunnel_ip))
    return node_endpoints


def get_sentinel_endpoints(state_json: dict) -> list[str]:
    """Get Sentinel tunnel IPs for ready nodes."""
    sentinel_props = state_json.get("sentinelNodeProperties", [])
    wg_props = state_json.get("sentinelWgNodeProperties", []) or state_json.get("wgNodeProperties", [])
    endpoints: list[str] = []
    for prop in sentinel_props:
        if prop.get("name") != "redis_sentinel_node_ready" or prop.get("value") != "true":
            continue
        node_id = prop.get("node_id")
        if not node_id:
            continue
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            endpoints.append(tunnel_ip)
    return sorted(set(endpoints))


def _normalize_master_addr(addr: str) -> str:
    a = addr.strip()
    if a.startswith("[") and a.endswith("]"):
        a = a[1:-1]
    return a


def _query_sentinel_for_master(sentinel_host: str) -> str | None:
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", sentinel_host, "-p", "26379", "sentinel", "get-master-addr-by-name", "redis-master"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        parts = result.stdout.split()
        if len(parts) >= 2:
            return parts[0]
    except Exception:
        pass
    return None


def get_master_ip_from_sentinels(sentinel_ips: list[str]) -> str | None:
    """Ask reachable Sentinels for redis-master; use majority (lowest IP on tie).

    Requiring unanimous agreement blocked apply during Sentinel failover transitions
    when one sentinel lagged behind the others.

    With exactly two reachable Sentinels that disagree 1:1, the lowest-IP tie-break
    may pick a non-master during split-brain; quorum is restored once a third
    Sentinel is reachable or views converge.
    """
    if not sentinel_ips:
        return None
    answers: list[str] = []
    for ip in sentinel_ips:
        m = _query_sentinel_for_master(ip)
        if m:
            answers.append(_normalize_master_addr(m))
    if not answers:
        return None

    counts: dict[str, int] = {}
    for addr in answers:
        counts[addr] = counts.get(addr, 0) + 1

    max_freq = max(counts.values())
    candidates = sorted(addr for addr, freq in counts.items() if freq == max_freq)
    if len(candidates) > 1 or len(counts) > 1:
        print(
            f"[!] Sentinels disagree on redis-master: {answers!r}; "
            f"using {candidates[0]!r} (majority/tie-break)",
            file=sys.stderr,
        )
    return candidates[0]


def sentinel_master_in_redis_membership(
    master_ip: str | None, node_endpoints: list[tuple[str, str]]
) -> bool:
    """True if Sentinel's redis-master address is a WireGuard IP of a cluster member.

    Rejects bootstrap / removed nodes / stale addresses that would make replicaof point
    at a host that is not part of this Redis ClusterService membership.
    """
    if not master_ip or not node_endpoints:
        return False
    n = _normalize_master_addr(master_ip)
    member_ips = {_normalize_master_addr(ip) for _, ip in node_endpoints}
    return n in member_ips


def is_cluster_initialized(redis_props: list) -> bool:
    """Check if cluster is already initialized by any node."""
    for prop in redis_props:
        if prop.get("name") == "redis_cluster_initialized" and prop.get("value") == "true":
            return True
    return False


def check_all_nodes_redis_ready(cluster_nodes: list, redis_props: list) -> bool:
    """Check if all cluster nodes have Redis running and ready."""
    not_ready_nodes = []
    for node in cluster_nodes:
        node_id = node.get("node_id")
        node_ready = False
        for prop in redis_props:
            if (prop.get("node_id") == node_id and
                prop.get("name") == "redis_node_ready" and
                prop.get("value") == "true"):
                node_ready = True
                break
        if not node_ready:
            not_ready_nodes.append(node_id)

    if not_ready_nodes:
        print(f"[*] Nodes not ready yet: {', '.join(not_ready_nodes)}", file=sys.stderr)
        return False

    print(f"[*] All {len(cluster_nodes)} nodes are ready", file=sys.stderr)
    return True


def is_redis_available() -> bool:
    """Check if required host binaries are available."""
    return (
        shutil.which(REDIS_CLI) is not None
        and shutil.which(VALKEY_CHECK_AOF) is not None
        and shutil.which(PODMAN_BIN) is not None
    )


def get_container_name(cluster_id: str | None) -> str:
    """Build deterministic Podman container name."""
    raw = cluster_id or "default"
    sanitized = re.sub(r"[^a-zA-Z0-9_.-]+", "-", raw).strip("-_.")
    if not sanitized:
        sanitized = "default"
    return f"valkey-redis-{sanitized}"[:120]


def stop_and_remove_container(container_name: str) -> None:
    """Stop gracefully, wait up to 1 min; if stuck in Stopping, force-remove."""
    try:
        subprocess.run(
            [PODMAN_BIN, "stop", container_name],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=20,
        )
    except subprocess.TimeoutExpired:
        pass
    for _ in range(12):
        time.sleep(5)
        try:
            result = subprocess.run(
                [PODMAN_BIN, "inspect", "--format", "{{.State.Status}}", container_name],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except subprocess.TimeoutExpired:
            continue
        if result.returncode != 0:
            return
        status = (result.stdout or "").strip().lower()
        if status in ("exited", "stopped", "configured"):
            subprocess.run([PODMAN_BIN, "rm", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        if status not in ("stopping", "running"):
            subprocess.run([PODMAN_BIN, "rm", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    subprocess.run([PODMAN_BIN, "rm", "-f", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_valkey_container(container_name: str) -> None:
    """Run ValKey server container with host networking and mounted config."""
    stop_and_remove_container(container_name)
    # Ensure config file and parent dir are readable by container (non-root); mount whole dir so /etc/valkey is ours
    try:
        REDIS_CONFIG_DIR.chmod(0o755)
        if REDIS_CONFIG_FILE.exists():
            REDIS_CONFIG_FILE.chmod(0o644)
    except PermissionError:
        pass
    cmd = [
        PODMAN_BIN,
        "run",
        "-d",
        "--name",
        container_name,
        "--network",
        "host",
        "-v",
        f"{REDIS_CONFIG_DIR}:/etc/valkey:ro",
        "-v",
        f"{REDIS_DATA_DIR}:/data",
        VALKEY_IMAGE,
        "valkey-server",
        "/etc/valkey/redis.conf",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Podman run timed out after 30s")
    if result.returncode != 0:
        raise RuntimeError(f"Failed to run ValKey container: {result.stderr.strip() or result.stdout.strip()}")


def aof_persistence_files_exist(data_dir: Path) -> bool:
    """True if any appendonly.aof* files exist under the Redis data directory."""
    if not data_dir.is_dir():
        return False
    return any(data_dir.glob("appendonly.aof*"))


def get_aof_check_path(data_dir: Path) -> Path | None:
    """Return manifest or legacy AOF path for valkey-check-aof, if present."""
    manifest = data_dir / "appendonly.aof.manifest"
    if manifest.is_file():
        return manifest
    legacy = data_dir / "appendonly.aof"
    if legacy.is_file():
        return legacy
    return None


def get_container_logs(container_name: str, tail: int = 80) -> str:
    """Fetch recent Podman logs for the Valkey container."""
    try:
        result = subprocess.run(
            [PODMAN_BIN, "logs", "--tail", str(tail), container_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return (result.stderr or result.stdout or "").strip()
        return (result.stdout or "").strip()
    except Exception:
        return ""


def container_logs_indicate_aof_corruption(container_name: str) -> bool:
    logs = get_container_logs(container_name).lower()
    if not logs:
        return False
    return any(marker.lower() in logs for marker in AOF_CORRUPTION_LOG_MARKERS)


def valkey_check_aof_ok(aof_path: Path) -> bool:
    """Run valkey-check-aof without --fix; False means corruption or check failure."""
    if shutil.which(VALKEY_CHECK_AOF) is None:
        return True
    try:
        result = subprocess.run(
            [VALKEY_CHECK_AOF, str(aof_path)],
            capture_output=True,
            text=True,
            timeout=120,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def repair_aof_files(aof_path: Path) -> tuple[bool, str]:
    """Run valkey-check-aof --fix. Returns (success, message)."""
    if shutil.which(VALKEY_CHECK_AOF) is None:
        return False, "valkey-check-aof not found; install valkey-tools on the host"

    try:
        result = subprocess.run(
            [VALKEY_CHECK_AOF, "--fix", str(aof_path)],
            input="y\n",
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        return False, "valkey-check-aof --fix timed out"

    output = (result.stdout or "") + (result.stderr or "")
    if result.returncode != 0:
        return False, f"valkey-check-aof --fix failed: {output.strip() or 'unknown error'}"
    print(f"[*] Repaired AOF at {aof_path}: {output.strip()}", file=sys.stderr)
    return True, output.strip()


def aof_corruption_detected(data_dir: Path, container_name: str) -> bool:
    """Detect corrupt AOF from container logs or valkey-check-aof."""
    if not aof_persistence_files_exist(data_dir):
        return False
    if container_logs_indicate_aof_corruption(container_name):
        return True
    aof_path = get_aof_check_path(data_dir)
    if aof_path is None:
        return False
    return not valkey_check_aof_ok(aof_path)


def try_repair_aof_after_startup_failure(
    data_dir: Path,
    container_name: str,
) -> tuple[bool, str | None]:
    """Stop container, repair corrupt AOF if detected. Returns (repaired, error_message)."""
    if not aof_corruption_detected(data_dir, container_name):
        return False, None

    aof_path = get_aof_check_path(data_dir)
    if aof_path is None:
        return False, "AOF corruption suspected but no checkable AOF manifest/file found"

    stop_and_remove_container(container_name)
    repaired, message = repair_aof_files(aof_path)
    if not repaired:
        return False, message
    return True, None


def install_redis():
    """Ensure required host dependencies are installed."""
    try:
        if shutil.which(PODMAN_BIN) is None:
            raise Exception("podman is not installed; install podman on the host before using redis service")

        if shutil.which(REDIS_CLI) is None:
            raise Exception("redis-cli not found. Ensure redis-tools is pre-installed on the host.")

        if shutil.which(VALKEY_CHECK_AOF) is None:
            raise Exception(
                "valkey-check-aof not found. Ensure valkey-tools is pre-installed on the host."
            )

        ensure_redis_directories()
    except Exception as e:
        print(f"[!] Failed to install Redis: {e}", file=sys.stderr)
        raise

def ensure_redis_directories():
    """Ensure Redis data and log directories exist with correct ownership."""
    REDIS_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    REDIS_DATA_DIR.mkdir(parents=True, exist_ok=True)
    log_dir = Path("/var/log/redis")
    log_dir.mkdir(parents=True, exist_ok=True)

    # Config and host log dir: redis user when present (host redis-cli / legacy).
    try:
        redis_user = pwd.getpwnam("redis")
        uid, gid = redis_user.pw_uid, redis_user.pw_gid
        for path in (REDIS_CONFIG_DIR, log_dir):
            try:
                os.chown(path, uid, gid)
            except PermissionError:
                pass
    except KeyError:
        pass

    # Data dir is bind-mounted into the ValKey container as /data; the image runs as valkey (999).
    # Using the host "redis" uid here caused RDB/AOF write failures (MISCONF / stop-writes-on-bgsave-error).
    try:
        os.chown(REDIS_DATA_DIR, VALKEY_UID, VALKEY_GID)
        REDIS_DATA_DIR.chmod(0o755)
    except PermissionError:
        pass

def write_redis_config(local_tunnel_ip: str, is_master: bool, master_ip: str):
    """Write Redis replication configuration file."""
    ensure_redis_directories()

    REDIS_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    REDIS_DATA_DIR.mkdir(parents=True, exist_ok=True)

    cfg_lines = [
        f"bind {local_tunnel_ip}",
        f"port {REDIS_PORT}",
        "protected-mode no",
        # Persistence: AOF + RDB
        "appendonly yes",
        "appendfilename appendonly.aof",
        "appendfsync everysec",
        # RDB snapshots
        "save 900 1",      # Save after 900 sec if at least 1 key changed
        "save 300 10",     # Save after 300 sec if at least 10 keys changed
        "save 60 10000",   # Save after 60 sec if at least 10000 keys changed
        "stop-writes-on-bgsave-error yes",
        "rdbcompression yes",
        "rdbchecksum yes",
        "dbfilename dump.rdb",
        "dir /data",
        "daemonize no",
        "supervised no",
        "loglevel notice",
        "logfile /data/redis-server.log",
    ]

    if not is_master:
        cfg_lines.append(f"replicaof {master_ip} {REDIS_PORT}")
        cfg_lines.append(f"replica-announce-ip {local_tunnel_ip}")
        cfg_lines.append(f"replica-announce-port {REDIS_PORT}")

    REDIS_CONFIG_FILE.write_text("\n".join(cfg_lines) + "\n")

    # Ensure container (ValKey runs as non-root) can read the mounted config
    try:
        REDIS_CONFIG_FILE.chmod(0o644)
    except PermissionError:
        pass


def wait_for_redis_ready(local_tunnel_ip: str, timeout_sec: int = 60) -> bool:
    """Wait for Redis server to become ready."""
    start_time = time.time()
    last_error = None

    while time.time() - start_time < timeout_sec:
        try:
            result = subprocess.run(
                [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "ping"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0 and result.stdout.strip() == "PONG":
                return True

            last_error = f"Redis returned: {result.stdout.strip()}"
        except subprocess.TimeoutExpired:
            last_error = "Redis ping timed out"
        except Exception as e:
            last_error = f"Redis ping error: {str(e)}"

        time.sleep(3)

    print(f"[!] Redis did not become ready within {timeout_sec}s. Last error: {last_error}", file=sys.stderr)
    return False


def redis_responds_pong(host: str, timeout_sec: int = 5) -> bool:
    """True if Valkey/Redis at host:REDIS_PORT answers PING with PONG."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", host, "-p", str(REDIS_PORT), "ping"],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        return result.returncode == 0 and result.stdout.strip() == "PONG"
    except Exception:
        return False


def is_redis_running(container_name: str) -> tuple[bool, str | None]:
    """Check if Redis server is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            [PODMAN_BIN, "inspect", "-f", "{{.State.Running}}", container_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False, f"Container inspect failed: {result.stderr.strip() or result.stdout.strip()}"
        is_active = result.stdout.strip().lower() == "true"
        return is_active, None if is_active else "ValKey container is not running"
    except subprocess.TimeoutExpired:
        return False, "Container inspect timed out"
    except Exception as e:
        return False, f"Failed to check container status: {str(e)}"


def get_replication_info(local_tunnel_ip: str) -> dict:
    """Fetch replication info from redis-server."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "info", "replication"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return {}
        info: dict[str, str] = {}
        for line in result.stdout.splitlines():
            if not line or line.startswith("#") or ":" not in line:
                continue
            key, value = line.split(":", 1)
            info[key.strip()] = value.strip()
        return info
    except Exception:
        return {}


def replication_role_is_replica(role: str | None) -> bool:
    """Valkey/Redis use role:slave; some versions may report replica."""
    return role in ("slave", "replica")


def replication_master_host_matches(expected: str | None, reported: str | None) -> bool:
    """Avoid restart loops from trivial address formatting differences."""
    if not expected or not reported:
        return expected == reported
    a, b = expected.strip(), reported.strip()
    if a == b:
        return True
    # Strip IPv6 brackets if present
    if a.startswith("[") and a.endswith("]"):
        a = a[1:-1]
    if b.startswith("[") and b.endswith("]"):
        b = b[1:-1]
    return a == b


def get_dbsize(host: str) -> int | None:
    """Return key count in DB 0, or None if unreachable / error."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", host, "-p", str(REDIS_PORT), "dbsize"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        return int(result.stdout.strip())
    except (ValueError, subprocess.TimeoutExpired, Exception):
        return None


def empty_master_data_loss_guard(
    local_tunnel_ip: str,
    node_endpoints: list[tuple[str, str]],
) -> str | None:
    """If Sentinel names us master but we have no keys while a peer still does, abort apply.

    When membership moves to new VMs, /var/lib/redis there is empty. If that host becomes
    replication master, replicas full-resync from it and wipe good copies — common total
    data loss path.
    """
    local_db = get_dbsize(local_tunnel_ip)
    if local_db is None or local_db > 0:
        return None
    for _node_id, peer_ip in node_endpoints:
        if replication_master_host_matches(local_tunnel_ip, peer_ip):
            continue
        peer_db = get_dbsize(peer_ip)
        if peer_db is not None and peer_db > 0:
            return (
                f"Refusing apply: Sentinel elected this host as master but DBSIZE=0 here while "
                f"peer {peer_ip} has {peer_db} keys — starting/keeping an empty master would "
                f"risk full resync wiping replica data. Restore data on this node, fix Sentinel, "
                f"or use durable volumes."
            )
    return None


def create_redis_cluster(cluster_nodes: list, wg_props: list, primary_ip: str | None = None) -> bool:
    """Ensure all Redis nodes form a single replicated cluster with one master shard.

    Behaviour:
    - 1 node  -> initialize a single-node cluster (all slots 0..16383 on that node).
    - N>1     -> same single-node cluster on the first node, all other nodes join
                as replicas of this master (no sharding, no additional masters).
    """
    try:
        # Build list of (node_id, tunnel_ip) for all nodes that have WireGuard IPs
        node_endpoints: list[tuple[str, str]] = []
        for node in cluster_nodes:
            node_id = node.get("node_id")
            tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
            if tunnel_ip:
                node_endpoints.append((node_id, tunnel_ip))

        if not node_endpoints:
            print(f"[!] Need at least 1 node for Redis cluster, got 0", file=sys.stderr)
            return False

        # Use a stable ordering (by node_id) so that the primary master is deterministic.
        node_endpoints.sort(key=lambda x: x[0])

        primary_id, resolved_primary_ip = node_endpoints[0]
        if primary_ip:
            for node_id, ip in node_endpoints:
                if ip == primary_ip:
                    primary_id, resolved_primary_ip = node_id, ip
                    break

        primary_ip = resolved_primary_ip

        # Helper: check if the given endpoint already has a healthy cluster_state=ok.
        def _cluster_state_ok(ip: str) -> bool:
            try:
                result = subprocess.run(
                    [REDIS_CLI, "-h", ip, "-p", str(REDIS_PORT), "cluster", "info"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    return False
                for line in result.stdout.splitlines():
                    if line.startswith("cluster_state:"):
                        state = line.split(":", 1)[1].strip()
                        return state == "ok"
                return False
            except Exception as e:
                print(f"[!] Failed to read cluster info from {ip}: {e}", file=sys.stderr)
                return False

        def _fix_cluster(ip: str) -> bool:
            try:
                cmd = [
                    REDIS_CLI,
                    "--cluster",
                    "fix",
                    f"{ip}:{REDIS_PORT}",
                    "--cluster-yes",
                ]
                print(f"[*] Running cluster fix on {ip}: {' '.join(cmd)}", file=sys.stderr)
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if result.returncode != 0:
                    output = f"{result.stdout}\n{result.stderr}".lower()
                    if "fix-with-unreachable-masters" in output:
                        cmd.append("--cluster-fix-with-unreachable-masters")
                        print(
                            f"[*] Retrying cluster fix with unreachable masters on {ip}",
                            file=sys.stderr,
                        )
                        result = subprocess.run(
                            cmd,
                            capture_output=True,
                            text=True,
                            timeout=300,
                        )
                    if result.returncode != 0:
                        print(f"[!] Cluster fix failed (rc={result.returncode})", file=sys.stderr)
                        print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                        print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                        return False
                return _cluster_state_ok(ip)
            except Exception as e:
                print(f"[!] Cluster fix error on {ip}: {e}", file=sys.stderr)
                return False

        def _revive_single_node(ip: str) -> bool:
            """Force-reset cluster metadata to single-node mode."""
            try:
                reset_cmd = [
                    REDIS_CLI,
                    "-h",
                    ip,
                    "-p",
                    str(REDIS_PORT),
                    "cluster",
                    "reset",
                    "hard",
                ]
                result = subprocess.run(
                    reset_cmd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    print(f"[!] Cluster reset failed on {ip}", file=sys.stderr)
                    print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                    print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                    return False

                addslots_cmd = [
                    REDIS_CLI,
                    "-h",
                    ip,
                    "-p",
                    str(REDIS_PORT),
                    "cluster",
                    "addslots",
                    *[str(i) for i in range(16384)],
                ]
                result = subprocess.run(
                    addslots_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if result.returncode != 0:
                    print(f"[!] Failed to assign slots after reset on {ip}", file=sys.stderr)
                    print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                    print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                    return False

                return _cluster_state_ok(ip)
            except Exception as e:
                print(f"[!] Cluster revive error on {ip}: {e}", file=sys.stderr)
                return False

        def _reset_node(ip: str) -> bool:
            """Reset node cluster metadata (for joining as replica)."""
            try:
                reset_cmd = [
                    REDIS_CLI,
                    "-h",
                    ip,
                    "-p",
                    str(REDIS_PORT),
                    "cluster",
                    "reset",
                    "hard",
                ]
                result = subprocess.run(
                    reset_cmd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    print(f"[!] Cluster reset failed on {ip}", file=sys.stderr)
                    print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                    print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                    return False
                return True
            except Exception as e:
                print(f"[!] Cluster reset error on {ip}: {e}", file=sys.stderr)
                return False

        # Step 1: ensure the primary master has a valid single-node cluster with all slots.
        if _cluster_state_ok(primary_ip):
            print(f"[*] Primary Redis node {primary_ip} already has cluster_state=ok", file=sys.stderr)
        else:
            if len(node_endpoints) == 1 and get_cluster_state(primary_ip) == "fail":
                print(
                    f"[*] Cluster is down on {primary_ip}, forcing single-node revive",
                    file=sys.stderr,
                )
                if _revive_single_node(primary_ip):
                    return True
                return False

            cmd = [
                REDIS_CLI,
                "-h",
                primary_ip,
                "-p",
                str(REDIS_PORT),
                "cluster",
                "addslots",
                *[str(i) for i in range(16384)],
            ]

            print(
                f"[*] Initializing single-node Redis cluster on primary {primary_ip} with command: "
                f"redis-cli -h {primary_ip} -p {REDIS_PORT} cluster addslots 0..16383",
                file=sys.stderr,
            )

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )

            output_text = f"{result.stdout}\n{result.stderr}".lower()
            busy_slots = "already busy" in output_text or "err slot" in output_text

            if result.returncode != 0 or busy_slots:
                # If slots are already assigned, Redis may return "ERR Slot X is already busy".
                if busy_slots:
                    if _cluster_state_ok(primary_ip):
                        print(f"[*] Primary {primary_ip} already has all slots assigned and cluster_state=ok", file=sys.stderr)
                    else:
                        print(f"[!] Primary {primary_ip} has slots but cluster_state is not ok", file=sys.stderr)
                        print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                        print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                        if _fix_cluster(primary_ip):
                            print(f"[*] Cluster fixed on {primary_ip}", file=sys.stderr)
                        else:
                            return False
                else:
                    print(f"[!] Single-node cluster initialization failed with return code {result.returncode}", file=sys.stderr)
                    print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                    print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                    return False
            else:
                print(f"[*] Single-node Redis cluster initialized successfully on {primary_ip}", file=sys.stderr)
                print(f"[*] Initialization output: {result.stdout}", file=sys.stderr)

        # If there's only one node, we're done.
        if len(node_endpoints) == 1:
            return True

        # Step 2: make all other nodes replicas of the primary master.
        for replica_id, replica_ip in node_endpoints[1:]:
            # If replica is already part of the cluster and cluster_state is ok, skip.
            if _cluster_state_ok(replica_ip):
                print(f"[*] Replica candidate {replica_ip} already has cluster_state=ok, skipping add-node", file=sys.stderr)
                continue

            # If replica is a standalone master with slots, reset it before joining.
            nodes_snapshot = get_cluster_nodes(replica_ip)
            local_snapshot = next((n for n in nodes_snapshot if "myself" in n.get("flags", [])), None)
            if local_snapshot and "master" in local_snapshot.get("flags", []) and node_has_slots(local_snapshot):
                print(f"[*] Replica candidate {replica_ip} has local slots, resetting cluster state", file=sys.stderr)
                if not _reset_node(replica_ip):
                    return False

            cmd = [
                REDIS_CLI,
                "--cluster",
                "add-node",
                f"{replica_ip}:{REDIS_PORT}",
                f"{primary_ip}:{REDIS_PORT}",
                "--cluster-slave",
            ]

            print(
                f"[*] Adding replica node {replica_ip} to Redis cluster via primary {primary_ip} "
                f"with command: {' '.join(cmd)}",
                file=sys.stderr,
            )

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )

            if result.returncode != 0:
                stdout_lower = (result.stdout or "").lower()
                stderr_lower = (result.stderr or "").lower()

                already_joined_markers = [
                    "already part of cluster",
                    "already known",
                    "already existing node",
                ]
                if any(m in stdout_lower or m in stderr_lower for m in already_joined_markers):
                    print(f"[*] Node {replica_ip} already part of the cluster, treating as success", file=sys.stderr)
                    continue

                reset_markers = [
                    "already has slots",
                    "err slot",
                    "is not empty",
                ]
                if any(m in stdout_lower or m in stderr_lower for m in reset_markers):
                    print(f"[*] Replica {replica_ip} has existing slots, resetting and retrying add-node", file=sys.stderr)
                    if _reset_node(replica_ip):
                        retry = subprocess.run(
                            cmd,
                            capture_output=True,
                            text=True,
                            timeout=300,
                        )
                        if retry.returncode == 0:
                            print(f"[*] Replica node {replica_ip} added after reset", file=sys.stderr)
                            continue
                        print(f"[!] Retry add-node failed for {replica_ip} (rc={retry.returncode})", file=sys.stderr)
                        print(f"[!] STDOUT: {retry.stdout}", file=sys.stderr)
                        print(f"[!] STDERR: {retry.stderr}", file=sys.stderr)

                print(f"[!] Failed to add replica node {replica_ip} to cluster (rc={result.returncode})", file=sys.stderr)
                print(f"[!] STDOUT: {result.stdout}", file=sys.stderr)
                print(f"[!] STDERR: {result.stderr}", file=sys.stderr)
                return False

            print(f"[*] Replica node {replica_ip} added to Redis cluster successfully", file=sys.stderr)
            print(f"[*] add-node output: {result.stdout}", file=sys.stderr)

        return True
    except Exception as e:
        print(f"[!] Failed to create or reconcile Redis cluster: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return False


def check_node_in_cluster(local_tunnel_ip: str) -> tuple[bool, str | None]:
    """Check if local node is part of the cluster.
    Returns (is_in_cluster, error_message)
    """
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "cluster", "info"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            return False, f"Failed to get cluster info: {result.stderr}"

        output = result.stdout.strip()
        # Check if cluster_state is ok
        for line in output.split('\n'):
            if line.startswith('cluster_state:'):
                state = line.split(':')[1].strip()
                is_ok = state == "ok"
                return is_ok, None if is_ok else f"Cluster state: {state}"

        return False, "Could not determine cluster state"
    except Exception as e:
        return False, f"Failed to check cluster status: {str(e)}"


def get_cluster_state(local_tunnel_ip: str) -> str | None:
    """Get cluster_state from redis-cli output."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "cluster", "info"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            if line.startswith("cluster_state:"):
                return line.split(":", 1)[1].strip()
        return None
    except Exception:
        return None


def get_cluster_nodes(local_tunnel_ip: str) -> list[dict]:
    """Parse `redis-cli cluster nodes` output."""
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "cluster", "nodes"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        nodes: list[dict] = []
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) < 8:
                continue
            node_id = parts[0]
            addr = parts[1]
            flags = parts[2].split(",")
            master_id = parts[3]
            link_state = parts[7]
            slots = parts[8:] if len(parts) > 8 else []
            nodes.append(
                {
                    "node_id": node_id,
                    "addr": addr,
                    "flags": flags,
                    "master_id": master_id,
                    "link_state": link_state,
                    "slots": slots,
                }
            )
        return nodes
    except Exception:
        return []


def node_has_slots(node: dict) -> bool:
    """Check if a node has any slot assignments in cluster nodes output."""
    for token in node.get("slots", []):
        if token.isdigit():
            return True
        if "-" in token and token.replace("-", "").isdigit():
            return True
    return False


def revive_single_node_cluster(local_tunnel_ip: str) -> tuple[bool, str | None]:
    """Reset cluster state when only this node is reachable."""
    nodes = get_cluster_nodes(local_tunnel_ip)
    if not nodes:
        return False, "Could not read cluster nodes"

    local = next((n for n in nodes if "myself" in n.get("flags", [])), None)
    if not local:
        return False, "Local node not found in cluster nodes"

    connected = [
        n for n in nodes
        if n.get("link_state") == "connected"
        and "fail" not in n.get("flags", [])
        and "fail?" not in n.get("flags", [])
    ]

    if len(connected) != 1 or connected[0] != local:
        return False, "More than one reachable node"

    try:
        reset_cmd = [
            REDIS_CLI,
            "-h",
            local_tunnel_ip,
            "-p",
            str(REDIS_PORT),
            "cluster",
            "reset",
            "hard",
        ]
        reset_result = subprocess.run(
            reset_cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if reset_result.returncode != 0:
            return False, reset_result.stderr.strip() or "Cluster reset failed"

        addslots_cmd = [
            REDIS_CLI,
            "-h",
            local_tunnel_ip,
            "-p",
            str(REDIS_PORT),
            "cluster",
            "addslots",
            *[str(i) for i in range(16384)],
        ]
        addslots_result = subprocess.run(
            addslots_cmd,
            capture_output=True,
            text=True,
            timeout=300,
        )
        if addslots_result.returncode != 0:
            return False, addslots_result.stderr.strip() or "Failed to assign slots after reset"

        if get_cluster_state(local_tunnel_ip) == "ok":
            return True, None
        return False, "Cluster state not ok after reset"
    except Exception as e:
        return False, f"Failed to revive single-node cluster: {e}"


def should_force_failover(nodes: list[dict]) -> tuple[bool, str]:
    """Decide whether local replica should force a failover."""
    local = next((n for n in nodes if "myself" in n.get("flags", [])), None)
    if not local:
        return False, "Local node not found in cluster nodes"
    if "slave" not in local.get("flags", []):
        return False, "Local node is not a replica"

    master_id = local.get("master_id")
    if not master_id or master_id == "-":
        return True, "Replica has no master assigned"

    master = next((n for n in nodes if n.get("node_id") == master_id), None)
    if not master:
        return True, "Master node not found in cluster"

    master_flags = set(master.get("flags", []))
    if "fail" in master_flags or "fail?" in master_flags:
        return True, "Master is marked as failed"

    if master.get("link_state") != "connected":
        return True, "Master link state is disconnected"

    return False, "Master appears healthy"


def maybe_force_failover(local_tunnel_ip: str) -> tuple[bool, str | None]:
    """Force failover on a replica when cluster_state is fail."""
    cluster_state = get_cluster_state(local_tunnel_ip)
    if cluster_state != "fail":
        return False, None

    revived, revive_error = revive_single_node_cluster(local_tunnel_ip)
    if revived:
        return True, None

    nodes = get_cluster_nodes(local_tunnel_ip)
    if not nodes:
        return False, "Could not read cluster nodes"

    should_force, reason = should_force_failover(nodes)
    if not should_force:
        return False, revive_error or reason

    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "cluster", "failover", "force"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return False, result.stderr.strip() or "Failed to force failover"
        # Re-check if the promoted node has slots; if not, try to claim all slots.
        time.sleep(2)
        nodes_after = get_cluster_nodes(local_tunnel_ip)
        local_after = next((n for n in nodes_after if "myself" in n.get("flags", [])), None)
        if local_after and "master" in local_after.get("flags", []):
            master_count = sum(1 for n in nodes_after if "master" in n.get("flags", []))
            if master_count <= 1 and not node_has_slots(local_after):
                # Try to fix cluster first (reassign slots from failed nodes)
                fix_cmd = [
                    REDIS_CLI,
                    "--cluster",
                    "fix",
                    f"{local_tunnel_ip}:{REDIS_PORT}",
                    "--cluster-yes",
                ]
                fix_result = subprocess.run(
                    fix_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if fix_result.returncode != 0:
                    output = f"{fix_result.stdout}\n{fix_result.stderr}".lower()
                    if "fix-with-unreachable-masters" in output:
                        fix_cmd.append("--cluster-fix-with-unreachable-masters")
                        fix_result = subprocess.run(
                            fix_cmd,
                            capture_output=True,
                            text=True,
                            timeout=300,
                        )
                if fix_result.returncode == 0 and get_cluster_state(local_tunnel_ip) == "ok":
                    return True, None
                addslots_cmd = [
                    REDIS_CLI,
                    "-h",
                    local_tunnel_ip,
                    "-p",
                    str(REDIS_PORT),
                    "cluster",
                    "addslots",
                    *[str(i) for i in range(16384)],
                ]
                addslots = subprocess.run(
                    addslots_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if addslots.returncode != 0:
                    return False, addslots.stderr.strip() or "Failed to assign slots after failover"
        return True, None
    except Exception as e:
        return False, f"Failed to force failover: {e}"


# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize Redis: install packages."""
    try:
        # Install Redis if not present
        if not is_redis_available():
            install_redis()
        else:
            ensure_redis_directories()

        # Ensure log directory exists
        Path("/var/log/redis").mkdir(parents=True, exist_ok=True)
        # Best-effort cleanup of legacy host Redis service.
        subprocess.run(["systemctl", "stop", "redis-server"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "redis-server"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply Redis configuration for standalone or replication."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])
    cluster = state_json.get("cluster", {})
    cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
    container_name = get_container_name(cluster_id)

    # Check if all nodes have WireGuard configured
    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all nodes',
            local_state=local_state
        )

    # Need at least 1 node for Redis service
    if len(cluster_nodes) < 1:
        return PluginOutput(
            status='postponed',
            error_message=f'Redis requires at least 1 node, currently have {len(cluster_nodes)}',
            local_state=local_state
        )

    if len(cluster_nodes) > REDIS_MAX_NODES:
        return PluginOutput(
            status='postponed',
            error_message=f'Redis supports up to {REDIS_MAX_NODES} nodes, got {len(cluster_nodes)}',
            local_state=local_state
        )

    member_ids = {n.get("node_id") for n in cluster_nodes if n.get("node_id")}
    if local_node_id not in member_ids:
        stop_and_remove_container(container_name)
        return PluginOutput(
            status="completed",
            node_properties={
                "redis_node_ready": None,
                "redis_cluster_initialized": None,
            },
            local_state={},
        )

    sentinel_props = state_json.get("sentinelNodeProperties", [])
    ready_sentinels = count_ready_sentinels(sentinel_props)
    if ready_sentinels < 1:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for at least one ready Redis Sentinel node',
            local_state=local_state
        )

    # Master identity: Sentinel only (get-master-addr-by-name). No Swarm leader / reachability.
    node_endpoints = build_node_endpoints(cluster_nodes, wg_props)

    if not node_endpoints:
        return PluginOutput(
            status='postponed',
            error_message='No nodes with WireGuard tunnel IPs found',
            local_state=local_state
        )

    node_endpoints.sort(key=lambda x: x[0])
    sentinel_ips = get_sentinel_endpoints(state_json)
    master_ip = get_master_ip_from_sentinels(sentinel_ips)
    if not master_ip:
        return PluginOutput(
            status='postponed',
            error_message=(
                'Waiting for Redis Sentinel to report a single agreed master '
                '(redis-master); ensure redis-sentinel apply has run'
            ),
            local_state=local_state,
        )

    if not sentinel_master_in_redis_membership(master_ip, node_endpoints):
        return PluginOutput(
            status='postponed',
            error_message=(
                f'Sentinel redis-master is {master_ip}, which is not a WireGuard endpoint of this '
                'Redis cluster (e.g. bootstrap or former member); waiting for Sentinel to elect a '
                'member node as master'
            ),
            local_state=local_state,
        )

    # Replication mode follows cluster membership, not transient redis-cli reachability.
    # Using reachable count caused apply loops: when the peer was briefly unreachable,
    # use_replication flipped and forced container recreate every plan tick.
    use_replication = len(cluster_nodes) >= 2

    # Get local tunnel IP
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        # Avoid running with default localhost bind before WG is ready.
        stop_and_remove_container(container_name)
        return PluginOutput(
            status='postponed',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state
        )

    is_master = replication_master_host_matches(local_tunnel_ip, master_ip)

    # Replicas start only after the Sentinel-elected master accepts connections (avoids
    # endless sync retries and stray standalone promotion while the primary is down).
    if use_replication and not is_master and not redis_responds_pong(master_ip):
        return PluginOutput(
            status='postponed',
            error_message=(
                f'Waiting for Redis master at {master_ip}:{REDIS_PORT} '
                '(per Sentinel) to accept connections before starting this replica'
            ),
            local_state=local_state,
        )

    # Write Redis configuration
    try:
        if use_replication:
            write_redis_config(local_tunnel_ip, is_master, master_ip)
        else:
            write_redis_config(local_tunnel_ip, True, master_ip)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to write config: {str(e)}', local_state=local_state)

    # Check if we need to restart Redis
    # Read the current config to see if it matches what we just wrote
    needs_restart = False
    redis_running, redis_error = is_redis_running(container_name)

    if not redis_running:
        needs_restart = True
    else:
        try:
            result = subprocess.run(
                [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "ping"],
                capture_output=True,
                text=True,
                timeout=2
            )
            if result.returncode != 0 or result.stdout.strip() != "PONG":
                needs_restart = True
        except Exception:
            needs_restart = True

        replication_info = get_replication_info(local_tunnel_ip)
        role = replication_info.get("role")
        master_host = replication_info.get("master_host")
        if use_replication:
            if is_master and role != "master":
                needs_restart = True
            if not is_master and (
                not replication_role_is_replica(role)
                or not replication_master_host_matches(master_ip, master_host)
            ):
                needs_restart = True
        else:
            if role and role != "master":
                needs_restart = True

        if local_state.get("redis_bind_ip") != local_tunnel_ip:
            needs_restart = True


    if needs_restart:
        # Start/restart Redis server
        try:
            run_valkey_container(container_name)
        except Exception as e:
            return PluginOutput(status='error', error_message=f'Failed to start ValKey container: {str(e)}', local_state=local_state)

        # Wait for Redis to become ready
        redis_ready = wait_for_redis_ready(local_tunnel_ip, timeout_sec=60)

        if not redis_ready and not local_state.get("aof_repair_attempted"):
            repaired, repair_error = try_repair_aof_after_startup_failure(
                REDIS_DATA_DIR,
                container_name,
            )
            if repair_error:
                return PluginOutput(
                    status="error",
                    error_message=f"AOF repair failed: {repair_error}",
                    local_state=local_state,
                )
            if repaired:
                local_state["aof_repair_attempted"] = str(time.time())
                try:
                    run_valkey_container(container_name)
                except Exception as e:
                    return PluginOutput(
                        status="error",
                        error_message=f"Failed to restart ValKey after AOF repair: {str(e)}",
                        local_state=local_state,
                    )
                redis_ready = wait_for_redis_ready(local_tunnel_ip, timeout_sec=60)

        if redis_ready:
            local_state.pop("aof_repair_attempted", None)
        elif local_state.get("aof_repair_attempted") and not aof_corruption_detected(
            REDIS_DATA_DIR, container_name
        ):
            local_state.pop("aof_repair_attempted", None)

        if not redis_ready:
            return PluginOutput(
                status='postponed',
                error_message='Redis did not become ready within timeout',
                local_state=local_state
            )

    # Do not call REPLICAOF NO ONE here — only Sentinel should change who is master. If
    # Sentinel says we are master but the process is still a replica, config+restart above
    # should fix; otherwise wait for Sentinel failover rather than forcing promotion.

    if use_replication and is_master:
        guard_msg = empty_master_data_loss_guard(local_tunnel_ip, node_endpoints)
        if guard_msg:
            return PluginOutput(status="error", error_message=guard_msg, local_state=local_state)

    node_properties = {
        "redis_node_ready": "true",
        "redis_role": "master" if (is_master or not use_replication) else "replica",
        "redis_master_ip": master_ip,
    }
    if is_master or not use_replication:
        node_properties["redis_cluster_initialized"] = "true"
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    node_properties.update(
        build_image_evidence_props(
            prefix="redis",
            image_ref=VALKEY_IMAGE,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )
    local_state["redis_master_ip"] = master_ip
    local_state["redis_use_replication"] = "true" if use_replication else "false"
    local_state["redis_bind_ip"] = local_tunnel_ip
    local_state["redis_container_name"] = container_name
    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        local_state=local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check Redis health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}
    cluster = state_json.get("cluster", {}) if isinstance(state_json, dict) else {}
    cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
    container_name = local_state.get("redis_container_name") or get_container_name(cluster_id)

    cluster_nodes = state_json.get("clusterNodes", []) if isinstance(state_json, dict) else []
    member_ids = {n.get("node_id") for n in cluster_nodes if n.get("node_id")}
    if local_node_id not in member_ids:
        return PluginOutput(
            status='postponed',
            error_message='This node is not in the Redis cluster membership',
            local_state=local_state,
        )

    # Check if Redis is running
    redis_running, redis_error = is_redis_running(container_name)
    if not redis_running:
        err = (redis_error or "").lower()
        not_found = "no such container" in err or "no such object" in err
        if not_found:
            return PluginOutput(
                status='postponed',
                error_message=redis_error or 'Redis service is not running',
                local_state=local_state,
            )
        return PluginOutput(
            status='error',
            error_message=redis_error or 'Failed to check Redis container status',
            local_state=local_state,
        )

    # Get local tunnel IP
    wg_props = state_json.get("wgNodeProperties", []) if isinstance(state_json, dict) else []
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)

    if not local_tunnel_ip:
        return PluginOutput(status='postponed', error_message='No tunnel IP available', local_state=local_state)

    # Check Redis ping
    try:
        result = subprocess.run(
            [REDIS_CLI, "-h", local_tunnel_ip, "-p", str(REDIS_PORT), "ping"],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode != 0 or result.stdout.strip() != "PONG":
            return PluginOutput(status='postponed', error_message='Redis is not responding', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='postponed', error_message=f'Failed to ping Redis: {e}', local_state=local_state)

    replication_info = get_replication_info(local_tunnel_ip)
    role = replication_info.get("role")
    if not role:
        return PluginOutput(status='postponed', error_message='Could not read replication role', local_state=local_state)

    sentinel_props = state_json.get("sentinelNodeProperties", [])
    master_ip_h: str | None = None
    if count_ready_sentinels(sentinel_props) >= 1:
        master_ip_h = get_master_ip_from_sentinels(get_sentinel_endpoints(state_json))
        if master_ip_h:
            node_endpoints_h = build_node_endpoints(cluster_nodes, wg_props)
            if not sentinel_master_in_redis_membership(master_ip_h, node_endpoints_h):
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'Sentinel redis-master {master_ip_h} is not a WireGuard endpoint of this '
                        'Redis cluster; waiting for a member to become master'
                    ),
                    local_state=local_state,
                )

    if len(cluster_nodes) >= 2:
        if count_ready_sentinels(sentinel_props) < 1:
            return PluginOutput(
                status='postponed',
                error_message='Waiting for at least one ready Redis Sentinel node',
                local_state=local_state,
            )
        if not master_ip_h:
            return PluginOutput(
                status='postponed',
                error_message=(
                    'Could not determine redis-master from Sentinels; cannot verify replication role'
                ),
                local_state=local_state,
            )
        is_master_expected = replication_master_host_matches(local_tunnel_ip, master_ip_h)
        if is_master_expected:
            if role != "master":
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'Expected master role (Sentinel redis-master is this node); '
                        f'Valkey reports role={role}'
                    ),
                    local_state=local_state,
                )
        else:
            if role == "master":
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'This node runs as master but Sentinel redis-master is {master_ip_h}; '
                        'expected replica configuration'
                    ),
                    local_state=local_state,
                )
            if not replication_role_is_replica(role):
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'Expected replica of {master_ip_h} per Sentinel; Valkey reports role={role}'
                    ),
                    local_state=local_state,
                )
            reported_master = replication_info.get("master_host")
            if reported_master and not replication_master_host_matches(master_ip_h, reported_master):
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'Replica follows {reported_master} but Sentinel redis-master is {master_ip_h}'
                    ),
                    local_state=local_state,
                )
            if replication_info.get("master_link_status") != "up":
                return PluginOutput(
                    status='postponed',
                    error_message='Replica is not connected to master',
                    local_state=local_state,
                )
        return PluginOutput(status='completed', local_state=local_state)

    if len(cluster_nodes) == 1 and count_ready_sentinels(sentinel_props) >= 1:
        if not master_ip_h:
            return PluginOutput(
                status='postponed',
                error_message='Could not determine redis-master from Sentinels; cannot verify single-node Redis',
                local_state=local_state,
            )
        if not replication_master_host_matches(local_tunnel_ip, master_ip_h):
            return PluginOutput(
                status='postponed',
                error_message=(
                    f'Sentinel redis-master {master_ip_h} does not match this node ({local_tunnel_ip}) '
                    'for single-node cluster'
                ),
                local_state=local_state,
            )
        if role != "master":
            return PluginOutput(
                status='postponed',
                error_message=f'Single-node Redis must be master; Valkey reports role={role}',
                local_state=local_state,
            )

    if replication_role_is_replica(role):
        if replication_info.get("master_link_status") != "up":
            return PluginOutput(
                status='postponed',
                error_message='Replica is not connected to master',
                local_state=local_state,
            )

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal (graceful shutdown)."""
    local_state = input_data.local_state or {}

    # TODO: Implement graceful node removal from cluster if needed.

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy Redis installation and clean up."""
    try:
        state_json = input_data.state or {}
        cluster = state_json.get("cluster", {}) if isinstance(state_json, dict) else {}
        cluster_id = cluster.get("id") if isinstance(cluster, dict) else None
        local_state = input_data.local_state or {}
        container_name = local_state.get("redis_container_name") or get_container_name(cluster_id)

        # Stop legacy service (if any) and ValKey container.
        subprocess.run(["systemctl", "stop", "redis-server"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "redis-server"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        stop_and_remove_container(container_name)

        # Remove config and data directories
        if REDIS_CONFIG_DIR.exists():
            shutil.rmtree(REDIS_CONFIG_DIR, ignore_errors=True)
        if REDIS_DATA_DIR.exists():
            shutil.rmtree(REDIS_DATA_DIR, ignore_errors=True)

        # Request deletion of node properties
        node_properties = {
            "redis_node_ready": None,
            "redis_cluster_initialized": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy Redis: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
