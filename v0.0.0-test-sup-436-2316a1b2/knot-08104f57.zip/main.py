#!/usr/bin/env python3
"""Knot DNS provision plugin.

Zone contents are a deterministic pure function of the SwarmDB-derived plugin state
and are rendered locally on every node. There is no DNS-level replication: no
master/slave AXFR/IXFR, no catalog zones, no RFC2136/TSIG dynamic updates. SwarmDB
anti-entropy is the only replication layer, same as for the rest of the platform.

Consequences of that design:
  * ``knot.conf`` has the same shape on every node and never mentions the leader,
    so a leader re-election neither rewrites the config nor restarts the service;
  * a zone file is rewritten (and the zone reloaded) only when the rendered content
    actually changed;
  * a node that lost its view of the cluster stops answering on port 53 instead of
    serving stale authoritative answers — resolvers then fail over to the healthy
    nameservers listed in the parent delegation.
"""

import sys
import os
import fcntl
import shutil
import subprocess
import hashlib
import time
from pathlib import Path

SWARM_APT_LOCK_FILE = "/run/lock/swarm-apt.lock"

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

# Configuration
KNOT_VERSION = os.environ.get("KNOT_VERSION", "3.5.1")
KNOT_SERVICE_NAME = "knot"
KNOT_APT_PIN_FILE = Path("/etc/apt/preferences.d/knot")
KNOT_APT_KEYRING = Path("/usr/share/keyrings/cznic-labs-pkg.gpg")
KNOT_APT_LIST = Path("/etc/apt/sources.list.d/cznic-labs-knot-dns.list")
KNOT_CONFIG_DIR = Path("/etc/knot")
KNOT_CONFIG_FILE = KNOT_CONFIG_DIR / "knot.conf"
KNOT_ZONES_CONFIG_FILE = KNOT_CONFIG_DIR / "zones.conf"
KNOT_DATA_DIR = Path("/var/lib/knot")
KNOT_ZONES_DIR = KNOT_DATA_DIR / "zones"
KNOT_CLI = "knotc"
KNOT_PORT = 53

# Record TTLs. The negative TTL (SOA minimum) is deliberately short: a resolver that
# hits a node mid-reconcile must not cache an NXDOMAIN for minutes.
RECORD_TTL = 300
SOA_TTL = 300
SOA_REFRESH = 3600
SOA_RETRY = 1800
SOA_EXPIRE = 604800
SOA_MINIMUM = 60

# How stale the merged peer state may get before Knot is stopped, in seconds.
# `peerStateAgeSecs` in the plugin state is the age of the freshest heartbeat any
# other node wrote into SwarmDB and this node has merged, bucketed to 30s by the
# manifest. Default grace is 2x the SwarmDB anti-entropy interval (30s). Override
# per cluster with the `knot_isolation_grace_secs` cluster property or the env var.
#
# 300s rather than one or two anti-entropy intervals: heartbeat propagation can stall
# cluster-wide for minutes during a leader re-election (QA measured ~4.5 min), and
# from inside a node that is indistinguishable from being partitioned. A short grace
# therefore gates healthy nodes off during exactly the events where DNS matters most.
# The cost is a slower response to a real partition, which only costs a resolver a
# retry against another delegated nameserver.
DEFAULT_ISOLATION_GRACE_SECS = 300

# Resolution of `peerStateAgeSecs`, mirroring the bucket width in manifest.yaml.
# The reported age is a lower bound, so the gate fires within [grace, grace+bucket).
PEER_STATE_AGE_BUCKET_SECS = 30

# Label of the dynamic child zone: dyn.<global_id>.<base_domain>.
DYN_LABEL = "dyn"

# Owner of the per-node diagnostic TXT record. On sp-vm the only port reachable from
# outside a node is the one this plugin serves, so the gate decision is published
# where it can always be read: `dig +norec @<node> _gate.<zone> TXT`. It is the one
# record in the zone that is deliberately per-node, so zone-content comparisons must
# exclude it (see examples/test-cluster/tests/apps/knot.sh).
GATE_TXT_LABEL = "_gate"
GATE_TXT_TTL = 5

# Service hostname prefix -> plugin state key holding that service's cluster nodes.
CNAME_SERVICE_PREFIXES = (
    ("auth", "authServiceNodes"),
    ("api", "swarmCloudApiNodes"),
    ("app", "swarmCloudUiNodes"),
    ("gatekeeper-s3", "swarmGatekeeperS3Nodes"),
    ("gatekeeper-harbor", "swarmGatekeeperHarborNodes"),
)

LEGACY_CLUSTER_PROPERTIES = ("knot_tsig_key_name", "knot_tsig_key_secret")
LEGACY_NODE_PROPERTIES = ("knot_cluster_initialized",)

# Plugin setup
plugin = ProvisionPlugin()


def log(msg: str) -> None:
    print(f"[knot] {msg}", file=sys.stderr)


# ---------------------------------------------------------------------------
# State accessors (pure)
# ---------------------------------------------------------------------------

def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props or []:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def get_node_addr(node_id: str, node_addrs: list) -> str | None:
    """Get physical address for a node as seen in the local gossip view."""
    for node in node_addrs or []:
        if node.get("node_id") != node_id:
            continue
        if node.get("status") not in (None, "alive"):
            continue
        addr = node.get("addr")
        if isinstance(addr, str) and addr.strip():
            return addr.strip()
    return None


def get_swarm_secret(state: dict, secret_id: str) -> str | None:
    """Get secret value from the SwarmSecrets projection."""
    for secret in state.get("swarmSecrets") or []:
        if isinstance(secret, dict) and secret.get("id") == secret_id:
            value = secret.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def get_cluster_property(state: dict, name: str) -> str | None:
    for prop in state.get("clusterProperties") or []:
        if prop.get("name") == name:
            value = prop.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def resolve_global_id(state: dict) -> str | None:
    global_id = state.get("globalId")
    if isinstance(global_id, str) and global_id.strip():
        return global_id.strip()
    return None


def resolve_base_domain(state: dict) -> str | None:
    base_domain = get_swarm_secret(state, "base_domain")
    if base_domain:
        return base_domain.rstrip(".")
    return None


def resolve_cluster_zone(state: dict) -> str | None:
    """The zone delegated to this cluster: ``<global_id>.<base_domain>``."""
    global_id = resolve_global_id(state)
    base_domain = resolve_base_domain(state)
    if global_id and base_domain:
        return f"{global_id}.{base_domain}"
    return None


def resolve_static_gateway_hostname(state: dict) -> str | None:
    custom = get_swarm_secret(state, "gateway_hostname")
    if custom:
        return custom.rstrip(".")
    return None


def resolve_dynamic_gateway_hostname(state: dict) -> str | None:
    cluster_zone = resolve_cluster_zone(state)
    if cluster_zone:
        return f"gw.dyn.{cluster_zone}"
    return None


def resolve_delegation_gateway_hostname(state: dict) -> str | None:
    """CNAME target for users: static gateway when configured, else the dynamic one."""
    return resolve_static_gateway_hostname(state) or resolve_dynamic_gateway_hostname(state)


def uses_custom_gateway_dns(state: dict) -> bool:
    """Custom gateway: the parent zone holds a wildcard CNAME, Knot holds A records."""
    return bool(resolve_static_gateway_hostname(state) and resolve_global_id(state))


def resolve_swarm_domain(state: dict) -> str | None:
    swarm_domain = get_swarm_secret(state, "swarm_domain") or state.get("swarmDomain")
    if isinstance(swarm_domain, str) and swarm_domain.strip():
        return swarm_domain.strip().rstrip(".")
    cluster_zone = resolve_cluster_zone(state)
    return f"app.{cluster_zone}" if cluster_zone else None


def resolve_pki_domain(state: dict) -> str | None:
    pki_domain = get_swarm_secret(state, "pki_domain") or state.get("pkiDomain")
    if isinstance(pki_domain, str) and pki_domain.strip():
        return pki_domain.strip().rstrip(".")
    cluster_zone = resolve_cluster_zone(state)
    return f"ca.{cluster_zone}" if cluster_zone else None


def any_ready(nodes: list) -> bool:
    return any(node.get("ready") == "true" for node in nodes or [])


def get_openresty_ready_ips(state: dict) -> list[str]:
    """Gateway addresses for ``gw.dyn``: ready openresty nodes, else all alive ones.

    The fallback keeps ``gw.dyn`` resolvable while no gateway is ready. Pointing at a
    gateway that is down fails soft — the client gets a connection error it retries —
    whereas an empty record set makes the name NXDOMAIN, which resolvers cache and
    which turns every service CNAME into a dangling one. That authoritative-NXDOMAIN
    behaviour is the exact user-visible symptom this issue is about. The value stays a
    pure function of SwarmDB state: ready nodes when any is ready, all alive nodes
    otherwise.
    """
    alive = {
        svc["external_ip"].strip(): svc.get("ready") == "true"
        for svc in state.get("openrestyServices") or []
        if isinstance(svc.get("external_ip"), str) and svc["external_ip"].strip()
    }
    ready = sorted(ip for ip, is_ready in alive.items() if is_ready)
    return ready or sorted(alive)


def node_id_to_ns_name(node_id: str) -> str:
    """Convert node_id to a DNS-compatible NS label using MD5 in base36.

    The parent zone's delegation glue (written by the dns-manager plugin) uses the
    same mapping, so in-zone NS names and the delegation must stay in sync.
    """
    md5_hash = hashlib.md5(node_id.encode()).hexdigest()
    hash_int = int(md5_hash, 16)
    base36_chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    if hash_int == 0:
        return "0"
    base36 = []
    while hash_int:
        hash_int, remainder = divmod(hash_int, 36)
        base36.append(base36_chars[remainder])
    return "".join(reversed(base36))


def compute_ns_entries(state: dict, local_node_id: str | None = None) -> list[tuple[str, str]]:
    """Apex NS set as ``[(ns_label, public_ip)]``, sorted by label.

    Same desired set the dns-manager plugin publishes as the parent delegation:
    knot nodes with ``knot_node_ready=true`` and an alive public address. A node
    that dropped out of the gossip view has no alive address and therefore leaves
    every node's NS set within one anti-entropy interval.
    """
    entries: dict[str, str] = {}
    for svc in state.get("knotServices") or []:
        external_ip = svc.get("external_ip")
        if svc.get("ready") != "true" or not isinstance(external_ip, str) or not external_ip.strip():
            continue
        node_id = svc.get("node_id")
        if not node_id:
            continue
        entries[node_id_to_ns_name(node_id)] = external_ip.strip()

    if not entries and local_node_id:
        # Bootstrap: `knot_node_ready` for this node is published only after the
        # first successful apply, so serve ourselves as the sole NS until then.
        local_addr = get_node_addr(local_node_id, state.get("nodeAddrs") or [])
        if local_addr:
            entries[node_id_to_ns_name(local_node_id)] = local_addr

    return sorted(entries.items())


def is_in_zone(hostname: str, zone: str) -> bool:
    """True for names strictly below ``zone`` (the apex itself cannot be a CNAME)."""
    if not hostname or not zone:
        return False
    return hostname.rstrip(".").endswith(f".{zone.rstrip('.')}")


def relative_owner(hostname: str, zone: str) -> str | None:
    """Owner name of ``hostname`` relative to ``zone``, or None if not below it."""
    if not is_in_zone(hostname, zone):
        return None
    normalized = hostname.rstrip(".")
    return normalized[: -(len(zone.rstrip(".")) + 1)]


def compute_gateway_hostnames(state: dict, zone: str) -> list[str]:
    """FQDNs inside ``zone`` that must resolve to the delegation gateway."""
    hostnames: set[str] = set()

    for prefix, state_key in CNAME_SERVICE_PREFIXES:
        if any_ready(state.get(state_key)):
            hostnames.add(f"{prefix}.{zone}")

    for domain in (resolve_swarm_domain(state), resolve_pki_domain(state)):
        if domain and is_in_zone(domain, zone):
            hostnames.add(domain.rstrip("."))

    for node in state.get("k8sNodes") or []:
        hostname = node.get("k8s_external_hostname")
        if node.get("ready") != "true" or not isinstance(hostname, str) or not hostname.strip():
            continue
        hostname = hostname.strip().rstrip(".")
        if is_in_zone(hostname, zone):
            hostnames.add(hostname)

    return sorted(hostnames)


# ---------------------------------------------------------------------------
# Zone rendering (pure)
# ---------------------------------------------------------------------------

def content_serial(body: str) -> int:
    """Deterministic 32-bit SOA serial derived from the zone's record set.

    Every node that converged on the same SwarmDB state renders a byte-identical
    zone file, serial included. Knot owns the serial actually served
    (``zonefile-load: difference-no-serial``), so this value never has to increase.
    """
    digest = hashlib.sha256(body.encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big") or 1


def render_zone_file(zone: str, ns_entries: list[tuple[str, str]], records: list[str]) -> str:
    """Render a complete zone file. Pure function of its arguments."""
    zone = zone.rstrip(".")
    if not ns_entries:
        raise ValueError(f"cannot render zone {zone} without any NS record")

    lines: list[str] = []
    for ns_label, _ip in ns_entries:
        lines.append(f"@\t{RECORD_TTL}\tIN\tNS\t{ns_label}.{zone}.")
    for ns_label, ip in ns_entries:
        lines.append(f"{ns_label}\t{RECORD_TTL}\tIN\tA\t{ip}")
    lines.extend(records)

    body = "\n".join(lines)
    primary_ns = f"{ns_entries[0][0]}.{zone}."
    header = (
        "; Rendered by the swarm knot provision plugin from SwarmDB state.\n"
        "; Do not edit: the file is overwritten whenever the rendered content changes.\n"
        f"$ORIGIN {zone}.\n"
        f"$TTL {RECORD_TTL}\n"
        f"@\t{SOA_TTL}\tIN\tSOA\t{primary_ns} hostmaster.{zone}. "
        f"( {content_serial(body)} {SOA_REFRESH} {SOA_RETRY} {SOA_EXPIRE} {SOA_MINIMUM} )\n"
    )
    return f"{header}{body}\n"


def gate_txt_record(state: dict, local_node_id: str | None, decision: str) -> str:
    """The diagnostic TXT line: what the gate decided and on what input."""
    age = peer_state_age_secs(state)
    body = (
        f'gate={decision} age={"-" if age is None else age} '
        f'grace={isolation_grace_secs(state)} '
        f'ready={len(ready_nameserver_members(state))} '
        f'build={plugin_build_fingerprint()}'
    )
    return f'{GATE_TXT_LABEL}\t{GATE_TXT_TTL}\tIN\tTXT\t"{body}"'


def replace_gate_txt(zone_text: str, record: str) -> str:
    """Swap the diagnostic TXT line in an already-rendered zone, leaving the rest.

    Used on the hold path: the node deliberately does not re-render its records from
    a decayed view, but it must still be able to say why — otherwise the breadcrumb
    freezes at the last healthy value and the hold is indistinguishable from serving.
    """
    lines = zone_text.splitlines()
    swapped = [record if line.startswith(f"{GATE_TXT_LABEL}\t") else line for line in lines]
    if not any(line.startswith(f"{GATE_TXT_LABEL}\t") for line in lines):
        return zone_text
    return "\n".join(swapped) + "\n"


def build_zone_files(state: dict, local_node_id: str | None) -> dict[str, str]:
    """Render both cluster zones from the plugin state.

    Returns ``{zone_name: zone_file_content}``, or an empty dict when the state does
    not yet describe a servable zone.
    """
    cluster_zone = resolve_cluster_zone(state)
    if not cluster_zone:
        return {}

    ns_entries = compute_ns_entries(state, local_node_id)
    if not ns_entries:
        return {}

    dyn_zone = f"dyn.{cluster_zone}"
    custom_gateway = uses_custom_gateway_dns(state)
    gateway_hostname = resolve_delegation_gateway_hostname(state)
    openresty_ips = get_openresty_ready_ips(state)

    # Delegate dyn.<zone> inside <zone> as well, not only from the parent zone in
    # PowerDNS. Without this cut, `gw.dyn.<zone>` is part of <zone>'s own namespace
    # and Knot answers NXDOMAIN for every service CNAME that targets it.
    cluster_records: list[str] = []
    reserved_owners = {ns_label for ns_label, _ip in ns_entries} | {DYN_LABEL}
    for ns_label, _ip in ns_entries:
        cluster_records.append(f"{DYN_LABEL}\t{RECORD_TTL}\tIN\tNS\t{ns_label}.{dyn_zone}.")
        reserved_owners.add(f"{ns_label}.{DYN_LABEL}")
    for ns_label, ip in ns_entries:
        cluster_records.append(f"{ns_label}.{DYN_LABEL}\t{RECORD_TTL}\tIN\tA\t{ip}")

    for hostname in compute_gateway_hostnames(state, cluster_zone):
        owner = relative_owner(hostname, cluster_zone)
        if not owner or owner in reserved_owners:
            # Never shadow an NS/glue owner with a service record.
            continue
        if custom_gateway:
            for ip in openresty_ips:
                cluster_records.append(f"{owner}\t{RECORD_TTL}\tIN\tA\t{ip}")
        elif gateway_hostname:
            cluster_records.append(f"{owner}\t{RECORD_TTL}\tIN\tCNAME\t{gateway_hostname.rstrip('.')}.")

    dyn_records = [f"gw\t{RECORD_TTL}\tIN\tA\t{ip}" for ip in openresty_ips]

    decision, _detail = evaluate_serving_gate(state, local_node_id)
    cluster_records.append(gate_txt_record(state, local_node_id, decision))
    reserved_owners.add(GATE_TXT_LABEL)

    return {
        cluster_zone: render_zone_file(cluster_zone, ns_entries, sorted(cluster_records)),
        dyn_zone: render_zone_file(dyn_zone, ns_entries, dyn_records),
    }


# ---------------------------------------------------------------------------
# Knot configuration rendering (pure)
# ---------------------------------------------------------------------------

def compute_listen_addresses(
    local_node_id: str,
    local_tunnel_ip: str,
    node_addrs: list,
    default_output_ip: str | None = None,
) -> list[str]:
    """WireGuard tunnel IP (intra-cluster), loopback, and the public addresses."""
    candidates = [local_tunnel_ip, "127.0.0.1", get_node_addr(local_node_id, node_addrs), default_output_ip]
    listen: list[str] = []
    for addr in candidates:
        if addr and addr not in listen:
            listen.append(addr)
    return listen


def render_knot_config(listen_addresses: list[str]) -> str:
    """Render ``knot.conf``. Identical in shape on every node, leader-agnostic."""
    listen_block = "\n".join(f"    listen: {addr}@{KNOT_PORT}" for addr in listen_addresses)
    return f"""# Knot DNS configuration rendered by the swarm knot provision plugin.
#
# Zones are rendered locally on every node from SwarmDB state; SwarmDB anti-entropy
# is the replication layer. No master/slave transfers, no catalog zones, no TSIG and
# no dynamic updates — the zone file is the single source of truth for its zone.

server:
{listen_block}
    rundir: "/run/knot"
    user: knot:knot
    pidfile: "/run/knot/knot.pid"

log:
  - target: syslog
    any: info

database:
    storage: "{KNOT_DATA_DIR}"

template:
  - id: default
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    # The plugin rewrites whole zone files and does not manage serials; let Knot
    # diff the file against the loaded zone and bump the serial itself. Knot
    # requires journal-content: all for that mode — the journal only keeps the
    # serial history, the zone file stays the source of truth for the contents.
    zonefile-load: difference-no-serial
    journal-content: all

# Zones are declared in a separate file so their set can change without touching
# the server configuration above.
include: {KNOT_ZONES_CONFIG_FILE}
"""


def render_zones_config(zones: list[str]) -> str:
    """Render ``zones.conf`` — the full, deterministic set of served zones."""
    lines = [
        "# Zones served by this node, rendered by the swarm knot provision plugin.",
        "# Do not edit: the file is overwritten on every change of the zone set.",
    ]
    if zones:
        lines.append("")
        lines.append("zone:")
        for zone in sorted(zones):
            lines.append(f"  - domain: {zone.rstrip('.')}")
            lines.append("    template: default")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Cluster view / isolation (pure)
# ---------------------------------------------------------------------------

def isolation_grace_secs(state: dict) -> int:
    """Seconds of zero-peer visibility tolerated before Knot is stopped."""
    for source in (get_cluster_property(state, "knot_isolation_grace_secs"),
                   os.environ.get("KNOT_ISOLATION_GRACE_SECS")):
        if not source:
            continue
        try:
            value = int(str(source).strip())
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    return DEFAULT_ISOLATION_GRACE_SECS


def peer_state_age_secs(state: dict) -> int | None:
    """Age of the freshest peer-written state this node has merged, in seconds.

    ``None`` means there is no peer to merge with at all (a single-node cluster, or
    no peer has ever reported a heartbeat) — that is not staleness and never gates.

    Measuring merged *data* rather than gossip membership is deliberate. Membership
    presence is not a freshness signal: in a one-way partition the node keeps
    receiving gossip about its peers — so they stay in the memberlist — while none of
    its own traffic gets out and no peer state ever arrives. That is the case QA
    reproduced on the cluster, and the production incident looked the same (the node
    still answered on its other ports while the cluster had dropped it). A heartbeat
    that stops advancing covers it, and covers a clean two-way partition too.
    """
    age = state.get("peerStateAgeSecs")
    if isinstance(age, bool) or not isinstance(age, (int, float)):
        return None
    return max(0, int(age))


def count_visible_peers(state: dict, local_node_id: str | None) -> tuple[int, int]:
    """``(peers_in_gossip_view, peers_in_cluster)`` — reported for diagnosis only.

    The pair distinguishes a one-way partition (peers still visible, state stale)
    from a two-way one (peers gone) in the status message; neither drives the gate.
    """
    peers = {
        node.get("node_id")
        for node in state.get("clusterNodes") or []
        if node.get("node_id") and node.get("node_id") != local_node_id
    }
    visible = {
        node.get("node_id")
        for node in state.get("nodeAddrs") or []
        if node.get("node_id") and node.get("node_id") != local_node_id
        and node.get("status") in (None, "alive")
    }
    return len(peers & visible), len(peers)


def cluster_state_is_stale(state: dict, grace_secs: int) -> bool:
    """True when no peer state has been merged for longer than the grace period."""
    age = peer_state_age_secs(state)
    return age is not None and age >= grace_secs


def ready_nameserver_members(state: dict) -> set[str]:
    """Knot nodes marked ready in replicated state, ignoring gossip aliveness.

    Deliberately *not* the rendered NS set. Aliveness decays within seconds of a
    partition, so a node that keyed "am I the last nameserver" off the rendered set
    would conclude it is last long before the grace period expires — and then every
    genuinely partitioned node would exempt itself and the gate would never fire.
    ``knot_node_ready`` on a non-tombstoned member is replicated state: a partitioned
    node keeps its peers' frozen props and so knows it is not alone.
    """
    return {
        svc["node_id"]
        for svc in state.get("knotServices") or []
        if svc.get("ready") == "true" and svc.get("node_id")
    }


def is_last_ready_nameserver(state: dict, local_node_id: str | None) -> bool:
    """True when replicated state knows of no ready nameserver other than this one.

    Covers the genuine scale-down survivor and the bring-up window, where no peer has
    published readiness yet.
    """
    if not local_node_id:
        return False
    return ready_nameserver_members(state) <= {local_node_id}


# Gate decisions. `hold` keeps answering with whatever was last rendered but does not
# re-render, because a decayed view would produce worse content than the node already
# serves; `stop` takes the node off port 53 so resolvers fail over.
GATE_SERVE = "serve"
GATE_HOLD = "hold"
GATE_STOP = "stop"

# Node property carrying the last gate decision, as `<decision>:<peer state age>`
# (`age` is `-` when there is no peer to merge with).
GATE_STATE_PROPERTY = "knot_gate_state"

# Node property carrying a fingerprint of the plugin actually running on the node.
# Served DNS cannot identify a build — a stale extracted copy of the service looks
# identical from outside — so publish what is executing.
BUILD_PROPERTY = "knot_plugin_build"


def plugin_build_fingerprint() -> str:
    """Short digest of this plugin's own sources, for identifying what is running."""
    digest = hashlib.sha256()
    for name in ("main.py", "manifest.yaml"):
        path = Path(__file__).resolve().parent / name
        try:
            digest.update(path.read_bytes())
        except OSError:
            digest.update(b"?")
    return digest.hexdigest()[:12]


def gate_state_property(state: dict, decision: str) -> dict:
    age = peer_state_age_secs(state)
    return {GATE_STATE_PROPERTY: f"{decision}:{'-' if age is None else age}"}


def evaluate_serving_gate(state: dict, local_node_id: str | None) -> tuple[str, str]:
    """``(decision, detail)`` for whether this node may keep answering on port 53."""
    age = peer_state_age_secs(state)
    if age is None:
        return GATE_SERVE, "no peer to merge with"

    grace_secs = isolation_grace_secs(state)
    visible_peers, total_peers = count_visible_peers(state, local_node_id)
    detail = (
        f"no peer state merged for {age}s "
        f"({visible_peers}/{total_peers} peers still in the gossip view)"
    )

    if age == 0:
        return GATE_SERVE, f"peer state is current ({visible_peers}/{total_peers} peers visible)"
    if age < grace_secs:
        return GATE_HOLD, f"{detail}, grace {grace_secs}s"
    if is_last_ready_nameserver(state, local_node_id):
        # Going dark would take the zone down outright, which is never better than
        # serving state that may be behind: there is no healthier nameserver for a
        # resolver to fail over to.
        return GATE_HOLD, f"{detail}; kept answering as the last ready nameserver"
    return GATE_STOP, detail


# ---------------------------------------------------------------------------
# Host side effects
# ---------------------------------------------------------------------------

def get_default_output_ip() -> str | None:
    """Get source IP used by default route (egress/default-output IP)."""
    try:
        result = subprocess.run(
            ["ip", "route", "get", "8.8.8.8"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode != 0:
            return None

        # Typical output contains: "... src <ip> ..."
        parts = (result.stdout or "").strip().split()
        if "src" in parts:
            src_idx = parts.index("src")
            if src_idx + 1 < len(parts):
                return parts[src_idx + 1]
        return None
    except Exception:
        return None


def is_knot_available() -> bool:
    """Check if Knot is properly installed (binary + system user)."""
    if shutil.which("knotd") is None:
        return False
    try:
        import pwd
        pwd.getpwnam("knot")
        return True
    except KeyError:
        return False


def run_cmd(cmd, err_msg, env=None):
    """Run command and raise exception on failure."""
    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if result.returncode != 0:
        raise Exception(f"{err_msg}: {result.stderr.strip()}")
    return result


def _apt_env() -> dict:
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    # Avoid needrestart blocking dpkg configure during unattended installs.
    env.setdefault("NEEDRESTART_MODE", "a")
    return env


class _SwarmAptLock:
    """Serialize apt/dpkg on one host across concurrent service plugin inits."""

    def __init__(self, timeout_sec: int = 300) -> None:
        self._timeout_sec = timeout_sec
        self._fd: int | None = None

    def __enter__(self) -> "_SwarmAptLock":
        lock_dir = os.path.dirname(SWARM_APT_LOCK_FILE) or "/run/lock"
        os.makedirs(lock_dir, exist_ok=True)
        self._fd = os.open(SWARM_APT_LOCK_FILE, os.O_CREAT | os.O_RDWR, 0o644)
        deadline = time.time() + self._timeout_sec
        while time.time() < deadline:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except BlockingIOError:
                time.sleep(1)
        raise Exception(f"Timed out waiting for {SWARM_APT_LOCK_FILE}")

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._fd is not None:
            fcntl.flock(self._fd, fcntl.LOCK_UN)
            os.close(self._fd)
            self._fd = None


def _ubuntu_codename() -> str:
    try:
        for line in Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("VERSION_CODENAME="):
                return line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    return "noble"


def _run_apt(cmd: list[str], *, err_msg: str) -> None:
    run_cmd(cmd, err_msg, env=_apt_env())


def _knot_deb_install_targets(version: str = KNOT_VERSION) -> list[str]:
    """Pinned knot stack for CZ.NIC noble packages (knot 3.5.x)."""
    packages = ("knot", "libdnssec10", "libknot16", "libzscanner5")
    return [f"{pkg}={version}*" for pkg in packages]


def _run_apt_install(packages: list[str], *, err_msg: str) -> None:
    cmd = [
        "apt-get",
        "install",
        "-y",
        "--no-install-recommends",
        "-o",
        "Dpkg::Options::=--force-confdef",
        "-o",
        "Dpkg::Options::=--force-confold",
        *packages,
    ]
    _run_apt(cmd, err_msg=err_msg)


def disable_knot_service() -> None:
    """Stop and disable the unit so it only runs after apply enables it."""
    subprocess.run(
        ["systemctl", "disable", "--now", KNOT_SERVICE_NAME],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def stop_knot_service() -> None:
    """Stop Knot but keep the unit enabled, so a later apply/health can resume it."""
    subprocess.run(
        ["systemctl", "stop", KNOT_SERVICE_NAME],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def enable_knot_service() -> None:
    """Enable and restart Knot (apply only)."""
    enable = subprocess.run(
        ["systemctl", "enable", KNOT_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if enable.returncode != 0:
        raise Exception(f"Failed to enable {KNOT_SERVICE_NAME}: {(enable.stderr or enable.stdout or '').strip()}")

    restart = subprocess.run(
        ["systemctl", "restart", KNOT_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if restart.returncode != 0:
        raise Exception(f"Failed to start {KNOT_SERVICE_NAME}: {(restart.stderr or restart.stdout or '').strip()}")


def _ensure_knot_apt_pin(version: str = KNOT_VERSION) -> None:
    pin_body = (
        "Package: knot knot-* libdnssec* libzscanner* libknot* python3-libknot*\n"
        "Pin-Priority: 1001\n"
        f"Pin: version {version}*\n"
    )
    KNOT_APT_PIN_FILE.parent.mkdir(parents=True, exist_ok=True)
    current = (
        KNOT_APT_PIN_FILE.read_text(encoding="utf-8", errors="ignore")
        if KNOT_APT_PIN_FILE.exists()
        else ""
    )
    if current != pin_body:
        KNOT_APT_PIN_FILE.write_text(pin_body, encoding="utf-8")


def _ensure_knot_apt_repo() -> None:
    codename = _ubuntu_codename()
    expected = (
        f"deb [signed-by={KNOT_APT_KEYRING}] https://pkg.labs.nic.cz/knot-dns {codename} main\n"
    )
    if KNOT_APT_LIST.exists():
        current = KNOT_APT_LIST.read_text(encoding="utf-8", errors="ignore")
        if current == expected:
            return
    KNOT_APT_KEYRING.parent.mkdir(parents=True, exist_ok=True)
    run_cmd(
        ["curl", "-fsSL", "https://pkg.labs.nic.cz/gpg", "-o", str(KNOT_APT_KEYRING)],
        "Failed to download CZ.NIC apt keyring",
        env=_apt_env(),
    )
    KNOT_APT_LIST.write_text(expected, encoding="utf-8")


def ensure_knot_package(version: str = KNOT_VERSION) -> None:
    """Install knot via apt only when knotd / knot user is missing."""
    if is_knot_available():
        disable_knot_service()
        return

    with _SwarmAptLock():
        _ensure_knot_apt_pin(version)
        _ensure_knot_apt_repo()
        _run_apt(["apt-get", "update"], err_msg="apt-get update failed")
        install_targets = _knot_deb_install_targets(version)
        _run_apt_install(
            install_targets,
            err_msg=f"Failed to install knot packages ({' '.join(install_targets)})",
        )
        if not is_knot_available():
            raise Exception(f"knot={version} package installed but knotd is not available")
    # Package postinst may enable/start the unit; keep it off until apply.
    disable_knot_service()


def _chown_knot(path: Path) -> None:
    subprocess.run(
        ["chown", "knot:knot", str(path)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def ensure_knot_directories() -> None:
    KNOT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    KNOT_DATA_DIR.mkdir(parents=True, exist_ok=True)
    KNOT_ZONES_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "knot:knot", str(KNOT_DATA_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def zone_file_path(zone: str) -> Path:
    return KNOT_ZONES_DIR / f"{zone.rstrip('.')}.zone"


def write_if_changed(path: Path, content: str, *, owned_by_knot: bool = False) -> bool:
    """Write ``content`` only when it differs from what is on disk."""
    if path.exists():
        try:
            if path.read_text(encoding="utf-8") == content:
                return False
        except OSError:
            pass
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    if owned_by_knot:
        _chown_knot(path)
    return True


def remove_stale_zone_files(served_zones: list[str]) -> None:
    """Drop zone files this node no longer serves.

    Covers the catalog zone and the member zones Knot used to materialise from it:
    ``zones.conf`` is rendered in full, so any other ``*.zone`` file is orphaned.
    """
    expected = {zone_file_path(zone).name for zone in served_zones}
    if not KNOT_ZONES_DIR.is_dir():
        return
    for path in sorted(KNOT_ZONES_DIR.glob("*.zone")):
        if path.name in expected:
            continue
        try:
            path.unlink()
            log(f"removed stale zone file {path}")
        except OSError as e:
            log(f"could not remove {path}: {e}")


def knotc(*args: str, timeout: int = 15) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            [KNOT_CLI, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, output.strip()
    except subprocess.TimeoutExpired:
        return False, f"{KNOT_CLI} {' '.join(args)} timed out"
    except Exception as e:  # pragma: no cover - defensive
        return False, str(e)


def is_knot_running() -> tuple[bool, str | None]:
    """Check if the Knot DNS service is active. Returns (is_running, error)."""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", KNOT_SERVICE_NAME],
            capture_output=True,
            text=True,
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def wait_for_knot_ready(timeout_sec: int = 30) -> bool:
    """Wait for Knot DNS server to become ready."""
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        ok, _ = knotc("status", timeout=5)
        if ok:
            return True
        time.sleep(2)
    return False


# ---------------------------------------------------------------------------
# Plugin commands
# ---------------------------------------------------------------------------

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize Knot DNS: install packages."""
    try:
        ensure_knot_package()
        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


def refresh_gate_txt_on_disk(state: dict, local_node_id: str | None, decision: str) -> bool:
    """Rewrite only the diagnostic TXT in the cluster zone and reload it."""
    cluster_zone = resolve_cluster_zone(state)
    if not cluster_zone:
        return False
    path = zone_file_path(cluster_zone)
    if not path.exists():
        return False
    try:
        current = path.read_text(encoding="utf-8")
    except OSError:
        return False
    updated = replace_gate_txt(current, gate_txt_record(state, local_node_id, decision))
    if updated == current:
        return False
    if not write_if_changed(path, updated, owned_by_knot=True):
        return False
    ok, output = knotc("zone-reload", cluster_zone)
    if not ok:
        log(f"could not reload {cluster_zone} after refreshing the gate record: {output}")
    return ok


def ensure_knot_serving_last_rendered() -> tuple[bool, str]:
    """Start Knot on the already-rendered zones when it is down but configured.

    The hold path deliberately does not re-render — a decayed view would produce
    worse content than what is on disk — but it must still *serve*. Without this, a
    node whose Knot died (VM reboot, daemon crash, or an earlier stop by this gate)
    stays dark for the whole hold window, and because the last-ready-nameserver
    valve holds indefinitely, that window can be unbounded: the zone would never
    come back on the one node still delegated to it.

    The "never start a bare Knot" guard is kept: with no rendered configuration on
    disk there is nothing to serve, which is the fresh-boot case.
    """
    if is_knot_running()[0]:
        return True, "serving the last rendered zones"
    if not is_knot_available():
        return False, "knot is not installed yet"
    if not (KNOT_CONFIG_FILE.exists() and KNOT_ZONES_CONFIG_FILE.exists()):
        return False, "no rendered configuration on disk yet"
    log("Knot is down but the last rendered zones are on disk, starting it")
    try:
        enable_knot_service()
    except Exception as e:
        return False, f"could not start Knot: {e}"
    if not wait_for_knot_ready(timeout_sec=30):
        return False, "Knot did not become ready within timeout"
    return True, "restarted on the last rendered zones"


def legacy_property_cleanup(state: dict, local_node_id: str | None) -> tuple[dict, dict]:
    """Delete TSIG / catalog-era properties once, if they are still present."""
    cluster_properties = {
        name: None
        for name in LEGACY_CLUSTER_PROPERTIES
        if get_cluster_property(state, name) is not None
    }
    local_node_props = {
        prop.get("name")
        for prop in state.get("knotNodeProperties") or []
        if prop.get("name") and prop.get("node_id") == local_node_id
    }
    node_properties = {name: None for name in LEGACY_NODE_PROPERTIES if name in local_node_props}
    return node_properties, cluster_properties


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Render both cluster zones from SwarmDB state and reconcile the local Knot."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = dict(input_data.local_state or {})

    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    wg_props = state_json.get("wgNodeProperties") or []
    node_addrs = state_json.get("nodeAddrs") or []

    if not resolve_global_id(state_json):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for global_id to be set in SwarmIdPointer table',
            local_state=local_state,
        )

    if not resolve_base_domain(state_json):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for base_domain to be set in SwarmSecrets',
            local_state=local_state,
        )

    # Only this node's tunnel IP matters — it is a listen address. Peer tunnel IPs
    # are not used anywhere any more (no remotes, no transfers), so a peer that is
    # missing its WireGuard property must not block rendering on this node.
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on this node',
            local_state=local_state,
        )

    if not is_knot_available():
        return PluginOutput(
            status='postponed',
            error_message='Waiting for knot package install (init)',
            local_state=local_state,
        )

    # A node whose merged state has gone stale must not re-render zones from it: it
    # keeps serving the last rendered content until the grace period expires, then
    # stops answering so resolvers fail over to the healthy delegated NS.
    decision, detail = evaluate_serving_gate(state_json, local_node_id)
    if decision == GATE_STOP:
        stop_knot_service()
        return PluginOutput(
            status='postponed',
            error_message=f'Node isolated from the cluster: {detail}; Knot stopped',
            node_properties=gate_state_property(state_json, decision),
            local_state=local_state,
        )
    if decision == GATE_HOLD:
        _serving, serving_detail = ensure_knot_serving_last_rendered()
        refresh_gate_txt_on_disk(state_json, local_node_id, decision)
        return PluginOutput(
            status='postponed',
            error_message=(
                f'Cluster state is stale: {detail}; keeping the last rendered zones '
                f'({serving_detail})'
            ),
            node_properties=gate_state_property(state_json, decision),
            local_state=local_state,
        )

    zone_files = build_zone_files(state_json, local_node_id)
    if not zone_files:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for a knot node with an alive public address',
            local_state=local_state,
        )

    try:
        ensure_knot_directories()
        changed_zones = [
            zone for zone, content in sorted(zone_files.items())
            if write_if_changed(zone_file_path(zone), content, owned_by_knot=True)
        ]
        # zones.conf first: knot.conf includes it and Knot refuses to start without it.
        zones_config_changed = write_if_changed(
            KNOT_ZONES_CONFIG_FILE,
            render_zones_config(list(zone_files)),
        )
        config_changed = write_if_changed(
            KNOT_CONFIG_FILE,
            render_knot_config(
                compute_listen_addresses(
                    local_node_id,
                    local_tunnel_ip,
                    node_addrs,
                    get_default_output_ip(),
                )
            ),
        )
        remove_stale_zone_files(list(zone_files))
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to write Knot configuration: {e}',
            local_state=local_state,
        )

    knot_running, _ = is_knot_running()

    if not knot_running or config_changed or zones_config_changed:
        reason = 'not running' if not knot_running else 'configuration changed'
        log(f"restarting Knot ({reason})")
        try:
            enable_knot_service()
        except Exception as e:
            return PluginOutput(status='error', error_message=f'Failed to start Knot: {e}', local_state=local_state)
        if not wait_for_knot_ready(timeout_sec=30):
            return PluginOutput(
                status='postponed',
                error_message='Knot DNS did not become ready within timeout',
                local_state=local_state,
            )
    elif changed_zones:
        for zone in changed_zones:
            ok, output = knotc("zone-reload", zone)
            if not ok:
                return PluginOutput(
                    status='postponed',
                    error_message=f'Failed to reload zone {zone}: {output}',
                    local_state=local_state,
                )
            log(f"reloaded zone {zone}")
    else:
        log("zones and configuration unchanged, nothing to reload")

    node_properties, cluster_properties = legacy_property_cleanup(state_json, local_node_id)
    node_properties["knot_node_ready"] = "true"
    node_properties[BUILD_PROPERTY] = plugin_build_fingerprint()
    node_properties.update(gate_state_property(state_json, decision))

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        cluster_properties=cluster_properties or None,
        local_state=local_state,
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check Knot health and gate serving on a fresh view of the cluster."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = dict(input_data.local_state or {})

    decision, detail = evaluate_serving_gate(state_json, local_node_id)
    if decision == GATE_STOP:
        if is_knot_running()[0]:
            log(f"{detail}, stopping Knot")
            stop_knot_service()
        return PluginOutput(
            status='postponed',
            error_message=f'Node isolated from the cluster: {detail}; Knot stopped so resolvers fail over',
            node_properties=gate_state_property(state_json, decision),
            local_state=local_state,
        )
    if decision == GATE_HOLD:
        _serving, serving_detail = ensure_knot_serving_last_rendered()
        return PluginOutput(
            status='postponed',
            error_message=f'Cluster state is stale: {detail} ({serving_detail})',
            node_properties=gate_state_property(state_json, decision),
            local_state=local_state,
        )

    knot_running, knot_error = is_knot_running()
    if not knot_running:
        # The cluster state is fresh again: resume serving if the gate had stopped us.
        # Only when apply already rendered a configuration — never start a bare Knot.
        if is_knot_available() and KNOT_CONFIG_FILE.exists() and KNOT_ZONES_CONFIG_FILE.exists():
            log("cluster state is fresh again, starting Knot")
            try:
                enable_knot_service()
            except Exception as e:
                return PluginOutput(status='error', error_message=f'Failed to start Knot: {e}', local_state=local_state)
            knot_running = wait_for_knot_ready(timeout_sec=30)
        if not knot_running:
            return PluginOutput(
                status='postponed',
                error_message=knot_error or 'Knot service is not running',
                local_state=local_state,
            )

    ok, output = knotc("status", timeout=5)
    if not ok:
        return PluginOutput(
            status='postponed',
            error_message=f'Knot is not responding: {output}',
            local_state=local_state,
        )

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Stop answering before this node leaves the cluster."""
    local_state = dict(input_data.local_state or {})
    stop_knot_service()
    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy Knot DNS installation and clean up."""
    try:
        disable_knot_service()

        if KNOT_CONFIG_DIR.exists():
            shutil.rmtree(KNOT_CONFIG_DIR, ignore_errors=True)
        if KNOT_DATA_DIR.exists():
            shutil.rmtree(KNOT_DATA_DIR, ignore_errors=True)

        node_properties = {
            "knot_node_ready": None,
            "knot_cluster_initialized": None,
            GATE_STATE_PROPERTY: None,
            BUILD_PROPERTY: None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy Knot DNS: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
