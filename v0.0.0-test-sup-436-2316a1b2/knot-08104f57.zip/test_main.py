#!/usr/bin/env python3
"""Unit tests for the knot plugin's zone renderer and cluster-state gating.

Run from the repository root:

    python3 -m unittest discover -s services/knot -p 'test_main.py' -v
"""

import copy
import importlib.util
import json
import random
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
import unittest.mock
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover - the manifest tests skip without it
    yaml = None

HERE = Path(__file__).resolve().parent
SDK_DIR = HERE.parents[1] / "provision-plugin-sdk"

for path in (str(HERE), str(SDK_DIR)):
    if path not in sys.path:
        sys.path.insert(0, path)

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402  (import after the SDK stub is installed)


def _load_dns_manager():
    """Load the dns-manager plugin module so both NS mappings can be compared."""
    mod_path = HERE.parent / "dns-manager" / "main.py"
    spec = importlib.util.spec_from_file_location("dns_manager_main", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


BASE_DOMAIN = "example.test"
GLOBAL_ID = "gid1"
CLUSTER_ZONE = f"{GLOBAL_ID}.{BASE_DOMAIN}"
DYN_ZONE = f"dyn.{CLUSTER_ZONE}"


def make_state(**overrides) -> dict:
    """A three-node cluster where node-1 and node-2 serve DNS."""
    state = {
        "clusterNodes": [
            {"id": "knot-c:node-1", "node_id": "node-1", "cluster": "knot-c"},
            {"id": "knot-c:node-2", "node_id": "node-2", "cluster": "knot-c"},
            {"id": "knot-c:node-3", "node_id": "node-3", "cluster": "knot-c"},
        ],
        "knotNodeProperties": [
            {"cluster_node": "knot-c:node-1", "name": "knot_node_ready", "value": "true", "node_id": "node-1"},
            {"cluster_node": "knot-c:node-2", "name": "knot_node_ready", "value": "true", "node_id": "node-2"},
        ],
        "clusterProperties": [],
        "wgNodeProperties": [
            {"name": "tunnel_ip", "value": "10.9.0.1", "node_id": "node-1"},
            {"name": "tunnel_ip", "value": "10.9.0.2", "node_id": "node-2"},
            {"name": "tunnel_ip", "value": "10.9.0.3", "node_id": "node-3"},
        ],
        "nodeAddrs": [
            {"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"},
            {"node_id": "node-2", "addr": "203.0.113.2", "port": 7946, "status": "alive"},
            {"node_id": "node-3", "addr": "203.0.113.3", "port": 7946, "status": "alive"},
        ],
        "knotServices": [
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "true", "external_ip": "203.0.113.2"},
            {"node_id": "node-3", "ready": None, "external_ip": "203.0.113.3"},
        ],
        "openrestyServices": [
            {"node_id": "node-2", "ready": "true", "external_ip": "203.0.113.2"},
        ],
        "authServiceNodes": [{"node_id": "node-1", "ready": "true"}],
        "swarmCloudApiNodes": [{"node_id": "node-1", "ready": "true"}],
        "swarmCloudUiNodes": [{"node_id": "node-1", "ready": "true"}],
        "swarmGatekeeperS3Nodes": [{"node_id": "node-1", "ready": "true"}],
        "swarmGatekeeperHarborNodes": [{"node_id": "node-3", "ready": None}],
        "k8sNodes": [
            {"node_id": "node-1", "ready": "true", "k8s_external_hostname": f"k8s.{CLUSTER_ZONE}"},
        ],
        "swarmSecrets": [{"id": "base_domain", "value": BASE_DOMAIN}],
        "globalId": GLOBAL_ID,
        "swarmDomain": f"app.{CLUSTER_ZONE}",
        "pkiDomain": f"ca.{CLUSTER_ZONE}",
        "localNodeId": "node-1",
        "peerStateAgeSecs": 0,
    }
    state.update(overrides)
    return state


def shuffled_state(state: dict, seed: int) -> dict:
    """Same state with every list shuffled — SwarmDB row order must not matter."""
    rng = random.Random(seed)
    out = copy.deepcopy(state)
    for key, value in out.items():
        if isinstance(value, list):
            rng.shuffle(value)
    return out


class NsSetTests(unittest.TestCase):
    def test_only_ready_nodes_with_an_alive_address_become_ns(self):
        entries = main.compute_ns_entries(make_state(), "node-1")
        self.assertEqual(
            dict(entries),
            {
                main.node_id_to_ns_name("node-1"): "203.0.113.1",
                main.node_id_to_ns_name("node-2"): "203.0.113.2",
            },
        )

    def test_ns_set_is_sorted_and_order_independent(self):
        state = make_state()
        expected = main.compute_ns_entries(state, "node-1")
        self.assertEqual(expected, sorted(expected))
        for seed in range(5):
            self.assertEqual(main.compute_ns_entries(shuffled_state(state, seed), "node-1"), expected)

    def test_node_that_left_the_gossip_view_drops_out(self):
        # node-2 is still `knot_node_ready` in SwarmDB but no longer alive, so the
        # jq projection yields no external_ip for it (mirrors the parent delegation).
        state = make_state(knotServices=[
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "true", "external_ip": None},
        ])
        self.assertEqual(
            dict(main.compute_ns_entries(state, "node-1")),
            {main.node_id_to_ns_name("node-1"): "203.0.113.1"},
        )

    def test_added_node_appears_once_it_is_ready(self):
        state = make_state()
        before = main.compute_ns_entries(state, "node-1")
        state["knotServices"].append(
            {"node_id": "node-4", "ready": "true", "external_ip": "203.0.113.4"}
        )
        after = main.compute_ns_entries(state, "node-1")
        self.assertEqual(len(after), len(before) + 1)
        self.assertEqual(dict(after)[main.node_id_to_ns_name("node-4")], "203.0.113.4")

    def test_bootstrap_falls_back_to_the_local_node(self):
        state = make_state(knotServices=[], knotNodeProperties=[])
        self.assertEqual(
            dict(main.compute_ns_entries(state, "node-1")),
            {main.node_id_to_ns_name("node-1"): "203.0.113.1"},
        )

    def test_no_ns_without_any_alive_address(self):
        state = make_state(knotServices=[], nodeAddrs=[])
        self.assertEqual(main.compute_ns_entries(state, "node-1"), [])

    def test_ns_label_matches_the_dns_manager_delegation(self):
        dns_manager = _load_dns_manager()
        for node_id in ("node-1", "azure-test-node-2-gz4k", "x", ""):
            self.assertEqual(main.node_id_to_ns_name(node_id), dns_manager.node_id_to_ns_name(node_id))


class ZoneRenderingTests(unittest.TestCase):
    def test_every_node_renders_byte_identical_zones(self):
        state = make_state()
        rendered_by_node_1 = main.build_zone_files(state, "node-1")
        rendered_by_node_2 = main.build_zone_files(shuffled_state(state, 7), "node-2")
        rendered_by_node_3 = main.build_zone_files(shuffled_state(state, 11), "node-3")
        self.assertEqual(rendered_by_node_1, rendered_by_node_2)
        self.assertEqual(rendered_by_node_1, rendered_by_node_3)

    def test_both_cluster_zones_are_rendered(self):
        zones = main.build_zone_files(make_state(), "node-1")
        self.assertEqual(sorted(zones), sorted([CLUSTER_ZONE, DYN_ZONE]))

    def test_serial_changes_with_content_and_is_stable_otherwise(self):
        state = make_state()
        first = main.build_zone_files(state, "node-1")[DYN_ZONE]
        again = main.build_zone_files(state, "node-1")[DYN_ZONE]
        self.assertEqual(first, again)

        state["openrestyServices"] = [
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
        ]
        after_failover = main.build_zone_files(state, "node-1")[DYN_ZONE]
        self.assertNotEqual(_soa_serial(first), _soa_serial(after_failover))

    def test_serial_is_a_32_bit_positive_integer(self):
        for zone in main.build_zone_files(make_state(), "node-1").values():
            serial = _soa_serial(zone)
            self.assertGreater(serial, 0)
            self.assertLess(serial, 2 ** 32)

    def test_apex_ns_and_glue_are_present_in_both_zones(self):
        zones = main.build_zone_files(make_state(), "node-1")
        ns1 = main.node_id_to_ns_name("node-1")
        ns2 = main.node_id_to_ns_name("node-2")
        self.assertIn(f"@\t300\tIN\tNS\t{ns1}.{CLUSTER_ZONE}.", zones[CLUSTER_ZONE])
        self.assertIn(f"@\t300\tIN\tNS\t{ns2}.{CLUSTER_ZONE}.", zones[CLUSTER_ZONE])
        self.assertIn(f"{ns1}\t300\tIN\tA\t203.0.113.1", zones[CLUSTER_ZONE])
        self.assertIn(f"@\t300\tIN\tNS\t{ns1}.{DYN_ZONE}.", zones[DYN_ZONE])
        self.assertIn(f"{ns2}\t300\tIN\tA\t203.0.113.2", zones[DYN_ZONE])

    def test_dyn_child_zone_is_delegated_inside_the_cluster_zone(self):
        # Without this cut, gw.dyn.<zone> belongs to <zone>'s own namespace and Knot
        # answers NXDOMAIN for every service CNAME that targets it.
        zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        for node_id, ip in (("node-1", "203.0.113.1"), ("node-2", "203.0.113.2")):
            ns = main.node_id_to_ns_name(node_id)
            self.assertIn(f"dyn\t300\tIN\tNS\t{ns}.{DYN_ZONE}.", zone)
            self.assertIn(f"{ns}.dyn\t300\tIN\tA\t{ip}", zone)

    def test_service_record_never_shadows_the_dyn_delegation(self):
        state = make_state(swarmDomain=f"dyn.{CLUSTER_ZONE}")
        zone = main.build_zone_files(state, "node-1")[CLUSTER_ZONE]
        self.assertNotIn("dyn\t300\tIN\tCNAME", zone)

    def test_gw_dyn_a_records_come_from_ready_openresty_nodes(self):
        state = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "true", "external_ip": "203.0.113.2"},
            {"node_id": "node-3", "ready": "false", "external_ip": "203.0.113.3"},
        ])
        dyn = main.build_zone_files(state, "node-1")[DYN_ZONE]
        self.assertIn("gw\t300\tIN\tA\t203.0.113.1", dyn)
        self.assertIn("gw\t300\tIN\tA\t203.0.113.2", dyn)
        self.assertNotIn("203.0.113.3", dyn)

    def test_service_cnames_point_at_the_dynamic_gateway(self):
        cluster_zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        for prefix in ("auth", "api", "app", "gatekeeper-s3"):
            self.assertIn(f"{prefix}\t300\tIN\tCNAME\tgw.{DYN_ZONE}.", cluster_zone)
        # harbor gatekeeper has no ready node in the fixture
        self.assertNotIn("gatekeeper-harbor\t", cluster_zone)

    def test_pki_and_k8s_hostnames_inside_the_zone_are_rendered(self):
        cluster_zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        self.assertIn(f"ca\t300\tIN\tCNAME\tgw.{DYN_ZONE}.", cluster_zone)
        self.assertIn(f"k8s\t300\tIN\tCNAME\tgw.{DYN_ZONE}.", cluster_zone)

    def test_hostnames_outside_the_zone_are_left_to_the_parent_zone(self):
        state = make_state(pkiDomain="ca.elsewhere.test", k8sNodes=[
            {"node_id": "node-1", "ready": "true", "k8s_external_hostname": "k8s.elsewhere.test"},
        ])
        cluster_zone = main.build_zone_files(state, "node-1")[CLUSTER_ZONE]
        self.assertNotIn("elsewhere.test", cluster_zone)

    def test_custom_gateway_mode_renders_a_records_instead_of_cnames(self):
        state = make_state(swarmSecrets=[
            {"id": "base_domain", "value": BASE_DOMAIN},
            {"id": "gateway_hostname", "value": "gw.customer.example"},
        ])
        cluster_zone = main.build_zone_files(state, "node-1")[CLUSTER_ZONE]
        self.assertIn("app\t300\tIN\tA\t203.0.113.2", cluster_zone)
        self.assertNotIn("CNAME", cluster_zone)

    def test_negative_ttl_is_short_and_record_ttl_is_300(self):
        self.assertEqual(main.SOA_MINIMUM, 60)
        self.assertEqual(main.RECORD_TTL, 300)
        zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        self.assertIn("$TTL 300", zone)
        self.assertIn(" 604800 60 )", zone)

    def test_zone_file_has_exactly_one_soa_and_an_origin(self):
        for name, zone in main.build_zone_files(make_state(), "node-1").items():
            self.assertEqual(zone.count("\tSOA\t"), 1, name)
            self.assertIn(f"$ORIGIN {name}.", zone)

    def test_primary_ns_in_soa_is_the_first_apex_ns(self):
        zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        expected = sorted([main.node_id_to_ns_name("node-1"), main.node_id_to_ns_name("node-2")])[0]
        self.assertIn(f"SOA\t{expected}.{CLUSTER_ZONE}. hostmaster.{CLUSTER_ZONE}.", zone)

    def test_service_record_never_shadows_an_ns_owner(self):
        ns_label = main.node_id_to_ns_name("node-1")
        state = make_state(k8sNodes=[
            {"node_id": "node-1", "ready": "true", "k8s_external_hostname": f"{ns_label}.{CLUSTER_ZONE}"},
        ])
        zone = main.build_zone_files(state, "node-1")[CLUSTER_ZONE]
        self.assertNotIn(f"{ns_label}\t300\tIN\tCNAME", zone)
        self.assertIn(f"{ns_label}\t300\tIN\tA\t203.0.113.1", zone)

    def test_no_zones_without_global_id_or_base_domain(self):
        self.assertEqual(main.build_zone_files(make_state(globalId=None), "node-1"), {})
        self.assertEqual(main.build_zone_files(make_state(swarmSecrets=[]), "node-1"), {})

    def test_rendering_a_zone_without_ns_is_refused(self):
        with self.assertRaises(ValueError):
            main.render_zone_file(CLUSTER_ZONE, [], [])


class KnotConfigTests(unittest.TestCase):
    def test_config_has_no_replication_remnants(self):
        config = main.render_knot_config(["10.9.0.1", "127.0.0.1", "203.0.113.1"])
        directives = "\n".join(
            line for line in config.lower().splitlines() if not line.strip().startswith("#")
        )
        for remnant in ("key:", "tsig", "remote:", "catalog", "master:", "acl:", "notify"):
            self.assertNotIn(remnant, directives, remnant)

    def test_config_declares_a_single_leader_agnostic_template(self):
        config = main.render_knot_config(["10.9.0.1"])
        self.assertIn("zonefile-load: difference-no-serial", config)
        self.assertIn("journal-content: all", config)
        self.assertEqual(config.count("- id: default"), 1)
        self.assertIn(f"include: {main.KNOT_ZONES_CONFIG_FILE}", config)

    def test_config_depends_only_on_the_listen_addresses(self):
        self.assertEqual(
            main.render_knot_config(["10.9.0.1", "127.0.0.1"]),
            main.render_knot_config(["10.9.0.1", "127.0.0.1"]),
        )
        self.assertNotEqual(
            main.render_knot_config(["10.9.0.1"]),
            main.render_knot_config(["10.9.0.2"]),
        )

    def test_listen_addresses_cover_tunnel_loopback_and_public_ip(self):
        state = make_state()
        listen = main.compute_listen_addresses("node-1", "10.9.0.1", state["nodeAddrs"], "203.0.113.1")
        self.assertEqual(listen, ["10.9.0.1", "127.0.0.1", "203.0.113.1"])

    def test_listen_addresses_add_a_distinct_egress_ip(self):
        state = make_state()
        listen = main.compute_listen_addresses("node-1", "10.9.0.1", state["nodeAddrs"], "10.13.94.91")
        self.assertEqual(listen, ["10.9.0.1", "127.0.0.1", "203.0.113.1", "10.13.94.91"])

    def test_zones_config_lists_both_zones_with_the_default_template(self):
        zones_config = main.render_zones_config([DYN_ZONE, CLUSTER_ZONE])
        self.assertIn(f"  - domain: {CLUSTER_ZONE}\n    template: default", zones_config)
        self.assertIn(f"  - domain: {DYN_ZONE}\n    template: default", zones_config)
        self.assertEqual(zones_config, main.render_zones_config([CLUSTER_ZONE, DYN_ZONE]))


class ClusterStateFreshnessTests(unittest.TestCase):
    """The gate keys off merged peer state, not gossip membership (SUP-327 QA FAIL)."""

    def test_fresh_state_is_not_stale(self):
        self.assertEqual(main.peer_state_age_secs(make_state()), 0)
        self.assertFalse(main.cluster_state_is_stale(make_state(), 60))

    def test_stale_state_past_the_grace_period_gates(self):
        self.assertTrue(main.cluster_state_is_stale(make_state(peerStateAgeSecs=60), 60))
        self.assertTrue(main.cluster_state_is_stale(make_state(peerStateAgeSecs=660), 60))

    def test_the_default_grace_tolerates_a_cluster_wide_propagation_stall(self):
        # QA measured a ~4.5 min stall during leader loss that gated a healthy node.
        self.assertGreaterEqual(main.DEFAULT_ISOLATION_GRACE_SECS, 300)

    def test_stale_state_within_the_grace_period_does_not_gate_yet(self):
        self.assertFalse(main.cluster_state_is_stale(make_state(peerStateAgeSecs=30), 60))

    def test_a_single_node_cluster_never_gates(self):
        # No peer has ever written a heartbeat: null, which is not staleness.
        self.assertIsNone(main.peer_state_age_secs(make_state(peerStateAgeSecs=None)))
        self.assertFalse(main.cluster_state_is_stale(make_state(peerStateAgeSecs=None), 60))
        self.assertFalse(main.cluster_state_is_stale(make_state(peerStateAgeSecs=None), 1))

    def test_a_missing_or_malformed_age_never_gates(self):
        for value in ({}, {"peerStateAgeSecs": "soon"}, {"peerStateAgeSecs": True}, {"peerStateAgeSecs": None}):
            state = make_state(**value) if value else make_state(peerStateAgeSecs=None)
            if value == {}:
                state = make_state()
                state.pop("peerStateAgeSecs")
            self.assertIsNone(main.peer_state_age_secs(state), value)
            self.assertFalse(main.cluster_state_is_stale(state, 60), value)

    def test_negative_age_is_clamped(self):
        self.assertEqual(main.peer_state_age_secs(make_state(peerStateAgeSecs=-5)), 0)

    def test_peers_visible_in_gossip_do_not_keep_a_stale_node_serving(self):
        # The one-way partition QA reproduced: peers still in the gossip view, but
        # no state arriving. Membership presence must not veto the gate.
        state = make_state(peerStateAgeSecs=660)
        self.assertEqual(main.count_visible_peers(state, "node-1"), (2, 2))
        self.assertTrue(main.cluster_state_is_stale(state, 60))

    def test_visible_peer_counts_are_reported_for_diagnosis(self):
        self.assertEqual(main.count_visible_peers(make_state(), "node-1"), (2, 2))
        two_way = make_state(nodeAddrs=[
            {"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"},
        ])
        self.assertEqual(main.count_visible_peers(two_way, "node-1"), (0, 2))
        dead_peer = make_state(nodeAddrs=[
            {"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"},
            {"node_id": "node-2", "addr": "203.0.113.2", "port": 7946, "status": "failed"},
        ])
        self.assertEqual(main.count_visible_peers(dead_peer, "node-1"), (0, 2))

    def test_grace_period_defaults_and_is_configurable_per_cluster(self):
        self.assertEqual(main.isolation_grace_secs(make_state()), main.DEFAULT_ISOLATION_GRACE_SECS)
        state = make_state(clusterProperties=[
            {"cluster": "knot-c", "name": "knot_isolation_grace_secs", "value": "180"},
        ])
        self.assertEqual(main.isolation_grace_secs(state), 180)

    def test_invalid_grace_period_falls_back_to_the_default(self):
        for value in ("", "0", "-5", "soon"):
            state = make_state(clusterProperties=[
                {"cluster": "knot-c", "name": "knot_isolation_grace_secs", "value": value},
            ])
            self.assertEqual(main.isolation_grace_secs(state), main.DEFAULT_ISOLATION_GRACE_SECS)

    def test_default_grace_is_a_whole_number_of_signal_buckets(self):
        # The manifest reports the age floored to the bucket width, so a grace that
        # is not a multiple of it would fire a bucket later than configured.
        self.assertEqual(main.DEFAULT_ISOLATION_GRACE_SECS % main.PEER_STATE_AGE_BUCKET_SECS, 0)


class ServingGateTests(unittest.TestCase):
    """The one decision both handlers share."""

    def test_current_state_serves(self):
        decision, _ = main.evaluate_serving_gate(make_state(), "node-1")
        self.assertEqual(decision, main.GATE_SERVE)

    def test_no_peer_to_merge_with_serves(self):
        decision, detail = main.evaluate_serving_gate(make_state(peerStateAgeSecs=None), "node-1")
        self.assertEqual(decision, main.GATE_SERVE)
        self.assertIn("no peer", detail)

    def test_staleness_within_grace_holds(self):
        decision, _ = main.evaluate_serving_gate(
            make_state(peerStateAgeSecs=main.PEER_STATE_AGE_BUCKET_SECS), "node-1"
        )
        self.assertEqual(decision, main.GATE_HOLD)

    def test_staleness_past_grace_stops(self):
        decision, detail = main.evaluate_serving_gate(
            make_state(peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS), "node-1"
        )
        self.assertEqual(decision, main.GATE_STOP)
        self.assertIn("no peer state merged", detail)

    def test_a_partitioned_node_stops_even_though_its_peers_look_unreachable(self):
        # The regression this valve originally introduced: gossip aliveness decays
        # within seconds of a partition, so a valve keyed off the rendered NS set made
        # every genuinely partitioned node exempt itself and AC 5 never fired. Peers
        # stay ready in replicated state, so the node knows it is not the last one.
        state = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 2,
            knotServices=[
                {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
                {"node_id": "node-2", "ready": "true", "external_ip": None},
                {"node_id": "node-3", "ready": "true", "external_ip": None},
            ],
            nodeAddrs=[{"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"}],
        )
        self.assertEqual(main.compute_ns_entries(state, "node-1"),
                         [(main.node_id_to_ns_name("node-1"), "203.0.113.1")],
                         "the rendered NS set does decay to just this node")
        self.assertFalse(main.is_last_ready_nameserver(state, "node-1"))
        self.assertEqual(main.evaluate_serving_gate(state, "node-1")[0], main.GATE_STOP)

    def test_a_true_scale_down_survivor_never_goes_dark(self):
        # Peers tombstoned, so they are gone from replicated state entirely. Going
        # dark would take the zone down outright.
        state = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10,
            knotServices=[{"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"}],
        )
        self.assertTrue(main.is_last_ready_nameserver(state, "node-1"))
        decision, detail = main.evaluate_serving_gate(state, "node-1")
        self.assertEqual(decision, main.GATE_HOLD)
        self.assertIn("last ready nameserver", detail)

    def test_the_valve_ignores_aliveness(self):
        # Same ready set, peer merely not alive: still not the last ready nameserver.
        state = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10,
            knotServices=[
                {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
                {"node_id": "node-2", "ready": "true", "external_ip": None},
            ],
        )
        self.assertEqual(main.ready_nameserver_members(state), {"node-1", "node-2"})
        self.assertFalse(main.is_last_ready_nameserver(state, "node-1"))
        self.assertEqual(main.evaluate_serving_gate(state, "node-1")[0], main.GATE_STOP)

    def test_the_valve_does_not_apply_when_the_sole_ready_nameserver_is_someone_else(self):
        state = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10,
            knotServices=[{"node_id": "node-2", "ready": "true", "external_ip": "203.0.113.2"}],
        )
        self.assertFalse(main.is_last_ready_nameserver(state, "node-1"))
        self.assertEqual(main.evaluate_serving_gate(state, "node-1")[0], main.GATE_STOP)

    def test_a_node_whose_peers_are_not_ready_yet_keeps_serving(self):
        # Knot placed on one node, or the bring-up window before peers publish
        # readiness: nothing to fail over to.
        for services in ([], [{"node_id": "node-2", "ready": None, "external_ip": "203.0.113.2"}]):
            state = make_state(
                peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10,
                knotServices=services,
                knotNodeProperties=[],
            )
            self.assertTrue(main.is_last_ready_nameserver(state, "node-1"), services)
            self.assertEqual(main.evaluate_serving_gate(state, "node-1")[0], main.GATE_HOLD, services)

    def test_the_valve_needs_a_local_node_id(self):
        state = make_state(peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10, knotServices=[])
        self.assertFalse(main.is_last_ready_nameserver(state, None))


class GateObservabilityTests(unittest.TestCase):
    """The gate decision and the running build must be readable without a shell."""

    def test_the_property_carries_the_decision_and_its_input(self):
        self.assertEqual(
            main.gate_state_property(make_state(peerStateAgeSecs=900), main.GATE_STOP),
            {"knot_gate_state": "stop:900"},
        )
        self.assertEqual(
            main.gate_state_property(make_state(), main.GATE_SERVE),
            {"knot_gate_state": "serve:0"},
        )

    def test_no_peer_to_merge_with_is_distinguishable_from_zero(self):
        # `serve:-` and `serve:0` mean different things: no peer at all versus a peer
        # whose state is current. Collapsing them would hide the case where the gate
        # is never consulted.
        self.assertEqual(
            main.gate_state_property(make_state(peerStateAgeSecs=None), main.GATE_SERVE),
            {"knot_gate_state": "serve:-"},
        )

    def test_the_build_fingerprint_is_stable_and_short(self):
        first = main.plugin_build_fingerprint()
        self.assertEqual(first, main.plugin_build_fingerprint())
        self.assertEqual(len(first), 12)
        self.assertTrue(all(c in "0123456789abcdef" for c in first))

    def test_destroy_clears_both_diagnostic_properties(self):
        out = main.handle_destroy(main.PluginInput(command="destroy", local_state={}))
        self.assertIsNone(out.node_properties[main.GATE_STATE_PROPERTY])
        self.assertIsNone(out.node_properties[main.BUILD_PROPERTY])


class GateBreadcrumbTests(unittest.TestCase):
    """The TXT record is the only gate read-out available on a node with no shell."""

    def test_the_record_carries_decision_input_and_build(self):
        record = main.gate_txt_record(make_state(peerStateAgeSecs=120), "node-1", main.GATE_HOLD)
        self.assertTrue(record.startswith(f"{main.GATE_TXT_LABEL}\t"))
        self.assertIn("gate=hold", record)
        self.assertIn("age=120", record)
        self.assertIn(f"grace={main.DEFAULT_ISOLATION_GRACE_SECS}", record)
        self.assertIn("ready=2", record)
        self.assertIn(f"build={main.plugin_build_fingerprint()}", record)

    def test_no_peer_to_merge_with_is_distinguishable(self):
        record = main.gate_txt_record(make_state(peerStateAgeSecs=None), "node-1", main.GATE_SERVE)
        self.assertIn("age=-", record)

    def test_the_record_is_in_the_cluster_zone_with_a_short_ttl(self):
        zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        line = next(l for l in zone.splitlines() if l.startswith(main.GATE_TXT_LABEL))
        self.assertEqual(line.split("\t")[1], str(main.GATE_TXT_TTL))
        self.assertLessEqual(main.GATE_TXT_TTL, 60, "must not be cached for long")

    def test_the_breadcrumb_does_not_break_byte_identical_zones(self):
        # Every field is a function of shared state plus the plugin build, so nodes
        # that converged on the same state still render identical zones — AC 1 holds
        # unchanged, and no comparison needs to exclude this record.
        node_1 = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        node_2 = main.build_zone_files(make_state(), "node-2")[CLUSTER_ZONE]
        self.assertEqual(node_1, node_2)

    def test_the_breadcrumb_diverges_exactly_when_the_nodes_views_diverge(self):
        fresh = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        stale = main.build_zone_files(make_state(peerStateAgeSecs=120), "node-1")[CLUSTER_ZONE]
        self.assertIn("gate=serve age=0", fresh)
        self.assertIn("gate=hold age=120", stale)
        self.assertEqual(_without_gate_txt(fresh), _without_gate_txt(stale),
                         "only the breadcrumb reacts to staleness, not the records")

    def test_replacing_the_record_leaves_every_other_line(self):
        zone = main.build_zone_files(make_state(), "node-1")[CLUSTER_ZONE]
        swapped = main.replace_gate_txt(zone, main.gate_txt_record(
            make_state(peerStateAgeSecs=600), "node-1", main.GATE_STOP))
        self.assertIn("gate=stop age=600", swapped)
        self.assertEqual(_without_gate_txt(swapped), _without_gate_txt(zone))

    def test_replacing_is_a_no_op_on_a_zone_without_the_record(self):
        self.assertEqual(main.replace_gate_txt("@\t300\tIN\tNS\tx.\n", "ignored"),
                         "@\t300\tIN\tNS\tx.\n")


class LegacyCleanupTests(unittest.TestCase):
    def test_tsig_cluster_properties_are_deleted_when_still_present(self):
        state = make_state(clusterProperties=[
            {"cluster": "knot-c", "name": "knot_tsig_key_name", "value": "swarm-update-key."},
            {"cluster": "knot-c", "name": "knot_tsig_key_secret", "value": "c2VjcmV0"},
        ])
        node_props, cluster_props = main.legacy_property_cleanup(state, "node-1")
        self.assertEqual(cluster_props, {"knot_tsig_key_name": None, "knot_tsig_key_secret": None})
        self.assertEqual(node_props, {})

    def test_nothing_is_deleted_once_the_cluster_is_clean(self):
        self.assertEqual(main.legacy_property_cleanup(make_state(), "node-1"), ({}, {}))

    def test_cluster_initialized_is_deleted_only_for_the_local_node(self):
        state = make_state(knotNodeProperties=[
            {"cluster_node": "knot-c:node-2", "name": "knot_cluster_initialized", "value": "true", "node_id": "node-2"},
        ])
        self.assertEqual(main.legacy_property_cleanup(state, "node-1")[0], {})
        self.assertEqual(
            main.legacy_property_cleanup(state, "node-2")[0],
            {"knot_cluster_initialized": None},
        )


class ZoneHelperTests(unittest.TestCase):
    def test_is_in_zone_excludes_the_apex_and_foreign_names(self):
        self.assertTrue(main.is_in_zone(f"app.{CLUSTER_ZONE}", CLUSTER_ZONE))
        self.assertTrue(main.is_in_zone(f"a.b.{CLUSTER_ZONE}.", CLUSTER_ZONE))
        self.assertFalse(main.is_in_zone(CLUSTER_ZONE, CLUSTER_ZONE))
        self.assertFalse(main.is_in_zone(f"x{CLUSTER_ZONE}", CLUSTER_ZONE))
        self.assertFalse(main.is_in_zone("app.other.test", CLUSTER_ZONE))

    def test_relative_owner_strips_the_zone_suffix(self):
        self.assertEqual(main.relative_owner(f"app.{CLUSTER_ZONE}", CLUSTER_ZONE), "app")
        self.assertEqual(main.relative_owner(f"a.b.{CLUSTER_ZONE}.", CLUSTER_ZONE), "a.b")
        self.assertIsNone(main.relative_owner(CLUSTER_ZONE, CLUSTER_ZONE))

    def test_get_node_addr_ignores_nodes_that_are_not_alive(self):
        addrs = [{"node_id": "node-2", "addr": "203.0.113.2", "status": "failed"}]
        self.assertIsNone(main.get_node_addr("node-2", addrs))
        addrs[0]["status"] = "alive"
        self.assertEqual(main.get_node_addr("node-2", addrs), "203.0.113.2")

    def test_gateway_hostname_prefers_the_static_one(self):
        state = make_state(swarmSecrets=[
            {"id": "base_domain", "value": BASE_DOMAIN},
            {"id": "gateway_hostname", "value": "gw.customer.example."},
        ])
        self.assertTrue(main.uses_custom_gateway_dns(state))
        self.assertEqual(main.resolve_delegation_gateway_hostname(state), "gw.customer.example")
        self.assertFalse(main.uses_custom_gateway_dns(make_state()))
        self.assertEqual(main.resolve_delegation_gateway_hostname(make_state()), f"gw.{DYN_ZONE}")


class GatewayRecordTests(unittest.TestCase):
    def test_ready_gateways_win(self):
        state = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "false", "external_ip": "203.0.113.2"},
        ])
        self.assertEqual(main.get_openresty_ready_ips(state), ["203.0.113.1"])

    def test_no_ready_gateway_falls_back_to_every_alive_one(self):
        # An empty gw.dyn record set means authoritative NXDOMAIN, which resolvers
        # cache and which dangles every service CNAME. A gateway that is down fails
        # soft instead.
        state = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "false", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": None, "external_ip": "203.0.113.2"},
        ])
        self.assertEqual(main.get_openresty_ready_ips(state), ["203.0.113.1", "203.0.113.2"])
        dyn = main.build_zone_files(state, "node-1")[DYN_ZONE]
        self.assertIn("gw\t300\tIN\tA\t203.0.113.1", dyn)
        self.assertIn("gw\t300\tIN\tA\t203.0.113.2", dyn)

    def test_gateway_that_left_the_gossip_view_is_not_used(self):
        # external_ip is null for a node the local gossip view no longer sees alive.
        state = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "true", "external_ip": None},
            {"node_id": "node-2", "ready": "false", "external_ip": "203.0.113.2"},
        ])
        self.assertEqual(main.get_openresty_ready_ips(state), ["203.0.113.2"])

    def test_no_openresty_node_at_all_leaves_gw_dyn_empty(self):
        state = make_state(openrestyServices=[])
        self.assertEqual(main.get_openresty_ready_ips(state), [])
        self.assertNotIn("gw\t", main.build_zone_files(state, "node-1")[DYN_ZONE])

    def test_the_fallback_is_still_a_pure_function_of_state(self):
        state = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "false", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "false", "external_ip": "203.0.113.2"},
        ])
        rendered = [main.build_zone_files(shuffled_state(state, seed), "node-1") for seed in range(4)]
        self.assertEqual(len({zones[DYN_ZONE] for zones in rendered}), 1)


class _FakeHost:
    """Records the host side effects a command handler performs."""

    def __init__(self, running: bool):
        self.running = running
        self.calls: list[str] = []
        self.reloaded: list[str] = []

    def install(self, test, tmpdir):
        import pathlib as _pathlib

        root = _pathlib.Path(tmpdir)
        patches = {
            "KNOT_CONFIG_DIR": root / "etc",
            "KNOT_CONFIG_FILE": root / "etc" / "knot.conf",
            "KNOT_ZONES_CONFIG_FILE": root / "etc" / "zones.conf",
            "KNOT_DATA_DIR": root / "data",
            "KNOT_ZONES_DIR": root / "data" / "zones",
        }
        for name, value in patches.items():
            patcher = unittest.mock.patch.object(main, name, value)
            patcher.start()
            test.addCleanup(patcher.stop)
        for name, fn in (
            ("is_knot_available", lambda: True),
            ("is_knot_running", lambda: (self.running, None if self.running else "Service status: inactive")),
            ("stop_knot_service", self._stop),
            ("enable_knot_service", self._start),
            ("wait_for_knot_ready", lambda timeout_sec=30: self.running),
            ("get_default_output_ip", lambda: None),
            ("_chown_knot", lambda path: None),
            ("ensure_knot_directories", self._mkdirs),
            ("knotc", self._knotc),
        ):
            patcher = unittest.mock.patch.object(main, name, fn)
            patcher.start()
            test.addCleanup(patcher.stop)
        self._root = root

    def _mkdirs(self):
        for directory in (main.KNOT_CONFIG_DIR, main.KNOT_DATA_DIR, main.KNOT_ZONES_DIR):
            directory.mkdir(parents=True, exist_ok=True)

    def _stop(self):
        self.calls.append("stop")
        self.running = False

    def _start(self):
        self.calls.append("start")
        self.running = True

    def _knotc(self, *args, timeout=15):
        self.calls.append(f"knotc {' '.join(args)}")
        if args and args[0] == "zone-reload":
            self.reloaded.append(args[1])
        return True, ""

    def zone_files(self):
        return sorted(p.name for p in main.KNOT_ZONES_DIR.glob("*.zone"))

    def zone_text(self, zone):
        return main.zone_file_path(zone).read_text()


class ApplyHandlerTests(unittest.TestCase):
    """The gate is exercised through the real command handlers, not just its helpers.

    The first version of this change passed every helper-level test and still failed
    on a real cluster, so the handlers are covered directly here.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def _apply(self, state, host, local_state=None):
        host.install(self, self.tmp.name)
        return main.handle_apply(
            main.PluginInput(
                command="apply",
                local_node_id="node-1",
                state=state,
                local_state=local_state if local_state is not None else {},
            )
        )

    def test_fresh_state_renders_both_zones_and_starts_knot(self):
        host = _FakeHost(running=False)
        out = self._apply(make_state(), host)
        self.assertEqual(out.status, "completed")
        self.assertEqual(out.node_properties["knot_node_ready"], "true")
        self.assertEqual(out.node_properties[main.GATE_STATE_PROPERTY], "serve:0")
        self.assertEqual(out.node_properties[main.BUILD_PROPERTY], main.plugin_build_fingerprint())
        self.assertEqual(host.zone_files(), [f"{DYN_ZONE}.zone", f"{CLUSTER_ZONE}.zone"])
        self.assertIn("start", host.calls)

    def test_unchanged_state_neither_restarts_nor_reloads(self):
        host = _FakeHost(running=False)
        state = make_state()
        self.assertEqual(self._apply(state, host).status, "completed")
        host.calls.clear()
        self.assertEqual(self._apply(state, host).status, "completed")
        self.assertEqual(host.calls, [])

    def test_stale_state_past_grace_stops_knot_without_rerendering(self):
        host = _FakeHost(running=False)
        state = make_state()
        self._apply(state, host)
        before = host.zone_text(CLUSTER_ZONE)
        host.calls.clear()

        # The node is cut off: peers have dropped out of its gossip view, but they
        # are still ready in replicated state, so the valve does not apply.
        isolated = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS,
            nodeAddrs=[{"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"}],
            openrestyServices=[],
        )
        out = self._apply(isolated, host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("isolated", out.error_message)
        self.assertEqual(out.node_properties[main.GATE_STATE_PROPERTY],
                         f"stop:{main.DEFAULT_ISOLATION_GRACE_SECS}")
        self.assertIn("stop", host.calls)
        self.assertEqual(host.zone_text(CLUSTER_ZONE), before, "zones must not be re-rendered while stale")

    def test_stale_state_within_grace_keeps_serving_the_last_records(self):
        host = _FakeHost(running=True)
        state = make_state()
        self._apply(state, host)
        before = host.zone_text(CLUSTER_ZONE)
        host.calls.clear()

        out = self._apply(
            make_state(peerStateAgeSecs=main.PEER_STATE_AGE_BUCKET_SECS, openrestyServices=[]),
            host,
        )
        self.assertEqual(out.status, "postponed")
        self.assertNotIn("stop", host.calls)
        # Every record except the diagnostic breadcrumb must be untouched: the node
        # deliberately does not re-render from a decayed view.
        self.assertEqual(_without_gate_txt(host.zone_text(CLUSTER_ZONE)), _without_gate_txt(before))

    def test_the_breadcrumb_is_refreshed_while_holding(self):
        # Otherwise it freezes at the last healthy value and a hold is
        # indistinguishable from serving to anyone reading it over DNS.
        host = _FakeHost(running=True)
        self._apply(make_state(), host)
        self.assertIn("gate=serve age=0", host.zone_text(CLUSTER_ZONE))

        self._apply(make_state(peerStateAgeSecs=main.PEER_STATE_AGE_BUCKET_SECS), host)
        zone = host.zone_text(CLUSTER_ZONE)
        self.assertIn(f"gate=hold age={main.PEER_STATE_AGE_BUCKET_SECS}", zone)
        self.assertIn(f"{CLUSTER_ZONE}", zone)

    def test_the_gate_does_not_depend_on_local_state_surviving(self):
        # Every invocation gets an empty local_state, as if nothing were persisted.
        host = _FakeHost(running=True)
        for _ in range(3):
            out = self._apply(
                make_state(peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 2),
                host,
                local_state={},
            )
            self.assertEqual(out.status, "postponed")
            self.assertIn("stop", host.calls)
            host.calls.clear()
            host.running = True

    def test_a_single_node_cluster_keeps_serving(self):
        host = _FakeHost(running=False)
        state = make_state(
            peerStateAgeSecs=None,
            clusterNodes=[{"id": "knot-c:node-1", "node_id": "node-1", "cluster": "knot-c"}],
        )
        self.assertEqual(self._apply(state, host).status, "completed")
        self.assertNotIn("stop", host.calls)

    def test_a_peer_missing_its_wireguard_property_does_not_block_rendering(self):
        # Peer tunnel IPs are unused now; requiring them stalled every node's render
        # whenever one node lacked the property.
        host = _FakeHost(running=False)
        state = make_state(wgNodeProperties=[
            {"name": "tunnel_ip", "value": "10.9.0.1", "node_id": "node-1"},
        ])
        self.assertEqual(self._apply(state, host).status, "completed")
        self.assertEqual(host.zone_files(), [f"{DYN_ZONE}.zone", f"{CLUSTER_ZONE}.zone"])

    def test_the_local_node_still_needs_its_own_wireguard_property(self):
        host = _FakeHost(running=False)
        state = make_state(wgNodeProperties=[
            {"name": "tunnel_ip", "value": "10.9.0.2", "node_id": "node-2"},
        ])
        out = self._apply(state, host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("WireGuard", out.error_message)

    def test_a_content_change_reloads_only_the_zone_that_changed(self):
        host = _FakeHost(running=True)
        self._apply(make_state(), host)
        host.calls.clear()
        host.reloaded.clear()
        moved = make_state(openrestyServices=[
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
        ])
        self.assertEqual(self._apply(moved, host).status, "completed")
        self.assertEqual(host.reloaded, [DYN_ZONE])
        self.assertNotIn("start", host.calls)


class HoldKeepsServingTests(unittest.TestCase):
    """A hold must keep the node answering, not merely stop it re-rendering.

    Found by Bugbot on the PR: both hold branches returned `postponed` before any
    is-running check, so a node whose Knot was down (VM reboot, daemon crash, or an
    earlier stop by this gate) stayed dark for the whole hold window — and the
    last-ready-nameserver valve holds indefinitely, so that window is unbounded.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def _install(self, host, *, configs_on_disk: bool):
        host.install(self, self.tmp.name)
        main.KNOT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if configs_on_disk:
            main.KNOT_CONFIG_FILE.write_text("# rendered")
            main.KNOT_ZONES_CONFIG_FILE.write_text("# rendered")
        else:
            for path in (main.KNOT_CONFIG_FILE, main.KNOT_ZONES_CONFIG_FILE):
                if path.exists():
                    path.unlink()

    def _hold_state(self, **overrides):
        return make_state(peerStateAgeSecs=main.PEER_STATE_AGE_BUCKET_SECS, **overrides)

    def _run(self, command, state, host):
        handler = main.handle_apply if command == "apply" else main.handle_health
        return handler(
            main.PluginInput(command=command, local_node_id="node-1", state=state, local_state={})
        )

    def test_apply_starts_a_down_knot_on_the_last_rendered_zones(self):
        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=True)
        out = self._run("apply", self._hold_state(), host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("start", host.calls)
        self.assertTrue(host.running)

    def test_health_starts_a_down_knot_on_the_last_rendered_zones(self):
        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=True)
        out = self._run("health", self._hold_state(), host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("start", host.calls)

    def test_a_bare_knot_is_never_started_without_a_rendered_config(self):
        # Fresh boot with no state on disk: there is nothing to serve.
        for command in ("apply", "health"):
            host = _FakeHost(running=False)
            self._install(host, configs_on_disk=False)
            out = self._run(command, self._hold_state(), host)
            self.assertEqual(out.status, "postponed", command)
            self.assertNotIn("start", host.calls, command)

    def test_the_last_ready_nameserver_is_restarted_while_holding(self):
        # The valve's promise — "going dark would take the zone down outright" — is
        # only kept if a crashed Knot on that node comes back.
        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=True)
        state = make_state(
            peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 10,
            knotServices=[{"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"}],
        )
        self.assertEqual(main.evaluate_serving_gate(state, "node-1")[0], main.GATE_HOLD)
        out = self._run("apply", state, host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("start", host.calls)

    def test_a_running_knot_is_not_restarted_while_holding(self):
        for command in ("apply", "health"):
            host = _FakeHost(running=True)
            self._install(host, configs_on_disk=True)
            out = self._run(command, self._hold_state(), host)
            self.assertEqual(out.status, "postponed", command)
            self.assertNotIn("start", host.calls, command)

    def test_a_node_stopped_by_the_gate_resumes_when_staleness_falls_back_into_grace(self):
        # stop -> partial heal -> must serve again. This is the sequence that was
        # unreachable: the restart logic sat after the hold branch.
        host = _FakeHost(running=True)
        self._install(host, configs_on_disk=True)
        stopped = self._run("health", make_state(peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 2), host)
        self.assertEqual(stopped.status, "postponed")
        self.assertIn("stop", host.calls)
        self.assertFalse(host.running)

        host.calls.clear()
        healed = self._run("health", self._hold_state(), host)
        self.assertEqual(healed.status, "postponed")
        self.assertIn("start", host.calls)
        self.assertTrue(host.running)

    def test_the_outcome_is_reported_in_the_status_message(self):
        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=True)
        out = self._run("apply", self._hold_state(), host)
        self.assertIn("restarted on the last rendered zones", out.error_message)

        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=False)
        out = self._run("apply", self._hold_state(), host)
        self.assertIn("no rendered configuration on disk yet", out.error_message)

    def test_the_helper_reports_a_failed_start_without_raising(self):
        host = _FakeHost(running=False)
        self._install(host, configs_on_disk=True)

        def boom():
            raise RuntimeError("systemctl said no")

        patcher = unittest.mock.patch.object(main, "enable_knot_service", boom)
        patcher.start()
        self.addCleanup(patcher.stop)
        serving, detail = main.ensure_knot_serving_last_rendered()
        self.assertFalse(serving)
        self.assertIn("systemctl said no", detail)


class HealthHandlerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def _health(self, state, host):
        host.install(self, self.tmp.name)
        main.KNOT_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        main.KNOT_CONFIG_FILE.write_text("# rendered")
        main.KNOT_ZONES_CONFIG_FILE.write_text("# rendered")
        return main.handle_health(
            main.PluginInput(command="health", local_node_id="node-1", state=state, local_state={})
        )

    def test_healthy_node_reports_completed(self):
        host = _FakeHost(running=True)
        self.assertEqual(self._health(make_state(), host).status, "completed")
        self.assertNotIn("stop", host.calls)

    def test_stale_state_past_grace_stops_knot(self):
        host = _FakeHost(running=True)
        out = self._health(make_state(peerStateAgeSecs=main.DEFAULT_ISOLATION_GRACE_SECS * 2), host)
        self.assertEqual(out.status, "postponed")
        self.assertIn("stop", host.calls)
        self.assertIn("isolated", out.error_message)

    def test_stale_state_within_grace_leaves_knot_running(self):
        host = _FakeHost(running=True)
        out = self._health(make_state(peerStateAgeSecs=main.PEER_STATE_AGE_BUCKET_SECS), host)
        self.assertEqual(out.status, "postponed")
        self.assertNotIn("stop", host.calls)

    def test_fresh_state_restarts_a_gated_knot(self):
        host = _FakeHost(running=False)
        out = self._health(make_state(), host)
        self.assertEqual(out.status, "completed")
        self.assertIn("start", host.calls)

    def test_a_single_node_cluster_is_never_stopped_by_health(self):
        host = _FakeHost(running=True)
        state = make_state(
            peerStateAgeSecs=None,
            clusterNodes=[{"id": "knot-c:node-1", "node_id": "node-1", "cluster": "knot-c"}],
        )
        self.assertEqual(self._health(state, host).status, "completed")
        self.assertNotIn("stop", host.calls)


def _jq_available() -> bool:
    return shutil.which("jq") is not None and yaml is not None


def _manifest_query() -> str:
    """The real stateExpr from manifest.yaml, with the template variable rendered."""
    manifest = yaml.safe_load((HERE / "manifest.yaml").read_text())
    return manifest["stateExpr"]["query"].replace("{{ clusterId }}", "knot-c")


def _swarmdb_fixture(heartbeats, *, removed_nodes=()) -> dict:
    """Minimal SwarmDB view: 2-node knot cluster, local node is node-1.

    ``heartbeats`` maps node_id -> last_heartbeat_ts (any JSON shape the writer may
    produce). ``removed_nodes`` are tombstoned in clusternodes but keep their
    ClusterServiceNodeStatuses row, which is what the real table does.
    """
    members = [n for n in dict.fromkeys(["node-1", *heartbeats]) if n not in removed_nodes]
    cluster_nodes = []
    for node in members:
        cluster_nodes.append({
            "id": f"knot-c:{node}", "cluster": "knot-c", "node": node, "deleted_ts": None,
        })
        cluster_nodes.append({
            "id": f"wg-c:{node}", "cluster": "wg-c", "node": node, "deleted_ts": None,
        })
    for node in removed_nodes:
        cluster_nodes.append({
            "id": f"knot-c:{node}", "cluster": "knot-c", "node": node, "deleted_ts": 1,
        })
    return {
        "clusters": [
            {"id": "knot-c", "cluster_policy": "knot", "deleted_ts": None},
            {"id": "wg-c", "cluster_policy": "wireguard", "deleted_ts": None},
        ],
        "clusternodes": cluster_nodes,
        "clusternodeproperties": [
            {"cluster_node": "wg-c:node-1", "name": "tunnel_ip", "value": "10.9.0.1", "deleted_ts": None},
            {"cluster_node": "knot-c:node-1", "name": "knot_node_ready", "value": "true", "deleted_ts": None},
        ],
        "clusterproperties": [],
        "nodes": [{"node_id": "node-1", "addr": "203.0.113.1", "port": 7946, "status": "alive"}],
        "swarmsecrets": [{"id": "base_domain", "value": BASE_DOMAIN}],
        "swarmidpointer": [{"id": "global_id", "value": GLOBAL_ID}],
        "localnodepointer": [{"node_id": "node-1"}],
        "clusterservicenodestatuses": [
            {
                "id": f"knot-c:knot:{node}", "cluster_id": "knot-c", "service_name": "knot",
                "node_id": node, "phase": "Ready", "last_heartbeat_ts": ts,
            }
            for node, ts in heartbeats.items()
        ],
    }


@unittest.skipUnless(_jq_available(), "needs the jq binary and PyYAML")
class ManifestQueryTests(unittest.TestCase):
    """Exercise the manifest's jq, where the freshness signal is actually computed.

    The Python helpers only read `peerStateAgeSecs`; everything that decides its
    value lives in the query, so it needs its own coverage.
    """

    def _peer_state_age(self, fixture: dict):
        result = subprocess.run(
            ["jq", "-n", "--argjson", "swarmdb", json.dumps(fixture), _manifest_query()],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)["peerStateAgeSecs"]

    @staticmethod
    def _ms_ago(seconds: float) -> int:
        return int(time.time() * 1000) - int(seconds * 1000)

    def test_a_fresh_peer_heartbeat_reads_as_zero(self):
        self.assertEqual(self._peer_state_age(_swarmdb_fixture({"node-2": self._ms_ago(8)})), 0)

    def test_a_stale_peer_heartbeat_reads_as_its_bucketed_age(self):
        self.assertEqual(self._peer_state_age(_swarmdb_fixture({"node-2": self._ms_ago(200)})), 180)

    def test_the_freshest_peer_wins(self):
        age = self._peer_state_age(_swarmdb_fixture({
            "node-2": self._ms_ago(8),
            "node-3": self._ms_ago(900),
        }))
        self.assertEqual(age, 0)

    def test_a_bigint_sent_as_a_string_is_coerced(self):
        # TypeORM writes bigint columns as strings; without coercion the arithmetic
        # in the query would fail and take the whole plan with it.
        self.assertEqual(self._peer_state_age(_swarmdb_fixture({"node-2": str(self._ms_ago(200))})), 180)

    def test_an_unparseable_heartbeat_is_skipped_not_fatal(self):
        age = self._peer_state_age(_swarmdb_fixture({
            "node-2": "not-a-number",
            "node-3": str(self._ms_ago(200)),
        }))
        self.assertEqual(age, 180)

    def test_a_null_heartbeat_is_ignored(self):
        self.assertIsNone(self._peer_state_age(_swarmdb_fixture({"node-2": None})))

    def test_a_single_node_swarm_reports_null(self):
        self.assertIsNone(self._peer_state_age(_swarmdb_fixture({"node-1": self._ms_ago(8)})))

    def test_a_removed_peers_frozen_heartbeat_is_ignored(self):
        # Scale-down-to-one: the removed node's clusternodes row is tombstoned but its
        # status row survives with a frozen heartbeat. Counting it would age past the
        # grace period and gate the last surviving nameserver off permanently.
        fixture = _swarmdb_fixture(
            {"node-1": self._ms_ago(8), "node-9": self._ms_ago(86400)},
            removed_nodes=("node-9",),
        )
        self.assertIsNone(self._peer_state_age(fixture))

    def test_a_removed_peer_does_not_mask_a_live_stale_one(self):
        fixture = _swarmdb_fixture(
            {"node-2": self._ms_ago(200), "node-9": self._ms_ago(86400)},
            removed_nodes=("node-9",),
        )
        self.assertEqual(self._peer_state_age(fixture), 180)

    def test_removing_a_dead_peer_restores_serving(self):
        # The operator escape hatch: the same dead peer, before and after removal.
        heartbeats = {"node-1": self._ms_ago(8), "node-2": self._ms_ago(86400)}
        still_a_member = _swarmdb_fixture(heartbeats)
        self.assertGreater(self._peer_state_age(still_a_member), 60)
        after_removal = _swarmdb_fixture(heartbeats, removed_nodes=("node-2",))
        self.assertIsNone(self._peer_state_age(after_removal))

    def test_a_healthy_cluster_keeps_the_value_stable_across_ticks(self):
        # A value that moved every tick would churn the plan hash and force an apply
        # on every provision tick.
        fixture = _swarmdb_fixture({"node-2": self._ms_ago(8)})
        self.assertEqual({self._peer_state_age(fixture) for _ in range(3)}, {0})


def _without_gate_txt(zone_text: str) -> str:
    """Zone content with the per-node diagnostic record and the derived serial removed."""
    lines = [l for l in zone_text.splitlines() if not l.startswith(main.GATE_TXT_LABEL)]
    return "\n".join(l for l in lines if "\tSOA\t" not in l)


def _soa_serial(zone_text: str) -> int:
    for line in zone_text.splitlines():
        if "\tSOA\t" in line:
            return int(line.split("( ", 1)[1].split()[0])
    raise AssertionError("no SOA record in zone")


if __name__ == "__main__":
    unittest.main()
