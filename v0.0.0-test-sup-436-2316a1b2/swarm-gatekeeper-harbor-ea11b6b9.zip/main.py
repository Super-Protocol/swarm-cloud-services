#!/usr/bin/env python3

import hashlib
import os
import shutil
import subprocess
import time
from pathlib import Path

import yaml
from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

def _str_representer(dumper, data):
    """Force literal block style (|) for multiline strings so PyYAML doesn't mangle them."""
    if "\n" in data:
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


yaml.add_representer(str, _str_representer)

GATEKEEPER_IMAGE = (
    os.environ.get("GATEKEEPER_HARBOR_IMAGE")
    or os.environ.get("GATEKEEPER_IMAGE")
    or "ghcr.io/super-protocol/swarm-cloud/swarm-gatekeeper:latest"
)
GATEKEEPER_INSTANCE = "gatekeeper-harbor"
GATEKEEPER_SERVER_PORT = 9110
GATEKEEPER_HEALTH_PORT = 9111
GATEKEEPER_CONFIG_DIR = Path("/etc/gatekeeper-harbor")
GATEKEEPER_CONFIG_FILE = GATEKEEPER_CONFIG_DIR / "gatekeeper.yaml"
PODMAN_BIN = "podman"
CONTAINER_NAME = "swarm-gatekeeper-harbor"
NODE_READY_PROPERTY = "gatekeeper_harbor_node_ready"
API_ENDPOINT_PROPERTY = "gatekeeper_harbor_api_endpoint"
REDIS_PUBSUB_CHANNEL = "gatekeeper:events"
SERVICE_PLUGIN_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG_PATH = SERVICE_PLUGIN_DIR / "gatekeeper.yaml"
EVIDENCE_TIMEOUT_SECS = 10

plugin = ProvisionPlugin()


def _normalize_domain(value: str) -> str:
    return value.strip().rstrip(".") if isinstance(value, str) else ""


def build_evidence_url(global_id: str, base_domain: str) -> str:
    """Public swarm-cloud-api endpoint that resolves `evidence_token` to evidence
    JSON. Mirrors `app.<global_id>.<base_domain>` published by dns-manager."""
    normalized_global_id = global_id.strip() if isinstance(global_id, str) else ""
    normalized_base_domain = _normalize_domain(base_domain)
    if not normalized_global_id:
        raise ValueError("globalId is missing")
    if not normalized_base_domain:
        raise ValueError("baseDomain is missing")
    return f"https://app.{normalized_global_id}.{normalized_base_domain}/v1/evidence/{{token}}"


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def get_leader_node(state_json: dict) -> str | None:
    cluster = state_json.get("cluster", {}) or {}
    return cluster.get("leader_node")


def get_secret_from_swarmdb(state_json: dict, secret_id: str) -> str | None:
    secrets = state_json.get("swarmSecrets", []) or []
    for secret in secrets:
        if secret.get("id") == secret_id:
            return secret.get("value")
    return None


def get_harbor_cluster_property(state_json: dict, name: str) -> str | None:
    """Read a string cluster property from the Harbor cluster (names start with `harbor_`)."""
    harbor_props = state_json.get("harborClusterProperties") or []
    for prop in harbor_props:
        if prop.get("name") == name:
            value = prop.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


REDIS_SENTINEL_PORT = 26379
REDIS_SENTINEL_MASTER_NAME = "redis-master"


def get_sentinel_tunnel_ips(state_json: dict) -> list[str]:
    sentinel_props = state_json.get("sentinelNodeProperties") or []
    wg_props = state_json.get("sentinelWgNodeProperties") or state_json.get("wgNodeProperties") or []

    sentinel_hosts = []
    for prop in sentinel_props:
        if prop.get("name") == "redis_sentinel_node_ready" and prop.get("value") == "true":
            node_id = prop.get("node_id")
            tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
            if tunnel_ip:
                sentinel_hosts.append(tunnel_ip)

    return sorted(set(sentinel_hosts))


def get_redis_config_from_state(state_json: dict) -> tuple[str | None, dict | None]:
    sentinel_ips = get_sentinel_tunnel_ips(state_json)
    if sentinel_ips:
        sentinel_urls = [f"redis://{ip}:{REDIS_SENTINEL_PORT}" for ip in sentinel_ips]
        return None, {
            "sentinel_urls": sentinel_urls,
            "sentinel_master_name": REDIS_SENTINEL_MASTER_NAME,
        }

    sentinel_props = state_json.get("sentinelNodeProperties") or []
    for prop in sentinel_props:
        if prop.get("name") == "redis_sentinel_master_ip":
            ip = prop.get("value")
            if ip:
                return f"redis://{ip}:6379", None

    return None, None


def ensure_config_dir() -> None:
    GATEKEEPER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _build_redis_section(redis_url: str | None = None, sentinel_config: dict | None = None) -> dict:
    if sentinel_config:
        return {
            "sentinel_urls": sentinel_config["sentinel_urls"],
            "sentinel_master_name": sentinel_config["sentinel_master_name"],
            "pubsub_channel": REDIS_PUBSUB_CHANNEL,
        }
    return {
        "url": redis_url or "redis://127.0.0.1:6379",
        "pubsub_channel": REDIS_PUBSUB_CHANNEL,
    }


def write_gatekeeper_config(
    redis_url: str | None = None,
    sentinel_config: dict | None = None,
    *,
    harbor_backend_endpoint: str | None = None,
    harbor_robot_username: str | None = None,
    harbor_robot_password: str | None = None,
    evidence_url: str | None = None,
) -> None:
    ensure_config_dir()
    redis_section = _build_redis_section(redis_url, sentinel_config)

    if DEFAULT_CONFIG_PATH.exists():
        config = yaml.safe_load(DEFAULT_CONFIG_PATH.read_text())
    else:
        config = {
            "server": {"host": "0.0.0.0", "port": GATEKEEPER_SERVER_PORT},
            "health": {"host": "0.0.0.0", "port": GATEKEEPER_HEALTH_PORT},
            "policy": {"engine": "regorus"},
        }

    if evidence_url:
        config["evidence"] = {
            "url": evidence_url,
            "timeout_secs": EVIDENCE_TIMEOUT_SECS,
        }

    if harbor_backend_endpoint and harbor_robot_username and harbor_robot_password:
        upstreams = config.get("upstreams") if isinstance(config, dict) else None
        if isinstance(upstreams, list):
            for upstream in upstreams:
                if not isinstance(upstream, dict):
                    continue
                name = upstream.get("name")
                match = upstream.get("match") if isinstance(upstream.get("match"), dict) else {}
                path_prefix = match.get("path_prefix")

                if name == "registry" or path_prefix == "/v2/":
                    proxy = upstream.get("proxy") if isinstance(upstream.get("proxy"), dict) else None
                    if not isinstance(proxy, dict):
                        proxy = {}
                        upstream["proxy"] = proxy
                    backend = proxy.get("backend") if isinstance(proxy.get("backend"), dict) else None
                    if not isinstance(backend, dict):
                        backend = {}
                        proxy["backend"] = backend

                    backend["endpoint"] = harbor_backend_endpoint
                    backend["auth"] = {
                        "type": "harbor-robot",
                        "username": harbor_robot_username,
                        "password": harbor_robot_password,
                        "token_endpoint": "/service/token",
                        "service": "harbor-registry",
                    }
                    break

    config["redis"] = redis_section
    content = yaml.dump(
        config,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
    )
    GATEKEEPER_CONFIG_FILE.write_text(content)


def is_podman_available() -> bool:
    return shutil.which(PODMAN_BIN) is not None


def is_container_running(container_name: str) -> tuple[bool, str | None]:
    try:
        result = subprocess.run(
            [PODMAN_BIN, "inspect", "-f", "{{.State.Running}}", container_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False, result.stderr.strip() or result.stdout.strip()
        is_active = result.stdout.strip().lower() == "true"
        return is_active, None if is_active else "Container is not running"
    except subprocess.TimeoutExpired:
        return False, "Container inspect timed out"
    except Exception as e:
        return False, str(e)


def stop_and_remove_container(container_name: str) -> None:
    try:
        subprocess.run(
            [PODMAN_BIN, "stop", container_name],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=20,
        )
    except subprocess.TimeoutExpired:
        pass

    for _ in range(12):
        time.sleep(2)
        try:
            result = subprocess.run(
                [PODMAN_BIN, "inspect", "--format", "{{.State.Status}}", container_name],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except subprocess.TimeoutExpired:
            continue
        if result.returncode != 0:
            return
        status = (result.stdout or "").strip().lower()
        if status in ("exited", "stopped", "configured"):
            subprocess.run(
                [PODMAN_BIN, "rm", container_name],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return
        if status not in ("stopping", "running"):
            subprocess.run(
                [PODMAN_BIN, "rm", container_name],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return
    subprocess.run(
        [PODMAN_BIN, "rm", "-f", container_name],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def run_gatekeeper_container(config_path: Path) -> None:
    stop_and_remove_container(CONTAINER_NAME)

    cmd = [
        PODMAN_BIN,
        "run",
        "-d",
        "--name",
        CONTAINER_NAME,
        "--network",
        "host",
        "-v",
        f"{config_path}:/etc/gatekeeper/gatekeeper.yaml:ro",
        "-e",
        "GK_CONFIG_PATH=/etc/gatekeeper/gatekeeper.yaml",
        "-e",
        "RUST_LOG=info",
        GATEKEEPER_IMAGE,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Podman run timed out after 60s")
    if result.returncode != 0:
        raise RuntimeError(
            f"Failed to run gatekeeper container: {result.stderr.strip() or result.stdout.strip()}"
        )


def wait_for_gatekeeper_ready(timeout_sec: int = 60) -> bool:
    import urllib.error
    import urllib.request

    start_time = time.time()
    url = f"http://127.0.0.1:{GATEKEEPER_HEALTH_PORT}/health"
    while time.time() - start_time < timeout_sec:
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(2)
    return False


@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    try:
        if not is_podman_available():
            return PluginOutput(
                status="error",
                error_message="podman is not installed; install podman on the host before using gatekeeper-harbor",
                local_state=input_data.local_state,
            )
        ensure_config_dir()
        try:
            subprocess.run(
                [PODMAN_BIN, "pull", GATEKEEPER_IMAGE],
                capture_output=True,
                text=True,
                timeout=120,
                check=True,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            print(f"[!] Failed to pull image (non-fatal): {e}", file=__import__("sys").stderr)
        return PluginOutput(status="completed", local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e), local_state=input_data.local_state)


@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    if not isinstance(state_json, dict):
        return PluginOutput(status="error", error_message="Invalid state format", local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])

    if len(cluster_nodes) < 1:
        return PluginOutput(
            status="postponed",
            error_message="gatekeeper-harbor requires at least 1 node",
            local_state=local_state,
        )

    leader_node_id = get_leader_node(state_json)
    if leader_node_id and local_node_id != leader_node_id:
        return PluginOutput(status="completed", local_state=local_state)

    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status="postponed",
            error_message="Waiting for WireGuard to be configured on gatekeeper-harbor node",
            local_state=local_state,
        )

    redis_url, sentinel_config = get_redis_config_from_state(state_json)
    if redis_url is None and sentinel_config is None:
        redis_url = os.environ.get("GATEKEEPER_REDIS_URL") or "redis://127.0.0.1:6379"

    global_id = state_json.get("globalId")
    base_domain = state_json.get("baseDomain")
    try:
        evidence_url = build_evidence_url(global_id, base_domain)
    except ValueError as e:
        return PluginOutput(
            status="postponed",
            error_message=f"Waiting for cluster identity to render evidence URL: {e}",
            local_state=local_state,
        )

    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status="postponed",
            error_message="Waiting for local WireGuard tunnel IP (tunnel_ip) on gatekeeper-harbor node",
            local_state=local_state,
        )

    harbor_values = []
    for prop_name in ("harbor_endpoint", "harbor_admin_username", "harbor_admin_password"):
        if (prop_value := get_harbor_cluster_property(state_json, prop_name)) is None:
            return PluginOutput(
                status="postponed",
                error_message=f"Waiting for {prop_name} in cluster state (published by the Harbor service)",
                local_state=local_state,
            )
        harbor_values.append(prop_value)

    harbor_backend_endpoint, harbor_robot_username, harbor_robot_password = harbor_values

    if not is_podman_available():
        return PluginOutput(
            status="error",
            error_message="podman is not installed",
            local_state=local_state,
        )

    try:
        write_gatekeeper_config(
            redis_url=redis_url,
            sentinel_config=sentinel_config,
            harbor_backend_endpoint=harbor_backend_endpoint,
            harbor_robot_username=harbor_robot_username,
            harbor_robot_password=harbor_robot_password,
            evidence_url=evidence_url,
        )
    except Exception as e:
        return PluginOutput(
            status="error",
            error_message=f"Failed to write config: {e}",
            local_state=local_state,
        )

    payload = (
        f"{redis_url}|{str(sentinel_config) if sentinel_config else ''}|"
        f"{harbor_backend_endpoint}|{harbor_robot_username}|{harbor_robot_password}|"
        f"{evidence_url}"
    )
    config_hash = hashlib.sha256(payload.encode()).hexdigest()
    if local_state.get("config_hash") == config_hash and local_state.get("gatekeeper_ready"):
        is_running, _ = is_container_running(CONTAINER_NAME)
        if is_running:
            return PluginOutput(
                status="completed",
                node_properties={NODE_READY_PROPERTY: "true"},
                local_state=local_state,
            )

    try:
        run_gatekeeper_container(GATEKEEPER_CONFIG_FILE)
    except Exception as e:
        return PluginOutput(
            status="error",
            error_message=f"Failed to start gatekeeper-harbor: {e}",
            local_state=local_state,
        )

    if not wait_for_gatekeeper_ready(timeout_sec=60):
        return PluginOutput(
            status="postponed",
            error_message="gatekeeper-harbor did not become ready within timeout",
            local_state={**local_state, "config_hash": config_hash, "gatekeeper_ready": False},
        )

    new_local_state = {
        **local_state,
        "config_hash": config_hash,
        "gatekeeper_ready": True,
    }

    # SP-7700: publish image identity for the control-plane evidence aggregator.
    node_props = {
        NODE_READY_PROPERTY: "true",
        API_ENDPOINT_PROPERTY: f"http://127.0.0.1:{GATEKEEPER_SERVER_PORT}",
    }
    node_props.update(
        build_image_evidence_props(
            prefix="gatekeeper_harbor",
            image_ref=GATEKEEPER_IMAGE,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )
    return PluginOutput(
        status="completed",
        node_properties=node_props,
        local_state=new_local_state,
    )


@plugin.command("health")
def handle_health(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    cluster = state_json.get("cluster", {}) if isinstance(state_json, dict) else {}
    leader_node_id = cluster.get("leader_node")
    if leader_node_id and local_node_id != leader_node_id:
        return PluginOutput(status="completed", local_state=local_state)

    is_running, error_msg = is_container_running(CONTAINER_NAME)
    if not is_running:
        not_found = error_msg and (
            "no such container" in error_msg.lower() or "no such object" in error_msg.lower()
        )
        return PluginOutput(
            status="postponed" if not_found else "error",
            error_message=error_msg or "gatekeeper-harbor container is not running",
            local_state=local_state,
        )

    import urllib.error
    import urllib.request

    try:
        url = f"http://127.0.0.1:{GATEKEEPER_HEALTH_PORT}/health"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status != 200:
                return PluginOutput(
                    status="postponed",
                    error_message=f"Health check returned {resp.status}",
                    local_state=local_state,
                )
    except Exception as e:
        return PluginOutput(
            status="postponed",
            error_message=f"Health check failed: {e}",
            local_state=local_state,
        )

    return PluginOutput(
        status="completed",
        node_properties={NODE_READY_PROPERTY: "true"},
        local_state=local_state,
    )


@plugin.command("finalize")
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    local_state = input_data.local_state or {}
    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("destroy")
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    try:
        stop_and_remove_container(CONTAINER_NAME)
        node_properties = {
            NODE_READY_PROPERTY: None,
            API_ENDPOINT_PROPERTY: None,
        }
        return PluginOutput(
            status="completed",
            node_properties=node_properties,
            local_state={},
        )
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e), local_state={})


if __name__ == "__main__":
    plugin.run()
