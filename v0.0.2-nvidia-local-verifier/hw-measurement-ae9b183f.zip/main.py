#!/usr/bin/env python3

import sys
import os
import re
import shutil
import platform
import subprocess
import json
import urllib.request
from typing import Tuple, Dict, Optional, List, Any

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

# Plugin setup
plugin = ProvisionPlugin()

GPU_PRESENT_LABEL = "device.swarm.io/gpu-present"
GPU_PRODUCT_LABEL = "device.swarm.io/gpu-product"
GPU_COUNT_LABEL = "device.swarm.io/gpu-count"
GPU_HOMOGENEOUS_LABEL = "device.swarm.io/gpu-homogeneous"
GPU_SIMULATED_LABEL = "device.swarm.io/gpu-simulated"
DEVICE_LABELS_SNAPSHOT_KEY = "deviceLabelsSnapshot"

# Debug-only: pretend this host has NVIDIA GPUs so labeling can be tested without hardware.
# Set on swarm-host-agent (plugins inherit its env), e.g. systemd drop-in:
#   Environment=SWARM_DEBUG_GPU_PRODUCT=NVIDIA A100-SXM4-40GB
# Comma-separated products → heterogeneous (no gpu-product label).
# While the product override is set, measurements include gpu_source=simulated and
# device.swarm.io/gpu-simulated=true. Placement still reserves those cards.
DEBUG_GPU_PRODUCT_ENV = "SWARM_DEBUG_GPU_PRODUCT"
DEBUG_GPU_COUNT_ENV = "SWARM_DEBUG_GPU_COUNT"
DEBUG_GPU_MEMORY_MIB_ENV = "SWARM_DEBUG_GPU_MEMORY_MIB"


# Helper functions

def get_cpu_total() -> int:
    """Get total logical CPU cores."""
    try:
        return os.cpu_count() or 0
    except Exception:
        return 0


def get_loadavg_5() -> float:
    """Get 5-minute load average from /proc/loadavg."""
    try:
        with open("/proc/loadavg", "r") as f:
            parts = f.read().strip().split()
            return float(parts[1])  # 5-minute load average
    except Exception:
        return 0.0


def get_cpu_avg_usage_percent() -> str:
    """Calculate approximate CPU usage from 5-min load average."""
    cpu_total = max(get_cpu_total(), 1)
    load5 = get_loadavg_5()
    usage = min(1.0, max(0.0, load5 / float(cpu_total))) * 100.0
    return f"{usage:.1f}"


def parse_meminfo() -> Tuple[int, int]:
    """Return (total_bytes, used_bytes) using MemTotal - MemAvailable."""
    meminfo: Dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if ":" not in line:
                    continue
                k, v = line.split(":", 1)
                v = v.strip()
                # Values are like '16338836 kB'
                num = v.split()[0]
                try:
                    meminfo[k] = int(num) * 1024  # to bytes
                except Exception:
                    pass
    except Exception:
        return 0, 0

    total = int(meminfo.get("MemTotal", 0))
    available = int(meminfo.get("MemAvailable", 0)) or int(meminfo.get("MemFree", 0))
    used = total - available if total and available else 0
    return total, used


def get_disk_usage_bytes() -> Tuple[int, int]:
    """Get disk usage for current working directory."""
    try:
        cwd = os.getcwd()
        usage = shutil.disk_usage(cwd)
        total = int(usage.total)
        used = int(usage.used)
        return total, used
    except Exception:
        return 0, 0


def try_cmd(cmd: list[str]) -> str:
    """Execute command and return output, or empty string on failure."""
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=3)
        return out.strip()
    except Exception:
        return ""


def debug_gpu_products() -> List[str]:
    """Product names from SWARM_DEBUG_GPU_PRODUCT, or empty if unset."""
    raw = os.environ.get(DEBUG_GPU_PRODUCT_ENV, "").strip()
    if not raw:
        return []
    return [p.strip() for p in raw.split(",") if p.strip()]


def debug_gpu_count_override() -> Optional[int]:
    raw = os.environ.get(DEBUG_GPU_COUNT_ENV, "").strip()
    if not raw:
        return None
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return None


def debug_gpu_memory_bytes_override() -> Optional[int]:
    raw = os.environ.get(DEBUG_GPU_MEMORY_MIB_ENV, "").strip()
    if not raw:
        return None
    if raw.isdigit() and int(raw) > 0:
        return int(raw) * 1024 * 1024
    return None


def debug_gpu_detection() -> Optional[Tuple[bool, str, Optional[str], Optional[bool]]]:
    """If debug env is set, return the same tuple shape as detect_gpu()."""
    names = debug_gpu_products()
    if not names:
        return None
    unique = sorted(set(names))
    print(
        f"[!] {DEBUG_GPU_PRODUCT_ENV} override active: {names}",
        file=sys.stderr,
    )
    if len(unique) == 1:
        product = unique[0]
        return True, product, product, True
    display = ", ".join(unique)
    return True, display, None, False


def get_gpu_count() -> int:
    """Get number of GPUs available."""
    debug_count = debug_gpu_count_override()
    if debug_count is not None:
        return debug_count
    products = debug_gpu_products()
    if products:
        return len(products)

    # Try nvidia-smi first
    out = try_cmd(["bash", "-lc", "command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi --query-gpu=count --format=csv,noheader | head -n1"])
    if out and out.isdigit():
        return int(out)

    # Count lines from nvidia-smi list
    out = try_cmd(["bash", "-lc", "command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi --query-gpu=name --format=csv,noheader | wc -l"])
    if out and out.strip().isdigit():
        count = int(out.strip())
        if count > 0:
            return count

    # Check nvidia procfs
    gpu_dirs = try_cmd(["bash", "-lc", "ls -d /proc/driver/nvidia/gpus/* 2>/dev/null | wc -l"])
    if gpu_dirs and gpu_dirs.strip().isdigit():
        count = int(gpu_dirs.strip())
        if count > 0:
            return count

    # Check DRI render nodes
    if os.path.isdir("/dev/dri"):
        try:
            dri_files = os.listdir("/dev/dri")
            render_count = len([f for f in dri_files if f.startswith("render")])
            if render_count > 0:
                return render_count
        except Exception:
            pass

    return 0


def get_gpu_memory_total() -> int:
    """Get total GPU memory in bytes across all GPUs."""
    debug_mem = debug_gpu_memory_bytes_override()
    if debug_mem is not None:
        return debug_mem
    if debug_gpu_products():
        return 0

    # Try nvidia-smi
    out = try_cmd(["bash", "-lc", "command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits"])
    if out:
        total = 0
        for line in out.splitlines():
            if line.strip().isdigit():
                total += int(line.strip()) * 1024 * 1024  # MiB to bytes
        if total > 0:
            return total

    return 0


def parse_nvidia_smi_names(out: str) -> List[str]:
    """Parse nvidia-smi --query-gpu=name lines into a list of product names."""
    names: List[str] = []
    for line in out.splitlines():
        name = line.strip()
        if name:
            names.append(name)
    return names


def build_gpu_labels_from_detection(
    has_gpu: bool,
    product_name: Optional[str],
    homogeneous: Optional[bool],
    gpu_count: int = 0,
    simulated: bool = False,
) -> Dict[str, Optional[str]]:
    """Build desired device.swarm.io GPU labels (null = soft-delete).

    Nodes without a GPU keep `gpu-present=false` so placement can select them;
    product/count/homogeneous are cleared. `gpu-simulated` is true only while the
    debug product override is active, and null otherwise so a removed override
    drops the marker.

    Args:
        has_gpu: whether any GPU presence was detected
        product_name: canonical nvidia-smi name when homogeneous; else None
        homogeneous: True/False when has_gpu and product known/mixed; None when
            present without a canonical product (lspci/DRI fallback)
        gpu_count: card count from nvidia-smi / debug env / fallbacks; 0 clears
            the count label
        simulated: true when SWARM_DEBUG_GPU_PRODUCT supplies the inventory
    """
    simulated_value = "true" if simulated else None
    if not has_gpu:
        return {
            GPU_PRESENT_LABEL: "false",
            GPU_PRODUCT_LABEL: None,
            GPU_COUNT_LABEL: None,
            GPU_HOMOGENEOUS_LABEL: None,
            GPU_SIMULATED_LABEL: simulated_value,
        }

    labels: Dict[str, Optional[str]] = {
        GPU_PRESENT_LABEL: "true",
        GPU_PRODUCT_LABEL: None,
        GPU_COUNT_LABEL: str(gpu_count) if gpu_count > 0 else None,
        GPU_HOMOGENEOUS_LABEL: None,
        GPU_SIMULATED_LABEL: simulated_value,
    }
    if homogeneous is True and product_name:
        labels[GPU_PRODUCT_LABEL] = product_name
        labels[GPU_HOMOGENEOUS_LABEL] = "true"
    elif homogeneous is False:
        labels[GPU_PRODUCT_LABEL] = None
        labels[GPU_HOMOGENEOUS_LABEL] = "false"
    # else: present without product (fallback detection) — leave product/homogeneous null
    return labels


def detect_gpu() -> Tuple[bool, str, Optional[str], Optional[bool]]:
    """Detect GPU presence, display model, and label-facing product info.

    Returns:
        (has_gpu, gpu_model_display, product_name, homogeneous)
        product_name is set only from nvidia-smi name when all GPUs share one name.
        homogeneous is True/False for nvidia-smi paths; None for non-product fallbacks.
    """
    debug = debug_gpu_detection()
    if debug is not None:
        return debug

    # Priority 1: Check GPU environment file (created by cloud-init for GPU nodes)
    gpu_env_file = "/etc/rancher/rke2/gpu.env"
    if os.path.exists(gpu_env_file):
        # We know this is a GPU node, try to get the model
        pass

    # Priority 2: nvidia-smi (most reliable for NVIDIA GPUs) — name only for product canon
    out = try_cmd(["bash", "-lc", "command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi --query-gpu=name --format=csv,noheader"])
    if out:
        names = parse_nvidia_smi_names(out)
        if names:
            unique = sorted(set(names))
            if len(unique) == 1:
                product = unique[0]
                return True, product, product, True
            # Heterogeneous: display joins names; no single product label
            display = ", ".join(unique)
            return True, display, None, False

    # Also try name+memory for legacy gpu_model display if name-only failed somehow
    out_mem = try_cmd(["bash", "-lc", "command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi --query-gpu=name,memory.total --format=csv,noheader"])
    if out_mem:
        gpu_info = []
        names = []
        for line in out_mem.splitlines():
            if line.strip():
                parts = line.strip().split(',')
                name = parts[0].strip()
                if name:
                    names.append(name)
                if len(parts) >= 2:
                    memory = parts[1].strip()
                    gpu_info.append(f"{name} ({memory})")
                else:
                    gpu_info.append(line.strip())
        if names:
            unique = sorted(set(names))
            if len(unique) == 1:
                product = unique[0]
                display = ", ".join(sorted(set(gpu_info))) if gpu_info else product
                return True, display, product, True
            display = ", ".join(sorted(set(gpu_info))) if gpu_info else ", ".join(unique)
            return True, display, None, False

    # Priority 3: Check NVIDIA driver presence via procfs — present, no product
    if os.path.exists("/proc/driver/nvidia/version"):
        try:
            with open("/proc/driver/nvidia/version", "r") as f:
                version_line = f.readline().strip()
                info_cmd = try_cmd(["bash", "-lc", "ls /proc/driver/nvidia/gpus/*/information 2>/dev/null | head -n1"])
                if info_cmd:
                    gpu_info_file = info_cmd.strip()
                    model_info = try_cmd(["bash", "-lc", f"grep 'Model:' {gpu_info_file} 2>/dev/null"])
                    if model_info:
                        model = model_info.split(':', 1)[1].strip() if ':' in model_info else model_info
                        return True, model, None, None
                return True, f"NVIDIA GPU (driver: {version_line.split()[0] if version_line else 'present'})", None, None
        except Exception:
            pass

    # Priority 4: lspci for any GPU (NVIDIA, AMD, Intel) — present, no product
    lspci = try_cmd(["bash", "-lc", "command -v lspci >/dev/null 2>&1 && lspci | grep -iE 'vga|3d controller|display controller'"])
    if lspci:
        for line in lspci.splitlines():
            low = line.lower()
            if any(keyword in low for keyword in ["nvidia", "amd", "radeon", "intel"]):
                if ':' in line:
                    parts = line.split(':', 2)
                    if len(parts) >= 3:
                        model = parts[2].strip()
                        return True, model, None, None
                return True, line.strip(), None, None

    # Priority 5: kernel devices (/dev/dri) as presence indicator — present, no product
    if os.path.isdir("/dev/dri"):
        dri_files = os.listdir("/dev/dri") if os.path.exists("/dev/dri") else []
        render_count = len([f for f in dri_files if f.startswith("render")])
        if render_count > 0:
            return True, f"GPU present (DRI render nodes: {render_count})", None, None
        return True, "DRM device present", None, None

    return False, "", None, None


def get_cpu_model() -> str:
    """Get CPU model name from /proc/cpuinfo or platform."""
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
                if line.lower().startswith("hardware") and not platform.machine().startswith("x86"):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return platform.processor() or ""


def get_arch() -> str:
    """Get processor architecture."""
    return platform.machine() or ""


_CMDLINE_BUILD_RE = re.compile(r"(?:^|\s)build=([A-Za-z0-9._-]+)")
MEASURE_URL = "http://127.0.0.1:9180/api/v1/getMeasure"
MEASURE_TIMEOUT_S = 90
MEASURE_STATE_KEY = "spVmMeasure"
_MRENCLAVE_RE = re.compile(r"^[0-9a-fA-F]+$")
EVIDENCE_TYPES = {
    "tdx",
    "tdx-google",
    "tdx-azure",
    "sev-snp",
    "sev-snp-azure",
    "untrusted",
}


def parse_sp_vm_cmdline(cmdline: str) -> Dict[str, str]:
    """sp-vm image version from the kernel command line."""
    props: Dict[str, str] = {}
    build = _CMDLINE_BUILD_RE.search(cmdline)
    if build:
        props["sp_vm_image_version"] = build.group(1)
    return props


def parse_measure_response(payload: Any) -> Dict[str, str]:
    """mrenclave and evidence type from pki-vm-measurements /api/v1/getMeasure."""
    if not isinstance(payload, dict):
        return {}
    evidence_type = payload.get("type")
    if evidence_type not in EVIDENCE_TYPES:
        return {}
    props = {"sp_vm_evidence_type": evidence_type}
    mrenclave = payload.get("mrenclaveHex")
    if isinstance(mrenclave, str) and _MRENCLAVE_RE.fullmatch(mrenclave):
        props["sp_vm_mrenclave"] = mrenclave.lower()
    return props


def fetch_sp_vm_measure() -> Dict[str, str]:
    try:
        with urllib.request.urlopen(MEASURE_URL, timeout=MEASURE_TIMEOUT_S) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return parse_measure_response(payload)
    except Exception as e:
        print(f"[!] Failed to read VM measurements: {e}", file=sys.stderr)
        return {}


def read_sp_vm_image_props() -> Dict[str, str]:
    try:
        with open("/proc/cmdline", "r") as f:
            return parse_sp_vm_cmdline(f.read())
    except Exception:
        return {}


# 1.3.6.1.3.8888.1.4.1 — NvtrustGPUList in the node certificate.
_GPU_ATTEST_OID = bytes((0x2B, 0x06, 0x01, 0x03, 0xC5, 0x38, 0x01, 0x04, 0x01))
_GPU_ATTEST_MODES = {1: "nras", 2: "proxy"}


def _read_asn1_length(data: bytes, index: int) -> Tuple[int, int]:
    if index >= len(data):
        raise ValueError("truncated ASN.1 length")
    first = data[index]
    index += 1
    if first < 0x80:
        return first, index
    count = first & 0x7F
    if count == 0 or index + count > len(data):
        raise ValueError("invalid ASN.1 length")
    length = int.from_bytes(data[index : index + count], "big")
    return length, index + count


def _read_varint(data: bytes, index: int) -> Tuple[int, int]:
    value = 0
    shift = 0
    while index < len(data):
        byte = data[index]
        index += 1
        value |= (byte & 0x7F) << shift
        if byte < 0x80:
            return value, index
        shift += 7
        if shift > 63:
            break
    raise ValueError("truncated protobuf varint")


def gpu_attest_mode_from_extension(payload: bytes) -> Optional[str]:
    """Read NvtrustGPUList.attestationMode. Nested GPU fields are skipped."""
    index = 0
    mode: Optional[int] = None
    while index < len(payload):
        key, index = _read_varint(payload, index)
        field, wire = key >> 3, key & 7
        if wire == 0:
            value, index = _read_varint(payload, index)
            if field == 2:
                mode = value
        elif wire == 2:
            length, index = _read_varint(payload, index)
            index += length
        elif wire == 5:
            index += 4
        elif wire == 1:
            index += 8
        else:
            return None
    return _GPU_ATTEST_MODES.get(mode) if mode is not None else None


def gpu_attest_mode_from_der(cert_der: bytes) -> Optional[str]:
    start = 0
    while True:
        found = cert_der.find(_GPU_ATTEST_OID, start)
        if found < 0:
            return None
        index = found + len(_GPU_ATTEST_OID)
        if index < len(cert_der) and cert_der[index] == 0x04:
            length, index = _read_asn1_length(cert_der, index + 1)
            return gpu_attest_mode_from_extension(cert_der[index : index + length])
        start = found + 1


def read_gpu_attest_mode(cert_dirs: Optional[list] = None) -> Optional[str]:
    import base64
    import glob

    directories = cert_dirs if cert_dirs is not None else [
        "/etc/super/certs/vm",
        "/etc/super/certs/swarm-init",
    ]
    for directory in directories:
        for path in sorted(glob.glob(os.path.join(directory, "*_cert.pem"))):
            try:
                pem = open(path, "r", encoding="utf-8").read()
            except OSError:
                continue
            body = "".join(line for line in pem.splitlines() if not line.startswith("-----"))
            try:
                der = base64.b64decode(body)
            except ValueError:
                continue
            mode = gpu_attest_mode_from_der(der)
            if mode:
                return mode
    return None


def measure_hardware() -> Tuple[Dict[str, str], Dict[str, Optional[str]]]:
    """Measure hardware parameters and desired GPU node labels.

    Returns:
        (measurement_props, desired_node_labels)
    """
    cpu_total = get_cpu_total()
    cpu_avg_usage = get_cpu_avg_usage_percent()
    ram_total, ram_used = parse_meminfo()
    disk_total, disk_used = get_disk_usage_bytes()
    has_gpu, gpu_model, product_name, homogeneous = detect_gpu()
    gpu_count = get_gpu_count() if has_gpu else 0
    gpu_memory_total = get_gpu_memory_total() if has_gpu else 0
    processor_model = get_cpu_model()
    processor_arch = get_arch()
    simulated = bool(debug_gpu_products())
    image_props = read_sp_vm_image_props()

    props: Dict[str, str] = {
        "cpu_total": str(cpu_total),
        "cpu_avg_usage": str(cpu_avg_usage),
        "ram_total_bytes": str(ram_total),
        "ram_used_bytes": str(ram_used),
        "disk_total_bytes": str(disk_total),
        "disk_used_bytes": str(disk_used),
        "has_gpu": "true" if has_gpu else "false",
        "gpu_model": gpu_model,
        "gpu_count": str(gpu_count) if has_gpu else "0",
        "gpu_memory_total_bytes": str(gpu_memory_total) if has_gpu else "0",
        "processor_model": processor_model,
        "processor_arch": processor_arch,
        **image_props,
    }
    gpu_attest_mode = read_gpu_attest_mode()
    if gpu_attest_mode:
        props["gpu_attest_mode"] = gpu_attest_mode
    if product_name:
        props["gpu_product_name"] = product_name
    if simulated:
        props["gpu_source"] = "simulated"

    labels = build_gpu_labels_from_detection(
        has_gpu, product_name, homogeneous, gpu_count, simulated=simulated
    )
    return props, labels


def build_measurement_output(
    local_node_id: Optional[str],
    local_state: Dict[str, Any],
) -> PluginOutput:
    """Measure hardware and publish device labels on every tick.

    persistDerivedNodeLabels skips unchanged rows, so repeating the desired set is cheap.
    A local snapshot would stop republishing after SwarmDB rows were deleted.
    """
    props, desired_labels = measure_hardware()
    new_state = dict(local_state)
    new_state.pop(DEVICE_LABELS_SNAPSHOT_KEY, None)

    image_version = props.get("sp_vm_image_version") or ""
    cached = new_state.get(MEASURE_STATE_KEY)
    cached_version = cached.get("sp_vm_image_version") if isinstance(cached, dict) else None
    cached_type = cached.get("sp_vm_evidence_type") if isinstance(cached, dict) else None
    # local_state survives an image upgrade on the persistent disk, so a new
    # cmdline build= must drop the previous image's mrenclave.
    if isinstance(cached, dict) and cached_type in EVIDENCE_TYPES and cached_version == image_version:
        measure_props = {k: v for k, v in cached.items() if isinstance(v, str) and v}
    else:
        measure_props = fetch_sp_vm_measure()
        if measure_props.get("sp_vm_evidence_type"):
            stored = dict(measure_props)
            stored["sp_vm_image_version"] = image_version
            new_state[MEASURE_STATE_KEY] = stored
            measure_props = stored
    props.update(measure_props)
    print(f"[*] Measured hardware properties: {', '.join([k for k, v in props.items() if v])}", file=sys.stderr)

    measurements = []
    for name, value in props.items():
        if value:  # Only include non-empty values
            measurements.append({
                "type": name,
                "node": local_node_id,
                "target_node": local_node_id,
                "value": value
            })

    return PluginOutput(
        status='completed',
        measurements=measurements,
        node_labels=desired_labels,
        local_state=new_state,
    )


# Plugin commands

@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Initial hardware measurement and record as measurements."""
    local_node_id = input_data.local_node_id
    local_state = input_data.local_state or {}

    try:
        return build_measurement_output(local_node_id, local_state)
    except Exception as e:
        print(f"[!] Failed to measure hardware: {e}", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Periodic hardware measurement (runs every 60 seconds)."""
    local_node_id = input_data.local_node_id
    local_state = input_data.local_state or {}

    try:
        return build_measurement_output(local_node_id, local_state)
    except Exception as e:
        print(f"[!] Failed to measure hardware: {e}", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Clean up - no action needed as measurements are time-series."""
    return PluginOutput(
        status='completed',
        local_state={}
    )


if __name__ == "__main__":
    plugin.run()
