"""Finalize must not postpone forever on an etcd container that is gone (SUP-706)."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load(name: str, path: Path):
    for p in (str(RKE2_DIR), str(SDK_DIR)):
        if p not in sys.path:
            sys.path.insert(0, p)
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def main_mod():
    return _load("rke2_main_finalize_etcd_list", RKE2_DIR / "main.py")


def test_first_failed_list_waits_and_records_the_window(main_mod):
    """etcd may be mid-restart with the member still registered — worth another tick."""
    action, state = main_mod.assess_finalize_etcd_list_failure(
        list_err="etcd container not found",
        local_state={},
        now=100.0,
    )
    assert action == "wait"
    assert state["finalize_etcd_list_down_since"] == 100.0


def test_keeps_waiting_inside_the_grace(main_mod):
    action, state = main_mod.assess_finalize_etcd_list_failure(
        list_err="etcd container not found",
        local_state={"finalize_etcd_list_down_since": 100.0},
        now=100.0 + main_mod.FINALIZE_ETCD_LIST_GRACE_SEC - 1,
    )
    assert action == "wait"
    assert state["finalize_etcd_list_down_since"] == 100.0


def test_gives_up_after_the_grace_instead_of_burning_the_leave_budget(main_mod):
    action, state = main_mod.assess_finalize_etcd_list_failure(
        list_err="etcd container not found",
        local_state={"finalize_etcd_list_down_since": 100.0},
        now=100.0 + main_mod.FINALIZE_ETCD_LIST_GRACE_SEC,
    )
    assert action == "skip"
    assert state.get("finalize_etcd_list_down_since") is None


def test_corrupt_marker_restarts_the_grace(main_mod):
    action, state = main_mod.assess_finalize_etcd_list_failure(
        list_err="etcdctl timed out",
        local_state={"finalize_etcd_list_down_since": "not-a-number"},
        now=100.0,
    )
    assert action == "wait"
    assert state["finalize_etcd_list_down_since"] == 100.0


def test_finalize_postpones_on_the_first_unreadable_list(main_mod):
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(
            main_mod,
            "list_etcd_members",
            return_value=(None, "etcd container not found"),
        ),
        patch.object(main_mod, "remove_etcd_member") as remove,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={"etcd_member_id": "d5d8f62c7559e4fc"},
            )
        )

    assert result.status == "postponed"
    assert "Cannot list etcd members yet" in (result.error_message or "")
    assert result.local_state["finalize_etcd_list_down_since"] is not None
    remove.assert_not_called()


def test_finalize_completes_once_the_list_stays_unreadable_past_the_grace(main_mod):
    """The etcd pod is gone for good: nothing to remove from here, destroy may run."""
    opened_at = 1000.0
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(
            main_mod,
            "list_etcd_members",
            return_value=(None, "etcd container not found"),
        ),
        patch.object(
            main_mod.time,
            "time",
            return_value=opened_at + main_mod.FINALIZE_ETCD_LIST_GRACE_SEC,
        ),
        patch.object(main_mod, "remove_etcd_member") as remove,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={
                    "etcd_member_id": "d5d8f62c7559e4fc",
                    "finalize_etcd_list_down_since": opened_at,
                },
            )
        )

    assert result.status == "completed"
    assert result.local_state.get("finalize_etcd_list_down_since") is None
    remove.assert_not_called()


def test_a_readable_list_ends_the_window(main_mod):
    """A list that answers again must not leave a stale wall clock behind."""
    local = {"id": "abc123", "name": "deadbeef-1", "peer_urls": [], "client_urls": []}
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(
            main_mod,
            "list_etcd_members",
            side_effect=[([local], None), ([], None)],
        ),
        patch.object(main_mod, "find_local_etcd_member", return_value=local),
        patch.object(main_mod, "remove_etcd_member", return_value=(True, None)) as remove,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={"finalize_etcd_list_down_since": 100.0},
            )
        )

    assert result.status == "completed"
    assert result.local_state["finalize_etcd_list_down_since"] is None
    remove.assert_called_once_with("abc123")


def test_remove_already_started_still_short_circuits(main_mod):
    """An unreadable list after this node issued the remove was already a completion."""
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(True, None)),
        patch.object(
            main_mod,
            "list_etcd_members",
            return_value=(None, "etcd container not found"),
        ),
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={
                    "etcd_member_id": "abc123",
                    "etcd_member_remove_started": True,
                },
            )
        )

    assert result.status == "completed"


def test_health_forgets_a_cancelled_window(main_mod):
    state = main_mod.clear_finalize_etcd_list_grace({"finalize_etcd_list_down_since": 100.0})
    assert state["finalize_etcd_list_down_since"] is None


def test_clearing_an_unset_window_is_a_no_op(main_mod):
    state = {"install_hash": "abc"}
    assert main_mod.clear_finalize_etcd_list_grace(state) is state
