"""Unit tests for authz webhook adapter (build_status, HTTP handler, policy integration)."""

from __future__ import annotations

import importlib.util
import io
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ADAPTER_DIR = Path(__file__).resolve().parents[1] / "configs" / "opa-authz-webhook" / "adapter"
DATA_JSON = Path(__file__).resolve().parents[1] / "configs" / "opa-authz-webhook" / "policies" / "data.json"


def _load_adapter_module():
    os.environ.setdefault("TLS_CERT_FILE", "/tmp/opa-authz-test.crt")
    os.environ.setdefault("TLS_KEY_FILE", "/tmp/opa-authz-test.key")
    os.environ.setdefault("CLIENT_CA_FILE", "/tmp/opa-authz-test-ca.crt")
    os.environ["POLICY_DATA_FILE"] = str(DATA_JSON)

    policy_spec = importlib.util.spec_from_file_location("authz_policy", ADAPTER_DIR / "policy.py")
    assert policy_spec and policy_spec.loader
    policy_mod = importlib.util.module_from_spec(policy_spec)
    sys.modules[policy_spec.name] = policy_mod
    policy_spec.loader.exec_module(policy_mod)

    adapter_spec = importlib.util.spec_from_file_location("authz_adapter", ADAPTER_DIR / "adapter.py")
    assert adapter_spec and adapter_spec.loader
    adapter_mod = importlib.util.module_from_spec(adapter_spec)
    sys.modules[adapter_spec.name] = adapter_mod
    adapter_spec.loader.exec_module(adapter_mod)
    return adapter_mod


@pytest.fixture
def adapter():
    return _load_adapter_module()


def _sample_review(*, verb: str = "get", name: str = "my-app", namespace: str = "user-abc") -> dict:
    attrs: dict[str, str] = {
        "namespace": namespace,
        "verb": verb,
        "group": "",
        "resource": "secrets",
    }
    if name:
        attrs["name"] = name
    return {
        "kind": "SubjectAccessReview",
        "spec": {
            "user": f"system:serviceaccount:{namespace}:ns-editor",
            "resourceAttributes": attrs,
        },
    }


def test_build_status_allow(adapter):
    review = _sample_review()
    status = adapter.build_status("allow", review)
    assert status["allowed"] is True
    assert status["denied"] is False
    assert "allowed" in status["reason"]


def test_build_status_deny(adapter):
    review = _sample_review(name="swarm-pull", verb="patch")
    status = adapter.build_status("deny", review)
    assert status["allowed"] is False
    assert status["denied"] is True
    assert "swarm-pull" in status["reason"]


def test_build_status_no_opinion(adapter):
    review = _sample_review(verb="deletecollection", name="")
    status = adapter.build_status("no_opinion", review)
    assert status["allowed"] is False
    assert status["denied"] is False
    assert "no opinion" in status["reason"]


def test_authorize_denies_patch_swarm_pull(adapter):
    body = json.dumps(_sample_review(verb="patch", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is True


def test_authorize_cross_tenant_secret_is_no_opinion(adapter):
    review = _sample_review(verb="get", name="swarm-pull", namespace="user-other-tenant")
    review["spec"]["user"] = "system:serviceaccount:user-abc:ns-editor"
    body = json.dumps(review).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is False


def test_authorize_allows_get_swarm_pull(adapter):
    body = json.dumps(_sample_review(verb="get", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is True
    assert status["denied"] is False


def test_authorize_degraded_fallback_on_policy_error(adapter):
    body = json.dumps(_sample_review(verb="patch", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    with patch.object(adapter, "evaluate", side_effect=RuntimeError("policy boom")):
        adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is True


class _FakeSocket:
    def __init__(self, data: bytes):
        self._read = io.BytesIO(data)
        self.response = io.BytesIO()

    def makefile(self, mode: str, bufsize: int = -1):
        if "r" in mode:
            return self._read
        return self.response

    def sendall(self, data: bytes) -> None:
        self.response.write(data)


def _serve_once(adapter, request_bytes: bytes) -> str:
    sock = _FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)
    return sock.response.getvalue().decode()


def test_healthz_response_is_delimited(adapter):
    """HTTP/1.1 with no Content-Length hangs keep-alive clients until they time out (SUP-354)."""
    raw = _serve_once(adapter, b"GET /healthz HTTP/1.1\r\nHost: x\r\n\r\n")
    headers, body = raw.split("\r\n\r\n", 1)

    assert "200" in headers.splitlines()[0]
    assert "Content-Length: 3" in headers
    assert body == "ok\n"


def test_health_alias_and_unknown_get_are_delimited(adapter):
    health = _serve_once(adapter, b"GET /health HTTP/1.1\r\nHost: x\r\n\r\n")
    assert "Content-Length: 3" in health.split("\r\n\r\n", 1)[0]

    missing = _serve_once(adapter, b"GET /nope HTTP/1.1\r\nHost: x\r\n\r\n")
    headers = missing.split("\r\n\r\n", 1)[0]
    assert "404" in headers.splitlines()[0]
    assert "Content-Length: 0" in headers


def test_rejected_post_bodies_are_delimited(adapter):
    body = b"not json"
    bad_json = _serve_once(
        adapter,
        b"POST /authorize HTTP/1.1\r\nContent-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body,
    )
    assert "400" in bad_json.splitlines()[0]
    assert "Content-Length: 0" in bad_json.split("\r\n\r\n", 1)[0]

    wrong_kind = json.dumps({"kind": "Pod"}).encode()
    not_a_review = _serve_once(
        adapter,
        b"POST /authorize HTTP/1.1\r\nContent-Length: " + str(len(wrong_kind)).encode() + b"\r\n\r\n" + wrong_kind,
    )
    assert "400" in not_a_review.splitlines()[0]
    assert "Content-Length: 0" in not_a_review.split("\r\n\r\n", 1)[0]

    unknown_path = _serve_once(adapter, b"POST /nope HTTP/1.1\r\nContent-Length: 0\r\n\r\n")
    assert "404" in unknown_path.splitlines()[0]
    assert "Content-Length: 0" in unknown_path.split("\r\n\r\n", 1)[0]
