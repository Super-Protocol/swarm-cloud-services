"""End-to-end check of the adapter healthz mTLS probe against the real adapter (SUP-354).

The server here is `adapter.Handler` itself, behind the certs `generate-certs.sh` issues,
and the client is the real `_probe_adapter_healthz_mtls` shelling out to real curl. Both
halves of SUP-354 only reproduce in that combination:

- the webhook server cert carries Service DNS SANs and no 127.0.0.1, so probing the IP
  fails verification;
- /healthz answered HTTP/1.1 with no Content-Length, so a keep-alive client blocked until
  the probe's timeout fired.

A stub server with well-formed responses hides the second one, which is exactly how it
reached a QA stand.
"""

from __future__ import annotations

import http.server
import importlib.util
import os
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
from pathlib import Path
from unittest.mock import patch

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]
ASSETS = RKE2_DIR / "configs" / "opa-authz-webhook"
GEN_CERTS = ASSETS / "configs" / "generate-certs.sh"
ADAPTER_DIR = ASSETS / "adapter"

pytestmark = pytest.mark.skipif(
    not (shutil.which("openssl") and shutil.which("curl")),
    reason="needs openssl and curl",
)


def _load_opa_module():
    spec = importlib.util.spec_from_file_location("opa_authz_webhook", RKE2_DIR / "opa_authz_webhook.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _load_adapter_module():
    os.environ.setdefault("TLS_CERT_FILE", "/tmp/opa-authz-test.crt")
    os.environ.setdefault("TLS_KEY_FILE", "/tmp/opa-authz-test.key")
    os.environ.setdefault("CLIENT_CA_FILE", "/tmp/opa-authz-test-ca.crt")
    os.environ["POLICY_DATA_FILE"] = str(ASSETS / "policies" / "data.json")

    policy_spec = importlib.util.spec_from_file_location("authz_policy", ADAPTER_DIR / "policy.py")
    assert policy_spec and policy_spec.loader
    policy_mod = importlib.util.module_from_spec(policy_spec)
    sys.modules[policy_spec.name] = policy_mod
    policy_spec.loader.exec_module(policy_mod)

    adapter_spec = importlib.util.spec_from_file_location("authz_adapter", ADAPTER_DIR / "adapter.py")
    assert adapter_spec and adapter_spec.loader
    adapter_mod = importlib.util.module_from_spec(adapter_spec)
    sys.modules[adapter_spec.name] = adapter_mod
    adapter_spec.loader.exec_module(adapter_mod)
    return adapter_mod


@pytest.fixture(scope="module")
def certs(tmp_path_factory) -> Path:
    out = tmp_path_factory.mktemp("opa-authz-certs")
    subprocess.run(["bash", str(GEN_CERTS), str(out)], check=True, capture_output=True, text=True, timeout=180)
    return out


@pytest.fixture
def adapter_server(certs: Path):
    """Run the real adapter Handler over mTLS on an ephemeral loopback port."""
    adapter = _load_adapter_module()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certs / "tls.crt", certs / "tls.key")
    ctx.verify_mode = ssl.CERT_REQUIRED
    ctx.load_verify_locations(cafile=str(certs / "client-ca.crt"))

    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), adapter.Handler)
    httpd.daemon_threads = True
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield httpd.server_address[1]
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=5)


def _material(certs: Path) -> tuple[str, str, str]:
    return (
        (certs / "ca.crt").read_text(),
        (certs / "apiserver-client.crt").read_text(),
        (certs / "apiserver-client.key").read_text(),
    )


def test_server_cert_has_no_loopback_san(certs: Path):
    text = subprocess.run(
        ["openssl", "x509", "-in", str(certs / "tls.crt"), "-noout", "-text"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    assert "DNS:opa-authz-webhook.opa-authz-system.svc" in text
    assert "IP Address:127.0.0.1" not in text


def test_probe_passes_promptly_against_the_real_adapter(certs: Path, adapter_server: int):
    """Passes, and well inside the 10 s timeout — a hang is the SUP-354 failure mode."""
    module = _load_opa_module()

    with (
        patch.object(module, "fetch_tls_material_from_cluster", return_value=_material(certs)),
        patch.object(module, "OPA_AUTHZ_WEBHOOK_LISTEN_PORT", adapter_server),
    ):
        started = time.monotonic()
        ok, err = module._probe_adapter_healthz_mtls()
        elapsed = time.monotonic() - started

    assert (ok, err) == (True, None)
    assert elapsed < 5, f"probe took {elapsed:.1f}s — it is waiting on something"


def test_adapter_healthz_delimits_its_body(certs: Path, adapter_server: int):
    """curl must see the response end without the server closing the connection."""
    r = subprocess.run(
        [
            "curl",
            "-sS",
            "-i",
            "--resolve",
            f"opa-authz-webhook.opa-authz-system.svc:{adapter_server}:127.0.0.1",
            "--cert",
            str(certs / "apiserver-client.crt"),
            "--key",
            str(certs / "apiserver-client.key"),
            "--cacert",
            str(certs / "ca.crt"),
            f"https://opa-authz-webhook.opa-authz-system.svc:{adapter_server}/healthz",
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert r.returncode == 0, r.stderr
    headers = r.stdout.split("\r\n\r\n", 1)[0].lower()
    assert "content-length:" in headers or "transfer-encoding:" in headers
    assert r.stdout.endswith("ok\n")


def test_loopback_url_is_the_regression_it_looks_like(certs: Path, adapter_server: int):
    """Documents the first half of SUP-354: the IP URL fails on the cert's SAN list."""
    r = subprocess.run(
        [
            "curl",
            "-fsS",
            "--cert",
            str(certs / "apiserver-client.crt"),
            "--key",
            str(certs / "apiserver-client.key"),
            "--cacert",
            str(certs / "ca.crt"),
            f"https://127.0.0.1:{adapter_server}/healthz",
        ],
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert r.returncode != 0
    assert "subject name" in r.stderr.lower() or "certificate" in r.stderr.lower()


def test_probe_reports_a_closed_port_instead_of_hanging(certs: Path):
    module = _load_opa_module()
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        free_port = s.getsockname()[1]

    with (
        patch.object(module, "fetch_tls_material_from_cluster", return_value=_material(certs)),
        patch.object(module, "OPA_AUTHZ_WEBHOOK_LISTEN_PORT", free_port),
    ):
        ok, err = module._probe_adapter_healthz_mtls()

    assert ok is False
    assert err
