"""Unit tests for OPA authz webhook reconcile (leader vs follower)."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

RKE2_DIR = Path(__file__).resolve().parents[1]


def _load_opa_module():
    mod_path = RKE2_DIR / "opa_authz_webhook.py"
    spec = importlib.util.spec_from_file_location("opa_authz_webhook", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _base_state(*, leader_id: str = "leader-1", local_id: str = "worker-1") -> dict:
    return {
        "cluster": {"leader_node": leader_id},
        "rke2NodeProperties": [
            {"node_id": leader_id, "name": "k8s_node_ready", "value": "true"},
            {"node_id": local_id, "name": "k8s_node_ready", "value": "true"},
        ],
    }


def test_follower_reconcile_wires_without_apply():
    module = _load_opa_module()
    state = _base_state()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "apply_namespace_only") as mock_ns,
        patch.object(module, "apply_kustomize") as mock_apply,
        patch.object(module, "wire_rke2_apiserver_if_needed", return_value=(None, {"wired": True})) as mock_wire,
        patch.object(module, "kubectl_run") as mock_kubectl,
        patch.object(module, "wait_opa_authz_workload_ready", return_value=(True, None)) as mock_wait,
        patch.object(module, "_local_opa_authz_pod_ready", return_value=(True, None)),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        mock_kubectl.return_value = MagicMock(returncode=0)

        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "worker-1",
            {"api_ready": True},
            is_leader=False,
            is_bootstrap=False,
            require_swarm_k8s_node_ready=True,
        )

    assert msg is None
    assert props == {"opa_authz_webhook_ready": "true"}
    assert st == {"wired": True}
    mock_ns.assert_not_called()
    mock_apply.assert_not_called()
    mock_wire.assert_called_once()
    mock_wait.assert_called_once()


def test_leader_reconcile_applies_and_wires():
    module = _load_opa_module()
    state = _base_state(local_id="leader-1")

    with (
        patch.object(module, "apply_namespace_only", return_value=(True, None)),
        patch.object(module, "ensure_tls_secret_leader", return_value=(True, None)),
        patch.object(module, "remove_legacy_opa_deployment"),
        patch.object(module, "apply_kustomize", return_value=(True, None)) as mock_apply,
        patch.object(module, "wait_opa_authz_workload_ready", return_value=(True, None)),
        patch.object(module, "_local_opa_authz_pod_ready", return_value=(True, None)),
        patch.object(module, "wire_rke2_apiserver_if_needed", return_value=(None, {"wired": True})) as mock_wire,
    ):
        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "leader-1",
            {},
            is_leader=True,
            is_bootstrap=True,
            require_swarm_k8s_node_ready=True,
        )

    assert msg is None
    assert props == {"opa_authz_webhook_ready": "true"}
    assert st == {"wired": True}
    mock_apply.assert_called_once()
    mock_wire.assert_called_once()


def test_follower_postpones_until_tls_secret_exists():
    module = _load_opa_module()
    state = _base_state()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "kubectl_run") as mock_kubectl,
        patch.object(module, "wait_opa_authz_workload_ready") as mock_wait,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        mock_kubectl.return_value = MagicMock(returncode=1)

        msg, props, st = module.reconcile_opa_authz_webhook(
            state,
            "worker-1",
            {},
            is_leader=False,
            is_bootstrap=False,
            require_swarm_k8s_node_ready=True,
        )

    assert msg == "Waiting for opa-authz TLS secret from leader"
    assert props == {}
    assert st == {}
    mock_wait.assert_not_called()


def test_health_check_light_only_requires_deploy():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)) as mock_exists,
        patch.object(module, "_deployment_ready_quick") as mock_ready,
        patch.object(module, "_probe_adapter_healthz_mtls") as mock_mtls,
        patch.object(module, "_check_sar_policy") as mock_sar,
        patch.object(module, "_check_leader_authorization_config") as mock_authz,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=False)

    assert ok is True
    assert err is None
    mock_exists.assert_called_once()
    mock_ready.assert_not_called()
    mock_mtls.assert_not_called()
    mock_sar.assert_not_called()
    mock_authz.assert_not_called()


def test_health_check_deep_runs_all_probes():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)) as mock_ready,
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)) as mock_mtls,
        patch.object(module, "_check_sar_policy", return_value=(True, None)) as mock_sar,
        patch.object(module, "_check_leader_authorization_config", return_value=(True, None)) as mock_authz,
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is True
    assert err is None
    mock_ready.assert_called_once()
    mock_mtls.assert_called_once()
    mock_sar.assert_called_once()
    mock_authz.assert_called_once()


def test_health_check_deep_postpones_when_sar_policy_fails():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)),
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)),
        patch.object(
            module,
            "_check_sar_policy",
            return_value=(False, "authz SAR health: expected deny on patch secret swarm-pull for tenant SA"),
        ),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert "swarm-pull" in (err or "")


def test_health_check_deep_postpones_when_adapter_not_ready():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(False, "deployment not ready")),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert err == "deployment not ready"


def test_append_kube_apiserver_authorization_config_inserts_into_existing_block(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text("kube-apiserver-arg:\n  - \"feature-gates=Foo=true\"\n")

    modified = module.append_kube_apiserver_authorization_config(cfg)

    assert modified is True
    text = cfg.read_text()
    assert 'authorization-config=/etc/rancher/rke2/authz-config.yaml' in text
    assert text.index("feature-gates") < text.index("authorization-config")


def test_append_kube_apiserver_authorization_config_appends_new_block(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text("write-kubeconfig-mode: 0644\n")

    modified = module.append_kube_apiserver_authorization_config(cfg)

    assert modified is True
    assert "kube-apiserver-arg:" in cfg.read_text()
    assert "authorization-config=" in cfg.read_text()


def test_append_kube_apiserver_authorization_config_idempotent(tmp_path):
    module = _load_opa_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text('kube-apiserver-arg:\n  - "authorization-config=/etc/rancher/rke2/authz-config.yaml"\n')

    assert module.append_kube_apiserver_authorization_config(cfg) is False


def test_health_check_skipped_when_opa_authz_disabled():
    module = _load_opa_module()

    with patch.dict("os.environ", {"OPA_AUTHZ_DISABLED": "true"}):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is True
    assert err is None


def test_health_check_deep_postpones_when_authz_config_missing():
    module = _load_opa_module()
    kubeconfig = MagicMock()
    kubeconfig.exists.return_value = True

    with (
        patch.object(module, "_deployment_exists", return_value=(True, None)),
        patch.object(module, "_deployment_ready_quick", return_value=(True, None)),
        patch.object(module, "_probe_adapter_healthz_mtls", return_value=(True, None)),
        patch.object(module, "_check_sar_policy", return_value=(True, None)),
        patch.object(
            module,
            "_check_leader_authorization_config",
            return_value=(False, "RKE2 config missing authorization-config kube-apiserver-arg"),
        ),
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
    ):
        ok, err = module.health_check_opa_authz_webhook(deep=True)

    assert ok is False
    assert "authorization-config" in (err or "")


def test_probe_adapter_healthz_requests_the_name_the_cert_carries():
    """The adapter listens on loopback but serves a cert with Service DNS SANs only.

    Probing https://127.0.0.1 fails verification (SUP-354), so the probe must ask for
    WEBHOOK_TLS_SERVER_NAME and pin it to loopback with --resolve, mirroring the
    tls-server-name kube-apiserver uses in authz-webhook.kubeconfig.
    """
    module = _load_opa_module()
    host = module.WEBHOOK_TLS_SERVER_NAME
    port = module.OPA_AUTHZ_WEBHOOK_LISTEN_PORT

    with (
        patch.object(module, "fetch_tls_material_from_cluster", return_value=("ca", "crt", "key")),
        patch.object(module.subprocess, "run", return_value=MagicMock(returncode=0, stdout="ok", stderr="")) as mock_run,
    ):
        ok, err = module._probe_adapter_healthz_mtls()

    assert (ok, err) == (True, None)
    argv = mock_run.call_args.args[0]
    assert argv[-1] == f"https://{host}:{port}/healthz"
    assert f"{host}:{port}:127.0.0.1" in argv
    assert argv[argv.index(f"{host}:{port}:127.0.0.1") - 1] == "--resolve"
    assert not any(a.startswith("https://127.0.0.1") for a in argv)
    assert "-k" not in argv and "--insecure" not in argv
    # A keep-alive response with an undelimited body blocked this probe until its
    # timeout on the SUP-354 stand; a one-shot probe asks the connection to close.
    assert "Connection: close" in argv
    assert argv[argv.index("Connection: close") - 1] == "-H"


def test_sar_probe_skipped_until_a_tenant_namespace_exists():
    """No cluster space yet means no user-* namespace and nothing for the policy to decide.

    Postponing here parked rke2 at phase=Degraded on a healthy, tenant-less cluster (SUP-354).
    """
    module = _load_opa_module()

    with (
        patch.object(module, "_find_tenant_namespace", return_value=(None, None)),
        patch.object(module, "_subject_access_review", side_effect=AssertionError("must not probe")) as mock_sar,
    ):
        ok, err = module._check_sar_policy()

    assert (ok, err) == (True, None)
    mock_sar.assert_not_called()


def test_sar_probe_still_asserts_policy_once_a_tenant_exists():
    module = _load_opa_module()
    # Tenant SA must be allowed get on swarm-pull; a deny means the policy is wrong.
    reviews = {
        ("get", "swarm-pull"): {"status": {"denied": True}},
    }

    def fake_review(*, user, namespace, verb, resource, name=None):
        return reviews.get((verb, name), {"status": {"allowed": True}}), None

    with (
        patch.object(module, "_find_tenant_namespace", return_value=("user-abc", None)),
        patch.object(module, "_subject_access_review", side_effect=fake_review),
    ):
        ok, err = module._check_sar_policy()

    assert ok is False
    assert "swarm-pull" in (err or "")


def test_sar_probe_postpones_when_the_namespace_list_fails():
    """A kubectl hiccup must not read as "no tenant" and wave the assertion through."""
    module = _load_opa_module()

    with (
        patch.object(module, "_find_tenant_namespace", return_value=(None, "Unable to connect to the server")),
        patch.object(module, "_subject_access_review", side_effect=AssertionError("must not probe")),
    ):
        ok, err = module._check_sar_policy()

    assert ok is False
    assert "Unable to connect to the server" in (err or "")
