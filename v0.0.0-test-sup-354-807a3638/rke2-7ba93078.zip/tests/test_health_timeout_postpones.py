"""A health probe that times out postpones; it must not become status=error (SUP-354).

The SDK turns an escaping exception into status=error, and the worker answers consecutive
health errors with a re-apply — which is how a healthy cluster ended up re-applying rke2
every ~80s while its 10 s adapter probe hung.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    spec = importlib.util.spec_from_file_location("rke2_main_health_timeout", RKE2_DIR / "main.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _input(module):
    return module.PluginInput(
        command="health",
        local_node_id="node-1",
        state={},
        local_state={"is_bootstrap": True},
    )


def test_health_postpones_on_probe_timeout():
    module = _load_main_module()
    timeout = subprocess.TimeoutExpired(cmd=["curl", "-fsS", "https://…/healthz"], timeout=10)

    with patch.object(module, "_check_rke2_health", side_effect=timeout):
        out = module.handle_health(_input(module))

    assert out.status == "postponed"
    assert "timed out after 10s" in (out.error_message or "")
    assert "curl" in (out.error_message or "")
    assert out.local_state == {"is_bootstrap": True}


def test_health_still_reports_real_errors():
    module = _load_main_module()
    expected = module.PluginOutput(status="error", error_message="Failed to check node")

    with patch.object(module, "_check_rke2_health", return_value=expected):
        out = module.handle_health(_input(module))

    assert out.status == "error"
