"""Unit tests for hw-measurement GPU label canon and skip-if-unchanged."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

HW_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = HW_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(HW_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = HW_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("hw_measurement_main", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_build_gpu_labels_no_gpu_clears_all():
    m = _load_main_module()
    labels = m.build_gpu_labels_from_detection(False, None, None, 0)
    assert labels == {
        m.GPU_PRESENT_LABEL: "false",
        m.GPU_PRODUCT_LABEL: None,
        m.GPU_COUNT_LABEL: None,
        m.GPU_HOMOGENEOUS_LABEL: None,
        m.GPU_SIMULATED_LABEL: None,
    }


def test_build_gpu_labels_homogeneous_product():
    m = _load_main_module()
    labels = m.build_gpu_labels_from_detection(True, "NVIDIA A100-SXM4-40GB", True, 2)
    assert labels[m.GPU_PRESENT_LABEL] == "true"
    assert labels[m.GPU_PRODUCT_LABEL] == "NVIDIA A100-SXM4-40GB"
    assert labels[m.GPU_COUNT_LABEL] == "2"
    assert labels[m.GPU_HOMOGENEOUS_LABEL] == "true"
    assert labels[m.GPU_SIMULATED_LABEL] is None


def test_build_gpu_labels_heterogeneous():
    m = _load_main_module()
    labels = m.build_gpu_labels_from_detection(True, None, False, 2)
    assert labels[m.GPU_PRESENT_LABEL] == "true"
    assert labels[m.GPU_PRODUCT_LABEL] is None
    assert labels[m.GPU_COUNT_LABEL] == "2"
    assert labels[m.GPU_HOMOGENEOUS_LABEL] == "false"


def test_build_gpu_labels_present_without_product():
    m = _load_main_module()
    labels = m.build_gpu_labels_from_detection(True, None, None, 1)
    assert labels[m.GPU_PRESENT_LABEL] == "true"
    assert labels[m.GPU_PRODUCT_LABEL] is None
    assert labels[m.GPU_COUNT_LABEL] == "1"
    assert labels[m.GPU_HOMOGENEOUS_LABEL] is None


def test_build_gpu_labels_present_zero_count_clears_count():
    m = _load_main_module()
    labels = m.build_gpu_labels_from_detection(True, "Tesla T4", True, 0)
    assert labels[m.GPU_PRESENT_LABEL] == "true"
    assert labels[m.GPU_COUNT_LABEL] is None


def test_parse_nvidia_smi_names():
    m = _load_main_module()
    assert m.parse_nvidia_smi_names("NVIDIA A100-SXM4-40GB\nNVIDIA A100-SXM4-40GB\n") == [
        "NVIDIA A100-SXM4-40GB",
        "NVIDIA A100-SXM4-40GB",
    ]


def test_debug_gpu_env_homogeneous(monkeypatch):
    m = _load_main_module()
    monkeypatch.setenv(m.DEBUG_GPU_PRODUCT_ENV, "NVIDIA A100-SXM4-40GB")
    monkeypatch.setenv(m.DEBUG_GPU_COUNT_ENV, "2")
    monkeypatch.setenv(m.DEBUG_GPU_MEMORY_MIB_ENV, "40960")

    has_gpu, display, product, homogeneous = m.detect_gpu()
    assert has_gpu is True
    assert product == "NVIDIA A100-SXM4-40GB"
    assert homogeneous is True
    assert display == "NVIDIA A100-SXM4-40GB"
    assert m.get_gpu_count() == 2
    assert m.get_gpu_memory_total() == 40960 * 1024 * 1024

    labels = m.build_gpu_labels_from_detection(
        has_gpu, product, homogeneous, m.get_gpu_count(), simulated=True
    )
    assert labels[m.GPU_PRESENT_LABEL] == "true"
    assert labels[m.GPU_PRODUCT_LABEL] == "NVIDIA A100-SXM4-40GB"
    assert labels[m.GPU_COUNT_LABEL] == "2"
    assert labels[m.GPU_HOMOGENEOUS_LABEL] == "true"
    assert labels[m.GPU_SIMULATED_LABEL] == "true"


def test_debug_gpu_env_heterogeneous(monkeypatch):
    m = _load_main_module()
    monkeypatch.setenv(m.DEBUG_GPU_PRODUCT_ENV, "NVIDIA A100-SXM4-40GB, Tesla T4")
    has_gpu, display, product, homogeneous = m.detect_gpu()
    assert has_gpu is True
    assert product is None
    assert homogeneous is False
    assert "Tesla T4" in display
    assert m.get_gpu_count() == 2

    labels = m.build_gpu_labels_from_detection(
        has_gpu, product, homogeneous, m.get_gpu_count(), simulated=True
    )
    assert labels[m.GPU_PRODUCT_LABEL] is None
    assert labels[m.GPU_COUNT_LABEL] == "2"
    assert labels[m.GPU_HOMOGENEOUS_LABEL] == "false"
    assert labels[m.GPU_SIMULATED_LABEL] == "true"


def test_debug_gpu_env_unset_does_not_force_gpu(monkeypatch):
    m = _load_main_module()
    monkeypatch.delenv(m.DEBUG_GPU_PRODUCT_ENV, raising=False)
    monkeypatch.setattr(m, "try_cmd", lambda _cmd: "")
    monkeypatch.setattr(m.os.path, "exists", lambda _p: False)
    monkeypatch.setattr(m.os.path, "isdir", lambda _p: False)
    has_gpu, display, product, homogeneous = m.detect_gpu()
    assert has_gpu is False
    assert product is None
    assert homogeneous is None
    assert display == ""


def test_measure_hardware_marks_debug_gpu_as_simulated(monkeypatch):
    m = _load_main_module()
    monkeypatch.setenv(m.DEBUG_GPU_PRODUCT_ENV, "NVIDIA A100-SXM4-40GB")
    monkeypatch.setenv(m.DEBUG_GPU_COUNT_ENV, "1")

    props, labels = m.measure_hardware()
    assert props["gpu_source"] == "simulated"
    assert props["has_gpu"] == "true"
    assert labels[m.GPU_SIMULATED_LABEL] == "true"
    assert labels[m.GPU_PRODUCT_LABEL] == "NVIDIA A100-SXM4-40GB"


def test_measure_hardware_clears_simulated_marker_without_debug_env(monkeypatch):
    m = _load_main_module()
    monkeypatch.delenv(m.DEBUG_GPU_PRODUCT_ENV, raising=False)
    monkeypatch.delenv(m.DEBUG_GPU_COUNT_ENV, raising=False)
    monkeypatch.delenv(m.DEBUG_GPU_MEMORY_MIB_ENV, raising=False)
    monkeypatch.setattr(m, "try_cmd", lambda _cmd: "")
    monkeypatch.setattr(m.os.path, "exists", lambda _p: False)
    monkeypatch.setattr(m.os.path, "isdir", lambda _p: False)

    props, labels = m.measure_hardware()
    assert "gpu_source" not in props
    assert props["has_gpu"] == "false"
    assert labels[m.GPU_SIMULATED_LABEL] is None
    assert labels[m.GPU_PRESENT_LABEL] == "false"


def test_build_measurement_output_republishes_labels_every_tick(monkeypatch):
    m = _load_main_module()
    desired = m.build_gpu_labels_from_detection(True, "Tesla T4", True, 1)
    props = {"cpu_total": "4", "has_gpu": "true", "gpu_model": "Tesla T4"}

    monkeypatch.setattr(m, "measure_hardware", lambda: (props, desired))

    out1 = m.build_measurement_output("node-a", {m.DEVICE_LABELS_SNAPSHOT_KEY: {"stale": "true"}})
    assert out1.node_labels == desired
    assert m.DEVICE_LABELS_SNAPSHOT_KEY not in out1.local_state

    out2 = m.build_measurement_output("node-a", out1.local_state)
    assert out2.node_labels == desired
    assert out2.measurements
