#!/usr/bin/env python3

import os
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from provision_plugin_sdk import (
    PluginInput, PluginOutput, ProvisionPlugin,
    build_image_evidence_props, read_manifest_version,
)

SERVICE_UNIT = "auth-service.service"
SERVICE_NAME = SERVICE_UNIT.removesuffix(".service")
SERVICE_PATH = Path(f"/etc/systemd/system/{SERVICE_UNIT}")
CONTAINER_NAME = "auth-service"

AUTH_IMAGE_REGISTRY = "ghcr.io"
AUTH_IMAGE_REPO = "super-protocol/swarm-cloud/auth-service"
DEFAULT_AUTH_IMAGE_TAG = "latest"

PROPERTY_PREFIX = "auth_service"
NODE_READY_PROPERTY = f"{PROPERTY_PREFIX}_node_ready"
SCHEMA_INITIALIZED_PROPERTY = f"{PROPERTY_PREFIX}_schema_initialized"


BASE_DIR = "/etc/auth-service"
CONFIG_PATH = Path(f"{BASE_DIR}/configuration.yaml")

AUTH_SERVICE_YAML_SECRET_ID = "auth_service_yaml"
AUTH_SERVICE_OIDC_YAML_SECRET_ID = "auth_service_oidc_yaml"
COCKROACH_ADMIN_DATABASE = "defaultdb"
AUTH_DATABASE_NAME = "auth"
AUTH_DATABASE_SCHEMA = "auth"

DEFAULT_PORT = 3002
METRICS_PORT = 9000
DEFAULT_LOG_LEVEL = "info"

BASE_CONFIG_TEMPLATE = """# Service port
port: {{PORT}}

# Logging level: fatal, error, warn, info, debug, trace
logLevel: "{{LOG_LEVEL}}"

# PostgreSQL (CockroachDB wire protocol)
postgresql:
  host: "{{POSTGRES_HOST}}"
  port: {{POSTGRES_PORT}}
  user: "{{POSTGRES_USER}}"
  password: "{{POSTGRES_PASSWORD}}"
  database: "{{POSTGRES_DATABASE}}"
  schema: "{{POSTGRES_SCHEMA}}"

# Better Auth configuration
betterAuth:
    secret: "{{BETTER_AUTH_SECRET}}"
    baseURL: "{{BETTER_AUTH_BASE_URL}}"
    siweDomain: "{{BETTER_AUTH_SIWE_DOMAIN}}"
    runMigrationsOnStartup: {{RUN_MIGRATIONS}}
    defaultCookieAttributes:
        sameSite: "lax"
        secure: true
{{OIDC_PROVIDER_BLOCK}}
{{OAUTH_BLOCK}}

devTools:
    enabled: false

metrics:
    defaultMetrics:
        enabled: true
    mode: pull
    push:
        enabled: false
    pull:
        enabled: true
        port: {{METRICS_PORT}}
        path: /metrics
"""

plugin = ProvisionPlugin()


def _node_ready_props(value: Optional[str]) -> Dict[str, Optional[str]]:
    return {NODE_READY_PROPERTY: value}


def get_image_ref_from_env() -> str:
    explicit_image = os.environ.get("AUTH_SERVICE_IMAGE")
    if explicit_image and explicit_image.strip():
        return explicit_image.strip()

    tag = get_image_tag_from_env()
    return f"{AUTH_IMAGE_REGISTRY}/{AUTH_IMAGE_REPO}:{tag}"


def get_image_tag_from_env() -> str:
    tag = os.environ.get("AUTH_SERVICE_TAG")
    if tag:
        return tag

    try:
        manifest_path = Path(__file__).parent / "manifest.yaml"
        if manifest_path.exists():
            import yaml

            with open(manifest_path, "r") as f:
                manifest = yaml.safe_load(f)
            return manifest.get("version", DEFAULT_AUTH_IMAGE_TAG)
    except Exception as e:
        print(f"[!] Failed to read manifest version: {e}", file=sys.stderr)

    return DEFAULT_AUTH_IMAGE_TAG


def pull_image(image_ref: str) -> None:
    subprocess.run(["podman", "pull", image_ref], check=True)


def create_systemd_service(image_ref: str, host_bind_ip: str) -> None:
    if not isinstance(host_bind_ip, str) or not host_bind_ip.strip():
        raise ValueError("host_bind_ip is required (local WireGuard tunnel IP)")

    host_bind_ip = host_bind_ip.strip()
    config_dir = Path(BASE_DIR)
    config_file = CONFIG_PATH

    service_content = f"""[Unit]
Description=Auth Service (Podman Container)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=-/usr/bin/podman stop {CONTAINER_NAME}
ExecStartPre=-/usr/bin/podman rm {CONTAINER_NAME}
ExecStart=/usr/bin/podman run \\
    --name {CONTAINER_NAME} \\
    --rm \\
    --network=host \
    -v {config_dir}:{config_dir}:ro \\
    -e NODE_ENV=production \\
    -e AUTH_CONFIG_PATH={config_file} \\
    {image_ref}
ExecStop=/usr/bin/podman stop {CONTAINER_NAME}
Restart=always
RestartSec=10
User=root
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    SERVICE_PATH.write_text(service_content, encoding="utf-8")
    subprocess.run(["systemctl", "daemon-reload"], check=True)


def is_service_active(service: str) -> tuple[bool, Optional[str]]:
    try:
        result = subprocess.run(
            ["systemctl", "is-active", service],
            capture_output=True,
            text=True,
            check=False,
        )
        active = result.stdout.strip() == "active"
        return active, None if active else f"Service status: {result.stdout.strip() or 'inactive'}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def check_state_dependencies(state_json: Dict[str, Any]) -> Optional[str]:
    cockroach_nodes = state_json.get("cockroachNodes", [])
    if not isinstance(cockroach_nodes, list) or not cockroach_nodes:
        return "Waiting for dependency cockroachNodes"
    if not any(
        isinstance(node, dict)
        and str(node.get("ready")).lower() == "true"
        and isinstance(node.get("ip"), str)
        and node.get("ip", "").strip()
        for node in cockroach_nodes
    ):
        return "Waiting for at least one CockroachDB node to be ready"

    swarm_domain = state_json.get("swarmDomain")
    if not isinstance(swarm_domain, str) or not swarm_domain.strip():
        return "Waiting for dependency swarmDomain"

    # Ensure it's usable (no scheme/path) for SIWE and base URL building.
    if not _normalize_domain(swarm_domain):
        return "Waiting for dependency swarmDomain"

    return None


def _pick_persistent_node(current_nodes: List[Dict[str, Any]], local_state_nodes: Any) -> Dict[str, Any]:
    if not current_nodes:
        raise ValueError("current_nodes must be non-empty")

    if isinstance(local_state_nodes, list) and local_state_nodes and isinstance(local_state_nodes[0], dict):
        preferred = local_state_nodes[0]
        preferred_ip = preferred.get("ip")
        if preferred_ip:
            for node in current_nodes:
                if node.get("ip") == preferred_ip:
                    return node

    return current_nodes[0]


def get_secret_from_swarmdb(state_json: Dict[str, Any], secret_id: str) -> Optional[str]:
    secrets = state_json.get("swarmSecrets", [])
    if not isinstance(secrets, list):
        return None
    for secret in secrets:
        if isinstance(secret, dict) and secret.get("id") == secret_id:
            value = secret.get("value")
            return value if isinstance(value, str) else None
    return None


def _normalize_domain(domain: str) -> str:
    d = domain.strip()
    if d.startswith("https://"):
        d = d[len("https://") :]
    elif d.startswith("http://"):
        d = d[len("http://") :]
    return d.strip().strip("/")


def get_node_tunnel_ip(node_id: str, wg_props: List[Dict[str, Any]]) -> Optional[str]:
    for prop in wg_props:
        if not isinstance(prop, dict):
            continue
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            value = prop.get("value")
            return value if isinstance(value, str) and value else None
    return None


def get_cockroach_connection_info(local_node_id: str, state_json: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """CockroachDB connection via WireGuard, preferring the local ready node."""
    cockroach_nodes = state_json.get("cockroachNodes", [])
    if not isinstance(cockroach_nodes, list):
        return None

    def build_conn(host: str) -> Dict[str, Any]:
        return {
            "host": host,
            "port": 26257,
            "username": "root",
            "password": "",
            "database": COCKROACH_ADMIN_DATABASE,
        }

    fallback_host = None
    for node in cockroach_nodes:
        if not isinstance(node, dict):
            continue
        node_id = node.get("node_id")
        host = node.get("ip")
        if str(node.get("ready")).lower() != "true":
            continue
        if isinstance(host, str) and host.strip():
            normalized_host = host.strip()
            if node_id == local_node_id:
                return build_conn(normalized_host)
            if fallback_host is None:
                fallback_host = normalized_host

    if fallback_host is not None:
        return build_conn(fallback_host)

    return None


def initialize_schema_if_needed(
    local_node_id: str,
    state_json: Dict[str, Any],
    image_ref: str,
) -> tuple[bool, Optional[str]]:
    cluster_properties = state_json.get("clusterProperties", [])
    schema_initialized = any(
        isinstance(prop, dict)
        and prop.get("name") == SCHEMA_INITIALIZED_PROPERTY
        and prop.get("value") == "true"
        for prop in cluster_properties
    )
    if schema_initialized:
        return True, None

    if not is_local_node_leader(local_node_id, state_json):
        return False, "Waiting for leader to initialize schema"

    cockroach_info = get_cockroach_connection_info(local_node_id, state_json)
    if not cockroach_info:
        return False, "No CockroachDB connection available"

    try:
        result = subprocess.run(
            [
                "podman",
                "run",
                "--rm",
                "--network",
                "host",
                "--entrypoint",
                "node",
                "-e",
                "DB_TYPE=postgres",
                "-e",
                f"DB_HOST={cockroach_info['host']}",
                "-e",
                f"DB_PORT={cockroach_info['port']}",
                "-e",
                f"DB_USERNAME={cockroach_info['username']}",
                "-e",
                f"DB_PASSWORD={cockroach_info.get('password', '')}",
                "-e",
                f"DB_ADMIN_DATABASE={cockroach_info['database']}",
                "-e",
                f"DB_DATABASE={AUTH_DATABASE_NAME}",
                "-e",
                f"DB_SCHEMA={AUTH_DATABASE_SCHEMA}",
                image_ref,
                "apps/auth-service/dist/cli/run-migrations.js",
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )

        if result.returncode != 0:
            error_output = (result.stderr or result.stdout or "schema sync failed").strip()
            return False, f"Schema sync failed: {error_output}"

        if result.stdout:
            print(result.stdout.strip(), file=sys.stderr)

        return True, None
    except subprocess.TimeoutExpired:
        return False, "Schema sync timed out after 5 minutes"
    except Exception as e:
        return False, f"Schema sync error: {e}"


def get_leader_node(state_json: Dict[str, Any]) -> Optional[str]:
    cluster = state_json.get("cluster", {})
    if not isinstance(cluster, dict):
        return None
    leader = cluster.get("leader_node")
    return leader if isinstance(leader, str) and leader else None


def is_local_node_leader(local_node_id: str, state_json: Dict[str, Any]) -> bool:
    return get_leader_node(state_json) == local_node_id


def get_route_domain(state_json: Dict[str, Any]) -> str:
    swarm_domain = state_json.get("swarmDomain")
    if not isinstance(swarm_domain, str) or not swarm_domain.strip():
        raise ValueError("Waiting for dependency swarmDomain")

    normalized = _normalize_domain(swarm_domain)
    if not normalized:
        raise ValueError("Waiting for dependency swarmDomain")
    return normalized


def prepare_config(config_template_path: Path, values: Dict[str, str]) -> str:
    template = BASE_CONFIG_TEMPLATE
    rendered = template
    for key, value in values.items():
        rendered = rendered.replace(f"{{{{{key}}}}}", value)
        rendered = rendered.replace(f"{{{{ {key} }}}}", value)

    if not rendered.endswith("\n"):
        rendered += "\n"
    return rendered


def write_config(config_path: Path, content: str) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(content, encoding="UTF-8")


def read_oauth_block(state_json: Dict[str, Any]) -> str:
    content = get_secret_from_swarmdb(state_json, AUTH_SERVICE_YAML_SECRET_ID)
    if not isinstance(content, str):
        return ""
    stripped = content.strip()
    if not stripped:
        return ""
    return stripped + "\n"


def read_oidc_provider_block(state_json: Dict[str, Any]) -> str:
    """Render the `betterAuth.oidcProvider` block, indented to sit inside `betterAuth`.

    Turning this on makes the cloud an OAuth 2.0 / OIDC authorization server, so external
    products — the Swarm Cloud Marketplace among them — can be authorized to act on a user's
    cloud through the stable /api/v1. It stays off unless a stand supplies the secret: a cloud
    with no registered clients has nothing to authorize.

    The secret holds a fragment starting at `oidcProvider:` in column zero; every line is
    indented by four spaces to match the surrounding block.
    """
    content = get_secret_from_swarmdb(state_json, AUTH_SERVICE_OIDC_YAML_SECRET_ID)
    if not isinstance(content, str):
        return ""
    stripped = content.strip("\n").rstrip()
    if not stripped.strip():
        return ""

    indented = "\n".join(f"    {line}" if line.strip() else "" for line in stripped.split("\n"))
    return indented + "\n"


def get_or_create_better_auth_secret(state_json: Dict[str, Any], local_state: Dict[str, Any]) -> str:
    state_value = state_json.get("authSecret")
    if isinstance(state_value, str) and state_value.strip():
        return state_value.strip()

    existing = local_state.get("betterAuthSecret")
    if isinstance(existing, str) and existing.strip():
        return existing.strip()

    return str(uuid.uuid4())


def build_effective_state(state_json: Dict[str, Any], local_state: Dict[str, Any]) -> Dict[str, Any]:
    better_auth_secret = get_or_create_better_auth_secret(state_json, local_state)
    swarm_domain = get_route_domain(state_json)

    return {
        "cockroachNodes": state_json.get("cockroachNodes", []),
        "wgNodeProperties": state_json.get("wgNodeProperties", []),
        "swarmDomain": swarm_domain,
        "betterAuthSecret": better_auth_secret,
        "swarmSecrets": state_json.get("swarmSecrets", []),
    }


def build_config_values(state_json: Dict[str, Any], local_node_id: str) -> Dict[str, str]:
    swarm_domain = get_route_domain(state_json)
    better_auth_secret = state_json["betterAuthSecret"]
    oauth_block = read_oauth_block(state_json)
    oidc_block = read_oidc_provider_block(state_json)

    cockroach_info = get_cockroach_connection_info(local_node_id, state_json)
    if not cockroach_info:
        raise ValueError("No CockroachDB nodes available")

    return {
        "PORT": str(DEFAULT_PORT),
        "LOG_LEVEL": DEFAULT_LOG_LEVEL,
        "POSTGRES_HOST": str(cockroach_info["host"]),
        "POSTGRES_PORT": str(cockroach_info["port"]),
        "POSTGRES_USER": str(cockroach_info["username"]),
        "POSTGRES_PASSWORD": str(cockroach_info.get("password", "")),
        "POSTGRES_DATABASE": AUTH_DATABASE_NAME,
        "POSTGRES_SCHEMA": AUTH_DATABASE_SCHEMA,
        "BETTER_AUTH_SECRET": better_auth_secret,
        "BETTER_AUTH_BASE_URL": f"https://{swarm_domain}",
        "BETTER_AUTH_SIWE_DOMAIN": swarm_domain,
        "RUN_MIGRATIONS": "true" if oidc_block.strip() else "false",
        "OIDC_PROVIDER_BLOCK": oidc_block,
        "OAUTH_BLOCK": oauth_block,
        "METRICS_PORT": str(METRICS_PORT),
    }


def safe_build_config_values(
    state_json: Optional[Dict[str, Any]],
    local_node_id: str,
) -> Optional[Dict[str, str]]:
    if not isinstance(state_json, dict):
        return None
    try:
        return build_config_values(state_json, local_node_id)
    except Exception:
        return None


def restart_service_unit(service_unit: str) -> Optional[str]:
    subprocess.run(["systemctl", "enable", service_unit], check=True)
    r = subprocess.run(
        ["systemctl", "restart", service_unit],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        return (r.stderr or r.stdout or "failed to restart service").strip()
    return None


@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}
    try:
        image_ref = get_image_ref_from_env()
        pull_image(image_ref)
        local_state["image_ref"] = image_ref
    except Exception as e:
        return PluginOutput(status="error", error_message=str(e), local_state=local_state)

    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state if isinstance(input_data.local_state, dict) else {}
    current_local_state = local_state
    node_properties: Dict[str, Optional[str]] = {}

    def out(
        status: str,
        error_message: Optional[str] = None,
        cluster_properties: Optional[Dict[str, Optional[str]]] = None,
    ) -> PluginOutput:
        return PluginOutput(
            status=status,
            error_message=error_message,
            local_state=current_local_state,
            node_properties=node_properties if node_properties else None,
            cluster_properties=cluster_properties,
        )

    try:
        if not isinstance(state_json, dict):
            raise ValueError("input_data.state must be a JSON object")

        dep_err = check_state_dependencies(state_json)
        if dep_err:
            return out(status="postponed", error_message=dep_err)

        effective_state = build_effective_state(state_json, local_state)
        current_local_state = effective_state

        desired_image_ref = get_image_ref_from_env()
        image_changed = local_state.get("image_ref") != desired_image_ref

        if image_changed:
            pull_image(desired_image_ref)

        schema_success, schema_error = initialize_schema_if_needed(
            local_node_id,
            state_json,
            desired_image_ref,
        )
        if not schema_success:
            return out(status="postponed", error_message=schema_error or "Waiting for schema initialization")

        wg_props = state_json.get("wgNodeProperties", [])
        local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props) if isinstance(wg_props, list) else None
        if not isinstance(local_tunnel_ip, str) or not local_tunnel_ip.strip():
            return out(status="postponed", error_message="Waiting for WireGuard tunnel IP on local node")
        local_tunnel_ip = local_tunnel_ip.strip()

        desired_config_values = build_config_values(effective_state, local_node_id)
        prev_config_values = safe_build_config_values(local_state, local_node_id)
        config_changed = prev_config_values != desired_config_values
        if not CONFIG_PATH.exists() or not SERVICE_PATH.exists():
            config_changed = True

        service_active, _ = is_service_active(SERVICE_UNIT)
        bind_ip_changed = local_state.get("host_bind_ip") != local_tunnel_ip
        restart_needed = config_changed or image_changed or bind_ip_changed or not service_active

        config_path = CONFIG_PATH

        if config_changed:
            content = prepare_config(config_path, desired_config_values)
            write_config(config_path, content)

        if image_changed or bind_ip_changed or not service_active:
            create_systemd_service(desired_image_ref, local_tunnel_ip)

        effective_state["image_ref"] = desired_image_ref
        effective_state["host_bind_ip"] = local_tunnel_ip
        current_local_state = effective_state

        if restart_needed:
            restart_err = restart_service_unit(SERVICE_UNIT)
            if restart_err:
                return out(status="error", error_message=restart_err)

        node_properties["authSecret"] = str(effective_state["betterAuthSecret"])
        node_properties.update(_node_ready_props("true"))
        # SP-7700: publish image identity for the control-plane evidence aggregator.
        node_properties.update(
            build_image_evidence_props(
                prefix=PROPERTY_PREFIX,
                image_ref=desired_image_ref,
                manifest_version=read_manifest_version(Path(__file__).parent),
            )
        )

        cluster_properties = None
        cluster_props = state_json.get("clusterProperties", [])
        schema_already_marked = any(
            isinstance(prop, dict)
            and prop.get("name") == SCHEMA_INITIALIZED_PROPERTY
            and prop.get("value") == "true"
            for prop in cluster_props
        )
        if is_local_node_leader(local_node_id, state_json) and not schema_already_marked:
            cluster_properties = {SCHEMA_INITIALIZED_PROPERTY: "true"}

        return out(
            status="completed",
            cluster_properties=cluster_properties,
        )
    except Exception as e:
        return out(status="error", error_message=str(e))


@plugin.command("health")
def handle_health(input_data: PluginInput) -> PluginOutput:
    active, err = is_service_active(SERVICE_UNIT)
    if not active:
        return PluginOutput(
            status="postponed",
            error_message=err or "service not running",
            local_state=input_data.local_state,
        )
    return PluginOutput(status="completed", local_state=input_data.local_state)


@plugin.command("finalize")
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    local_state = input_data.local_state or {}

    try:
        subprocess.run(["systemctl", "stop", SERVICE_NAME], check=False)
    except Exception as e:
        print(f"[!] Failed to stop {SERVICE_NAME}: {e}", file=sys.stderr)

    return PluginOutput(status="completed", local_state=local_state, node_properties=_node_ready_props("false"))


@plugin.command("destroy")
def handle_destroy(_input_data: PluginInput) -> PluginOutput:
    try:
        subprocess.run(["systemctl", "stop", SERVICE_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", SERVICE_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        subprocess.run(["podman", "stop", CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["podman", "rm", CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        if SERVICE_PATH.exists():
            SERVICE_PATH.unlink()
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        node_properties = _node_ready_props(None)
        node_properties["authSecret"] = None
        return PluginOutput(
            status="completed",
            node_properties=node_properties,
            local_state={},
        )
    except Exception as e:
        return PluginOutput(
            status="error",
            error_message=f"Failed to destroy {SERVICE_UNIT}: {e}",
            local_state={},
        )


if __name__ == "__main__":
    plugin.run()
