#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import random
import hashlib

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

# This service implements a safe, portable subset of the previous WireGuard up/down/check
# logic adapted to the new Provision plugin protocol.
# It focuses on computing/updating node properties (pub_key, port)
# and uses in-memory localState passed via stdin/stdout (no local files).
# When WireGuard tools are not present on the host, system-level configuration is skipped to remain test-friendly.

# Where the rendered interface config lives. Module-level so tests can retarget it.
WG_CONF_PATH = "/etc/wireguard/wg0.conf"


# Helpers

def wg_available():
    return shutil.which("wg") is not None and shutil.which("wg-quick") is not None


def generate_keypair(existing_priv=None):
    """Generate wg keypair using `wg genkey` when available or fall back to os.urandom.
    Returns (private_key, public_key).
    """
    if existing_priv:
        # Recompute public key from private when possible
        try:
            pk = subprocess.run(["wg", "pubkey"], input=existing_priv.encode(), capture_output=True, check=False)
            if pk.returncode == 0:
                return existing_priv, pk.stdout.decode().strip()
        except Exception as e:
            # Continue to try wg_available or fallback
            print(f"[!] Failed to recompute public key: {e}", file=sys.stderr)

    if wg_available():
        try:
            sk = subprocess.check_output(["wg", "genkey"]).decode().strip()
            pk = subprocess.run(["wg", "pubkey"], input=sk.encode(), capture_output=True)
            return sk, pk.stdout.decode().strip()
        except Exception as e:
            # Fallback to random
            print(f"[!] Failed to generate keypair with wg: {e}, using fallback", file=sys.stderr)

    # Portable fallback: not secure for production, but good for tests
    sk_bytes = os.urandom(32)
    # Derive a pseudo public value (not a real wg public key) for tests only
    pk_bytes = hashlib.sha256(sk_bytes).digest()
    sk = sk_bytes.hex()
    pk = pk_bytes.hex()
    return sk, pk




def get_plan_nodes_and_props(state_json):
    """From generic state (jq results), extract cluster nodes and their properties.
    Expected shape (mirrors e2e fixture manifest query):
      state.clusterNodes: [{ id, node_id }]
      state.nodeProperties: [{ cluster_node, name, value }]

    Note:
      ClusterNodeProperty.cluster_node already equals ClusterNode.id. No parsing needed.
    """
    cluster_nodes = state_json.get("clusterNodes") or []
    props = state_json.get("nodeProperties") or []

    # Build map: cluster_node_id -> { propName: value }
    props_by_cluster_node_id = {}
    for p in props:
        cn_id = p.get("cluster_node")
        if not cn_id:
            continue
        if cn_id not in props_by_cluster_node_id:
            props_by_cluster_node_id[cn_id] = {}
        props_by_cluster_node_id[cn_id][p.get("name")] = p.get("value")

    return cluster_nodes, props_by_cluster_node_id


def generate_random_ip(existing):
    while True:
        ip = f"10.13.{random.randint(0,255)}.{random.randint(1,254)}"
        if ip not in existing:
            return ip


def install_wireguard_packages():
    if shutil.which("wg") and shutil.which("wg-quick"):
        return
    raise Exception("WireGuard tools not found. Ensure wireguard and wireguard-tools are pre-installed on the host.")


def ensure_kernel_net_settings():
    """Configure kernel settings for WireGuard networking."""
    errors = []

    try:
        result = subprocess.run(["modprobe", "br_netfilter"], capture_output=True, text=True)
        if result.returncode != 0:
            errors.append(f"Failed to load br_netfilter: {result.stderr}")
    except Exception as e:
        errors.append(f"Failed to load br_netfilter: {str(e)}")

    sysctls = [
        ("net.bridge.bridge-nf-call-iptables", "1"),
        ("net.bridge.bridge-nf-call-ip6tables", "1"),
        ("net.ipv4.ip_forward", "1"),
        ("net.ipv4.conf.all.rp_filter", "2"),
        ("net.ipv4.conf.default.rp_filter", "2"),
    ]
    for k, v in sysctls:
        try:
            result = subprocess.run(["sysctl", "-w", f"{k}={v}"], capture_output=True, text=True)
            if result.returncode != 0:
                errors.append(f"Failed to set {k}={v}: {result.stderr}")
        except Exception as e:
            errors.append(f"Failed to set {k}={v}: {str(e)}")

    if errors:
        raise Exception("; ".join(errors))


def read_interface_section(conf_path):
    """Return Interface key/value pairs from an existing wg config file."""
    if not os.path.exists(conf_path):
        return None

    section = None
    result = {}
    with open(conf_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                section = line.strip("[]").lower()
                continue
            if section != "interface" or "=" not in line:
                continue
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()

    return result if result else None


def read_peer_allowed_ips(conf_path):
    """Return AllowedIPs CIDRs from all [Peer] sections in a wg config file."""
    section = None
    allowed = []
    with open(conf_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                section = line.strip("[]").lower()
                continue
            if section != "peer" or not line.startswith("AllowedIPs"):
                continue
            _, _, value = line.partition("=")
            cidr = value.strip()
            if cidr:
                allowed.append(cidr)
    return allowed


def read_peer_sections(conf_path):
    """Return {public_key: {key: value}} for every [Peer] section in a wg config.

    Used to recover a peer's last known Endpoint when the current plan cannot
    tell us where that peer lives (SUP-344).
    """
    if not conf_path or not os.path.exists(conf_path):
        return {}

    section = None
    current = None
    peers = {}
    with open(conf_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                section = line.strip("[]").lower()
                current = {} if section == "peer" else None
                continue
            if section != "peer" or current is None or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            current[key] = value
            if key == "PublicKey" and value:
                peers[value] = current

    return peers


def endpoint_host(endpoint):
    """Split the host out of a wg `Endpoint = host:port` value."""
    if not endpoint:
        return None
    # Split on the last colon so bracketed IPv6 literals ("[::1]:51820") survive.
    host, sep, _ = endpoint.rpartition(":")
    if not sep:
        return endpoint or None
    return host or None


def _normalize_route_dest(dest: str) -> str:
    """Normalize kernel route destination for comparison with AllowedIPs CIDRs."""
    if "/" in dest:
        return dest
    if ":" in dest:
        return f"{dest}/128"
    return f"{dest}/32"


def _route_dest_in_allowed(dest: str, allowed: set[str]) -> bool:
    return dest in allowed or _normalize_route_dest(dest) in allowed


def read_peer_routes_on_interface(interface="wg0"):
    """Return non-kernel routes on the WireGuard interface (peer AllowedIPs)."""
    result = subprocess.run(
        ["ip", "-o", "route", "show", "dev", interface],
        capture_output=True,
        text=True,
        check=False,
    )
    routes = []
    for line in result.stdout.splitlines():
        if " proto kernel " in f" {line} ":
            continue
        parts = line.split()
        if not parts:
            continue
        dest = parts[1] if ":" in parts[0] else parts[0]
        if dest:
            routes.append(dest)
    return routes


def sync_wireguard_routes(conf_path, interface="wg0"):
    """Ensure kernel routes exist for peer AllowedIPs.

    wg syncconf updates peers but does not install routes; wg-quick does that on
    up/restart via PostUp. Without these routes, cross-node tunnel traffic fails.
    """
    desired = set(read_peer_allowed_ips(conf_path))
    for cidr in desired:
        subprocess.run(
            ["ip", "route", "replace", cidr, "dev", interface],
            check=False,
            capture_output=True,
        )
    for cidr in read_peer_routes_on_interface(interface):
        if not _route_dest_in_allowed(cidr, desired):
            subprocess.run(
                ["ip", "route", "del", cidr, "dev", interface],
                check=False,
                capture_output=True,
            )


def sync_wireguard_peers(conf_path):
    """Apply peer changes from config without restarting the wg0 interface."""
    strip = subprocess.run(
        ["wg-quick", "strip", conf_path],
        capture_output=True,
        check=False,
    )
    if strip.returncode != 0:
        stderr = strip.stderr.decode().strip()
        raise Exception(f"wg-quick strip failed: {stderr or strip.returncode}")

    sync = subprocess.run(
        ["wg", "syncconf", "wg0", "/dev/stdin"],
        input=strip.stdout,
        capture_output=True,
        check=False,
    )
    if sync.returncode != 0:
        stderr = sync.stderr.decode().strip()
        raise Exception(f"wg syncconf failed: {stderr or sync.returncode}")

    sync_wireguard_routes(conf_path)


# Plugin setup
plugin = ProvisionPlugin()


@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """One-time installation/setup step.
    - Install WireGuard packages if needed.
    - Ensure kernel module and sysctls are set.
    - Do not create config, keys, or change nodeProperties.
    - Return completed and pass-through localState.
    """
    # Best-effort system preparation
    try:
        install_wireguard_packages()
        ensure_kernel_net_settings()
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to initialize WireGuard: {str(e)}',
            local_state=input_data.local_state
        )

    return PluginOutput(status='completed', local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}

    # Ensure state_json is a dict, not a list
    if not isinstance(state_json, dict):
        state_json = {}

    cluster_nodes, props_by_cluster_node = get_plan_nodes_and_props(state_json)

    # Build peers info with addr and port if available in properties and plan
    # Expect an auxiliary array state.nodeAddrs: [{ node_id, addr }]
    node_addrs_list = state_json.get("nodeAddrs") or []
    addr_by_node = {item.get("node_id"): item.get("addr") for item in node_addrs_list}

    # Determine local cluster_node id
    local_cluster_node_id = None
    for cn in cluster_nodes:
        if cn.get("node_id") == local_node_id:
            local_cluster_node_id = cn.get("id")
            break

    # `nodeAddrs` is derived from swarm-db's live memberlist view, so a node that
    # is briefly cut off from gossip sees it shrink to just itself. Rendering the
    # config from that view alone made such a node drop every [Peer] section and
    # then `wg syncconf` them off the live interface — dismantling its own
    # overlay and turning a seconds-long blip into a permanent dropout
    # (SUP-344). Endpoints therefore fall back to durable sources: the
    # `endpoint_addr` node property (CRDT-replicated) and, failing that, the
    # peer's last known Endpoint in the config already on disk.
    conf_path = WG_CONF_PATH
    existing_peers = read_peer_sections(conf_path)

    peers = []
    for cn in cluster_nodes:
        nid = cn.get("node_id")
        if not nid or nid == local_node_id:
            continue
        props = props_by_cluster_node.get(cn.get("id"), {})
        pub_key = props.get("pub_key")
        addr = addr_by_node.get(nid) or props.get("endpoint_addr")
        if not addr and pub_key:
            addr = endpoint_host(existing_peers.get(pub_key, {}).get("Endpoint"))
        peers.append({
            "node_id": nid,
            "pub_key": pub_key,
            "port": int(props.get("port")) if props.get("port") else 51820,
            "addr": addr,
            "tunnel_ip": props.get("tunnel_ip"),
        })

    # Local properties by cluster_node id
    local_props = props_by_cluster_node.get(local_cluster_node_id, {})

    # Load previous local state from input
    local_state = input_data.local_state or {}
    priv = local_state.get("private_key")
    pub = local_state.get("public_key")
    addr = local_state.get("address")

    # Generate or reuse keys
    priv, pub_new = generate_keypair(priv)

    # Compute tunnel IP if missing
    if not addr:
        addr = generate_random_ip(set())

    # Prepare nodeProperties changes for global DB: pub_key, listen port, and tunnel IP
    node_properties = {}
    if local_props.get("pub_key") != pub_new:
        node_properties["pub_key"] = pub_new
    # Ensure port property exists and is 51820 (can be customized later)
    desired_port = str(51820)
    if local_props.get("port") != desired_port:
        node_properties["port"] = desired_port
    # Share tunnel IP so peers can set AllowedIPs correctly
    if local_props.get("tunnel_ip") != addr:
        node_properties["tunnel_ip"] = addr
    # Publish our own endpoint address so peers keep a durable record of where
    # to reach us. The local node is always present in its own memberlist view,
    # so this is the one entry of `nodeAddrs` that a partition cannot hide.
    local_endpoint_addr = addr_by_node.get(local_node_id)
    if local_endpoint_addr and local_props.get("endpoint_addr") != local_endpoint_addr:
        node_properties["endpoint_addr"] = local_endpoint_addr

    # Persist local state
    local_state.update({
        "private_key": priv,
        "public_key": pub_new,
        "address": addr,
    })

    # Apply system configuration: write /etc/wireguard/wg0.conf and bring interface up/sync
    try:
        if wg_available():
            os.makedirs(os.path.dirname(conf_path), exist_ok=True)
            old_interface = read_interface_section(conf_path)

            renderable = [p for p in peers if p.get("pub_key") and p.get("addr")]

            # Last line of defence against the SUP-344 teardown: never replace a
            # populated peer set with an empty one while the cluster still has
            # remote members. Writing that config and syncing it would strip
            # every peer off the live interface and delete their routes, so stay
            # with what is already running and let the worker retry.
            if peers and not renderable and existing_peers:
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'refusing to drop {len(existing_peers)} WireGuard peer(s): no endpoint could be '
                        f'resolved for any of the {len(peers)} remote cluster node(s)'
                    ),
                    node_properties=node_properties if node_properties else None,
                    local_state=local_state
                )

            lines = [
                "[Interface]",
                f"PrivateKey = {priv}",
                f"Address = {addr}/24",
                f"ListenPort = {desired_port}",
                ""
            ]

            # Render peers
            for peer in renderable:
                endpoint = f"{peer['addr']}:{peer['port']}"
                # Use peer's tunnel IP if available, otherwise fall back to subnet
                peer_tunnel_ip = peer.get("tunnel_ip")
                allowed_ips = f"{peer_tunnel_ip}/32" if peer_tunnel_ip else "10.13.0.0/16"
                lines += [
                    "[Peer]",
                    f"PublicKey = {peer['pub_key']}",
                    f"AllowedIPs = {allowed_ips}",
                    f"Endpoint = {endpoint}",
                    "PersistentKeepalive = 25",
                    ""
                ]

            with open(conf_path, "w") as f:
                f.write("\n".join(lines))
            os.chmod(conf_path, 0o600)

            # Always ensure service is enabled for boot persistence
            subprocess.run(["systemctl", "enable", "wg-quick@wg0"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            # Check if wg0 interface exists using ip link
            ip_check = subprocess.run(["ip", "link", "show", "wg0"], capture_output=True)
            interface_exists = ip_check.returncode == 0

            interface_unchanged = (
                old_interface is not None
                and old_interface.get("PrivateKey") == priv
                and old_interface.get("Address") == f"{addr}/24"
                and old_interface.get("ListenPort") == desired_port
            )

            if interface_exists:
                if interface_unchanged:
                    # Hot-reload peers only — avoids tearing down wg0 (and breaking flannel)
                    sync_wireguard_peers(conf_path)
                else:
                    subprocess.run(
                        ["systemctl", "restart", "wg-quick@wg0"],
                        check=False,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
            else:
                subprocess.run(
                    ["systemctl", "start", "wg-quick@wg0"],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to configure WireGuard: {str(e)}',
            local_state=local_state
        )

    return PluginOutput(
        status='completed',
        node_properties=node_properties if node_properties else None,
        local_state=local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    # Healthy if wg0 is up and local state exists; otherwise postponed
    local_state = input_data.local_state or {}
    try:
        show = subprocess.run(["wg", "show", "wg0"], capture_output=True)
        if show.returncode == 0 and local_state.get("private_key") and local_state.get("public_key"):
            # Optionally assess handshakes
            lh = subprocess.run(["wg", "show", "wg0", "latest-handshakes"], capture_output=True, text=True)
            if lh.returncode == 0 and lh.stdout.strip():
                return PluginOutput(status='completed', local_state=local_state)
            # No handshakes yet — consider degraded but completed to avoid backoff storms
            return PluginOutput(status='completed', local_state=local_state)
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Health check failed: {str(e)}',
            local_state=local_state
        )
    return PluginOutput(status='postponed', error_message='wg0 not ready', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    # Stop and disable wg0, remove config
    errors = []
    try:
        subprocess.run(["wg-quick", "down", "wg0"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "wg-quick@wg0"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        errors.append(f'Failed to stop service: {str(e)}')

    try:
        conf_path = WG_CONF_PATH
        if os.path.exists(conf_path):
            os.remove(conf_path)
    except Exception as e:
        errors.append(f'Failed to remove config: {str(e)}')

    if errors:
        return PluginOutput(
            status='error',
            error_message='; '.join(errors),
            local_state={}
        )

    # Request deletion of global properties
    return PluginOutput(
        status='completed',
        node_properties={
            "pub_key": None,
            "port": None,
            "tunnel_ip": None,
            "endpoint_addr": None,
        },
        local_state={}
    )


@plugin.command('drain')
@plugin.command('finalize')
def handle_noop(input_data: PluginInput) -> PluginOutput:
    # No-op but keep reporting local state to be safe
    return PluginOutput(status='completed', local_state=input_data.local_state)


if __name__ == "__main__":
  plugin.run()
