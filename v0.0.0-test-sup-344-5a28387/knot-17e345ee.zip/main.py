#!/usr/bin/env python3

import sys
import os
import fcntl
import shutil
import subprocess
import hashlib
import time
import json
import requests
from pathlib import Path
from typing import Optional

SWARM_APT_LOCK_FILE = "/run/lock/swarm-apt.lock"

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

# Configuration
KNOT_VERSION = os.environ.get("KNOT_VERSION", "3.5.1")
KNOT_SERVICE_NAME = "knot"
KNOT_APT_PIN_FILE = Path("/etc/apt/preferences.d/knot")
KNOT_APT_KEYRING = Path("/usr/share/keyrings/cznic-labs-pkg.gpg")
KNOT_APT_LIST = Path("/etc/apt/sources.list.d/cznic-labs-knot-dns.list")
KNOT_CONFIG_DIR = Path("/etc/knot")
KNOT_CONFIG_FILE = KNOT_CONFIG_DIR / "knot.conf"
KNOT_ZONES_CONFIG_FILE = KNOT_CONFIG_DIR / "zones.conf"
KNOT_DATA_DIR = Path("/var/lib/knot")
KNOT_ZONES_DIR = KNOT_DATA_DIR / "zones"
KNOT_CLI = "knotc"
KNOT_PORT = 53

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions

def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def get_node_addr(node_id: str, node_addrs: list) -> str | None:
    """Get physical address for a node."""
    for node in node_addrs:
        if node.get("node_id") == node_id:
            return node.get("addr")
    return None


def get_default_output_ip() -> str | None:
    """Get source IP used by default route (egress/default-output IP)."""
    try:
        result = subprocess.run(
            ["ip", "route", "get", "8.8.8.8"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode != 0:
            return None

        # Typical output contains: "... src <ip> ..."
        parts = (result.stdout or "").strip().split()
        if "src" in parts:
            src_idx = parts.index("src")
            if src_idx + 1 < len(parts):
                return parts[src_idx + 1]
        return None
    except Exception:
        return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def is_cluster_initialized(knot_props: list) -> bool:
    """Check if cluster is already initialized by any node."""
    for prop in knot_props:
        if prop.get("name") == "knot_cluster_initialized" and prop.get("value") == "true":
            return True
    return False


def check_all_nodes_knot_ready(cluster_nodes: list, knot_props: list, local_node_id: str = None) -> bool:
    """Check if all cluster nodes have Knot running and ready.

    Args:
        cluster_nodes: List of cluster nodes
        knot_props: List of knot node properties
        local_node_id: ID of local node (treated as ready if provided)
    """
    not_ready_nodes = []
    for node in cluster_nodes:
        node_id = node.get("node_id")

        # Treat local node as ready since we're about to mark it
        if local_node_id and node_id == local_node_id:
            continue

        node_ready = False
        for prop in knot_props:
            if (prop.get("node_id") == node_id and
                prop.get("name") == "knot_node_ready" and
                prop.get("value") == "true"):
                node_ready = True
                break
        if not node_ready:
            not_ready_nodes.append(node_id)

    if not_ready_nodes:
        print(f"[*] Nodes not ready yet: {', '.join(not_ready_nodes)}", file=sys.stderr)
        return False

    print(f"[*] All {len(cluster_nodes)} nodes are ready", file=sys.stderr)
    return True


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")




def get_secret_from_swarmdb(state_json: dict, secret_id: str) -> str | None:
    """Get secret value from SwarmSecrets table."""
    secrets = state_json.get("swarmSecrets", [])
    for secret in secrets:
        if secret.get("id") == secret_id:
            return secret.get("value")
    return None


def is_knot_available() -> bool:
    """Check if Knot is properly installed (binary + system user)."""
    if shutil.which("knotd") is None:
        return False
    try:
        import pwd
        pwd.getpwnam("knot")
        return True
    except KeyError:
        return False


def generate_tsig_key() -> tuple[str, str] | None:
    """Generate TSIG key for DNS UPDATE authentication.

    Returns:
        (key_name, key_secret) tuple or None on failure
    """
    try:
        key_name = "swarm-update-key."

        # Generate TSIG key using keymgr or manually
        # Format: keymgr will generate hmac-sha256 key
        result = subprocess.run(
            ["dd", "if=/dev/urandom", "bs=32", "count=1"],
            capture_output=True,
            timeout=10
        )

        if result.returncode != 0:
            print(f"[!] Failed to generate random bytes", file=sys.stderr)
            return None

        # Base64 encode the key
        import base64
        key_secret = base64.b64encode(result.stdout).decode('ascii')

        print(f"[*] Generated TSIG key: {key_name}", file=sys.stderr)
        return (key_name, key_secret)

    except Exception as e:
        print(f"[!] Failed to generate TSIG key: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return None


def run_cmd(cmd, err_msg, env=None):
    """Run command and raise exception on failure."""
    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if result.returncode != 0:
        raise Exception(f"{err_msg}: {result.stderr.strip()}")
    return result


def _apt_env() -> dict:
    env = os.environ.copy()
    env["DEBIAN_FRONTEND"] = "noninteractive"
    # Avoid needrestart blocking dpkg configure during unattended installs.
    env.setdefault("NEEDRESTART_MODE", "a")
    return env


class _SwarmAptLock:
    """Serialize apt/dpkg on one host across concurrent service plugin inits."""

    def __init__(self, timeout_sec: int = 300) -> None:
        self._timeout_sec = timeout_sec
        self._fd: int | None = None

    def __enter__(self) -> "_SwarmAptLock":
        lock_dir = os.path.dirname(SWARM_APT_LOCK_FILE) or "/run/lock"
        os.makedirs(lock_dir, exist_ok=True)
        self._fd = os.open(SWARM_APT_LOCK_FILE, os.O_CREAT | os.O_RDWR, 0o644)
        deadline = time.time() + self._timeout_sec
        while time.time() < deadline:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except BlockingIOError:
                time.sleep(1)
        raise Exception(f"Timed out waiting for {SWARM_APT_LOCK_FILE}")

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._fd is not None:
            fcntl.flock(self._fd, fcntl.LOCK_UN)
            os.close(self._fd)
            self._fd = None


def _ubuntu_codename() -> str:
    try:
        for line in Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("VERSION_CODENAME="):
                return line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    return "noble"


def _run_apt(cmd: list[str], *, err_msg: str) -> None:
    run_cmd(cmd, err_msg, env=_apt_env())


def _knot_deb_install_targets(version: str = KNOT_VERSION) -> list[str]:
    """Pinned knot stack for CZ.NIC noble packages (knot 3.5.x)."""
    packages = ("knot", "libdnssec10", "libknot16", "libzscanner5")
    return [f"{pkg}={version}*" for pkg in packages]


def _run_apt_install(packages: list[str], *, err_msg: str) -> None:
    cmd = [
        "apt-get",
        "install",
        "-y",
        "--no-install-recommends",
        "-o",
        "Dpkg::Options::=--force-confdef",
        "-o",
        "Dpkg::Options::=--force-confold",
        *packages,
    ]
    _run_apt(cmd, err_msg=err_msg)


def disable_knot_service() -> None:
    """Stop and disable the unit so it only runs after apply enables it."""
    subprocess.run(
        ["systemctl", "disable", "--now", KNOT_SERVICE_NAME],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def enable_knot_service() -> None:
    """Enable and restart Knot (apply only)."""
    enable = subprocess.run(
        ["systemctl", "enable", KNOT_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if enable.returncode != 0:
        raise Exception(f"Failed to enable {KNOT_SERVICE_NAME}: {(enable.stderr or enable.stdout or '').strip()}")

    restart = subprocess.run(
        ["systemctl", "restart", KNOT_SERVICE_NAME],
        capture_output=True,
        text=True,
    )
    if restart.returncode != 0:
        raise Exception(f"Failed to start {KNOT_SERVICE_NAME}: {(restart.stderr or restart.stdout or '').strip()}")


def _ensure_knot_apt_pin(version: str = KNOT_VERSION) -> None:
    pin_body = (
        "Package: knot knot-* libdnssec* libzscanner* libknot* python3-libknot*\n"
        "Pin-Priority: 1001\n"
        f"Pin: version {version}*\n"
    )
    KNOT_APT_PIN_FILE.parent.mkdir(parents=True, exist_ok=True)
    current = (
        KNOT_APT_PIN_FILE.read_text(encoding="utf-8", errors="ignore")
        if KNOT_APT_PIN_FILE.exists()
        else ""
    )
    if current != pin_body:
        KNOT_APT_PIN_FILE.write_text(pin_body, encoding="utf-8")


def _ensure_knot_apt_repo() -> None:
    codename = _ubuntu_codename()
    expected = (
        f"deb [signed-by={KNOT_APT_KEYRING}] https://pkg.labs.nic.cz/knot-dns {codename} main\n"
    )
    if KNOT_APT_LIST.exists():
        current = KNOT_APT_LIST.read_text(encoding="utf-8", errors="ignore")
        if current == expected:
            return
    KNOT_APT_KEYRING.parent.mkdir(parents=True, exist_ok=True)
    run_cmd(
        ["curl", "-fsSL", "https://pkg.labs.nic.cz/gpg", "-o", str(KNOT_APT_KEYRING)],
        "Failed to download CZ.NIC apt keyring",
        env=_apt_env(),
    )
    KNOT_APT_LIST.write_text(expected, encoding="utf-8")


def ensure_knot_package(version: str = KNOT_VERSION) -> None:
    """Install knot via apt only when knotd / knot user is missing."""
    if is_knot_available():
        disable_knot_service()
        return

    with _SwarmAptLock():
        _ensure_knot_apt_pin(version)
        _ensure_knot_apt_repo()
        _run_apt(["apt-get", "update"], err_msg="apt-get update failed")
        install_targets = _knot_deb_install_targets(version)
        _run_apt_install(
            install_targets,
            err_msg=f"Failed to install knot packages ({' '.join(install_targets)})",
        )
        if not is_knot_available():
            raise Exception(f"knot={version} package installed but knotd is not available")
    # Package postinst may enable/start the unit; keep it off until apply.
    disable_knot_service()


def write_knot_config(
    local_node_id: str,
    local_tunnel_ip: str,
    cluster_nodes: list,
    wg_props: list,
    is_catalog_master: bool,
    tsig_key_name: str,
    tsig_key_secret: str,
    catalog_master_ip: str = None,
    node_addrs: list | None = None,
):
    """Write Knot DNS configuration file with RFC 2136, TSIG, and catalog zones support.

    Args:
        local_node_id: ID of local node
        local_tunnel_ip: Local WireGuard tunnel IP
        cluster_nodes: List of all cluster nodes
        wg_props: WireGuard properties with tunnel IPs
        is_catalog_master: Whether this node is the catalog zone master
        tsig_key_name: TSIG key name for authentication
        tsig_key_secret: TSIG key secret (base64)
        catalog_master_ip: IP of catalog master (for non-master nodes)
    """
    # Create directories with proper ownership for knot user
    KNOT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    KNOT_DATA_DIR.mkdir(parents=True, exist_ok=True)
    KNOT_ZONES_DIR.mkdir(parents=True, exist_ok=True)

    # Ensure knot user can write to data directories
    try:
        subprocess.run(["chown", "-R", "knot:knot", str(KNOT_DATA_DIR)],
                      check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass  # Non-critical if chown fails

    # Determine external IP for this node (for listening on public interface)
    external_ip = None
    if node_addrs:
        external_ip = get_node_addr(local_node_id, node_addrs)

    # Determine default-output IP (egress IP selected by routing table)
    default_output_ip = get_default_output_ip()

    # Build list of remote server IPs (all nodes except local)
    remote_ips = []
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if node_id == local_node_id:
            continue
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            remote_ips.append(tunnel_ip)

    # Remote servers configuration
    remote_section = ""
    if not is_catalog_master and catalog_master_ip:
        # Member nodes: only need remote for catalog master
        remote_section = f"""remote:
  - id: catalog_master
    address: {catalog_master_ip}@{KNOT_PORT}
    key: {tsig_key_name}
"""
    elif is_catalog_master and remote_ips:
        # Master node: remotes with TSIG for NOTIFY/AXFR/IXFR
        remote_lines = []
        for i, ip in enumerate(remote_ips):
            # Remote with TSIG (for NOTIFY and AXFR/IXFR)
            remote_lines.append(f"  - id: node_{i}\n    address: {ip}@{KNOT_PORT}\n    key: {tsig_key_name}")
        remote_section = f"remote:\n" + "\n".join(remote_lines) + "\n"

    # Catalog zone configuration
    catalog_zone_name = "swarm-catalog"
    catalog_config = ""

    if is_catalog_master:
        # Master node: catalog-generate
        # Build notify list for catalog zone (all member nodes with TSIG)
        notify_list = ", ".join([f"node_{i}" for i in range(len(remote_ips))]) if remote_ips else ""
        notify_section = f"notify: [{notify_list}]" if notify_list else ""

        catalog_config = f"""
# Catalog zone (master node)
template:
  - id: default
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    acl: [tsig_update_acl, tsig_transfer_acl]
    {notify_section}

  - id: member
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    acl: [tsig_update_acl, tsig_transfer_acl]
    {notify_section}

  - id: dynamic
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    acl: [tsig_update_acl, tsig_transfer_acl]
    {notify_section}

zone:
  - domain: {catalog_zone_name}
    storage: "{KNOT_ZONES_DIR}"
    catalog-role: generate
    {notify_section}
"""
    else:
        # Member node: catalog-interpret
        catalog_config = f"""
# Catalog zone (member node)
template:
  - id: default
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    acl: [tsig_update_acl]

  - id: member
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    master: catalog_master
    acl: [notify_from_master]

  - id: dynamic
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    master: catalog_master
    acl: [notify_from_master]

  - id: slave
    storage: "{KNOT_ZONES_DIR}"
    semantic-checks: on
    master: catalog_master
    acl: [notify_from_master]

zone:
  - domain: {catalog_zone_name}
    storage: "{KNOT_ZONES_DIR}"
    master: catalog_master
    acl: [notify_from_master, tsig_update_acl]
    catalog-role: interpret
    catalog-template: member
"""

    # Build server listen directives:
    # - always listen on WireGuard tunnel IP (for intra-cluster traffic)
    # - always listen on loopback
    # - if external_ip is available, listen on it as well (for external clients)
    listen_lines = [
        f"    listen: {local_tunnel_ip}@{KNOT_PORT}",
        f"    listen: 127.0.0.1@{KNOT_PORT}",
    ]
    if external_ip:
        listen_lines.append(f"    listen: {external_ip}@{KNOT_PORT}")
    if default_output_ip and default_output_ip not in {local_tunnel_ip, "127.0.0.1", external_ip}:
        listen_lines.append(f"    listen: {default_output_ip}@{KNOT_PORT}")
    listen_block = "\n".join(listen_lines)

    cfg_content = f"""# Knot DNS Configuration with TSIG, RFC 2136, and Catalog Zones

server:
{listen_block}
    rundir: "/run/knot"
    user: knot:knot
    pidfile: "/run/knot/knot.pid"

log:
  - target: syslog
    any: info

database:
    storage: "{KNOT_DATA_DIR}"

key:
  - id: {tsig_key_name}
    algorithm: hmac-sha256
    secret: "{tsig_key_secret}"

{remote_section}
acl:
  - id: tsig_update_acl
    key: {tsig_key_name}
    action: update

  - id: tsig_transfer_acl
    key: {tsig_key_name}
    action: transfer

  - id: notify_from_master
    key: {tsig_key_name}
    action: notify

{catalog_config}

# User zones will be added to catalog automatically

# Include zones configuration file for dynamic zone management
include: {KNOT_ZONES_CONFIG_FILE}
"""

    KNOT_CONFIG_FILE.write_text(cfg_content)
    print(f"[*] Wrote Knot config to {KNOT_CONFIG_FILE}", file=sys.stderr)
    print(f"[*] Role: {'CATALOG MASTER' if is_catalog_master else 'CATALOG MEMBER'}", file=sys.stderr)
    print(f"[*] TSIG key: {tsig_key_name}", file=sys.stderr)

    # Create empty zones.conf if it doesn't exist
    if not KNOT_ZONES_CONFIG_FILE.exists():
        KNOT_ZONES_CONFIG_FILE.write_text("# Dynamic zones configuration\n# This file is managed automatically\n")
        print(f"[*] Created zones config file: {KNOT_ZONES_CONFIG_FILE}", file=sys.stderr)


def add_zone_to_zones_conf(zone_name: str, template: str) -> bool:
    """Add zone to zones.conf file (persistent configuration).

    Args:
        zone_name: Full zone name (e.g., "example.swarm.anthrax63.fun")
        template: Template name (e.g., "member", "dynamic")

    Returns:
        True if zone was added successfully, False otherwise
    """
    try:
        # Ensure config directory exists
        KNOT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        # Read existing zones.conf
        if KNOT_ZONES_CONFIG_FILE.exists():
            existing_content = KNOT_ZONES_CONFIG_FILE.read_text()
        else:
            existing_content = "# Dynamic zones configuration\n# This file is managed automatically\n"

        # Check if zone already exists in config
        if f"domain: {zone_name}" in existing_content:
            print(f"[*] Zone {zone_name} already exists in zones.conf", file=sys.stderr)
            return True

        # Add zone configuration
        zone_config = f"""
zone:
  - domain: {zone_name}
    template: {template}
"""

        # Append to zones.conf
        with open(KNOT_ZONES_CONFIG_FILE, "a") as f:
            f.write(zone_config)

        print(f"[*] Added zone {zone_name} (template: {template}) to zones.conf", file=sys.stderr)
        return True

    except Exception as e:
        print(f"[!] Failed to add zone to zones.conf: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return False


def remove_zone_from_zones_conf(zone_name: str) -> bool:
    """Remove zone from zones.conf file.

    Args:
        zone_name: Full zone name to remove

    Returns:
        True if zone was removed successfully, False otherwise
    """
    try:
        if not KNOT_ZONES_CONFIG_FILE.exists():
            return True

        # Read existing zones.conf
        content = KNOT_ZONES_CONFIG_FILE.read_text()
        lines = content.split('\n')

        # Filter out the zone block
        new_lines = []
        skip_until_next_zone = False
        for line in lines:
            if f"domain: {zone_name}" in line:
                skip_until_next_zone = True
                continue
            if skip_until_next_zone:
                if line.startswith('zone:') or (line.strip() and not line.startswith(' ')):
                    skip_until_next_zone = False
                else:
                    continue
            new_lines.append(line)

        # Write back
        KNOT_ZONES_CONFIG_FILE.write_text('\n'.join(new_lines))
        print(f"[*] Removed zone {zone_name} from zones.conf", file=sys.stderr)
        return True

    except Exception as e:
        print(f"[!] Failed to remove zone from zones.conf: {e}", file=sys.stderr)
        return False


def is_knot_running() -> tuple[bool, str | None]:
    """Check if Knot DNS server is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "knot"],
            capture_output=True,
            text=True
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def wait_for_knot_ready(timeout_sec: int = 30) -> bool:
    """Wait for Knot DNS server to become ready."""
    start_time = time.time()

    while time.time() - start_time < timeout_sec:
        try:
            result = subprocess.run(
                [KNOT_CLI, "status"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0:
                return True

        except subprocess.TimeoutExpired:
            pass
        except Exception:
            pass

        time.sleep(2)

    return False


def create_catalog_zone_file(catalog_zone_name: str = "swarm-catalog") -> bool:
    """Create initial catalog zone file for master node.

    Note: For catalog-role: generate, this file is not strictly required.
    Knot will manage the catalog zone content automatically. We create it
    only to avoid potential issues during initial setup.

    Args:
        catalog_zone_name: Name of catalog zone

    Returns:
        True if created successfully, False otherwise
    """
    try:
        # Ensure zones directory exists
        KNOT_ZONES_DIR.mkdir(parents=True, exist_ok=True)

        catalog_file = KNOT_ZONES_DIR / f"{catalog_zone_name}.zone"

        # Don't recreate if already exists
        if catalog_file.exists():
            print(f"[*] Catalog zone file already exists: {catalog_file}", file=sys.stderr)
            return True

        # Create minimal catalog zone file
        catalog_content = f"""$ORIGIN {catalog_zone_name}.
$TTL 3600

@   SOA ns1.{catalog_zone_name}. admin.{catalog_zone_name}. (
        1          ; serial
        3600       ; refresh
        1800       ; retry
        604800     ; expire
        86400 )    ; minimum

@   NS  ns1.{catalog_zone_name}.
ns1 A   127.0.0.1

; Member zones will be added automatically by catalog-role: generate
"""
        catalog_file.write_text(catalog_content)
        print(f"[*] Created catalog zone file: {catalog_file}", file=sys.stderr)

        # Set proper ownership
        subprocess.run(
            ["chown", "knot:knot", str(catalog_file)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return True

    except Exception as e:
        print(f"[!] Failed to create catalog zone file: {e}", file=sys.stderr)
        return False


def create_user_zone_file(zone_name: str, cluster_nodes: list = None, node_addrs: list = None) -> bool:
    """Create minimal zone file for user zone.

    This is required even with zonefile-load: none to provide initial
    zone content on first load. After initial load, Knot will use journal.

    Args:
        zone_name: Full zone name (e.g., "example.swarm.anthrax63.fun")
        cluster_nodes: List of cluster nodes (optional, for NS records)
        node_addrs: List of node addresses (optional, for glue A records)

    Returns:
        True if created successfully, False otherwise
    """
    try:
        # Ensure zones directory exists
        KNOT_ZONES_DIR.mkdir(parents=True, exist_ok=True)

        zone_file = KNOT_ZONES_DIR / f"{zone_name}.zone"

        # Don't recreate if already exists
        if zone_file.exists():
            print(f"[*] Zone file already exists: {zone_file}", file=sys.stderr)
            return True

        # Build NS and glue A records
        ns_records = []
        glue_records = []

        if cluster_nodes and node_addrs:
            # Create NS records for each cluster node with public IPs
            for i, node in enumerate(cluster_nodes, start=1):
                node_id = node.get("node_id")
                node_addr = get_node_addr(node_id, node_addrs)

                if node_addr:
                    # Use MD5 hash for consistent NS hostnames
                    node_hash = node_id_to_ns_name(node_id)
                    ns_hostname = f"ns{i}"
                    ns_records.append(f"@   NS  {ns_hostname}.{zone_name}.")
                    glue_records.append(f"{ns_hostname} A   {node_addr}")

        # Fallback to single localhost record if no cluster info provided
        if not ns_records:
            ns_records.append(f"@   NS  ns1.{zone_name}.")
            glue_records.append("ns1 A   127.0.0.1")

        ns_section = "\n".join(ns_records)
        glue_section = "\n".join(glue_records)

        # Create minimal zone file with SOA and NS records
        zone_content = f"""$ORIGIN {zone_name}.
$TTL 300

@   SOA ns1.{zone_name}. admin.{zone_name}. (
        1          ; serial
        3600       ; refresh
        1800       ; retry
        604800     ; expire
        300 )      ; minimum

{ns_section}
{glue_section}

; This zone is managed via catalog zones and dynamic updates
"""
        zone_file.write_text(zone_content)
        print(f"[*] Created user zone file: {zone_file}", file=sys.stderr)
        if cluster_nodes and node_addrs:
            print(f"[*] Added {len(ns_records)} NS records with public IPs", file=sys.stderr)

        # Set proper ownership
        subprocess.run(
            ["chown", "knot:knot", str(zone_file)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return True

    except Exception as e:
        print(f"[!] Failed to create user zone file: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return False


def create_dynamic_zone_in_knot(zone_name: str, is_catalog_master: bool, cluster_nodes: list = None, node_addrs: list = None, catalog_master_ip: str = None) -> bool:
    """Create dynamic zone for RFC2136 UPDATE with master-slave replication.

    Master node: Creates master zone that accepts RFC2136 UPDATE and sends NOTIFY to slaves.
    Member nodes: Creates slave zone that syncs from master via AXFR/IXFR.

    This ensures all nodes have the same DNS records after UPDATE on master.

    Args:
        zone_name: Full dynamic zone name (e.g., "dyn.abc123.swarm.anthrax63.fun")
        is_catalog_master: Whether this node is the catalog master
        cluster_nodes: List of cluster nodes (for NS records)
        node_addrs: List of node addresses (for glue A records)
        catalog_master_ip: IP of catalog master (used by member nodes to verify zone exists)

    Returns:
        True if zone was created or already exists, False on error
    """
    try:
        # Check if zone already exists
        result = subprocess.run(
            [KNOT_CLI, "zone-status", zone_name],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            print(f"[*] Dynamic zone {zone_name} already exists in Knot", file=sys.stderr)
            return True

        # Create dynamic zone (template differs for master vs member nodes)
        if is_catalog_master:
            print(f"[*] Creating dynamic zone {zone_name} as MASTER (accepts UPDATE, sends NOTIFY)", file=sys.stderr)
        else:
            print(f"[*] Creating dynamic zone {zone_name} as SLAVE (syncs from master)", file=sys.stderr)

        # Create minimal zone file
        if not create_user_zone_file(zone_name, cluster_nodes, node_addrs):
            print(f"[!] Failed to create zone file for {zone_name}", file=sys.stderr)
            return False

        # Add zone to zones.conf (persistent configuration)
        if not add_zone_to_zones_conf(zone_name, "dynamic"):
            print(f"[!] Failed to add zone to zones.conf", file=sys.stderr)
            return False

        # Reload Knot to apply changes
        result = subprocess.run(
            [KNOT_CLI, "reload"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            print(f"[!] Failed to reload Knot: {result.stderr}", file=sys.stderr)
            return False

        # Wait a bit for zone to load
        time.sleep(1)

        # Verify zone is loaded
        result = subprocess.run(
            [KNOT_CLI, "zone-status", zone_name],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            print(f"[*] Successfully created dynamic zone {zone_name} (accepts RFC2136 UPDATE)", file=sys.stderr)
            return True
        else:
            print(f"[!] Zone {zone_name} added to config but not loaded yet", file=sys.stderr)
            print(f"[!] Zone status: {result.stderr}", file=sys.stderr)
            # Return True anyway, it may load on next reload
            return True

    except subprocess.TimeoutExpired:
        print(f"[!] Timeout while creating dynamic zone {zone_name}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[!] Failed to create dynamic zone {zone_name}: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return False


def create_zone_in_knot(zone_name: str, is_catalog_master: bool, cluster_nodes: list = None, node_addrs: list = None) -> bool:
    """Create zone in Knot DNS via zones.conf (only on catalog master).

    With catalog zones, zones should only be created on the master node.
    They will automatically propagate to member nodes via catalog zone.

    Args:
        zone_name: Full zone name (e.g., "g5ebqqpj740uhqtu.swarm.anthrax63.fun")
        is_catalog_master: Whether this node is the catalog master
        cluster_nodes: List of cluster nodes (for NS records)
        node_addrs: List of node addresses (for glue A records)

    Returns:
        True if zone was created or already exists, False on error
    """
    try:
        # Check if zone already exists
        result = subprocess.run(
            [KNOT_CLI, "zone-status", zone_name],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            print(f"[*] Zone {zone_name} already exists in Knot", file=sys.stderr)
            return True

        # Zone doesn't exist, create it
        if is_catalog_master:
            print(f"[*] Creating zone {zone_name} on catalog master", file=sys.stderr)
        else:
            print(f"[*] Creating zone {zone_name} as member (syncs from master)", file=sys.stderr)

        # Create minimal zone file first
        if not create_user_zone_file(zone_name, cluster_nodes, node_addrs):
            print(f"[!] Failed to create zone file for {zone_name}", file=sys.stderr)
            return False

        # Add zone to zones.conf (persistent configuration)
        if not add_zone_to_zones_conf(zone_name, "member"):
            print(f"[!] Failed to add zone to zones.conf", file=sys.stderr)
            return False

        # Reload Knot to apply changes
        result = subprocess.run(
            [KNOT_CLI, "reload"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode != 0:
            print(f"[!] Failed to reload Knot: {result.stderr}", file=sys.stderr)
            return False

        # Wait a bit for zone to load
        time.sleep(1)

        # Verify zone is loaded
        result = subprocess.run(
            [KNOT_CLI, "zone-status", zone_name],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            print(f"[*] Successfully created zone {zone_name} on catalog master (will sync to members)", file=sys.stderr)
            return True
        else:
            print(f"[!] Zone {zone_name} added to config but not loaded yet", file=sys.stderr)
            print(f"[!] Zone status: {result.stderr}", file=sys.stderr)
            # Return True anyway, it may load on next reload or via catalog
            return True

    except subprocess.TimeoutExpired:
        print(f"[!] Timeout while creating zone {zone_name}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[!] Failed to create zone {zone_name}: {e}", file=sys.stderr)
        import traceback
        print(f"[!] Traceback: {traceback.format_exc()}", file=sys.stderr)
        return False


def node_id_to_ns_name(node_id: str) -> str:
    """Convert node_id to DNS-compatible NS name using MD5 hash in base36."""
    md5_hash = hashlib.md5(node_id.encode()).hexdigest()
    # Convert hex to int, then to base36
    hash_int = int(md5_hash, 16)
    base36_chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    if hash_int == 0:
        return "0"
    base36 = []
    while hash_int:
        hash_int, remainder = divmod(hash_int, 36)
        base36.append(base36_chars[remainder])
    return ''.join(reversed(base36))



# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize Knot DNS: install packages."""
    try:
        ensure_knot_package()

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply Knot DNS configuration and start the service."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    knot_props = state_json.get("knotNodeProperties", [])
    cluster_props = state_json.get("clusterProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])
    node_addrs = state_json.get("nodeAddrs", [])
    cluster = state_json.get("cluster", {})

    # Check if all nodes have WireGuard configured
    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all nodes',
            local_state=local_state
        )

    # Get global_id (required for zone name)
    global_id = state_json.get("globalId")
    if not global_id:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for global_id to be set in SwarmIdPointer table',
            local_state=local_state
        )

    # Get base_domain (required for zone name)
    base_domain = get_secret_from_swarmdb(state_json, "base_domain")
    if not base_domain:
        return PluginOutput(
            status='postponed',
            error_message='Waiting for base_domain to be set in SwarmSecrets',
            local_state=local_state
        )

    # Determine if this is leader node
    leader_node_id = get_leader_node(state_json)
    is_leader = (leader_node_id == local_node_id)
    cluster_initialized = is_cluster_initialized(knot_props)

    # Get local tunnel IP
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status='error',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state
        )

    if not is_knot_available():
        return PluginOutput(
            status='postponed',
            error_message='Waiting for knot package install (init)',
            local_state=local_state,
        )

    # Get or generate TSIG key (leader node only, once)
    tsig_key_name = None
    tsig_key_secret = None

    for prop in cluster_props:
        if prop.get("name") == "knot_tsig_key_name":
            tsig_key_name = prop.get("value")
        elif prop.get("name") == "knot_tsig_key_secret":
            tsig_key_secret = prop.get("value")

    cluster_properties = {}

    if not tsig_key_name or not tsig_key_secret:
        if is_leader and not cluster_initialized:
            # Leader generates TSIG key on first initialization
            print(f"[*] Leader node generating TSIG key", file=sys.stderr)
            tsig_result = generate_tsig_key()
            if not tsig_result:
                return PluginOutput(
                    status='error',
                    error_message='Failed to generate TSIG key',
                    local_state=local_state
                )
            tsig_key_name, tsig_key_secret = tsig_result
            cluster_properties["knot_tsig_key_name"] = tsig_key_name
            cluster_properties["knot_tsig_key_secret"] = tsig_key_secret
            print(f"[*] Generated TSIG key: {tsig_key_name}", file=sys.stderr)
            print(f"[*] Will publish cluster_properties: {list(cluster_properties.keys())}", file=sys.stderr)
        else:
            # Non-leader or already initialized: wait for TSIG key
            return PluginOutput(
                status='postponed',
                error_message='Waiting for TSIG key to be generated by leader',
                local_state=local_state
            )

    # Determine catalog master (use leader node as catalog master)
    is_catalog_master = is_leader

    # Get catalog master IP (first node in sorted list for consistency)
    catalog_master_ip = None
    if not is_catalog_master:
        # Find leader's tunnel IP
        catalog_master_ip = get_node_tunnel_ip(leader_node_id, wg_props)
        if not catalog_master_ip:
            return PluginOutput(
                status='postponed',
                error_message='Waiting for leader node to have WireGuard tunnel IP',
                local_state=local_state
            )

    # Create catalog zone file BEFORE writing config (master node only)
    # Note: For catalog-role: generate, the file is not strictly required,
    # but we create it to avoid any potential issues
    if is_catalog_master:
        catalog_created = create_catalog_zone_file()
        if not catalog_created:
            return PluginOutput(
                status='postponed',
                error_message='Failed to create catalog zone file',
                local_state=local_state
            )

    # Write Knot configuration
    try:
        write_knot_config(
            local_node_id=local_node_id,
            local_tunnel_ip=local_tunnel_ip,
            cluster_nodes=cluster_nodes,
            wg_props=wg_props,
            is_catalog_master=is_catalog_master,
            tsig_key_name=tsig_key_name,
            tsig_key_secret=tsig_key_secret,
            catalog_master_ip=catalog_master_ip,
            node_addrs=node_addrs,
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to write config: {str(e)}', local_state=local_state)

    # Start/restart Knot DNS server
    try:
        enable_knot_service()
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to start Knot: {str(e)}', local_state=local_state)

    # Wait for Knot to become ready
    knot_ready = wait_for_knot_ready(timeout_sec=30)
    if not knot_ready:
        return PluginOutput(
            status='postponed',
            error_message='Knot DNS did not become ready within timeout',
            local_state=local_state
        )

    # Mark node as ready
    node_properties = {"knot_node_ready": "true"}

    # Create zones in Knot FIRST (before PowerDNS) - zones are required for auth-service and other
    # internal DNS updates. PowerDNS is for external delegation; if it fails, zones still work.
    delegated_zone = f"{global_id}.{base_domain}"
    dynamic_zone = f"dyn.{delegated_zone}"

    zone_created = create_zone_in_knot(delegated_zone, is_catalog_master, cluster_nodes, node_addrs)
    if not zone_created:
        print(f"[!] Failed to create base zone {delegated_zone} in Knot, will retry", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message=f'Failed to create zone {delegated_zone} in Knot',
            node_properties=node_properties,
            cluster_properties=cluster_properties if cluster_properties else None,
            local_state=local_state
        )

    dynamic_zone_created = create_dynamic_zone_in_knot(dynamic_zone, is_catalog_master, cluster_nodes, node_addrs)
    if not dynamic_zone_created:
        print(f"[!] Failed to create dynamic zone {dynamic_zone} in Knot, will retry", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message=f'Failed to create dynamic zone {dynamic_zone} in Knot',
            node_properties=node_properties,
            cluster_properties=cluster_properties if cluster_properties else None,
            local_state=local_state
        )

    # Mark cluster as initialized once zones are created (leader only, once)
    if is_leader and not cluster_initialized:
        print(f"[*] Leader: zones ready, marking cluster as initialized", file=sys.stderr)
        node_properties["knot_cluster_initialized"] = "true"

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        cluster_properties=cluster_properties if cluster_properties else None,
        local_state=local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check Knot DNS health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Check if Knot is running
    knot_running, knot_error = is_knot_running()
    if not knot_running:
        if knot_error and 'Failed to' in knot_error:
            # Real error checking status
            return PluginOutput(status='error', error_message=knot_error, local_state=local_state)
        else:
            # Service not running yet
            return PluginOutput(status='postponed', error_message=knot_error or 'Knot service is not running', local_state=local_state)

    # Check Knot status
    try:
        result = subprocess.run(
            [KNOT_CLI, "status"],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode != 0:
            return PluginOutput(status='postponed', error_message='Knot is not responding', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='postponed', error_message=f'Failed to check Knot status: {e}', local_state=local_state)

    # If this is the leader node, verify PowerDNS A records registration
    cluster = state_json.get("cluster", {})
    leader_node_id = cluster.get("leader_node")
    is_leader = (leader_node_id == local_node_id)

    if is_leader:
        knot_props = state_json.get("knotNodeProperties", [])
        cluster_initialized = is_cluster_initialized(knot_props)

        if cluster_initialized:
            # Get PowerDNS credentials and verify base zone accessibility
            powerdns_api_url = get_secret_from_swarmdb(state_json, "powerdns_api_url")
            powerdns_api_key = get_secret_from_swarmdb(state_json, "powerdns_api_key")
            base_domain = get_secret_from_swarmdb(state_json, "base_domain")
            global_id = state_json.get("globalId")

            if powerdns_api_url and powerdns_api_key and base_domain and global_id:
                try:
                    headers = {
                        "X-API-Key": powerdns_api_key,
                        "Content-Type": "application/json"
                    }
                    # Verify base zone is accessible (not subzone)
                    base_zone_url = f"{powerdns_api_url}/api/v1/servers/localhost/zones/{base_domain}."
                    check_response = requests.get(base_zone_url, headers=headers, timeout=10)

                    if check_response.status_code != 200:
                        print(f"[!] PowerDNS base zone {base_domain} check failed: {check_response.status_code}", file=sys.stderr)
                        return PluginOutput(
                            status='postponed',
                            error_message=f'PowerDNS base zone verification failed: {check_response.status_code}',
                            local_state=local_state
                        )
                    else:
                        print(f"[*] PowerDNS base zone {base_domain} verified successfully", file=sys.stderr)

                except requests.exceptions.RequestException as e:
                    print(f"[!] Failed to verify PowerDNS base zone: {e}", file=sys.stderr)
                    return PluginOutput(
                        status='postponed',
                        error_message=f'PowerDNS connectivity check failed: {str(e)}',
                        local_state=local_state
                    )

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal (graceful shutdown)."""
    local_state = input_data.local_state or {}

    # TODO: Implement graceful node removal if needed
    # This could involve:
    # - Removing node from PowerDNS
    # - Waiting for DNS propagation

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy Knot DNS installation and clean up."""
    try:
        disable_knot_service()

        # Remove config and data directories
        if KNOT_CONFIG_DIR.exists():
            shutil.rmtree(KNOT_CONFIG_DIR, ignore_errors=True)
        if KNOT_DATA_DIR.exists():
            shutil.rmtree(KNOT_DATA_DIR, ignore_errors=True)

        # Request deletion of node properties
        node_properties = {
            "knot_node_ready": None,
            "knot_cluster_initialized": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy Knot DNS: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
