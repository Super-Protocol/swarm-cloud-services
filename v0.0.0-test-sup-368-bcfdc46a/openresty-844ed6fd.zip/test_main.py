#!/usr/bin/env python3
"""Unit tests for openresty/main.py pure helpers."""

import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402


def _nginx_config() -> str:
    return main.generate_nginx_config(
        redis_hosts=["10.0.0.1"],
        sentinel_hosts=["10.0.0.1"],
        is_leader=True,
        acme_leader_addr=None,
        acme_ca_url=None,
    )


def _strip_comments(text: str, marker: str) -> str:
    """Drop whole-line comments so assertions read code, not the rationale."""
    return "\n".join(
        line for line in text.splitlines() if not line.lstrip().startswith(marker)
    )


def _location_block(config: str, path: str) -> str:
    """Return the body of the `location = <path>` block, braces balanced."""
    start = config.index(f"location = {path} {{")
    depth = 0
    for index in range(start, len(config)):
        char = config[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return config[start : index + 1]
    raise AssertionError(f"unterminated location block for {path}")


class SwarmEvidenceCorsTests(unittest.TestCase):
    """SUP-192: the evidence document is public and signed, so it is CORS-open."""

    EVIDENCE_PATH = "/.well-known/swarm-evidence"

    def setUp(self):
        self.block = _location_block(_nginx_config(), self.EVIDENCE_PATH)

    def test_allows_any_origin(self):
        self.assertIn('add_header Access-Control-Allow-Origin "*" always;', self.block)

    def test_exposes_the_headers_a_verifier_reads(self):
        self.assertIn(
            'add_header Access-Control-Expose-Headers "Content-Type, Cache-Control" always;',
            self.block,
        )

    def test_cors_headers_are_unconditional(self):
        # `always` is what makes the 404 not-attested / 503 contract responses
        # readable cross-origin instead of an opaque CORS failure.
        for header in self.block.splitlines():
            if "Access-Control-" in header:
                self.assertTrue(header.rstrip().endswith("always;"), header.strip())

    def test_keeps_serving_the_bundle_no_store(self):
        self.assertIn('add_header Cache-Control "no-store" always;', self.block)
        self.assertIn("content_by_lua_file conf/lua/swarm_evidence.lua;", self.block)

    def test_other_locations_are_not_cors_open(self):
        # The blanket `location /` proxies tenant traffic; opening it would be a
        # real policy change rather than publishing a public document.
        elsewhere = _strip_comments(_nginx_config().replace(self.block, ""), "#")
        self.assertNotIn("Access-Control-", elsewhere)


class SwarmRoutesEndpointTests(unittest.TestCase):
    """SUP-216: the host reads the ingress hostname index over :443, not ssh."""

    ROUTES_PATH = "/.well-known/swarm-routes"

    def setUp(self):
        self.config = _nginx_config()
        self.block = _location_block(self.config, self.ROUTES_PATH)

    def test_serves_the_lua_handler_as_json(self):
        self.assertIn("content_by_lua_file conf/lua/swarm_routes.lua;", self.block)
        self.assertIn("default_type application/json;", self.block)

    def test_is_not_cached(self):
        # A stale index would keep a just-deployed ingress hostname invisible to
        # the host for as long as any cache in between holds it.
        self.assertIn('add_header Cache-Control "no-store" always;', self.block)

    def test_is_not_cors_open(self):
        # Only a curl on the host reads this; there is no browser origin to
        # allow, so it must not inherit swarm-evidence's blanket ACAO.
        self.assertNotIn("Access-Control-", _strip_comments(self.block, "#"))

    def test_shares_the_tls_terminating_server_with_swarm_evidence(self):
        # It has to answer on the hostname the host probes, which is the one the
        # gateway terminates TLS for -- not the :80 redirect server.
        evidence = self.config.index("location = /.well-known/swarm-evidence {")
        routes = self.config.index(f"location = {self.ROUTES_PATH} {{")
        blanket = self.config.index("        location / {\n            # Important:")
        self.assertLess(evidence, routes)
        self.assertLess(routes, blanket)

    def test_has_its_own_cache_dict(self):
        # Keyed by a constant, so it cannot share route_cache (keyed by hostname)
        # without risking a collision with a real domain.
        self.assertIn("lua_shared_dict swarm_routes_cache 1m;", self.config)


class SwarmRoutesLuaTests(unittest.TestCase):
    """What the handler is allowed to disclose, and how it reads Redis."""

    def setUp(self):
        self.lua = main.SWARM_ROUTES_LUA
        self.code = _strip_comments(self.lua, "--")

    def test_publishes_hostnames_from_both_route_prefixes(self):
        self.assertIn('local PREFIXES = { "routes:", "manual-routes:" }', self.lua)
        self.assertIn("count = #hosts", self.lua)

    def test_discloses_nothing_from_the_route_object(self):
        # The unauthenticated-path argument rests on this: hostnames are already
        # public in DNS, upstream targets and tunnel IPs are not.
        for leaked in ("targets", "path_routes", "passthrough", "red:get("):
            self.assertNotIn(leaked, self.code, f"handler reads/returns {leaked!r}")

    def test_scans_instead_of_listing_keys(self):
        # KEYS blocks the Redis master for the whole keyspace walk.
        self.assertIn("red:scan(cursor", self.code)
        self.assertNotIn("red:keys(", self.code)

    def test_scan_loop_is_bounded(self):
        self.assertIn("local MAX_SCAN_CALLS = 500", self.lua)
        self.assertIn('until cursor == "0"', self.code)

    def test_a_truncated_walk_fails_instead_of_answering(self):
        # The bound counts redis round trips over the whole keyspace, not matches, so hitting
        # it means the walk did NOT finish. Serving the partial list would silently drop
        # ingress hostnames — and flap, since SCAN order is arbitrary.
        self.assertIn('if cursor ~= "0" and calls >= MAX_SCAN_CALLS then', self.code)
        self.assertIn('return fail(503, "scan-incomplete")', self.code)

    def test_emits_a_json_array_even_when_there_are_no_routes(self):
        # An empty Lua table encodes as `{}`, and the host rejects a body whose `hosts` is
        # not an array — turning "nothing routed yet" into "channel unavailable".
        self.assertIn("cjson.empty_array", self.code)

    def test_sorts_the_list(self):
        # The host compares successive polls to decide whether to rewrite its
        # SNI map; SCAN order is arbitrary, so an unsorted list would churn.
        self.assertIn("table.sort(hosts)", self.code)

    def test_caches_the_index_briefly(self):
        self.assertIn("local CACHE_TTL = 10", self.lua)
        self.assertIn("cache:set(CACHE_KEY, body, CACHE_TTL)", self.code)

    def test_rejects_writes(self):
        self.assertIn('if method ~= "GET" and method ~= "HEAD" then', self.code)
        self.assertIn('return fail(405, "method-not-allowed")', self.code)

    def test_closes_redis_on_the_scan_error_path(self):
        # A leaked connection on a 503 path would exhaust the master's client
        # slots under the host's polling timer.
        scan_fail = self.code.index('return fail(503, "redis-error")')
        self.assertIn("red:close()", self.code[scan_fail - 200:scan_fail])


class SwarmRoutesLuaWriterTests(unittest.TestCase):
    def test_writes_handler_when_absent(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            target_dir = Path(tmp) / "lua"
            original = main.OPENRESTY_LUA_DIR
            main.OPENRESTY_LUA_DIR = target_dir
            try:
                main.write_swarm_routes_lua()
                written = (target_dir / "swarm_routes.lua").read_text(encoding="utf-8")
            finally:
                main.OPENRESTY_LUA_DIR = original
        self.assertEqual(written, main.SWARM_ROUTES_LUA)


class SwarmEvidencePreflightTests(unittest.TestCase):
    """The preflight is answered without consulting cluster state."""

    def setUp(self):
        self.lua = main.SWARM_EVIDENCE_LUA

    def test_answers_options_with_204(self):
        self.assertIn('if ngx.req.get_method() == "OPTIONS" then', self.lua)
        self.assertIn("return ngx.exit(204)", self.lua)

    def test_advertises_the_methods_and_headers_a_verifier_may_send(self):
        self.assertIn(
            'ngx.header["Access-Control-Allow-Methods"] = "GET, HEAD, OPTIONS"', self.lua
        )
        self.assertIn('ngx.header["Access-Control-Allow-Headers"] = "*"', self.lua)
        self.assertIn('ngx.header["Access-Control-Max-Age"] = "86400"', self.lua)

    def test_preflight_short_circuits_before_redis(self):
        options_branch = self.lua.index('if ngx.req.get_method() == "OPTIONS" then')
        redis_connect = self.lua.index("connect_redis_master(red)")
        self.assertLess(options_branch, redis_connect)

    def test_preflight_does_not_set_allow_origin_itself(self):
        # nginx adds it for every response on the location; a second copy in Lua
        # would emit the header twice and browsers reject a duplicated ACAO.
        self.assertNotIn("Access-Control-Allow-Origin", _strip_comments(self.lua, "--"))


class SwarmEvidenceLuaWriterTests(unittest.TestCase):
    def test_writes_handler_when_absent(self):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            target_dir = Path(tmp) / "lua"
            original = main.OPENRESTY_LUA_DIR
            main.OPENRESTY_LUA_DIR = target_dir
            try:
                main.write_swarm_evidence_lua()
                written = (target_dir / "swarm_evidence.lua").read_text(encoding="utf-8")
            finally:
                main.OPENRESTY_LUA_DIR = original
        self.assertEqual(written, main.SWARM_EVIDENCE_LUA)
        self.assertIn('if ngx.req.get_method() == "OPTIONS" then', written)


class ConfigHashCoversRenderedFilesTests(unittest.TestCase):
    """SUP-192: a template-only release must not take the unchanged shortcut."""

    HASH_ARGS = (
        ["10.0.0.1"],  # redis_hosts
        ["10.0.0.1"],  # sentinel_hosts
        "node-a",  # leader_node_id
        "10.0.0.1:443",  # leader_addr
        "letsencrypt",  # acme_provider
        None,  # acme_ca_url
        None,  # acme_eab_fingerprint
        "openresty@sha256:abc",  # openresty_image
    )

    def _hash(self, rendered: str) -> str:
        return main.compute_config_hash(*self.HASH_ARGS, rendered)

    def test_same_topology_and_template_hash_alike(self):
        self.assertEqual(self._hash("server {}"), self._hash("server {}"))

    def test_changed_nginx_template_changes_the_hash(self):
        # The exact failure this guards: topology is byte-identical across a
        # service upgrade, so only the rendered config can signal the change.
        self.assertNotEqual(
            self._hash("server {}"),
            self._hash("server { add_header Access-Control-Allow-Origin \"*\" always; }"),
        )

    def test_changed_routes_handler_changes_the_hash(self):
        # SUP-216 ships a second Lua file; leaving it out of the hash would make
        # a release that only edits it a no-op on a running gateway.
        original = main.SWARM_ROUTES_LUA
        before = self._hash("server {}")
        main.SWARM_ROUTES_LUA = original + "\n-- edited\n"
        try:
            after = self._hash("server {}")
        finally:
            main.SWARM_ROUTES_LUA = original
        self.assertNotEqual(before, after)

    def test_changed_lua_handler_changes_the_hash(self):
        original = main.SWARM_EVIDENCE_LUA
        before = self._hash("server {}")
        main.SWARM_EVIDENCE_LUA = original + "\n-- edited\n"
        try:
            after = self._hash("server {}")
        finally:
            main.SWARM_EVIDENCE_LUA = original
        self.assertNotEqual(before, after)

    def test_topology_still_moves_the_hash(self):
        other = list(self.HASH_ARGS)
        other[0] = ["10.0.0.2"]
        self.assertNotEqual(
            self._hash("server {}"),
            main.compute_config_hash(*other, "server {}"),
        )



class GatewayErrorsEndpointTests(unittest.TestCase):
    """SUP-367: the gateway has to leave a trace of the 5xx it renders."""

    def setUp(self):
        self.config = _nginx_config()

    def test_records_on_every_response_of_the_tls_server(self):
        # Hooked at server level, not per location: `ngx.exec` hands the request
        # to an internal location before the log phase, and the routing Lua's
        # own `503 No backend targets available` never reaches one at all.
        server = self.config.index("listen 127.0.0.1:8443 ssl;")
        hook = self.config.index('require("gateway_errors").record()')
        first_location = self.config.index("        location = /.well-known/swarm-evidence {")
        self.assertLess(server, hook)
        self.assertLess(hook, first_location)
        self.assertIn("log_by_lua_block {", self.config)

    def test_has_its_own_dict(self):
        # Sharing route_cache (keyed by hostname) would let a counter key
        # collide with a real domain's cached route.
        self.assertIn("lua_shared_dict gateway_errors 2m;", self.config)

    def test_flush_timer_starts_in_every_worker(self):
        init_worker = self.config.index("init_worker_by_lua_block {")
        start = self.config.index('require("gateway_errors").start()')
        self.assertLess(init_worker, start)

    def test_does_not_expose_the_samples_over_https(self):
        # A sample carries the upstream target -- a WireGuard IP and NodePort --
        # so unlike /.well-known/swarm-routes (hostnames only, already public in
        # DNS) it must not get a credential-free path. The authenticated API
        # reads it out of Redis instead.
        for key in ("gateway-errors:recent", "gateway-errors:counters", "gateway-errors:heartbeat"):
            self.assertNotIn(key, self.config)
        self.assertEqual(
            sorted(re.findall(r"location = (/\.well-known/\S+) \{", self.config)),
            ["/.well-known/swarm-evidence", "/.well-known/swarm-routes"],
        )


class GatewayErrorsLuaTests(unittest.TestCase):
    """The contract the module keeps even when Redis is unavailable."""

    def setUp(self):
        self.lua = main.GATEWAY_ERRORS_LUA
        self.code = _strip_comments(self.lua, "--")

    def test_only_server_errors_are_recorded(self):
        self.assertIn("if not status or status < 500 then", self.code)

    def test_counters_and_ring_live_under_a_retention_ttl(self):
        # Both key families expire: an incident log that grows forever is a
        # different outage.
        self.assertIn("local RETENTION = 172800", self.lua)
        self.assertIn("red:expire(bucket, RETENTION)", self.code)
        self.assertIn("red:expire(RECENT_KEY, RETENTION)", self.code)

    def test_counters_are_bucketed_by_hour(self):
        # "How many 5xx on this hostname at 08:00 UTC" is the question SUP-365
        # could not answer; a single cumulative counter would not answer it either.
        self.assertIn('os.date("!%Y%m%d%H")', self.lua)

    def test_the_log_phase_never_touches_a_socket(self):
        # log_by_lua has no cosocket support, so a Redis call in `record` would
        # fail at runtime on every single error -- exactly when it matters.
        record = self.code[self.code.index("function _M.record()") : self.code.index("local function collect")]
        self.assertNotIn("redis", record)
        self.assertNotIn("connect_redis_master", record)

    def _drain(self) -> str:
        start = self.code.index("local function drain(dict)")
        return self.code[start : self.code.index("function _M.flush()")]

    def test_the_dict_is_drained_only_after_redis_accepts(self):
        # Otherwise a Redis blip silently eats the evidence it was collecting.
        drain = self._drain()
        subtract = drain.index("dict:incr(counter.key, -counter.delta")
        write = drain.index("red:hincrby(bucket")
        self.assertLess(write, subtract)
        self.assertIn('ngx.log(ngx.ERR, "gateway-errors: redis connect failed: ", err)', drain)

    def test_a_flushed_counter_is_never_recreated_negative(self):
        # `incr` with an `init` would resurrect a key the dict TTL expired
        # mid-flush holding a negative count; `collect` only reads values > 0,
        # so the next window's real counts would vanish into that hole.
        self.assertIn("dict:incr(counter.key, -counter.delta)\n", self._drain())

    def test_the_flush_releases_its_own_lock(self):
        # A lock left to expire after FLUSH_INTERVAL makes every second window
        # a no-op, halving the cadence it advertises.
        flush = self.code[self.code.index("function _M.flush()") :]
        self.assertIn('dict:delete("flush_lock")', flush)

    def test_one_worker_drains_per_window(self):
        # The dict is shared across nginx workers; without the lock they would
        # race to drain the same keys and double-count.
        self.assertIn('if not dict:add("flush_lock", 1, FLUSH_INTERVAL) then', self.lua)

    def test_dropped_samples_are_published(self):
        # A truncated window must not read like a quiet one.
        self.assertIn('local DROPPED_FIELD = "#dropped"', self.lua)
        self.assertIn("local MAX_PENDING_SAMPLES = 200", self.lua)

    def test_every_flush_heartbeats_even_the_quiet_ones(self):
        # Otherwise "this gateway served no 5xx" and "nothing here publishes
        # 5xx" are the same empty read, and the reader cannot tell good news
        # from a dead channel.
        drain = self._drain()
        heartbeat = drain.index("red:setex(HEARTBEAT_KEY")
        drain_guard = drain.index("if #counters == 0 and #samples == 0 then")
        self.assertLess(heartbeat, drain_guard)
        self.assertIn("local HEARTBEAT_TTL = 60", self.lua)


class GatewayErrorsLuaBehaviourTests(unittest.TestCase):
    """Executes the module against fake ngx/Redis -- see test_gateway_errors.lua."""

    HARNESS = HERE / "test_gateway_errors.lua"

    @unittest.skipUnless(shutil.which("luajit"), "luajit not installed")
    def test_harness_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = Path(tmp) / "gateway_errors.lua"
            module.write_text(main.GATEWAY_ERRORS_LUA, encoding="utf-8")
            result = subprocess.run(
                ["luajit", str(self.HARNESS), str(module)],
                capture_output=True,
                text=True,
                check=False,
            )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


class GatewayErrorsLuaWriterTests(unittest.TestCase):
    """The log phase `require`s the module, so apply must have written it."""

    def test_writes_the_module_next_to_the_other_handlers(self):
        with tempfile.TemporaryDirectory() as tmp:
            target_dir = Path(tmp) / "lua"
            original = main.OPENRESTY_LUA_DIR
            main.OPENRESTY_LUA_DIR = target_dir
            try:
                main.write_gateway_errors_lua()
                written = (target_dir / "gateway_errors.lua").read_text(encoding="utf-8")
            finally:
                main.OPENRESTY_LUA_DIR = original
        self.assertEqual(written, main.GATEWAY_ERRORS_LUA)

    def test_changed_module_changes_the_config_hash(self):
        # Same reason as SUP-216's handler: a release that only edits the module
        # would otherwise take apply's unchanged-config shortcut and never land.
        original = main.GATEWAY_ERRORS_LUA
        args = GatewayErrorsLuaWriterTests.HASH_ARGS
        before = main.compute_config_hash(*args, "server {}")
        main.GATEWAY_ERRORS_LUA = original + "\n-- edited\n"
        try:
            after = main.compute_config_hash(*args, "server {}")
        finally:
            main.GATEWAY_ERRORS_LUA = original
        self.assertNotEqual(before, after)


GatewayErrorsLuaWriterTests.HASH_ARGS = ConfigHashCoversRenderedFilesTests.HASH_ARGS


class NginxConfigShapeTests(unittest.TestCase):
    def test_braces_balance(self):
        config = _nginx_config()
        self.assertEqual(config.count("{"), config.count("}"))

    def test_no_unexpanded_format_placeholders(self):
        config = _nginx_config()
        self.assertIsNone(
            re.search(r"\{[a-z_]+\}", config),
            "generated config still contains a str.format placeholder",
        )


if __name__ == "__main__":
    unittest.main()
