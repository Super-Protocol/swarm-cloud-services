#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import hashlib
import time
import json
import shlex
import tempfile
import traceback
import builtins as _builtins
from pathlib import Path

from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

# Configuration
OPENRESTY_CONFIG_DIR = Path("/usr/local/openresty/nginx/conf")
OPENRESTY_CONFIG_FILE = OPENRESTY_CONFIG_DIR / "nginx.conf"
OPENRESTY_SSL_DIR = OPENRESTY_CONFIG_DIR / "ssl"
OPENRESTY_LUA_DIR = OPENRESTY_CONFIG_DIR / "lua"
OPENRESTY_LOG_DIR = Path("/var/log/openresty")
NGINX_LOGS_DIR = Path("/usr/local/openresty/nginx/logs")

# ACME/AutoSSL config
OPENRESTY_ACME_CONFIG_PATH = Path("/sp/swarm/openresty.yaml")
DEFAULT_ACME_PROVIDER = "letsencrypt"
SUPPORTED_ACME_PROVIDER_OVERRIDE = "zerossl"
AUTO_SSL_DIR = Path("/etc/resty-auto-ssl")
DEHYDRATED_BIN = Path("/usr/local/bin/resty-auto-ssl/dehydrated")

PODMAN_BIN = os.environ.get("PODMAN_BIN", "podman")
# Noble-based image: includes `www-data` (33:33) matching `user www-data` in generated nginx.conf.
# Lua deps (lua-resty-http, lua-resty-auto-ssl) are not in upstream slim/minimal tags — installed via OPM into OPENRESTY_SITE_DIR.
OPENRESTY_IMAGE = os.environ.get(
    "OPENRESTY_IMAGE",
    "registry-1.docker.io/openresty/openresty:noble-amd64@sha256:471a00e7bf7235f64fe67861e5b46484358b5e39b7692e5043c6d541227e1d94",
)
OPENRESTY_CONTAINER_NAME = os.environ.get("OPENRESTY_CONTAINER_NAME", "openresty-gateway")
OPENRESTY_SERVICE_UNIT = "openresty.service"
OPENRESTY_SERVICE_NAME = OPENRESTY_SERVICE_UNIT.removesuffix(".service")
OPENRESTY_SITE_DIR = Path("/usr/local/openresty/site")
OPM_AUTO_SSL_PACKAGE = os.environ.get("OPM_LUA_RESTY_AUTO_SSL", "maskshell/lua-resty-auto-ssl")
# lua-resty-auto-ssl Makefile installs this file from juce/lua-resty-shell; OPM tarballs often omit it.
LUA_RESTY_SHELL_VERSION = os.environ.get(
    "LUA_RESTY_SHELL_VERSION",
    "955243d70506c21e7cc29f61d745d1a8a718994f",
)
# Binaries under DEHYDRATED_BIN.parent (bind-mounted as /usr/local/bin/resty-auto-ssl); see lua-resty-auto-ssl Makefile.
LUA_RESTY_AUTO_SSL_TAG = os.environ.get("LUA_RESTY_AUTO_SSL_TAG", "v0.13.1").strip() or "v0.13.1"
SOCKPROC_VERSION = os.environ.get(
    "SOCKPROC_VERSION",
    "92aba736027bb5d96e190b71555857ac5bb6b2be",
)
OPENRESTY_CPU_PLATFORM = os.environ.get("OPENRESTY_CPU_PLATFORM", "linux/amd64")


def _ensure_apt_state_dirs() -> None:
    """Best-effort creation of directories/files required by apt/dpkg.

    Some minimal images/VM snapshots may be missing /var/lib/dpkg entirely, which
    makes apt fail with: 'Could not open lock file ... lock-frontend'.
    """
    paths_to_mkdir = [
        Path("/var/lib/dpkg"),
        Path("/var/lib/dpkg/updates"),
        Path("/var/lib/dpkg/info"),
        Path("/var/lib/dpkg/alternatives"),
        Path("/var/lib/dpkg/triggers"),
        Path("/var/lib/apt/lists/partial"),
        Path("/var/cache/apt/archives/partial"),
    ]
    for p in paths_to_mkdir:
        try:
            p.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    # Touch lock files and status file if they are missing.
    paths_to_touch = [
        Path("/var/lib/dpkg/lock-frontend"),
        Path("/var/lib/dpkg/lock"),
        Path("/var/lib/dpkg/status"),
    ]
    for p in paths_to_touch:
        try:
            if not p.exists():
                p.touch(exist_ok=True)
        except Exception:
            pass


def ensure_hexdump_available() -> None:
    """Ensure `hexdump` exists on the host and can be bind-mounted into the OpenResty container.

    Dehydrated runs inside the Podman workload but may invoke `hexdump`; official images may not
    ship it, so we install `bsdextrautils` on Ubuntu and mount `/usr/bin/hexdump` read-only.
    """
    # If hexdump is already present, nothing to do.
    if shutil.which("hexdump"):
        return

    os_release = ""
    try:
        os_release = Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore").lower()
    except Exception:
        pass

    if "ubuntu" not in os_release:
        raise RuntimeError("Missing required command 'hexdump' (unable to auto-install on non-Ubuntu)")

    apt_env = os.environ.copy()
    apt_env["DEBIAN_FRONTEND"] = "noninteractive"

    _ensure_apt_state_dirs()

    # Bootstrap apt-utils first so dpkg/debconf don't block later installs.
    subprocess.run(
        ["apt-get", "install", "-y", "--no-install-recommends", "apt-utils"],
        capture_output=True,
        text=True,
        check=False,
        env=apt_env,
    )

    subprocess.run(["apt-get", "update"], capture_output=True, text=True, check=False, env=apt_env)

    # Packages that commonly provide hexdump across Ubuntu versions.
    candidates = ["bsdextrautils", "bsdmainutils"]
    last_err = ""
    for pkg in candidates:
        try:
            result = subprocess.run(
                ["apt-get", "install", "-y", "--no-install-recommends", pkg],
                capture_output=True,
                text=True,
                check=False,
                env=apt_env,
            )
            if result.returncode == 0 and shutil.which("hexdump"):
                return
            last_err = (result.stderr or result.stdout or "").strip()
        except Exception as e:
            last_err = str(e)

    raise RuntimeError(
        "Missing required command 'hexdump' and auto-install failed. "
        f"Tried packages: {', '.join(candidates)}. Details: {last_err}"
    )

# Plugin setup
plugin = ProvisionPlugin()


def print(*args, **kwargs):
    """Module-local print wrapper to prefix all logs with service name."""
    prefix = "[openresty]"
    if args and isinstance(args[0], str) and args[0].startswith(prefix):
        return _builtins.print(*args, **kwargs)
    return _builtins.print(prefix, *args, **kwargs)


# Helper functions

def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def get_redis_tunnel_ips(state_json: dict) -> list[str]:
    """Get tunnel IPs of all ready Redis nodes."""
    redis_node_props = state_json.get("redisNodeProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])

    redis_hosts = []
    for prop in redis_node_props:
        if prop.get("name") == "redis_node_ready" and prop.get("value") == "true":
            node_id = prop.get("node_id")
            tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
            if tunnel_ip:
                redis_hosts.append(tunnel_ip)

    return sorted(set(redis_hosts))


def get_sentinel_tunnel_ips(state_json: dict) -> list[str]:
    """Get tunnel IPs of all ready Redis Sentinel nodes."""
    sentinel_props = state_json.get("sentinelNodeProperties", [])
    wg_props = state_json.get("sentinelWgNodeProperties", []) or state_json.get("wgNodeProperties", [])

    sentinel_hosts = []
    for prop in sentinel_props:
        if prop.get("name") == "redis_sentinel_node_ready" and prop.get("value") == "true":
            node_id = prop.get("node_id")
            tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
            if tunnel_ip:
                sentinel_hosts.append(tunnel_ip)

    return sorted(set(sentinel_hosts))



def get_node_addr(node_id: str, node_addrs: list) -> str | None:
    """Get physical address for a node."""
    for node in node_addrs:
        if node.get("node_id") == node_id:
            return node.get("addr")
    return None


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")



def compute_config_hash(
    redis_hosts: list[str],
    sentinel_hosts: list[str],
    leader_node_id: str | None,
    leader_addr: str | None,
    acme_provider: str,
    acme_ca_url: str | None,
    acme_eab_fingerprint: str | None,
    openresty_image: str,
    rendered_config: str,
) -> str:
    """Compute hash of configuration based on Redis/Sentinel hosts, leader/stream TLS routing, container image, and the rendered gateway files.

    `rendered_config` folds the nginx config this apply would write — and the
    Lua handlers that ship beside it — into the hash. Without it, a service
    release that only changes the templates re-applies to nothing: the topology
    inputs are byte-identical, `apply` takes the unchanged-config shortcut, and
    the new files are never written to a running gateway (SUP-192).
    """
    payload_parts = sorted(redis_hosts) + ["||"] + sorted(sentinel_hosts)
    payload_parts.append(f"leader_node_id:{leader_node_id or ''}")
    payload_parts.append(f"leader_addr:{leader_addr or ''}")
    payload_parts.append(f"acme_provider:{acme_provider}")
    payload_parts.append(f"acme_ca_url:{acme_ca_url or ''}")
    payload_parts.append(f"acme_eab:{acme_eab_fingerprint or ''}")
    payload_parts.append(f"openresty_image:{openresty_image}")
    rendered = f"{rendered_config}\n{SWARM_EVIDENCE_LUA}\n{SWARM_ROUTES_LUA}\n{GATEWAY_ERRORS_LUA}"
    payload_parts.append(f"rendered:{hashlib.sha256(rendered.encode()).hexdigest()}")
    payload = "|".join(payload_parts)
    return hashlib.sha256(payload.encode()).hexdigest()


def _fingerprint_secret(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _parse_simple_yaml_kv(content: str) -> dict[str, str]:
    """Parse a minimal YAML subset: flat `key: value` pairs.

    Intended for `/sp/swarm/openresty.yaml` where values are simple scalars.
    """
    result: dict[str, str] = {}
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue

        # Strip inline comments for unquoted values.
        if value and not (value.startswith('"') or value.startswith("'")):
            value = value.split(" #", 1)[0].split("\t#", 1)[0].strip()

        # Strip surrounding quotes.
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("\"", "'"):
            value = value[1:-1]

        result[key] = value
    return result


def load_acme_config_from_yaml(
    config_path: Path,
) -> tuple[str, str, str, str, str] | None:
    """Load ACME settings.

    Returns (provider, url, eab_kid, eab_hmac_key, eab_fingerprint) when config exists.

    - If YAML is missing: returns None (default remains Let's Encrypt).
    - If YAML exists: only `ACME_provider: zerossl` is allowed, and EAB fields + url are required.
    """
    if not config_path.exists():
        return None

    try:
        raw = config_path.read_text(encoding="utf-8")
    except Exception as e:
        raise ValueError(f"Failed to read {config_path}: {e}") from e

    data = _parse_simple_yaml_kv(raw)

    # New key names (preferred): ACME_PROVIDER / ACME_URL.
    # Old key names are accepted for backward compatibility.
    provider = (data.get("ACME_PROVIDER") or data.get("ACME_provider") or "").strip()
    if not provider:
        raise ValueError("/sp/swarm/openresty.yaml is missing required key: ACME_PROVIDER")
    if provider != SUPPORTED_ACME_PROVIDER_OVERRIDE:
        raise ValueError(
            f"Unsupported ACME_provider '{provider}'. Only '{SUPPORTED_ACME_PROVIDER_OVERRIDE}' is supported"
        )

    url = (data.get("ACME_URL") or data.get("url") or "").strip()
    if not url:
        raise ValueError("/sp/swarm/openresty.yaml is missing required key: ACME_URL")

    eab_kid = (data.get("EAB_KID") or "").strip() or None
    # Strict key name.
    eab_hmac_key = (data.get("EAB_HMAC_KEY") or "").strip() or None

    if not eab_kid or not eab_hmac_key:
        raise ValueError("/sp/swarm/openresty.yaml must include EAB_KID and EAB_HMAC_KEY for zerossl")

    eab_fingerprint = _fingerprint_secret(f"{eab_kid}|{eab_hmac_key}")
    return provider, url, eab_kid, eab_hmac_key, eab_fingerprint


def write_dehydrated_zerossl_config(eab_kid: str, eab_hmac_key: str, ca_url: str) -> None:
    """Write dehydrated config overrides for ZeroSSL EAB.

    Important: lua-resty-auto-ssl overwrites `${dir}/letsencrypt/config` on every
    `auto_ssl:init()` (master init). It explicitly supports custom overrides via
    `${dir}/letsencrypt/conf.d/*.sh`.

    So we write a dedicated conf.d script that sets CA + EAB vars.
    """
    target_dir = AUTO_SSL_DIR / "letsencrypt"
    conf_d_dir = target_dir / "conf.d"
    AUTO_SSL_DIR.mkdir(parents=True, exist_ok=True)
    target_dir.mkdir(parents=True, exist_ok=True)
    conf_d_dir.mkdir(parents=True, exist_ok=True)

    # Single deterministic override file.
    config_path = conf_d_dir / "50-zerossl-eab.sh"

    def bash_quote(value: str) -> str:
        # Dehydrated config is sourced by a shell; avoid expansion/parsing issues.
        return shlex.quote(value)

    # Keep minimal & deterministic.
    # Dehydrated sources these files; no need for `export`.
    config_body = (
        "# Managed by swarm-cloud provisioner.\n"
        f"CA={bash_quote(ca_url)}\n"
        f"EAB_KID={bash_quote(eab_kid)}\n"
        f"EAB_HMAC_KEY={bash_quote(eab_hmac_key)}\n"
    )
    config_path.write_text(config_body, encoding="utf-8")

    # Dehydrated runs from within OpenResty (user `www-data`), so ensure it can read the config.
    # Keep permissions restrictive as it contains EAB secrets.
    try:
        os.chmod(config_path, 0o600)
        os.chmod(conf_d_dir, 0o700)
        os.chmod(target_dir, 0o700)
        os.chmod(AUTO_SSL_DIR, 0o700)
    except Exception:
        pass

    try:
        subprocess.run(
            ["chown", "-R", "www-data:www-data", str(AUTO_SSL_DIR)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        # Best-effort; `chown` may be unavailable in some environments.
        pass


def _sanity_check_acme_directory_url(*, url: str) -> None:
    """Fail fast when ACME directory URL does not look like JSON.

    Dehydrated parses ACME responses as JSON. If the URL is wrong or outbound
    traffic is intercepted, it may return HTML (often starting with '<'), which
    leads to errors like: 'EXPECTED value GOT <'.
    """
    if not url:
        raise ValueError("ACME_URL is empty")

    # Avoid introducing a hard dependency on curl; use Python stdlib.
    # We capture enough response metadata to make debugging HTML/interception obvious.
    try:
        import urllib.error
        import urllib.request
    except Exception as e:  # pragma: no cover
        raise RuntimeError(f"Python stdlib urllib is unavailable: {e}") from e

    def _request(
        request_url: str,
        *,
        method: str = "GET",
        timeout_seconds: int = 8,
        read_bytes: int = 4096,
    ) -> tuple[int | None, str, dict[str, str], bytes]:
        headers = {
            "Accept": "application/json",
            "User-Agent": "swarm-cloud-openresty-provisioner",
        }
        req = urllib.request.Request(request_url, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
                status = getattr(resp, "status", None)
                final_url = getattr(resp, "geturl", lambda: request_url)() or request_url
                resp_headers = {k: v for k, v in resp.headers.items()}
                body = resp.read(read_bytes) if read_bytes > 0 else b""
                return status, final_url, resp_headers, body
        except urllib.error.HTTPError as e:
            # HTTPError is also a valid response object; read a small preview.
            try:
                body = e.read(read_bytes) if read_bytes > 0 else b""
            except Exception:
                body = b""
            status = getattr(e, "code", None)
            final_url = getattr(e, "geturl", lambda: request_url)() or request_url
            resp_headers = {k: v for k, v in getattr(e, "headers", {}).items()}
            return status, final_url, resp_headers, body

    try:
        status, final_url, resp_headers, body = _request(url, method="GET", read_bytes=4096)
    except Exception as e:
        raise RuntimeError(f"Failed to fetch ACME_URL directory: {type(e).__name__}: {e}") from e

    content_type = (resp_headers.get("Content-Type") or resp_headers.get("content-type") or "").strip()

    # Strip leading whitespace for the first-char heuristic.
    trimmed = body.lstrip()
    if not trimmed:
        raise RuntimeError(
            "ACME_URL returned an empty response. "
            f"status={status} final_url={final_url!r} content_type={content_type!r}"
        )
    if trimmed.startswith(b"<"):
        preview = trimmed[:200].decode("utf-8", errors="replace")
        raise RuntimeError(
            "ACME_URL does not look like an ACME directory JSON (got HTML). "
            f"status={status} final_url={final_url!r} content_type={content_type!r}; "
            f"First bytes: {preview!r}"
        )

    try:
        directory = json.loads(trimmed.decode("utf-8", errors="strict"))
    except Exception as exc:
        preview = trimmed[:200].decode("utf-8", errors="replace")
        raise RuntimeError(
            "ACME_URL did not return valid JSON. "
            f"status={status} final_url={final_url!r} content_type={content_type!r}; "
            f"First bytes: {preview!r}"
        ) from exc

    if not isinstance(directory, dict):
        raise RuntimeError(f"ACME_URL directory JSON is not an object (type={type(directory)})")

    new_nonce_url = directory.get("newNonce")
    if not isinstance(new_nonce_url, str) or not new_nonce_url:
        raise RuntimeError("ACME_URL directory JSON is missing 'newNonce'")

    # Validate that we can hit the newNonce endpoint. This is a common place where
    # network interception returns HTML and breaks dehydrated JSON parsing.
    try:
        nonce_status, nonce_final_url, nonce_headers, nonce_body = _request(
            new_nonce_url,
            method="HEAD",
            read_bytes=256,
        )
        # Some servers do send small bodies even to HEAD (misconfigured proxies).
        replay_nonce = (nonce_headers.get("Replay-Nonce") or nonce_headers.get("replay-nonce"))
    except Exception as e:
        raise RuntimeError(f"Failed to fetch ACME newNonce endpoint: {type(e).__name__}: {e}") from e

    nonce_content_type = (nonce_headers.get("Content-Type") or nonce_headers.get("content-type") or "").strip()
    nonce_trimmed = (nonce_body or b"").lstrip()
    if nonce_trimmed.startswith(b"<"):
        preview = nonce_trimmed[:200].decode("utf-8", errors="replace")
        raise RuntimeError(
            "ACME newNonce endpoint returned HTML (expected headers-only response). "
            f"status={nonce_status} final_url={nonce_final_url!r} content_type={nonce_content_type!r}; "
            f"First bytes: {preview!r}"
        )

    if not replay_nonce:
        # Not strictly required for every CA implementation, but ACMEv2 newNonce
        # should provide Replay-Nonce.
        raise RuntimeError(
            "ACME newNonce endpoint did not include Replay-Nonce header. "
            f"status={nonce_status} final_url={nonce_final_url!r} content_type={nonce_content_type!r}"
        )


DEHYDRATED_UPSTREAM_URL = (
    "https://raw.githubusercontent.com/dehydrated-io/dehydrated/v0.7.1/dehydrated"
)


def _install_dehydrated_from_upstream(*, backup_existing: bool) -> None:
    """Download pinned dehydrated to DEHYDRATED_BIN (host path bind-mounted into OpenResty)."""
    DEHYDRATED_BIN.parent.mkdir(parents=True, exist_ok=True)

    if backup_existing and DEHYDRATED_BIN.exists():
        backup_path = DEHYDRATED_BIN.with_suffix(".bak")
        try:
            if not backup_path.exists():
                shutil.copy2(DEHYDRATED_BIN, backup_path)
        except Exception:
            pass

    tmp_path = DEHYDRATED_BIN.with_suffix(".tmp")
    result = subprocess.run(
        ["wget", "-q", "-O", str(tmp_path), DEHYDRATED_UPSTREAM_URL],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        curl_result = subprocess.run(
            ["curl", "-fsSL", "-o", str(tmp_path), DEHYDRATED_UPSTREAM_URL],
            capture_output=True,
            text=True,
            check=False,
        )
        if curl_result.returncode != 0:
            raise RuntimeError(
                "Failed to download dehydrated using both wget and curl: "
                f"wget=({result.stderr.strip() or result.stdout.strip()}); "
                f"curl=({curl_result.stderr.strip() or curl_result.stdout.strip()})"
            )

    try:
        if tmp_path.stat().st_size < 100:
            raise RuntimeError("Downloaded dehydrated is unexpectedly small; refusing to install it")
    except FileNotFoundError as exc:
        raise RuntimeError("Downloaded dehydrated file is missing; refusing to install it") from exc

    tmp_path.replace(DEHYDRATED_BIN)
    try:
        os.chmod(DEHYDRATED_BIN, 0o755)
    except Exception:
        subprocess.run(["chmod", "755", str(DEHYDRATED_BIN)], capture_output=True, text=True, check=False)
    subprocess.run(
        ["chown", "www-data:www-data", str(DEHYDRATED_BIN)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def ensure_dehydrated_present() -> None:
    """Ensure pinned dehydrated exists on the host (required for ACME via lua-resty-auto-ssl; not only ZeroSSL)."""
    try:
        if (
            DEHYDRATED_BIN.is_file()
            and os.access(DEHYDRATED_BIN, os.X_OK)
            and DEHYDRATED_BIN.stat().st_size > 500
        ):
            return
    except OSError:
        pass
    ensure_hexdump_available()
    _install_dehydrated_from_upstream(backup_existing=False)


def ensure_dehydrated_eab_support() -> None:
    """Install pinned dehydrated version that supports EAB (required for ZeroSSL newAccount)."""
    ensure_hexdump_available()
    try:
        _install_dehydrated_from_upstream(backup_existing=True)
    except RuntimeError as e:
        raise RuntimeError(
            "ZeroSSL requires EAB-capable dehydrated, but download failed: " + str(e)
        ) from e



def podman_executable() -> str:
    """Resolve podman binary path for subprocess and systemd units."""
    if os.path.isabs(PODMAN_BIN) and os.path.isfile(PODMAN_BIN):
        return PODMAN_BIN
    which = shutil.which(PODMAN_BIN)
    if which:
        return which
    raise RuntimeError(
        "podman not found in PATH; install podman on the host before using the openresty service"
    )


def require_podman() -> None:
    podman_executable()


def pull_openresty_image() -> None:
    """Pull pinned OpenResty image."""
    exe = podman_executable()
    result = subprocess.run(
        [exe, "pull", OPENRESTY_IMAGE],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"Failed to pull image {OPENRESTY_IMAGE}: {err}")


def is_openresty_image_available() -> bool:
    """Return True if the pinned image exists locally."""
    try:
        exe = podman_executable()
    except RuntimeError:
        return False
    r1 = subprocess.run(
        [exe, "image", "exists", OPENRESTY_IMAGE],
        capture_output=True,
        text=True,
    )
    if r1.returncode == 0:
        return True
    r2 = subprocess.run(
        [exe, "inspect", "--type", "image", OPENRESTY_IMAGE],
        capture_output=True,
        text=True,
    )
    return r2.returncode == 0


def is_openresty_available() -> bool:
    """True when the container image is present (OpenResty runs in Podman, not on the host)."""
    return is_openresty_image_available()


def _opm_install_marker_path() -> Path:
    key = f"{OPENRESTY_IMAGE}|{OPM_AUTO_SSL_PACKAGE}"
    h = hashlib.sha256(key.encode()).hexdigest()[:32]
    return OPENRESTY_SITE_DIR / f".opm_ok_{h}"


def ensure_mime_types_from_image() -> None:
    """Populate mime.types from the official image when missing (host conf is bind-mounted)."""
    dest = OPENRESTY_CONFIG_DIR / "mime.types"
    if dest.exists():
        return
    OPENRESTY_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    exe = podman_executable()
    result = subprocess.run(
        [
            exe,
            "run",
            "--rm",
            "--pull=never",
            "--platform",
            OPENRESTY_CPU_PLATFORM,
            OPENRESTY_IMAGE,
            "cat",
            "/usr/local/openresty/nginx/conf/mime.types",
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "Failed to read mime.types from OpenResty image: "
            + (result.stderr or result.stdout or "").strip()
        )
    dest.write_text(result.stdout, encoding="utf-8")


def ensure_opm_lua_packages() -> None:
    """Install lua-resty-auto-ssl (+deps) into OPENRESTY_SITE_DIR using opm inside the pulled image."""
    OPENRESTY_SITE_DIR.mkdir(parents=True, exist_ok=True)
    marker = _opm_install_marker_path()
    if marker.exists():
        return
    exe = podman_executable()
    result = subprocess.run(
        [
            exe,
            "run",
            "--rm",
            "--pull=never",
            "--network=host",
            "--platform",
            OPENRESTY_CPU_PLATFORM,
            "-v",
            f"{OPENRESTY_SITE_DIR}:/usr/local/openresty/site:z",
            OPENRESTY_IMAGE,
            "opm",
            "get",
            OPM_AUTO_SSL_PACKAGE,
        ],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "opm get failed: " + (result.stderr or result.stdout or "").strip()
        )
    try:
        marker.write_text("ok\n", encoding="utf-8")
    except OSError:
        marker.touch()
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(OPENRESTY_SITE_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def _lua_resty_vendor_shell_url() -> str:
    override = os.environ.get("LUA_RESTY_VENDOR_SHELL_URL", "").strip()
    if override:
        return override
    return (
        "https://raw.githubusercontent.com/juce/lua-resty-shell/"
        f"{LUA_RESTY_SHELL_VERSION}/lib/resty/shell.lua"
    )


def _vendor_shell_marker_path() -> Path:
    key = f"{_lua_resty_vendor_shell_url()}|{LUA_RESTY_SHELL_VERSION}"
    h = hashlib.sha256(key.encode()).hexdigest()[:32]
    return OPENRESTY_SITE_DIR / f".vendor_shell_ok_{h}"


def ensure_lua_resty_vendor_shell() -> None:
    """Fetch resty.auto-ssl.vendor.shell (lua-resty-shell) into site/lualib; OPM packages omit this file."""
    OPENRESTY_SITE_DIR.mkdir(parents=True, exist_ok=True)
    dest = OPENRESTY_SITE_DIR / "lualib/resty/auto-ssl/vendor/shell.lua"
    marker = _vendor_shell_marker_path()
    if marker.exists() and dest.is_file() and dest.stat().st_size > 200:
        return

    dest.parent.mkdir(parents=True, exist_ok=True)
    url = _lua_resty_vendor_shell_url()
    tmp_path = dest.with_suffix(".tmp")

    result = subprocess.run(
        ["wget", "-q", "-O", str(tmp_path), url],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        curl_result = subprocess.run(
            ["curl", "-fsSL", "-o", str(tmp_path), url],
            capture_output=True,
            text=True,
            check=False,
        )
        if curl_result.returncode != 0:
            raise RuntimeError(
                "Failed to download lua-resty-shell (vendor/shell.lua) for lua-resty-auto-ssl: "
                f"wget=({result.stderr.strip() or result.stdout.strip()}); "
                f"curl=({curl_result.stderr.strip() or curl_result.stdout.strip()})"
            )

    try:
        if tmp_path.stat().st_size < 200:
            raise RuntimeError("Downloaded vendor shell.lua is unexpectedly small; refusing to install it")
    except FileNotFoundError as exc:
        raise RuntimeError("Downloaded vendor shell.lua file is missing; refusing to install it") from exc

    tmp_path.replace(dest)
    try:
        os.chmod(dest, 0o644)
    except Exception:
        pass
    subprocess.run(
        ["chown", "www-data:www-data", str(dest)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        marker.write_text("ok\n", encoding="utf-8")
    except OSError:
        marker.touch()


def _wget_or_curl_download(url: str, dest: Path, *, min_bytes: int = 1) -> None:
    """Write URL contents to dest (atomic replace via caller)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["wget", "-q", "-O", str(dest), url],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        curl_result = subprocess.run(
            ["curl", "-fsSL", "-o", str(dest), url],
            capture_output=True,
            text=True,
            check=False,
        )
        if curl_result.returncode != 0:
            raise RuntimeError(
                "download failed: "
                f"wget=({result.stderr.strip() or result.stdout.strip()}); "
                f"curl=({curl_result.stderr.strip() or curl_result.stdout.strip()})"
            )
    try:
        if dest.stat().st_size < min_bytes:
            raise RuntimeError("downloaded file is unexpectedly small")
    except FileNotFoundError as exc:
        raise RuntimeError("downloaded file is missing") from exc


def _auto_ssl_scripts_marker_path() -> Path:
    key = f"{LUA_RESTY_AUTO_SSL_TAG}|start_sockproc|letsencrypt_hooks"
    h = hashlib.sha256(key.encode()).hexdigest()[:32]
    return DEHYDRATED_BIN.parent / f".auto_ssl_scripts_ok_{h}"


def _sockproc_marker_path() -> Path:
    key = f"{SOCKPROC_VERSION}|sockproc"
    h = hashlib.sha256(key.encode()).hexdigest()[:32]
    return DEHYDRATED_BIN.parent / f".sockproc_ok_{h}"


def ensure_sockproc_build_deps() -> None:
    """Install gcc/make on Ubuntu when missing (required to build juce/sockproc)."""
    if shutil.which("make") and (shutil.which("gcc") or shutil.which("cc")):
        return
    os_release = ""
    try:
        os_release = Path("/etc/os-release").read_text(encoding="utf-8", errors="ignore").lower()
    except Exception:
        pass
    if "ubuntu" not in os_release:
        raise RuntimeError(
            "Cannot build sockproc: install gcc and make (e.g. build-essential) on this system"
        )
    _ensure_apt_state_dirs()
    subprocess.run(["apt-get", "update"], capture_output=True, text=True, check=False)
    r = subprocess.run(
        ["apt-get", "install", "-y", "--no-install-recommends", "build-essential"],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0 or not (shutil.which("make") and (shutil.which("gcc") or shutil.which("cc"))):
        raise RuntimeError(
            "Failed to install build-essential for sockproc: "
            + (r.stderr or r.stdout or "").strip()
        )


def ensure_resty_auto_ssl_scripts() -> None:
    """Install start_sockproc and letsencrypt_hooks next to dehydrated (upstream lua-resty-auto-ssl)."""
    bindir = DEHYDRATED_BIN.parent
    bindir.mkdir(parents=True, exist_ok=True)
    start_dest = bindir / "start_sockproc"
    hooks_dest = bindir / "letsencrypt_hooks"
    marker = _auto_ssl_scripts_marker_path()
    if marker.exists() and start_dest.is_file() and hooks_dest.is_file():
        return

    base = (
        "https://raw.githubusercontent.com/auto-ssl/lua-resty-auto-ssl/"
        f"{LUA_RESTY_AUTO_SSL_TAG}/bin"
    )
    tmp_start = start_dest.with_suffix(".tmp")
    tmp_hooks = hooks_dest.with_suffix(".tmp")
    _wget_or_curl_download(f"{base}/start_sockproc", tmp_start, min_bytes=50)
    _wget_or_curl_download(f"{base}/letsencrypt_hooks", tmp_hooks, min_bytes=50)
    tmp_start.replace(start_dest)
    tmp_hooks.replace(hooks_dest)
    for p in (start_dest, hooks_dest):
        try:
            os.chmod(p, 0o755)
        except Exception:
            subprocess.run(["chmod", "755", str(p)], capture_output=True, text=True, check=False)
    subprocess.run(
        ["chown", "www-data:www-data", str(start_dest), str(hooks_dest)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        marker.write_text("ok\n", encoding="utf-8")
    except OSError:
        marker.touch()


def ensure_sockproc_binary() -> None:
    """Build and install juce/sockproc next to start_sockproc (lua-resty-auto-ssl runtime)."""
    bindir = DEHYDRATED_BIN.parent
    bindir.mkdir(parents=True, exist_ok=True)
    dest = bindir / "sockproc"
    marker = _sockproc_marker_path()
    if marker.exists() and dest.is_file() and os.access(dest, os.X_OK) and dest.stat().st_size > 500:
        return

    tarball_url = f"https://github.com/juce/sockproc/archive/{SOCKPROC_VERSION}.tar.gz"
    with tempfile.TemporaryDirectory(prefix="sockproc-build-") as tmp:
        tdir = Path(tmp)
        tar_path = tdir / "sockproc.tar.gz"
        _wget_or_curl_download(tarball_url, tar_path, min_bytes=500)
        ex = subprocess.run(
            ["tar", "-xzf", str(tar_path), "-C", str(tdir)],
            capture_output=True,
            text=True,
            check=False,
        )
        if ex.returncode != 0:
            raise RuntimeError("failed to extract sockproc tarball: " + (ex.stderr or ex.stdout or "").strip())

        src_dir = tdir / f"sockproc-{SOCKPROC_VERSION}"
        if not src_dir.is_dir():
            raise RuntimeError(f"unexpected sockproc extract layout (missing {src_dir})")

        def _make() -> subprocess.CompletedProcess:
            return subprocess.run(
                ["make", "-C", str(src_dir)],
                capture_output=True,
                text=True,
                check=False,
            )

        mk = _make()
        if mk.returncode != 0:
            ensure_sockproc_build_deps()
            mk = _make()
        if mk.returncode != 0:
            raise RuntimeError(
                "sockproc build failed: " + (mk.stderr or mk.stdout or "").strip()
            )
        built = src_dir / "sockproc"
        if not built.is_file():
            raise RuntimeError("sockproc make did not produce a binary")
        shutil.copy2(built, dest)

    try:
        os.chmod(dest, 0o755)
    except Exception:
        subprocess.run(["chmod", "755", str(dest)], capture_output=True, text=True, check=False)
    subprocess.run(
        ["chown", "www-data:www-data", str(dest)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        marker.write_text("ok\n", encoding="utf-8")
    except OSError:
        marker.touch()


def ensure_resty_auto_ssl_host_bins() -> None:
    """OPM does not install dehydrated/sockproc/start_sockproc/letsencrypt_hooks; install on host bind mount."""
    ensure_dehydrated_present()
    ensure_resty_auto_ssl_scripts()
    ensure_sockproc_binary()


def ensure_podman_volume_host_paths() -> None:
    """Create host paths before `podman run -v` — Podman fails with statfs if a mount source is missing."""
    AUTO_SSL_DIR.mkdir(parents=True, exist_ok=True)
    DEHYDRATED_BIN.parent.mkdir(parents=True, exist_ok=True)
    OPENRESTY_SITE_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(AUTO_SSL_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(DEHYDRATED_BIN.parent)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def podman_volume_flags() -> list[str]:
    """Podman -v arguments shared by systemd unit and config test container."""
    flags: list[str] = [
        "-v",
        f"{OPENRESTY_CONFIG_DIR}:/usr/local/openresty/nginx/conf:z",
        "-v",
        f"{OPENRESTY_LOG_DIR}:/var/log/openresty:z",
        "-v",
        f"{NGINX_LOGS_DIR}:/usr/local/openresty/nginx/logs:z",
        "-v",
        f"{AUTO_SSL_DIR}:/etc/resty-auto-ssl:z",
        "-v",
        f"{Path('/var/www/dehydrated')}:/var/www/dehydrated:z",
        "-v",
        f"{DEHYDRATED_BIN.parent}:/usr/local/bin/resty-auto-ssl:z",
        "-v",
        f"{OPENRESTY_SITE_DIR}:/usr/local/openresty/site:z",
    ]
    hexdump_host = Path("/usr/bin/hexdump")
    if hexdump_host.is_file():
        flags.extend(["-v", f"{hexdump_host}:/usr/bin/hexdump:ro"])
    return flags


def create_openresty_systemd_service() -> None:
    """Write systemd unit that runs OpenResty in Podman with host networking."""
    ensure_podman_volume_host_paths()
    exe = podman_executable()
    parts: list[str] = [
        "[Unit]",
        "Description=OpenResty gateway (Podman)",
        "After=network-online.target",
        "Wants=network-online.target",
        "",
        "[Service]",
        "Type=simple",
        f"ExecStartPre=-{exe} stop {OPENRESTY_CONTAINER_NAME}",
        f"ExecStartPre=-{exe} rm {OPENRESTY_CONTAINER_NAME}",
        f"ExecStart={exe} run \\",
        f"    --name {OPENRESTY_CONTAINER_NAME} \\",
        "    --rm \\",
        "    --pull=never \\",
        "    --network=host \\",
        f"    --platform {OPENRESTY_CPU_PLATFORM} \\",
    ]
    vf = podman_volume_flags()
    # Every `-v` line must end with ` \` so systemd continues `ExecStart` onto the image ref line.
    # If the last volume omits `\`, the image line is parsed as a separate key and `podman run` gets no image.
    for i in range(0, len(vf), 2):
        cont = vf[i + 1]
        parts.append(f"    {vf[i]} {cont} \\")
    parts.extend(
        [
            f'    "{OPENRESTY_IMAGE}"',
            f"ExecStop=-{exe} stop {OPENRESTY_CONTAINER_NAME}",
            "Restart=always",
            "RestartSec=5",
            "LimitNOFILE=1048576",
            "TimeoutStopSec=120",
            "User=root",
            "StandardOutput=journal",
            "StandardError=journal",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ]
    )
    service_path = Path("/etc/systemd/system") / OPENRESTY_SERVICE_UNIT
    service_path.write_text("\n".join(parts), encoding="utf-8")
    subprocess.run(["systemctl", "daemon-reload"], check=False)


def run_openresty_config_test() -> subprocess.CompletedProcess:
    """Run `openresty -t` inside a one-shot container with the same mounts as the service."""
    ensure_podman_volume_host_paths()
    exe = podman_executable()
    cmd: list[str] = [
        exe,
        "run",
        "--rm",
        "--pull=never",
        "--network=host",
        "--platform",
        OPENRESTY_CPU_PLATFORM,
    ]
    cmd.extend(podman_volume_flags())
    cmd.extend(
        [
            OPENRESTY_IMAGE,
            "/usr/local/openresty/bin/openresty",
            "-t",
        ]
    )
    return subprocess.run(cmd, capture_output=True, text=True, timeout=120)


def bootstrap_openresty_runtime(*, eab_support: bool = False) -> None:
    """Prepare Podman image, mime.types, OPM Lua packages, and optional ZeroSSL dehydrated deps."""
    ensure_podman_volume_host_paths()
    require_podman()
    pull_openresty_image()
    ensure_mime_types_from_image()
    ensure_opm_lua_packages()
    ensure_lua_resty_vendor_shell()
    ensure_resty_auto_ssl_host_bins()
    if eab_support:
        ensure_dehydrated_eab_support()


def generate_nginx_config(
    redis_hosts: list[str],
    sentinel_hosts: list[str],
    is_leader: bool,
    acme_leader_addr: str | None,
    acme_ca_url: str | None
) -> str:
    """Generate Nginx configuration content."""
    def escape_lua_string(value: str) -> str:
        return value.replace("\\", "\\\\").replace('"', '\\"')

    escaped_ca_url = escape_lua_string(acme_ca_url) if acme_ca_url else ""
    auto_ssl_ca_line = (
        f'        auto_ssl:set("ca", "{escaped_ca_url}")\n'
        if acme_ca_url else ""
    )
    redis_host_list = ", ".join([f'"{host}:6379"' for host in redis_hosts])
    sentinel_host_list = ", ".join([f'"{host}:26379"' for host in sentinel_hosts])

    # HTTP-01: serve from shared storage (Redis via storage_adapter). Issuance stores
    # the token via the hook on whichever node triggered dehydrated; every gateway must
    # read the same keys — do NOT proxy only to the cluster leader (LE may hit any node).
    acme_challenge_location = """        # ACME challenge location
        location /.well-known/acme-challenge/ {
            content_by_lua_block {
                auto_ssl:challenge_server()
            }
        }
"""

    stream_tls_target = "127.0.0.1:8443"
    if not is_leader and acme_leader_addr:
        stream_tls_target = f"{acme_leader_addr}:443"

    config = f"""# Nginx/OpenResty configuration for Gateway with AutoSSL, SSL Passthrough and Redis routing

user www-data;
worker_processes auto;
pid /usr/local/openresty/nginx/logs/nginx.pid;

events {{
    worker_connections 1024;
}}

# Stream block for SSL passthrough routing (port 443)
stream {{
    # Logging
    log_format basic '$remote_addr [$time_local] '
                     '$protocol $status $bytes_sent $bytes_received '
                     '$session_time';

    access_log /var/log/openresty/stream-access.log basic;
    error_log /var/log/openresty/stream-error.log info;

    # Shared memory zones
    lua_shared_dict stream_route_cache 10m;
    lua_shared_dict stream_rr_counters 10m;
    lua_shared_dict stream_redis_master_cache 1m;

    # Redis hosts
    init_by_lua_block {{
        stream_redis_hosts = {{{redis_host_list}}}
        stream_sentinel_hosts = {{{sentinel_host_list}}}

        local function parse_host(host)
            local h, p = host:match("^([^:]+):?(%d*)$")
            if not h or h == "" then
                return nil, nil
            end
            if not p or p == "" then
                p = "6379"
            end
            return h, tonumber(p)
        end

        local function get_master_from_sentinel()
            if not stream_sentinel_hosts or #stream_sentinel_hosts == 0 then
                return nil, nil
            end

            local cache = ngx.shared.stream_redis_master_cache
            local cached = cache:get("redis_master")
            if cached and cached:find(":") then
                local ch, cp = cached:match("^([^:]+):(%d+)$")
                if ch and cp then
                    return ch, tonumber(cp)
                end
            end

            local redis = require "resty.redis"
            for _, shost in ipairs(stream_sentinel_hosts) do
                local red = redis:new()
                red:set_timeout(1000)
                local host, port = parse_host(shost)
                if host then
                    local ok = red:connect(host, port)
                    if ok then
                        local res, err = red:sentinel("get-master-addr-by-name", "redis-master")
                        red:close()
                        if type(res) == "table" and res[1] and res[2] then
                            cache:set("redis_master", res[1] .. ":" .. res[2], 5)
                            return res[1], tonumber(res[2])
                        end
                    end
                end
            end
            return nil, nil
        end

        function stream_connect_redis_master(red)
            local host, port = get_master_from_sentinel()
            if host then
                return red:connect(host, port)
            end
            for _, host in ipairs(stream_redis_hosts) do
                local rh, rp = parse_host(host)
                if rh then
                    local ok, err = red:connect(rh, rp)
                    if ok then
                        return ok
                    end
                end
            end
            return nil, "no redis host available"
        end
    }}

    # SSL preread to get SNI hostname
    ssl_preread on;

    server {{
        listen 443;

        # Variable for dynamic upstream
        set $upstream_target "";

        # Lua code to route based on passthrough flag
        preread_by_lua_block {{
            local cjson = require "cjson"
            local domain = ngx.var.ssl_preread_server_name

            if not domain or domain == "" then
                -- No SNI, close connection
                return ngx.exit(421)
            end

            -- Try to get route from cache
            local cache = ngx.shared.stream_route_cache
            local cached_route = cache:get(domain)

            if not cached_route then
                -- Query Redis (master) for route
                local redis = require "resty.redis"
                local red = redis:new()
                red:set_timeout(1000)

                local route_data = nil
                local ok, err = stream_connect_redis_master(red)
                if ok then
                    local route, err = red:get("manual-routes:" .. domain)
                    if not route or route == ngx.null then
                        route, err = red:get("routes:" .. domain)
                    end
                    if route and route ~= ngx.null then
                        route_data = route
                    end
                    red:close()
                end
                if not route_data then
                    -- No route found, close connection
                    return ngx.exit(421)
                end

                -- Cache for 30 seconds
                cache:set(domain, route_data, 30)
                cached_route = route_data
            end

            -- Parse route configuration
            local route = cjson.decode(cached_route)
            local passthrough = route.passthrough or false

            if not passthrough then
                -- SSL termination mode: proxy to local HTTP server or leader stream
                ngx.var.upstream_target = "{stream_tls_target}"
                return
            end

            -- Passthrough mode: select backend target
            local targets = route.targets or {{}}

            if #targets == 0 then
                return ngx.exit(421)
            end

            -- Select target based on policy
            local policy = route.policy or "rr"
            local target_url

            if policy == "rr" then
                -- Round-robin
                local counters = ngx.shared.stream_rr_counters
                local counter = counters:get(domain) or 0
                local idx = (counter % #targets) + 1
                target_url = targets[idx].url
                counters:incr(domain, 1, 0)

            elseif policy == "ip_hash" then
                -- IP hash
                local ip = ngx.var.remote_addr
                local hash = ngx.crc32_long(ip)
                local idx = (hash % #targets) + 1
                target_url = targets[idx].url

            else
                -- Default to first target
                target_url = targets[1].url
            end

            -- Extract host and port from URL
            -- Format: https://host:port or http://host:port
            local backend_host, backend_port = target_url:match("^https?://([^:/]+):?(%d*)/?")

            if not backend_host then
                return ngx.exit(421)
            end

            -- Default port to 443 if not specified and using https
            if not backend_port or backend_port == "" then
                if target_url:match("^https://") then
                    backend_port = "443"
                else
                    backend_port = "80"
                end
            end

            ngx.var.upstream_target = backend_host .. ":" .. backend_port
        }}

        proxy_pass $upstream_target;
        proxy_connect_timeout 5s;
    }}
}}

http {{
    include /usr/local/openresty/nginx/conf/mime.types;
    default_type application/octet-stream;

    # Logging
    access_log /var/log/openresty/access.log;
    error_log /var/log/openresty/error.log;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    # WebSocket support: map Upgrade header to Connection header.
    #
    # For regular HTTP proxy traffic (including S3 uploads), do not force
    # `Connection: close` because it can destabilize streamed request bodies.
    map $http_upgrade $connection_upgrade {{
        default upgrade;
        '' '';
    }}

    # Lua package path
    # OPM deps (lua-resty-http, lua-resty-auto-ssl) live under site/lualib — they MUST be searched before
    # the image's /usr/local/openresty/lualib (via ;;) or mixed resty.* versions break submodule loads.
    lua_package_path "/usr/local/openresty/site/lualib/?.lua;/usr/local/openresty/site/lualib/?/init.lua;/usr/local/openresty/nginx/conf/lua/?.lua;/usr/local/openresty/nginx/conf/lua/?/init.lua;;";
    lua_shared_dict auto_ssl 1m;
    lua_shared_dict auto_ssl_settings 64k;
    lua_shared_dict route_cache 10m;
    lua_shared_dict rr_counters 10m;
    lua_shared_dict redis_master_cache 1m;
    lua_shared_dict swarm_routes_cache 1m;
    # 5xx forensics (SUP-367). Holds only the deltas between two flushes of
    # conf/lua/gateway_errors.lua -- a few counter keys plus a capped ring of
    # samples -- so 2m is generous rather than tight.
    lua_shared_dict gateway_errors 2m;

    map $http_upgrade $connection_upgrade {{
        default upgrade;
        '' '';
    }}

    # Redis hosts for backend storage
    init_by_lua_block {{
        redis_hosts = {{{redis_host_list}}}
        sentinel_hosts = {{{sentinel_host_list}}}

        local function parse_host(host)
            local h, p = host:match("^([^:]+):?(%d*)$")
            if not h or h == "" then
                return nil, nil
            end
            if not p or p == "" then
                p = "6379"
            end
            return h, tonumber(p)
        end

        local function get_master_from_sentinel()
            if not sentinel_hosts or #sentinel_hosts == 0 then
                return nil, nil
            end

            local cache = ngx.shared.redis_master_cache
            local cached = cache:get("redis_master")
            if cached and cached:find(":") then
                local ch, cp = cached:match("^([^:]+):(%d+)$")
                if ch and cp then
                    return ch, tonumber(cp)
                end
            end

            local redis = require "resty.redis"
            for _, shost in ipairs(sentinel_hosts) do
                local red = redis:new()
                red:set_timeout(1000)
                local host, port = parse_host(shost)
                if host then
                    local ok = red:connect(host, port)
                    if ok then
                        local res, err = red:sentinel("get-master-addr-by-name", "redis-master")
                        red:close()
                        if type(res) == "table" and res[1] and res[2] then
                            cache:set("redis_master", res[1] .. ":" .. res[2], 5)
                            return res[1], tonumber(res[2])
                        end
                    end
                end
            end
            return nil, nil
        end

        function connect_redis_master(red)
            local host, port = get_master_from_sentinel()
            if host then
                return red:connect(host, port)
            end
            for _, host in ipairs(redis_hosts) do
                local rh, rp = parse_host(host)
                if rh then
                    local ok, err = red:connect(rh, rp)
                    if ok then
                        return ok
                    end
                end
            end
            return nil, "no redis host available"
        end

        -- Auto-SSL setup
        auto_ssl = (require "resty.auto-ssl").new()
        auto_ssl:set("dir", "/etc/resty-auto-ssl")
{auto_ssl_ca_line}        auto_ssl:set("storage_adapter", "resty.auto-ssl.storage_adapters.redis_sentinel")
        auto_ssl:set("storage_adapter_options", {{
            sentinel_hosts = sentinel_hosts,
            redis_hosts = redis_hosts,
            key_prefix = "auto-ssl:"
        }})
        -- Disable OCSP stapling to avoid errors
        auto_ssl:set("ocsp_stapling_enabled", false)
        auto_ssl:set("allow_domain", function(domain)
            -- Check if route exists in Redis for this domain
            local redis = require "resty.redis"
            local cjson = require "cjson"
            local red = redis:new()
            red:set_timeout(1000)
            local ok, err = connect_redis_master(red)
            if ok then
                local route, route_err = red:get("manual-routes:" .. domain)
                if not route or route == ngx.null then
                    route, route_err = red:get("routes:" .. domain)
                end
                red:close()
                if route_err then
                    ngx.log(ngx.ERR, "redis get failed: ", route_err)
                end
                if not route or route == ngx.null then
                    return false
                end
                -- Only allow AutoSSL for domains WITHOUT passthrough flag
                local decode_ok, route_data = pcall(cjson.decode, route)
                if not decode_ok or type(route_data) ~= "table" then
                    ngx.log(ngx.ERR, "route decode failed for domain ", domain)
                    return false
                end
                local passthrough = route_data.passthrough or false
                -- Only allow AutoSSL for non-passthrough domains
                return not passthrough
            end
            return false
        end)
        auto_ssl:init()
    }}

    init_worker_by_lua_block {{
        auto_ssl:init_worker()
        -- SUP-367: start the 5xx flush timer. log_by_lua has no cosocket
        -- support, so the log phase can only write to a shared dict; this
        -- timer is what moves it to Redis where the API can read it back.
        --
        -- pcall because an error raised here aborts worker init: forensics are
        -- worth a gateway that records nothing, never a gateway that does not
        -- start.
        local ok, err = pcall(function() require("gateway_errors").start() end)
        if not ok then
            ngx.log(ngx.ERR, "gateway-errors: could not initialise: ", err)
        end
    }}

    # ACME hook server (internal)
    server {{
        listen 127.0.0.1:8999;
        client_body_buffer_size 128k;
        client_max_body_size 128k;
        location / {{
            content_by_lua_block {{
                auto_ssl:hook_server()
            }}
        }}
    }}

    # HTTP server (port 80)
    server {{
        listen 80;
        server_name _;

{acme_challenge_location}

        # Redirect all other traffic to HTTPS
        location / {{
            return 301 https://$host$request_uri;
        }}
    }}

    # HTTPS server (port 8443 - for SSL termination via stream proxy)
    server {{
        listen 127.0.0.1:8443 ssl;
        server_name _;

        # Declare variable for use in proxy_pass
        set $upstream_url "";

        # 5xx forensics (SUP-367). Declared once at server level so it covers
        # every response this gateway emits on the TLS channel -- the proxied
        # ones, the `503 No backend targets available` the routing Lua raises
        # itself, and the swarm-evidence/swarm-routes 503s -- instead of
        # needing one hook per location that could proxy.
        log_by_lua_block {{
            -- pcall for the same reason as init_worker: a bug in the recorder
            -- must not turn into an error line per request on a cloud that is
            -- already serving 5xx.
            pcall(function() require("gateway_errors").record() end)
        }}

        # Auto-SSL certificates
        ssl_certificate_by_lua_block {{
            auto_ssl:ssl_certificate()
        }}
        ssl_certificate /usr/local/openresty/nginx/conf/ssl/fallback.crt;
        ssl_certificate_key /usr/local/openresty/nginx/conf/ssl/fallback.key;

        # Unified swarm-evidence endpoint, served on every host openresty
        # terminates TLS for. The Lua handler reads `evidence-jws:<host>` +
        # `attestation-bundle:current` from Redis and assembles the bundle
        # without any per-host nginx state. See SP-7699.
        #
        # The bundle is a public, signed, self-authenticating document — the
        # same class of resource a JWKS endpoint serves — and no credential is
        # ever accepted on this path, so `Access-Control-Allow-Origin: *` is the
        # correct value rather than a concession: it lets any browser-based
        # verifier on any origin read it. `always` matters because the handler's
        # contract responses are 404/503, and a verifier has to be able to read
        # those statuses too instead of seeing an opaque CORS failure. The
        # preflight is answered inside the Lua handler (SUP-192).
        location = /.well-known/swarm-evidence {{
            default_type application/json;
            add_header Cache-Control "no-store" always;
            add_header Access-Control-Allow-Origin "*" always;
            add_header Access-Control-Expose-Headers "Content-Type, Cache-Control" always;
            content_by_lua_file conf/lua/swarm_evidence.lua;
        }}

        # Index of the ingress hostnames this gateway routes, for the host
        # orchestrator (SUP-216). Release sp-vm images ship no sshd, so the
        # host cannot read the fabric's route table over ssh any more; it polls
        # this path over the same :443 channel it already probes for tls_state,
        # then issues each hostname's public cert and adds its SNI entry to the
        # host stream router. Hostnames only -- conf/lua/swarm_routes.lua
        # carries the reasoning for why the path needs no credential.
        #
        # Deliberately NOT CORS-open, unlike swarm-evidence: the only consumer
        # is a curl on the host, so there is no browser origin to allow and no
        # reason to widen who can read it.
        location = /.well-known/swarm-routes {{
            default_type application/json;
            add_header Cache-Control "no-store" always;
            content_by_lua_file conf/lua/swarm_routes.lua;
        }}

        location / {{
            # Important: body size can be validated before internal ngx.exec().
            # Keep entry location unlimited and route to internal locations based
            # on request characteristics in Lua.
            client_max_body_size 0;

            access_by_lua_block {{
                local cjson = require "cjson"
                local domain = ngx.var.host

                -- Try to get route from cache
                local cache = ngx.shared.route_cache
                local cached_route = cache:get(domain)

                if not cached_route then
                    -- Query Redis (master) for route
                    local redis = require "resty.redis"
                    local red = redis:new()
                    red:set_timeout(1000)
                    local ok, err = connect_redis_master(red)
                    local route = nil
                    if ok then
                        route, err = red:get("manual-routes:" .. domain)
                        if not route or route == ngx.null then
                            route, err = red:get("routes:" .. domain)
                        end
                    end
                    if not route or route == ngx.null then
                        if err then
                            ngx.log(ngx.ERR, "redis get failed: ", err)
                        end
                    end
                    if ok then
                        red:close()
                    end

                    local route_data = (route and route ~= ngx.null) and route or nil

                    if not route_data then
                        ngx.status = 404
                        ngx.say("No route configured for this domain")
                        return ngx.exit(404)
                    end

                    -- Cache for 30 seconds
                    cache:set(domain, route_data, 30)
                    cached_route = route_data
                end

                -- Parse route configuration
                local route = cjson.decode(cached_route)

                -- Optional path-based routing (longest prefix match).
                -- If the route object contains `path_routes`, a matching entry will be used
                -- to select upstream targets/policy for this request URI.
                local request_uri = ngx.var.uri or "/"

                local function normalize_prefix(p)
                    if not p or p == "" then
                        return "/"
                    end
                    if p:sub(1, 1) ~= "/" then
                        p = "/" .. p
                    end
                    if #p > 1 and p:sub(-1) == "/" then
                        p = p:sub(1, -2)
                    end
                    return p
                end

                local function has_prefix(s, prefix)
                    if prefix == "/" then
                        return true
                    end
                    if s == prefix then
                        return true
                    end
                    if s:sub(1, #prefix) ~= prefix then
                        return false
                    end
                    -- Boundary match: "/api" should match "/api" and "/api/...", but not "/api2"
                    local next_ch = s:sub(#prefix + 1, #prefix + 1)
                    return next_ch == "/"
                end

                local function select_path_route(parent_route, uri)
                    local candidates = parent_route.path_routes
                    if type(candidates) ~= "table" then
                        return parent_route
                    end

                    local best = nil
                    local best_len = -1

                    for _, r in ipairs(candidates) do
                        if type(r) == "table" then
                            local prefix = normalize_prefix(r.path or r.prefix)
                            if prefix and has_prefix(uri, prefix) then
                                local l = #prefix
                                if l > best_len then
                                    best = r
                                    best_len = l
                                end
                            end
                        end
                    end

                    if not best then
                        return parent_route
                    end

                    -- Inherit selected fields from the parent route when missing.
                    if best.policy == nil then best.policy = parent_route.policy end
                    if best.cookie_name == nil then best.cookie_name = parent_route.cookie_name end
                    if best.preserve_host == nil then best.preserve_host = parent_route.preserve_host end
                    if best.client_max_body_size == nil then best.client_max_body_size = parent_route.client_max_body_size end

                    return best
                end

                local selected_route = select_path_route(route, request_uri)
                local targets = selected_route.targets or route.targets or {{}}

                if #targets == 0 then
                    ngx.status = 503
                    ngx.say("No backend targets available")
                    return ngx.exit(503)
                end

                -- Select target based on policy
                local policy = selected_route.policy or route.policy or "rr"
                local target_url

                if policy == "rr" then
                    -- Round-robin
                    local counters = ngx.shared.rr_counters
                    local counter = counters:get(domain) or 0
                    local total_weight = 0
                    for _, t in ipairs(targets) do
                        total_weight = total_weight + (t.weight or 1)
                    end

                    local idx = (counter % #targets) + 1
                    target_url = targets[idx].url
                    counters:incr(domain, 1, 0)

                elseif policy == "ip_hash" then
                    -- IP hash
                    local ip = ngx.var.remote_addr
                    local hash = ngx.crc32_long(ip)
                    local idx = (hash % #targets) + 1
                    target_url = targets[idx].url

                elseif policy == "cookie" then
                    -- Cookie-based sticky session
                    local cookie_name = selected_route.cookie_name or route.cookie_name or "sticky"
                    local cookie_value = ngx.var["cookie_" .. cookie_name]

                    if not cookie_value then
                        -- Assign new cookie
                        local idx = math.random(#targets)
                        target_url = targets[idx].url
                        cookie_value = tostring(idx)
                        ngx.header["Set-Cookie"] = cookie_name .. "=" .. cookie_value .. "; Path=/; HttpOnly"
                    else
                        local idx = tonumber(cookie_value) or 1
                        if idx < 1 or idx > #targets then
                            idx = 1
                        end
                        target_url = targets[idx].url
                    end
                else
                    -- Default to first target
                    target_url = targets[1].url
                end

                -- Set upstream variable
                ngx.var.upstream_url = target_url

                -- Set Host header based on preserve_host
                if selected_route.preserve_host then
                    ngx.req.set_header("Host", domain)
                end

                local lim = selected_route.client_max_body_size or route.client_max_body_size
                local lim_str = (type(lim) == "string") and string.lower(lim) or nil

                -- S3 gateway domains must always allow streaming uploads.
                -- Some manually managed routes may miss client_max_body_size=0.
                local is_s3_domain = (type(domain) == "string") and (
                    string.find(string.lower(domain), "^gatekeeper%-s3%.", 1, false) ~= nil
                )

                local unlimited = (lim == 0) or (lim == "0") or (lim_str == "unlimited")
                if lim_str == "0m" or lim_str == "0k" or lim_str == "0g" or lim_str == "0b" then
                    unlimited = true
                end

                -- GraphQL: use large-body path only for upload-like requests.
                local is_graphql_path = has_prefix(request_uri, "/graphql")
                local method = ngx.req.get_method()
                local content_type = string.lower(ngx.var.http_content_type or "")
                local content_length = tonumber(ngx.var.http_content_length or "")

                local is_graphql_multipart_upload = is_graphql_path
                    and method == "POST"
                    and string.find(content_type, "multipart/form%-data", 1, false) ~= nil

                -- Fallback for non-multipart large GraphQL POST payloads.
                local is_graphql_large_post = is_graphql_path
                    and method == "POST"
                    and content_length ~= nil
                    and content_length > 1024 * 1024

                if is_s3_domain or unlimited or is_graphql_multipart_upload or is_graphql_large_post then
                    return ngx.exec("@swc_proxy_large_body")
                end
                return ngx.exec("@swc_proxy_default")
            }}

        }}

        location @swc_proxy_default {{
            internal;
            client_max_body_size 1m;
            proxy_pass $upstream_url;

            # WebSocket support
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $connection_upgrade;

            # Standard headers
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            # Streaming support
            proxy_buffering off;
            proxy_request_buffering off;

            # Extended timeouts for long-lived WebSocket connections
            proxy_read_timeout 3600s;
            proxy_send_timeout 3600s;
            proxy_connect_timeout 75s;
        }}

        location @swc_proxy_large_body {{
            internal;
            client_max_body_size 0;
            proxy_pass $upstream_url;

            # WebSocket support
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $connection_upgrade;

            # Standard headers
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            # Streaming support
            proxy_buffering off;
            proxy_request_buffering off;

            # Extended timeouts for long-lived WebSocket connections
            proxy_read_timeout 3600s;
            proxy_send_timeout 3600s;
            proxy_connect_timeout 75s;
        }}
    }}
}}
"""
    return config


SWARM_EVIDENCE_LUA = """-- /.well-known/swarm-evidence handler (SP-7699).
--
-- Serves the unified attestation bundle on every hostname openresty terminates
-- TLS for, with no per-host nginx state:
--   1. evidence-jws:<host>           per-host JWS produced by ingress-sync
--   2. attestation-bundle:current    cloud-wide cert chain + (future) TEE quote
--   3. evidence-tls-leaf:<host>      per-host TLS leaf PEM (SP-7665, optional)
--
-- The JWS payload already carries hostname/kind/issuedAt/certFingerprint, so
-- the handler decodes the payload, splices it into the cloud bundle, attaches
-- the TLS leaf if available, and emits the wire format the swarm-attestation
-- verifier consumes. The tls-leaf key is optional: a missing value just omits
-- `tlsLeaf` from the response (backward-compatible — chrome MV3 then fails at
-- stage `tls-fingerprint`, desktop continues on the live observed channel).
--
-- Every response on this path is CORS-open by design (SUP-192); the location
-- block in `generate_nginx_config` carries the reasoning.
local cjson = require "cjson.safe"
local redis = require "resty.redis"

local function fail(status, code)
    ngx.status = status
    ngx.print(cjson.encode({ error = code }))
    return ngx.exit(status)
end

local function base64url_decode(s)
    if not s then return nil end
    s = s:gsub('-', '+'):gsub('_', '/')
    local rem = #s % 4
    if rem == 2 then
        s = s .. '=='
    elseif rem == 3 then
        s = s .. '='
    elseif rem == 1 then
        return nil
    end
    return ngx.decode_base64(s)
end

local function decode_jws_payload(jws)
    if type(jws) ~= "string" then return nil end
    local _, payload_b64, _ = jws:match("^([^.]+)%.([^.]+)%.([^.]+)$")
    if not payload_b64 then return nil end
    local raw = base64url_decode(payload_b64)
    if not raw then return nil end
    local ok, decoded = pcall(cjson.decode, raw)
    if not ok or type(decoded) ~= "table" then return nil end
    return decoded
end

-- SUP-192: answer the CORS preflight here, before touching Redis — a browser
-- verifier on another origin sends it for every non-simple request, and the
-- answer never depends on cluster state. `Access-Control-Allow-Origin` itself
-- is added by nginx for every response on this location, including this one.
if ngx.req.get_method() == "OPTIONS" then
    ngx.header["Access-Control-Allow-Methods"] = "GET, HEAD, OPTIONS"
    ngx.header["Access-Control-Allow-Headers"] = "*"
    ngx.header["Access-Control-Max-Age"] = "86400"
    return ngx.exit(204)
end

local host = ngx.var.host
if not host or host == "" then
    return fail(400, "missing-host")
end

local red = redis:new()
red:set_timeout(1000)
local ok, err = connect_redis_master(red)
if not ok then
    ngx.log(ngx.ERR, "swarm-evidence: redis connect failed: ", err)
    return fail(503, "redis-unavailable")
end

local jws, jws_err = red:get("evidence-jws:" .. host)
if jws_err then
    red:close()
    ngx.log(ngx.ERR, "swarm-evidence: redis get evidence-jws failed: ", jws_err)
    return fail(503, "redis-error")
end
if not jws or jws == ngx.null then
    red:close()
    return fail(404, "not-attested")
end

-- SP-7665: best-effort fetch of the per-host TLS leaf PEM. Errors and absence
-- both degrade gracefully: the handler simply omits `tlsLeaf` from the bundle
-- and the verifier then falls back to its observed channel-binding path
-- (desktop) or fails at `tls-fingerprint` (chrome MV3, which has no other
-- channel binding option).
local tls_leaf, tls_leaf_err = red:get("evidence-tls-leaf:" .. host)
if tls_leaf_err then
    ngx.log(ngx.ERR, "swarm-evidence: redis get evidence-tls-leaf failed: ", tls_leaf_err)
    tls_leaf = nil
end

local bundle_raw, bundle_err = red:get("attestation-bundle:current")
red:close()
if bundle_err then
    ngx.log(ngx.ERR, "swarm-evidence: redis get attestation-bundle failed: ", bundle_err)
    return fail(503, "redis-error")
end
-- A missing cloud-wide bundle is the legacy/non-sp-vm deployment shape (no
-- pki-authority producing pki_* secrets). The contract response here is the
-- same as a host without a JWS: 404 not-attested. Once pki-authority is
-- present and the AttestationBundleSyncWorker has published, this path
-- transitions to the 200 bundle on the next request.
if not bundle_raw or bundle_raw == ngx.null then
    return fail(404, "not-attested")
end

local bundle = cjson.decode(bundle_raw)
if type(bundle) ~= "table" then
    return fail(503, "bundle-malformed")
end

local payload = decode_jws_payload(jws)
if not payload then
    ngx.log(ngx.ERR, "swarm-evidence: failed to decode JWS payload for host ", host)
    return fail(500, "jws-malformed")
end

bundle.kind = payload.kind
bundle.hostname = payload.hostname or host
bundle.issuedAt = payload.issuedAt
bundle.certFingerprint = payload.certFingerprint
bundle.jws = jws
if tls_leaf and tls_leaf ~= ngx.null and tls_leaf ~= "" then
    bundle.tlsLeaf = tls_leaf
end

ngx.print(cjson.encode(bundle))
"""


SWARM_ROUTES_LUA = """-- /.well-known/swarm-routes handler (SUP-216).
--
-- Publishes the ingress hostnames this cloud's gateway currently routes: the
-- key suffixes of `routes:<host>` and `manual-routes:<host>` in the fabric
-- Redis, and nothing else out of those route objects.
--
-- Why it exists: the host orchestrator (`tools/spvm/spvm_cloud.py`) needs that
-- list to do two things it owns -- issue the public Let's Encrypt cert for an
-- app's custom ingress hostname, and add that hostname as an exact SNI key in
-- its :443 stream router. It used to read the list by ssh-ing into a guest and
-- running `redis-cli --scan`. Release-variant sp-vm images ship no sshd, so on
-- a release cloud the host learned nothing: no cert was issued, no SNI entry
-- was written, and every custom app-ingress hostname answered with a closed
-- connection. The gateway already talks to the host on :443 (that is how
-- `tls_state` is probed), which makes this the one read channel that works on
-- a release image.
--
-- No credential is accepted on this path, by design. The response carries
-- hostnames only -- no targets, no wireguard IPs, no path routes -- so it
-- grants no reachability knowledge: the fabric's own dns-manager publishes
-- every one of these names in public DNS before the gateway can serve a
-- request on it, which makes the list the same class of public document as the
-- cloud's DNS zone. Adding anything from the route object to this response
-- would break that argument.
local cjson = require "cjson.safe"
local redis = require "resty.redis"

local PREFIXES = { "routes:", "manual-routes:" }
local CACHE_KEY = "index"
-- The host polls this on its reconcile timer; a few seconds of staleness costs
-- nothing (a new hostname is picked up on the next pass) and keeps a hot loop
-- off the Redis master.
local CACHE_TTL = 10
-- SCAN is cursor-paged over the WHOLE keyspace, not just matches, so this bounds
-- redis round trips rather than route count -- it exists to stop a pathological
-- cursor from pinning a worker. A walk that hits it has NOT finished, and a
-- truncated route list served as authoritative would silently drop ingress
-- hostnames (and flap between polls, since SCAN order is arbitrary), so the
-- handler fails instead of answering with part of the answer.
local MAX_SCAN_CALLS = 500
local SCAN_COUNT = 1000

local function fail(status, code)
    ngx.status = status
    ngx.print(cjson.encode({ error = code }))
    return ngx.exit(status)
end

local method = ngx.req.get_method()
if method ~= "GET" and method ~= "HEAD" then
    ngx.header["Allow"] = "GET, HEAD"
    return fail(405, "method-not-allowed")
end

local cache = ngx.shared.swarm_routes_cache
local cached = cache:get(CACHE_KEY)
if cached then
    ngx.print(cached)
    return
end

local red = redis:new()
red:set_timeout(1000)
local ok, err = connect_redis_master(red)
if not ok then
    ngx.log(ngx.ERR, "swarm-routes: redis connect failed: ", err)
    return fail(503, "redis-unavailable")
end

local seen = {}
for _, prefix in ipairs(PREFIXES) do
    local cursor = "0"
    local calls = 0
    repeat
        local res, scan_err = red:scan(cursor, "MATCH", prefix .. "*", "COUNT", SCAN_COUNT)
        if not res or res == ngx.null then
            red:close()
            ngx.log(ngx.ERR, "swarm-routes: redis scan ", prefix, " failed: ", scan_err)
            return fail(503, "redis-error")
        end
        cursor = res[1]
        for _, key in ipairs(res[2]) do
            local host = string.sub(key, #prefix + 1)
            if host ~= "" then
                seen[host] = true
            end
        end
        calls = calls + 1
        if cursor ~= "0" and calls >= MAX_SCAN_CALLS then
            red:close()
            ngx.log(ngx.ERR, "swarm-routes: redis scan ", prefix,
                    " did not finish within ", calls, " calls")
            return fail(503, "scan-incomplete")
        end
    until cursor == "0"
end
red:close()

local hosts = {}
for host in pairs(seen) do
    hosts[#hosts + 1] = host
end
-- Sorted so the host's "did the route set change?" comparison is stable across
-- polls: Redis SCAN returns keys in no particular order.
table.sort(hosts)

-- An empty Lua table encodes as `{}`, not `[]`, and the host rejects a body whose
-- `hosts` is not an array -- which would turn "this cloud routes nothing yet" into
-- "this channel is unavailable" and send it back to the ssh fallback.
local body = cjson.encode({ hosts = (#hosts > 0) and hosts or cjson.empty_array,
                            count = #hosts })
cache:set(CACHE_KEY, body, CACHE_TTL)
ngx.print(body)
"""


GATEWAY_ERRORS_LUA = """-- Gateway 5xx forensics (SUP-367).
--
-- Why this exists: on a release cloud the rendered error page is the ONLY
-- trace an incident leaves. Release sp-vm images ship no sshd, so nobody can
-- read /var/log/openresty/error.log afterwards, and the gateway keeps no state
-- of its own -- so "which node's :30080 failed at 08:05, and how often" has no
-- answer by the time anyone asks. This module keeps that answer: every
-- response the gateway emits with status >= 500 is counted per
-- (hostname, upstream target, status) into an hourly bucket, and a bounded
-- ring of recent samples carries the detail (upstream address, upstream
-- status, timings).
--
-- Why Redis rather than another /.well-known endpoint: a sample names the
-- upstream target -- a WireGuard IP and NodePort -- which is reachability
-- knowledge, so unlike /.well-known/swarm-routes (hostnames only, already
-- public in DNS) it must not be served without a credential. The authenticated
-- swarm-cloud API reads these keys back and scopes them to the caller's own
-- cluster space, which it can do because it owns hostname -> owner
-- (DomainResourceMapping).
--
-- Why a timer rather than a direct write: log_by_lua has no cosocket support,
-- so the log phase can only touch a shared dict. One flush timer per gateway
-- (dict-held lock, so a single nginx worker drains per window) moves it out.
local cjson = require "cjson.safe"
local redis = require "resty.redis"

local _M = {}

local DICT_NAME = "gateway_errors"
-- Flush cadence. Long enough that a hard-down backend costs a couple of Redis
-- round trips per window instead of one per request; short enough that an
-- operator looking seconds after the incident already sees it.
local FLUSH_INTERVAL = 5
-- The ring is best-effort and capped; the counters are not. A storm that
-- outruns the ring therefore loses detail, never arithmetic -- and the loss is
-- itself published (DROPPED_FIELD) so a reader can tell a quiet window from a
-- truncated one.
local MAX_PENDING_SAMPLES = 200
local RECENT_KEY = "gateway-errors:recent"
local RECENT_MAX = 1000
local COUNTER_PREFIX = "gateway-errors:counters:"
local DROPPED_FIELD = "#dropped"
-- Refreshed on every flush, including the ones with nothing to say. Without it
-- "this gateway has served no 5xx" and "this gateway never publishes" are the
-- same empty read, and an operator cannot tell good news from a dead channel.
local HEARTBEAT_KEY = "gateway-errors:heartbeat"
local HEARTBEAT_TTL = 60
-- 48h, matching what it takes to root-cause an incident found the next
-- morning. Both key families carry it, so nothing here grows without bound.
local RETENTION = 172800
-- Counter keys are recreated on demand, so an hour's TTL is what stops the
-- dict's key set from growing with every hostname the gateway has ever served.
-- It can cost at most one unflushed window's counts for a key that expires
-- between flushes.
local COUNTER_DICT_TTL = 3600
local URI_MAX = 256

local function counter_key(field)
    return "c:" .. field
end

function _M.record()
    local status = tonumber(ngx.var.status)
    if not status or status < 500 then
        return
    end

    local dict = ngx.shared[DICT_NAME]
    if not dict then
        return
    end

    local host = ngx.var.host
    if not host or host == "" then
        host = "-"
    end
    -- The route's chosen target. "-" covers the gateway's own 5xx (no route
    -- selected yet), which is a distinct and interesting case: it means the
    -- gateway failed before it reached a backend at all.
    local target = ngx.var.upstream_url
    if not target or target == "" then
        target = "-"
    end

    local field = host .. "|" .. target .. "|" .. status
    if not dict:incr(counter_key(field), 1, 0, COUNTER_DICT_TTL) then
        -- Out of dict memory: a sample would fail the same way, so record the
        -- loss where the reader will see it and stop.
        dict:incr(counter_key(DROPPED_FIELD), 1, 0, COUNTER_DICT_TTL)
        return
    end

    -- `pending` is decremented by the flush as each sample leaves. A Redis
    -- outage therefore parks the ring at its cap (counters keep accruing) and
    -- sampling resumes by itself once a flush drains again.
    local pending = dict:incr("pending", 1, 0)
    if not pending or pending > MAX_PENDING_SAMPLES then
        dict:incr("pending", -1)
        dict:incr(counter_key(DROPPED_FIELD), 1, 0, COUNTER_DICT_TTL)
        return
    end

    local uri = ngx.var.uri or "-"
    if #uri > URI_MAX then
        uri = string.sub(uri, 1, URI_MAX)
    end

    local sample = cjson.encode({
        ts = ngx.time(),
        host = host,
        status = status,
        method = ngx.req.get_method(),
        uri = uri,
        target = target,
        -- `$upstream_addr` is the peer nginx actually dialled, so a 502 names
        -- the node whose ingress NodePort failed even when the route lists
        -- several targets and the retry chain tried more than one (SUP-366).
        upstreamAddr = ngx.var.upstream_addr or "-",
        upstreamStatus = ngx.var.upstream_status or "-",
        upstreamTime = ngx.var.upstream_response_time or "-",
        requestTime = ngx.var.request_time or "-",
    })

    local seq = sample and dict:incr("seq", 1, 0)
    if not seq or not dict:set("s:" .. seq, sample) then
        dict:incr("pending", -1)
        dict:incr(counter_key(DROPPED_FIELD), 1, 0, COUNTER_DICT_TTL)
    end
end

-- Snapshot the dict without mutating it: nothing is removed until Redis has
-- accepted it, so a Redis outage costs a retry rather than the data.
local function collect(dict)
    local counters, samples = {}, {}
    for _, key in ipairs(dict:get_keys(0)) do
        local kind = string.sub(key, 1, 2)
        if kind == "c:" then
            local value = dict:get(key)
            if value and value > 0 then
                counters[#counters + 1] = { key = key, field = string.sub(key, 3), delta = value }
            end
        elseif kind == "s:" then
            local value = dict:get(key)
            if value then
                samples[#samples + 1] = { key = key, seq = tonumber(string.sub(key, 3)) or 0, body = value }
            end
        end
    end
    -- Oldest first, so the LPUSH order below leaves the Redis list newest-first.
    table.sort(samples, function(a, b)
        return a.seq < b.seq
    end)
    return counters, samples
end

local function drain(dict)
    local red = redis:new()
    red:set_timeout(1000)
    local ok, err = connect_redis_master(red)
    if not ok then
        -- Leave the dict untouched; the next window retries the same deltas.
        ngx.log(ngx.ERR, "gateway-errors: redis connect failed: ", err)
        return
    end

    red:setex(HEARTBEAT_KEY, HEARTBEAT_TTL, ngx.time())

    local counters, samples = collect(dict)
    if #counters == 0 and #samples == 0 then
        red:close()
        return
    end

    local bucket = COUNTER_PREFIX .. os.date("!%Y%m%d%H")
    for _, counter in ipairs(counters) do
        local _, hincr_err = red:hincrby(bucket, counter.field, counter.delta)
        if hincr_err then
            ngx.log(ngx.ERR, "gateway-errors: hincrby failed: ", hincr_err)
        else
            -- Subtract only what Redis took, and only after it took it:
            -- increments that landed since `collect` stay for the next window.
            --
            -- No `init` argument, deliberately: COUNTER_DICT_TTL may have
            -- expired the key since `collect` read it, and an init here would
            -- re-create it holding a NEGATIVE count. `collect` skips values
            -- <= 0, so the following window's real counts would silently fill
            -- that hole instead of being reported. A "not found" is the right
            -- answer -- the counts went with the key.
            dict:incr(counter.key, -counter.delta)
        end
    end
    if #counters > 0 then
        red:expire(bucket, RETENTION)
    end

    for _, sample in ipairs(samples) do
        local _, push_err = red:lpush(RECENT_KEY, sample.body)
        if push_err then
            ngx.log(ngx.ERR, "gateway-errors: lpush failed: ", push_err)
            break
        end
        dict:delete(sample.key)
        dict:incr("pending", -1)
    end
    if #samples > 0 then
        red:ltrim(RECENT_KEY, 0, RECENT_MAX - 1)
        red:expire(RECENT_KEY, RETENTION)
    end

    red:close()
end

function _M.flush()
    local dict = ngx.shared[DICT_NAME]
    if not dict then
        return
    end
    -- One flush per gateway per window, not one per nginx worker: the dict is
    -- shared, so without this every worker would race to drain the same keys.
    --
    -- Released as soon as the drain returns rather than left to expire: a lock
    -- that outlives its own flush makes every second window a no-op, halving
    -- the cadence. The TTL stays as the guard for a worker that dies mid-drain.
    if not dict:add("flush_lock", 1, FLUSH_INTERVAL) then
        return
    end
    local ok, err = pcall(drain, dict)
    dict:delete("flush_lock")
    if not ok then
        error(err, 0)
    end
end

function _M.start()
    local ok, err = ngx.timer.every(FLUSH_INTERVAL, function(premature)
        if premature then
            return
        end
        local called, flush_err = pcall(_M.flush)
        if not called then
            ngx.log(ngx.ERR, "gateway-errors: flush failed: ", flush_err)
        end
    end)
    if not ok then
        ngx.log(ngx.ERR, "gateway-errors: could not start flush timer: ", err)
    end
end

return _M
"""


def write_swarm_routes_lua() -> None:
    """Write the /.well-known/swarm-routes Lua handler (SUP-216)."""
    target = OPENRESTY_LUA_DIR / "swarm_routes.lua"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_text(encoding="utf-8") == SWARM_ROUTES_LUA:
        return
    target.write_text(SWARM_ROUTES_LUA, encoding="utf-8")
    print(f"[*] Wrote {target}", file=sys.stderr)


def write_gateway_errors_lua() -> None:
    """Write the 5xx forensics Lua module (SUP-367)."""
    target = OPENRESTY_LUA_DIR / "gateway_errors.lua"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_text(encoding="utf-8") == GATEWAY_ERRORS_LUA:
        return
    target.write_text(GATEWAY_ERRORS_LUA, encoding="utf-8")
    print(f"[*] Wrote {target}", file=sys.stderr)


def write_swarm_evidence_lua() -> None:
    """Write the /.well-known/swarm-evidence Lua handler (SP-7699)."""
    target = OPENRESTY_LUA_DIR / "swarm_evidence.lua"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_text(encoding="utf-8") == SWARM_EVIDENCE_LUA:
        return
    target.write_text(SWARM_EVIDENCE_LUA, encoding="utf-8")
    print(f"[*] Wrote {target}", file=sys.stderr)


def write_nginx_config(config_content: str):
    """Write Nginx configuration to disk and setup required directories."""
    ensure_podman_volume_host_paths()
    ensure_opm_lua_packages()
    ensure_lua_resty_vendor_shell()
    ensure_resty_auto_ssl_host_bins()
    # Ensure config directory exists
    OPENRESTY_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Ensure Lua module directory exists
    OPENRESTY_LUA_DIR.mkdir(parents=True, exist_ok=True)

    # Ensure log directory exists
    OPENRESTY_LOG_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(OPENRESTY_LOG_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Ensure nginx logs directory exists (for PID file)
    NGINX_LOGS_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(NGINX_LOGS_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Dehydrated WELLKNOWN dir required by resty-auto-ssl hooks
    wellknown_dir = Path("/var/www/dehydrated")
    wellknown_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(wellknown_dir)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        os.chmod(wellknown_dir, 0o755)
    except Exception:
        pass

    # Write configuration
    OPENRESTY_CONFIG_FILE.write_text(config_content)
    print(f"[*] Wrote Nginx config to {OPENRESTY_CONFIG_FILE}", file=sys.stderr)

    # Write the /.well-known/swarm-evidence Lua handler (SP-7699).
    write_swarm_evidence_lua()

    # Write the /.well-known/swarm-routes Lua handler (SUP-216).
    write_swarm_routes_lua()

    # Write the 5xx forensics module the log phase requires (SUP-367).
    write_gateway_errors_lua()

    # Write AutoSSL Redis Cluster storage adapter
    # This adapter will be installed to /usr/local/share/lua/5.1/resty/auto-ssl/storage_adapters/
    storage_adapter_path = OPENRESTY_LUA_DIR / "resty/auto-ssl/storage_adapters/redis_sentinel.lua"
    storage_adapter_path.parent.mkdir(parents=True, exist_ok=True)
    storage_adapter_path.write_text(
        """local redis = require "resty.redis"

local _M = {}

function _M.new(auto_ssl_instance)
  local options = auto_ssl_instance:get("storage_adapter_options") or {}
  return setmetatable({ options = options }, { __index = _M })
end

local function parse_host(host)
  local h, p = host:match("^([^:]+):?(%d*)$")
  if not h or h == "" then
    return nil, nil
  end
  if not p or p == "" then
    p = "6379"
  end
  return h, tonumber(p)
end

local function get_master_from_sentinel(self)
  local sentinel_hosts = self.options.sentinel_hosts or {}
  if #sentinel_hosts == 0 then
    return nil, nil
  end
  for _, host in ipairs(sentinel_hosts) do
    local red = redis:new()
    red:set_timeout(1000)
    local h, p = parse_host(host)
    if h then
      local ok = red:connect(h, p)
      if ok then
        local res, err = red:sentinel("get-master-addr-by-name", "redis-master")
        red:close()
        if type(res) == "table" and res[1] and res[2] then
          return res[1], tonumber(res[2])
        end
      end
    end
  end
  return nil, nil
end

local function get_client(self)
  local red = redis:new()
  red:set_timeout(1000)
  local host, port = get_master_from_sentinel(self)
  if host then
    red:connect(host, port)
    return red
  end
  local redis_hosts = self.options.redis_hosts or {}
  for _, host in ipairs(redis_hosts) do
    local h, p = parse_host(host)
    if h then
      local ok = red:connect(h, p)
      if ok then
        return red
      end
    end
  end
  return red
end

local function prefixed_key(self, key)
  local prefix = self.options.key_prefix or "auto-ssl:"
  return prefix .. key
end

function _M.setup()
end

function _M.get(self, key)
  local red = get_client(self)
  local full_key = prefixed_key(self, key)

  local val, err = red:get(full_key)
  if err then
    return nil, err
  end

  if val == ngx.null then
    return nil
  end

  return val
end

function _M.set(self, key, value, options)
  local red = get_client(self)
  local full_key = prefixed_key(self, key)

  local ok, err
  if options and options["exptime"] then
    ok, err = red:setex(full_key, options["exptime"], value)
  else
    ok, err = red:set(full_key, value)
  end

  if err then
    return false, err
  end

  return ok, err
end

function _M.delete(self, key)
  local red = get_client(self)
  local full_key = prefixed_key(self, key)

  local ok, err = red:del(full_key)
  if err then
    return false, err
  end

  return ok, err
end

function _M.keys_with_suffix(self, suffix)
  -- Redis cluster doesn't support KEYS command efficiently
  -- Return empty list for now
  return {}
end

return _M
"""
    )

    # Copy storage adapter to the correct location for auto-ssl to find it
    system_lua_path = Path("/usr/local/share/lua/5.1/resty/auto-ssl/storage_adapters")
    if system_lua_path.exists():
        system_adapter_path = system_lua_path / "redis_sentinel.lua"
        try:
            shutil.copy2(str(storage_adapter_path), str(system_adapter_path))
            print(f"[*] Copied Redis sentinel adapter to {system_adapter_path}", file=sys.stderr)
        except Exception as e:
            print(f"[!] Warning: Failed to copy adapter to system path: {e}", file=sys.stderr)

    # Create SSL directory and self-signed fallback certificate if not exists
    OPENRESTY_SSL_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["chown", "-R", "www-data:www-data", str(OPENRESTY_SSL_DIR)],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    fallback_cert = OPENRESTY_SSL_DIR / "fallback.crt"
    if not fallback_cert.exists():
        # Generate self-signed certificate as fallback
        subprocess.run(
            [
                "openssl", "req", "-new", "-newkey", "rsa:2048", "-days", "3650",
                "-nodes", "-x509", "-subj", "/CN=fallback",
                "-keyout", str(OPENRESTY_SSL_DIR / "fallback.key"),
                "-out", str(OPENRESTY_SSL_DIR / "fallback.crt")
            ],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )


def is_openresty_running() -> tuple[bool, str | None]:
    """Check if OpenResty is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "openresty"],
            capture_output=True,
            text=True
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize OpenResty: install packages."""
    try:
        # If ZeroSSL override is configured, validate config up-front and
        # install EAB-capable dehydrated + deps during init.
        eab_support = False
        try:
            acme_cfg = load_acme_config_from_yaml(OPENRESTY_ACME_CONFIG_PATH)
            eab_support = acme_cfg is not None
        except Exception as e:
            # Init must not fail on missing/invalid config; fall back to default flow.
            # (Apply will validate strictly when actually configuring ACME.)
            print(f"[!] Warning: ACME config is missing/invalid, ignoring for init: {e}", file=sys.stderr)
            eab_support = False

        # Install OpenResty if not present
        bootstrap_openresty_runtime(eab_support=eab_support)

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


def get_swarm_secret(state: dict, secret_id: str) -> str | None:
    swarm_secrets = state.get("swarmSecrets", [])
    if not isinstance(swarm_secrets, list):
        return None
    for secret in swarm_secrets:
        if isinstance(secret, dict) and secret.get("id") == secret_id:
            value = secret.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def resolve_global_id(state: dict) -> str | None:
    global_id = state.get("globalId")
    if isinstance(global_id, str) and global_id.strip():
        return global_id.strip()
    return None


def resolve_dynamic_gateway_hostname(state: dict) -> str | None:
    global_id = resolve_global_id(state)
    base_domain = get_swarm_secret(state, "base_domain")
    if global_id and base_domain:
        return f"gw.dyn.{global_id}.{base_domain.rstrip('.')}"
    return None


def resolve_static_gateway_hostname(state: dict) -> str | None:
    custom = get_swarm_secret(state, "gateway_hostname")
    if custom:
        return custom.rstrip(".")
    return None


def resolve_delegation_gateway_hostname(state: dict) -> str | None:
    """CNAME target for users: static gateway when configured, else dynamic."""
    static = resolve_static_gateway_hostname(state)
    if static:
        return static
    return resolve_dynamic_gateway_hostname(state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply OpenResty configuration and start the service."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    print(f"[DEBUG] apply: local_node_id={local_node_id}", file=sys.stderr)

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        print(f"[DEBUG] apply: invalid state_json type: {type(state_json)}", file=sys.stderr)
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    # Get Redis hosts from state
    redis_hosts = get_redis_tunnel_ips(state_json)
    sentinel_hosts = get_sentinel_tunnel_ips(state_json)

    if not redis_hosts:
        print("[DEBUG] apply: no redis_hosts yet (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for Redis nodes to become ready',
            local_state=local_state
        )

    if not sentinel_hosts:
        print("[DEBUG] apply: no sentinel_hosts yet (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for Redis Sentinel nodes to become ready',
            local_state=local_state
        )

    # Main apply log line (requested style).
    print(
        f"[*] Found {len(redis_hosts)} Redis hosts: {redis_hosts}; "
        f"sentinel_hosts={len(sentinel_hosts)}; local_node_id={local_node_id}",
        file=sys.stderr,
    )

    try:
        require_podman()
    except RuntimeError as e:
        return PluginOutput(status='error', error_message=str(e), local_state=local_state)

    if not is_openresty_image_available():
        try:
            bootstrap_openresty_runtime(eab_support=False)
        except Exception as e:
            return PluginOutput(status='error', error_message=str(e), local_state=local_state)

    # Determine leader and address for ACME challenge proxying
    openresty_wg_props = state_json.get("openrestyWgNodeProperties", [])
    openresty_wg_cluster = state_json.get("openrestyWgCluster", {})
    leader_node_id = get_leader_node(state_json)
    is_leader = (leader_node_id == local_node_id)
    leader_addr = get_node_tunnel_ip(leader_node_id, openresty_wg_props) if leader_node_id else None

    print(
        f"[DEBUG] apply: leader_node_id={leader_node_id} is_leader={is_leader} leader_addr={leader_addr}",
        file=sys.stderr,
    )

    if not openresty_wg_cluster.get("id"):
        print("[DEBUG] apply: openresty_wg_cluster missing id (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard cluster for OpenResty nodes',
            local_state=local_state
        )

    if not openresty_wg_props:
        print("[DEBUG] apply: openresty_wg_props empty (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard tunnel IPs for OpenResty nodes',
            local_state=local_state
        )

    if not leader_node_id:
        print("[DEBUG] apply: leader_node_id missing (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for cluster leader to be elected',
            local_state=local_state
        )

    if not is_leader and not leader_addr:
        print("[DEBUG] apply: follower without leader_addr (postponed)", file=sys.stderr)
        return PluginOutput(
            status='postponed',
            error_message='Waiting for leader tunnel IP (stream TLS routing)',
            local_state=local_state
        )

    # ACME provider config (ZeroSSL only)
    try:
        acme_cfg = load_acme_config_from_yaml(
            OPENRESTY_ACME_CONFIG_PATH
        )
    except ValueError as e:
        print(f"[DEBUG] apply: ACME config validation error: {e}", file=sys.stderr)
        return PluginOutput(status='error', error_message=str(e), local_state=local_state)
    except Exception as e:
        print(f"[DEBUG] apply: ACME config load error: {e}", file=sys.stderr)
        return PluginOutput(status='error', error_message=f"Failed to load ACME config: {e}", local_state=local_state)

    # Defaults: keep current Let's Encrypt behavior when YAML missing.
    acme_provider = "letsencrypt"
    acme_ca_url: str | None = None
    eab_fingerprint: str | None = None

    # If YAML exists, enable ZeroSSL, require EAB creds and CA url.
    if acme_cfg is not None:
        _acme_provider, acme_ca_url, eab_kid, eab_hmac_key, eab_fingerprint = acme_cfg
        acme_provider = _acme_provider
        print(
            f"[DEBUG] apply: ACME override enabled provider={acme_provider} ca_url={acme_ca_url} "
            f"eab_fingerprint={eab_fingerprint}",
            file=sys.stderr,
        )
        try:
            if is_leader and acme_ca_url:
                _sanity_check_acme_directory_url(url=acme_ca_url)
            ensure_dehydrated_eab_support()
            write_dehydrated_zerossl_config(eab_kid, eab_hmac_key, acme_ca_url)
        except Exception as e:
            print(f"[DEBUG] apply: ZeroSSL EAB setup failed: {e}", file=sys.stderr)
            try:
                print(f"[DEBUG] apply traceback: {traceback.format_exc()}", file=sys.stderr)
            except Exception:
                pass
            return PluginOutput(
                status='error',
                error_message=f"Failed to write ZeroSSL EAB config: {e}",
                local_state=local_state
            )
    else:
        print("[DEBUG] apply: ACME override not configured (default letsencrypt)", file=sys.stderr)

    # Render first, then hash: the rendered files are part of what "config"
    # means, so a template-only service release still reconfigures (SUP-192).
    # Rendering is pure string formatting — cheap enough to do before the
    # unchanged-config shortcut.
    try:
        config_content = generate_nginx_config(redis_hosts, sentinel_hosts, is_leader, leader_addr, acme_ca_url)
    except Exception as e:
        print(f"[DEBUG] apply: failed to generate nginx config: {e}", file=sys.stderr)
        try:
            print(f"[DEBUG] apply traceback: {traceback.format_exc()}", file=sys.stderr)
        except Exception:
            pass
        return PluginOutput(
            status='error',
            error_message=f'Failed to generate config: {str(e)}',
            local_state=local_state
        )

    # Compute config hash to detect changes
    config_hash = compute_config_hash(
        redis_hosts,
        sentinel_hosts,
        leader_node_id,
        leader_addr,
        acme_provider,
        acme_ca_url,
        eab_fingerprint,
        OPENRESTY_IMAGE,
        config_content,
    )

    # Check if we need to reconfigure
    prev_config_hash = local_state.get("config_hash")
    if prev_config_hash == config_hash and local_state.get("openresty_ready"):
        # No changes, skip reconfiguration
        print(f"[DEBUG] apply: config unchanged (hash={config_hash}), skipping", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)

    # Write configuration
    try:
        write_nginx_config(config_content)
        create_openresty_systemd_service()
    except Exception as e:
        print(f"[DEBUG] apply: failed to write nginx config: {e}", file=sys.stderr)
        try:
            print(f"[DEBUG] apply traceback: {traceback.format_exc()}", file=sys.stderr)
        except Exception:
            pass
        return PluginOutput(
            status='error',
            error_message=f'Failed to write config: {str(e)}',
            local_state=local_state
        )

    # Restart OpenResty to apply configuration
    try:
        # Test configuration first (same mounts as systemd unit)
        print("[*] Testing OpenResty configuration", file=sys.stderr)
        test_result = run_openresty_config_test()
        if test_result.returncode != 0:
            print("[DEBUG] apply: openresty -t failed", file=sys.stderr)
            if test_result.stdout:
                print(f"[DEBUG] openresty -t stdout: {test_result.stdout.strip()}", file=sys.stderr)
            if test_result.stderr:
                print(f"[DEBUG] openresty -t stderr: {test_result.stderr.strip()}", file=sys.stderr)
            err_out = (test_result.stderr or test_result.stdout or "").strip()
            return PluginOutput(
                status='error',
                error_message=f'Configuration test failed: {err_out}',
                local_state=local_state
            )

        # Always restart to ensure configuration is applied
        # This handles both initial start and configuration updates
        print("[*] Restarting OpenResty", file=sys.stderr)

        # Enable service for autostart
        result = subprocess.run(
            ["systemctl", "enable", "openresty"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            if result.stdout:
                print(f"[DEBUG] systemctl enable stdout: {result.stdout.strip()}", file=sys.stderr)
            if result.stderr:
                print(f"[DEBUG] systemctl enable stderr: {result.stderr.strip()}", file=sys.stderr)
            return PluginOutput(
                status='error',
                error_message=f'Failed to enable OpenResty: {result.stderr}',
                local_state=local_state
            )

        # Restart service (works whether running or not)
        result = subprocess.run(
            ["systemctl", "restart", "openresty"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            if result.stdout:
                print(f"[DEBUG] systemctl restart stdout: {result.stdout.strip()}", file=sys.stderr)
            if result.stderr:
                print(f"[DEBUG] systemctl restart stderr: {result.stderr.strip()}", file=sys.stderr)
            return PluginOutput(
                status='error',
                error_message=f'Failed to restart OpenResty: {result.stderr}',
                local_state=local_state
            )

    except Exception as e:
        print(f"[DEBUG] apply: exception while starting/restarting openresty: {e}", file=sys.stderr)
        try:
            print(f"[DEBUG] apply traceback: {traceback.format_exc()}", file=sys.stderr)
        except Exception:
            pass
        return PluginOutput(
            status='error',
            error_message=f'Failed to start OpenResty: {str(e)}',
            local_state=local_state
        )

    # Wait a bit for OpenResty to start
    time.sleep(2)

    # Update local state
    new_local_state = {
        **local_state,
        "config_hash": config_hash,
        "redis_hosts": redis_hosts,
        "sentinel_hosts": sentinel_hosts,
        "openresty_ready": True
    }

    # Prepare node properties
    node_properties = {
        "openresty_ready": "true"
    }
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    node_properties.update(
        build_image_evidence_props(
            prefix="openresty",
            image_ref=OPENRESTY_IMAGE,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )

    cluster_properties = None
    delegation_gateway_hostname = resolve_delegation_gateway_hostname(state_json)
    if delegation_gateway_hostname:
        cluster_properties = {
            "gateway_hostname": delegation_gateway_hostname,
        }
        print(
            f"[*] Publishing delegation gateway hostname to cluster properties: {delegation_gateway_hostname}",
            file=sys.stderr,
        )

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        local_state=new_local_state,
        cluster_properties=cluster_properties,
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check OpenResty health."""
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Check if OpenResty is running
    openresty_running, openresty_error = is_openresty_running()
    if not openresty_running:
        if openresty_error and 'Failed to' in openresty_error:
            # Real error checking status
            return PluginOutput(status='error', error_message=openresty_error, local_state=local_state)
        else:
            # Service not running yet
            return PluginOutput(
                status='postponed',
                error_message=openresty_error or 'OpenResty service is not running',
                local_state=local_state
            )

    # Check if Redis hosts changed
    if isinstance(state_json, dict):
        current_redis_hosts = get_redis_tunnel_ips(state_json)
        previous_redis_hosts = local_state.get("redis_hosts", [])
        current_sentinel_hosts = get_sentinel_tunnel_ips(state_json)
        previous_sentinel_hosts = local_state.get("sentinel_hosts", [])

        if sorted(current_redis_hosts) != sorted(previous_redis_hosts):
            print(f"[*] Redis hosts changed, will be updated on next apply", file=sys.stderr)

        if sorted(current_sentinel_hosts) != sorted(previous_sentinel_hosts):
            print(f"[*] Redis Sentinel hosts changed, will be updated on next apply", file=sys.stderr)
            # Don't fail health check, just log that config needs update
            # The next apply will handle the update

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal (graceful shutdown)."""
    local_state = input_data.local_state or {}

    # TODO: Implement graceful shutdown if needed
    # This could involve:
    # - Draining connections
    # - Waiting for active requests to complete

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy OpenResty installation and clean up."""
    try:
        subprocess.run(
            ["systemctl", "stop", OPENRESTY_SERVICE_NAME],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["systemctl", "disable", OPENRESTY_SERVICE_NAME],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            exe = podman_executable()
            subprocess.run(
                [exe, "stop", OPENRESTY_CONTAINER_NAME],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            subprocess.run(
                [exe, "rm", OPENRESTY_CONTAINER_NAME],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except RuntimeError:
            pass

        unit_path = Path("/etc/systemd/system") / OPENRESTY_SERVICE_UNIT
        if unit_path.is_file():
            try:
                unit_path.unlink()
            except OSError:
                pass
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        if OPENRESTY_CONFIG_FILE.exists():
            OPENRESTY_CONFIG_FILE.unlink()

        if OPENRESTY_SSL_DIR.exists():
            shutil.rmtree(OPENRESTY_SSL_DIR, ignore_errors=True)

        node_properties = {
            "openresty_ready": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to destroy OpenResty: {e}',
            local_state={}
        )


if __name__ == "__main__":
    plugin.run()
