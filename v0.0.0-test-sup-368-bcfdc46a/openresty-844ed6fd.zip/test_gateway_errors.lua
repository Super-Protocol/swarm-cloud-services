-- Behavioural tests for the 5xx forensics module (SUP-367).
--
-- Run as `luajit test_gateway_errors.lua <path-to-gateway_errors.lua>`.
-- `test_main.py` writes GATEWAY_ERRORS_LUA out of main.py into a temp file and
-- drives this script, skipping when no luajit is installed -- the Python string
-- assertions stay the always-on guard, these are the ones that actually execute
-- the log-phase and flush paths against fake ngx/Redis.

local module_path = arg and arg[1]
if not module_path then
    io.stderr:write("usage: luajit test_gateway_errors.lua <gateway_errors.lua>\n")
    os.exit(2)
end

local failures = 0

local function check(name, ok, detail)
    if ok then
        print("ok   - " .. name)
    else
        failures = failures + 1
        print("FAIL - " .. name .. (detail and (": " .. tostring(detail)) or ""))
    end
end

local function eq(name, actual, expected)
    check(name, actual == expected, string.format("got %s, want %s", tostring(actual), tostring(expected)))
end

-- ── fake ngx.shared.DICT ────────────────────────────────────────────────────
-- Only the semantics the module relies on: `incr` needs its `init` argument to
-- create a missing key, `add` must fail on an existing one (that is the flush
-- lock), and `get_keys` must enumerate everything (that is how flush drains).

local function new_dict()
    local store = {}
    local dict = {}

    function dict:get(key)
        local entry = store[key]
        if entry == nil then
            return nil
        end
        return entry.value
    end

    function dict:set(key, value, exptime)
        store[key] = { value = value, exptime = exptime }
        return true
    end

    function dict:add(key, value, exptime)
        if store[key] ~= nil then
            return nil, "exists"
        end
        store[key] = { value = value, exptime = exptime }
        return true
    end

    function dict:delete(key)
        store[key] = nil
    end

    function dict:incr(key, value, init, init_ttl)
        local entry = store[key]
        if entry == nil then
            if init == nil then
                return nil, "not found"
            end
            store[key] = { value = init + value, init_ttl = init_ttl }
            return store[key].value
        end
        entry.value = entry.value + value
        return entry.value
    end

    function dict:get_keys(_)
        local keys = {}
        for key in pairs(store) do
            keys[#keys + 1] = key
        end
        table.sort(keys)
        return keys
    end

    -- Test affordances, not part of the ngx API.
    dict.store = store
    function dict:count(prefix)
        local total = 0
        for key in pairs(store) do
            if string.sub(key, 1, #prefix) == prefix then
                total = total + 1
            end
        end
        return total
    end

    return dict
end

-- ── fakes for cjson.safe / resty.redis / ngx ────────────────────────────────

local function encode(value)
    local keys = {}
    for key in pairs(value) do
        keys[#keys + 1] = key
    end
    table.sort(keys)
    local parts = {}
    for _, key in ipairs(keys) do
        local raw = value[key]
        local rendered = type(raw) == "number" and tostring(raw) or ('"' .. tostring(raw) .. '"')
        parts[#parts + 1] = '"' .. key .. '":' .. rendered
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

local redis_calls = {}
local redis_connect_fails = false
local redis_hincrby_fails = false
-- Set by a test that needs something to happen between `collect` and the
-- dict subtraction -- the window the dict's own TTL can fire in.
local on_hincrby = nil

local redis_stub = {}
function redis_stub.new()
    local client = {}
    function client:set_timeout(_) end
    function client:close()
        redis_calls[#redis_calls + 1] = { "close" }
    end
    function client:hincrby(key, field, delta)
        redis_calls[#redis_calls + 1] = { "hincrby", key, field, delta }
        if on_hincrby then
            on_hincrby(field)
        end
        if redis_hincrby_fails then
            return nil, "hincrby boom"
        end
        return delta
    end
    function client:expire(key, ttl)
        redis_calls[#redis_calls + 1] = { "expire", key, ttl }
        return 1
    end
    function client:lpush(key, value)
        redis_calls[#redis_calls + 1] = { "lpush", key, value }
        return 1
    end
    function client:ltrim(key, from, to)
        redis_calls[#redis_calls + 1] = { "ltrim", key, from, to }
        return 1
    end
    function client:setex(key, ttl, value)
        redis_calls[#redis_calls + 1] = { "setex", key, ttl, value }
        return 1
    end
    return client
end

package.preload["cjson.safe"] = function()
    return { encode = encode }
end
package.preload["resty.redis"] = function()
    return redis_stub
end

local dict = new_dict()
local timers = {}

ngx = {
    shared = { gateway_errors = dict },
    var = {},
    ERR = "ERR",
    log = function() end,
    time = function()
        return 1760774700
    end,
    req = {
        get_method = function()
            return "GET"
        end,
    },
    timer = {
        every = function(interval, handler)
            timers[#timers + 1] = { interval = interval, handler = handler }
            return true
        end,
    },
}

connect_redis_master = function()
    if redis_connect_fails then
        return nil, "no redis host available"
    end
    return true
end

local gateway_errors = assert(loadfile(module_path))()

local function request(vars)
    ngx.var = vars
    gateway_errors.record()
end

local function redis_fields(command)
    local found = {}
    for _, call in ipairs(redis_calls) do
        if call[1] == command then
            found[#found + 1] = call
        end
    end
    return found
end

local function new_window()
    -- flush releases its own lock, so this only exists for the tests that need
    -- to assert the lock is what stops a second drain inside one window.
    dict:delete("flush_lock")
end

-- ── the log phase ───────────────────────────────────────────────────────────

request({ status = "200", host = "console.router.superprotocol.com", upstream_url = "http://10.0.0.1:30080", uri = "/" })
eq("a 2xx leaves no counter", dict:count("c:"), 0)
eq("a 2xx leaves no sample", dict:count("s:"), 0)

request({ status = "404", host = "console.router.superprotocol.com", upstream_url = "", uri = "/missing" })
eq("a 4xx leaves no counter", dict:count("c:"), 0)

request({
    status = "502",
    host = "console.router.superprotocol.com",
    upstream_url = "http://10.0.0.1:30080",
    upstream_addr = "10.0.0.1:30080",
    upstream_status = "502",
    upstream_response_time = "0.001",
    request_time = "0.002",
    uri = "/api/health",
})
eq(
    "a 502 counts against (host, target, status)",
    dict:get("c:console.router.superprotocol.com|http://10.0.0.1:30080|502"),
    1
)
eq("a 502 stores one sample", dict:count("s:"), 1)
eq("the sample is accounted for in pending", dict:get("pending"), 1)
check(
    "the sample names the peer nginx actually dialled",
    string.find(dict:get("s:1"), '"upstreamAddr":"10.0.0.1:30080"', 1, true) ~= nil,
    dict:get("s:1")
)

request({ status = "503", host = "api.router.superprotocol.com", upstream_url = "", uri = "/" })
eq(
    "a gateway-generated 5xx records with no target",
    dict:get("c:api.router.superprotocol.com|-|503"),
    1
)

-- ── the flush ───────────────────────────────────────────────────────────────

redis_connect_fails = true
gateway_errors.flush()
eq("a Redis outage keeps the counter for the next window", dict:get("c:api.router.superprotocol.com|-|503"), 1)
eq("a Redis outage keeps the samples for the next window", dict:count("s:"), 2)
eq("a Redis outage writes nothing", #redis_calls, 0)

redis_connect_fails = false
new_window()
gateway_errors.flush()

eq("every distinct counter is pushed to Redis", #redis_fields("hincrby"), 2)
eq("every sample is pushed to Redis", #redis_fields("lpush"), 2)
check(
    "counters land in an hourly bucket",
    string.find(redis_fields("hincrby")[1][2], "^gateway%-errors:counters:%d%d%d%d%d%d%d%d%d%d$") ~= nil,
    redis_fields("hincrby")[1][2]
)
check(
    "the ring is trimmed so it cannot grow without bound",
    #redis_fields("ltrim") == 1 and redis_fields("ltrim")[1][4] == 999,
    "ltrim calls: " .. #redis_fields("ltrim")
)
check("both key families get a retention TTL", #redis_fields("expire") == 2, #redis_fields("expire"))
for _, call in ipairs(redis_fields("expire")) do
    eq("retention is 48h for " .. call[2], call[3], 172800)
end
eq("flushed counters are zeroed, not re-sent", dict:get("c:api.router.superprotocol.com|-|503"), 0)
eq("flushed samples are removed", dict:count("s:"), 0)
eq("pending is released so sampling resumes", dict:get("pending"), 0)

check("the heartbeat marks the channel live", #redis_fields("setex") == 1, #redis_fields("setex"))
eq("the heartbeat expires so a dead gateway stops looking live", redis_fields("setex")[1][3], 60)

local before = #redis_calls
-- The lock must be released by the flush itself: a lock left to expire makes
-- every second window a no-op and halves the cadence.
check("the flush releases its own lock", dict:get("flush_lock") == nil, dict:get("flush_lock"))
dict:add("flush_lock", 1, 5)
gateway_errors.flush()
eq("a held lock stops a second drain in the same window", #redis_calls, before)

new_window()
gateway_errors.flush()
-- A quiet window still heartbeats: "no 5xx" has to be distinguishable from
-- "this gateway never publishes".
eq("a quiet window writes only the heartbeat", #redis_calls, before + 2)
eq("the quiet window's only write is the heartbeat", #redis_fields("setex"), 2)

-- An increment that lands between `collect` and the Redis write must survive.
request({ status = "502", host = "console.router.superprotocol.com", upstream_url = "-", uri = "/" })
redis_hincrby_fails = true
new_window()
gateway_errors.flush()
eq("a rejected hincrby keeps the delta", dict:get("c:console.router.superprotocol.com|-|502"), 1)
redis_hincrby_fails = false

-- A counter key whose COUNTER_DICT_TTL expires between `collect` and the
-- subtraction must stay gone. Re-creating it holding a negative count would
-- make `collect` skip it (it only reads values > 0) while the next window's
-- real counts fill the hole back up -- silent under-reporting.
local expiring = "c:console.router.superprotocol.com|-|502"
new_window()
gateway_errors.flush()
request({ status = "502", host = "console.router.superprotocol.com", upstream_url = "-", uri = "/" })
eq("the new error is counted", dict:get(expiring), 1)
on_hincrby = function(field)
    -- The dict TTL firing after `collect` read the key and before the flush
    -- subtracts the delta it just published.
    if field == "console.router.superprotocol.com|-|502" then
        dict:delete(expiring)
    end
end
new_window()
gateway_errors.flush()
on_hincrby = nil
eq("a counter that expired mid-flush is not re-created negative", dict:get(expiring), nil)
request({ status = "502", host = "console.router.superprotocol.com", upstream_url = "-", uri = "/" })
eq("the next window's counts are reported, not absorbed", dict:get(expiring), 1)

-- ── the sample cap ──────────────────────────────────────────────────────────

local capped = new_dict()
ngx.shared.gateway_errors = capped
for index = 1, 260 do
    request({
        status = "502",
        host = "console.router.superprotocol.com",
        upstream_url = "http://10.0.0.1:30080",
        uri = "/" .. index,
    })
end
eq("the ring stops at its cap", capped:count("s:"), 200)
eq("the counters stay exact past the cap", capped:get("c:console.router.superprotocol.com|http://10.0.0.1:30080|502"), 260)
eq("the dropped samples are published", capped:get("c:#dropped"), 60)

-- ── the timer ───────────────────────────────────────────────────────────────

gateway_errors.start()
eq("start registers exactly one flush timer", #timers, 1)
eq("the flush cadence matches the module constant", timers[1].interval, 5)
timers[1].handler(true)
check("a premature timer does not flush", true)

if failures > 0 then
    print(string.format("\n%d check(s) failed", failures))
    os.exit(1)
end
print("\nall checks passed")
