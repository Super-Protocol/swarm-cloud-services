#!/usr/bin/env python3

import sys
import os
import json
import shutil
import subprocess
import hashlib
import time
from dataclasses import dataclass
from pathlib import Path

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

# Configuration
COCKROACH_VERSION = os.environ.get("COCKROACH_VERSION", "v23.2.0")
COCKROACH_SQL_PORT = 26257
COCKROACH_HTTP_PORT = 8180
COCKROACH_CONFIG_DIR = Path("/etc/cockroachdb")
COCKROACH_DATA_DIR = Path("/var/lib/cockroachdb")
COCKROACH_CERTS_DIR = COCKROACH_CONFIG_DIR / "certs"
COCKROACH_BIN = "/usr/local/bin/cockroach"
# Keep each finalize status poll under swarm membership heartbeat_stale_ms (default 60s)
# even when querying several peers sequentially.
FINALIZE_PEER_STATUS_TIMEOUT_SEC = 8

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions

def hash_node_id(node_id: str) -> str:
    """Create hex MD5 hash of node ID for CockroachDB node name compatibility."""
    return hashlib.md5(node_id.encode()).hexdigest()


def compute_install_hash(state_json: dict, version: str) -> str:
    """Compute hash of cluster configuration to detect changes."""
    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])

    # Build payload from node IDs and their WG addresses
    node_ids = sorted([n["node_id"] for n in cluster_nodes])
    wg_addresses = []

    # Build map of node_id -> tunnel_ip
    tunnel_ip_map = {}
    for prop in wg_props:
        if prop.get("name") == "tunnel_ip":
            tunnel_ip_map[prop.get("node_id")] = prop.get("value")

    for node_id in node_ids:
        hashed_id = hash_node_id(node_id)
        tunnel_ip = tunnel_ip_map.get(node_id, "unknown")
        wg_addresses.append(f"{hashed_id}={tunnel_ip}")

    payload = "|".join(node_ids) + "|" + "|".join(wg_addresses) + "|" + str(COCKROACH_SQL_PORT) + "|" + version
    return hashlib.sha256(payload.encode()).hexdigest()


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def get_local_wg_ip(interface: str = "wg0") -> str | None:
    """Read this host's WireGuard tunnel IP directly from the interface.

    Fallback for when plan state no longer carries our own tunnel_ip: a drained
    node is dropped from cluster membership (and thus from wgNodeProperties)
    before finalize runs, yet its wg0 interface and CockroachDB are still up, so
    we can still identify ourselves to a healthy peer and decommission cleanly.
    """
    try:
        result = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", interface],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    for token in result.stdout.split():
        if "/" in token and token.count(".") == 3:
            return token.split("/", 1)[0]
    return None


def build_wg_overlay_exempt_node_ids(state_json: dict) -> set[str]:
    """CRDB members not in active wireguard ClusterNodes (deferred swap leaving nodes)."""
    exempt: set[str] = set()
    for node_id in state_json.get("wgOverlayExemptNodeIds") or []:
        if isinstance(node_id, str) and node_id:
            exempt.add(node_id)
    return exempt


def check_all_nodes_have_wg(
    cluster_nodes: list,
    wg_props: list,
    wg_overlay_exempt_node_ids: set[str] | None = None,
) -> bool:
    """Check WireGuard tunnel IPs for cluster nodes that still participate in the overlay."""
    exempt = wg_overlay_exempt_node_ids or set()
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not node_id or node_id in exempt:
            continue
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def is_cluster_initialized(cluster_properties: list) -> bool:
    """Check if the CockroachDB cluster was already initialized (ClusterProperties)."""
    for prop in cluster_properties:
        if prop.get("name") == "cockroachdb_cluster_initialized" and prop.get("value") == "true":
            return True
    return False


def peer_has_running_cluster(join_address: str, timeout_sec: int = 5) -> bool:
    """Return True if a join peer already serves an initialized CockroachDB cluster."""
    try:
        result = subprocess.run(
            [COCKROACH_BIN, "node", "status", "--insecure", "--host", join_address],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        if result.returncode == 0:
            return True
        err = (result.stderr or result.stdout or "").strip().replace("\n", " ")
        if err:
            print(
                f"[*] Peer {join_address} probe failed (exit {result.returncode}): {err}",
                file=sys.stderr,
            )
        else:
            print(
                f"[*] Peer {join_address} probe failed (exit {result.returncode})",
                file=sys.stderr,
            )
        return False
    except subprocess.TimeoutExpired:
        print(
            f"[*] Peer {join_address} probe timed out after {timeout_sec}s",
            file=sys.stderr,
        )
        return False
    except Exception as e:
        print(f"[*] Peer {join_address} probe error: {e}", file=sys.stderr)
        return False


def discover_cluster_initialized_on_peers(
    join_addresses: list[str],
    local_tunnel_ip: str,
) -> bool:
    """Probe join peers before running init to avoid creating a second cluster."""
    local_addr = f"{local_tunnel_ip}:{COCKROACH_SQL_PORT}"
    for addr in join_addresses:
        if addr == local_addr:
            continue
        if peer_has_running_cluster(addr):
            print(f"[*] CockroachDB cluster already running on peer {addr}", file=sys.stderr)
            return True
    return False


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")


def is_cockroach_available() -> bool:
    """Check if CockroachDB binary is available."""
    return os.path.exists(COCKROACH_BIN)


def install_cockroachdb():
    """Install CockroachDB binary."""
    try:
        # Download CockroachDB binary
        if not os.path.exists("/usr/local/bin"):
            os.makedirs("/usr/local/bin", exist_ok=True)

        # Detect architecture
        arch_result = subprocess.run(["uname", "-m"], capture_output=True, text=True)
        arch = arch_result.stdout.strip()

        # Map architecture names
        arch_map = {
            "x86_64": "amd64",
            "aarch64": "arm64",
            "arm64": "arm64"
        }
        cockroach_arch = arch_map.get(arch, "amd64")

        # Download and install
        download_url = f"https://binaries.cockroachdb.com/cockroach-{COCKROACH_VERSION}.linux-{cockroach_arch}.tgz"

        print(f"[*] Downloading CockroachDB from {download_url}", file=sys.stderr)

        result = subprocess.run(
            ["curl", "-L", download_url, "-o", "/tmp/cockroach.tgz"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise Exception(f"Failed to download CockroachDB: {result.stderr}")

        # Extract
        result = subprocess.run(
            ["tar", "-xzf", "/tmp/cockroach.tgz", "-C", "/tmp/"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise Exception(f"Failed to extract CockroachDB: {result.stderr}")

        # Find the extracted binary
        extracted_dir = f"/tmp/cockroach-{COCKROACH_VERSION}.linux-{cockroach_arch}"
        if not os.path.exists(extracted_dir):
            raise Exception(f"Extracted directory not found: {extracted_dir}")

        # Copy binary
        shutil.copy(f"{extracted_dir}/cockroach", COCKROACH_BIN)
        os.chmod(COCKROACH_BIN, 0o755)

        # Cleanup
        shutil.rmtree(extracted_dir, ignore_errors=True)
        os.remove("/tmp/cockroach.tgz")

        print(f"[*] CockroachDB installed successfully", file=sys.stderr)
    except Exception as e:
        print(f"[!] Failed to install CockroachDB: {e}", file=sys.stderr)
        raise


def create_systemd_service(local_tunnel_ip: str, join_addresses: list):
    """Create systemd service for CockroachDB."""
    service_content = f"""[Unit]
Description=CockroachDB
After=network.target

[Service]
Type=notify
User=root
ExecStart={COCKROACH_BIN} start \\
  --insecure \\
  --advertise-addr={local_tunnel_ip}:{COCKROACH_SQL_PORT} \\
  --listen-addr={local_tunnel_ip}:{COCKROACH_SQL_PORT} \\
  --http-addr={local_tunnel_ip}:{COCKROACH_HTTP_PORT} \\
  --store={COCKROACH_DATA_DIR} \\
  --cache=.25 \\
  --max-sql-memory=.25 \\
  --join={','.join(join_addresses)}
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    service_path = "/etc/systemd/system/cockroachdb.service"
    with open(service_path, "w") as f:
        f.write(service_content)

    # Reload systemd
    subprocess.run(["systemctl", "daemon-reload"], check=False)


def wait_for_cockroach_ready(local_tunnel_ip: str, timeout_sec: int = 60) -> bool:
    """Wait for CockroachDB process to start and listen on port."""
    start_time = time.time()
    last_error = None

    while time.time() - start_time < timeout_sec:
        try:
            # Check if service is active
            result = subprocess.run(
                ["systemctl", "is-active", "cockroachdb"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.stdout.strip() != "active":
                last_error = f"Service not active: {result.stdout.strip()}"
                time.sleep(3)
                continue

            # Check if port is listening using nc (netcat)
            result = subprocess.run(
                ["nc", "-z", local_tunnel_ip, str(COCKROACH_SQL_PORT)],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0:
                print(f"[*] CockroachDB process is ready and listening on {local_tunnel_ip}:{COCKROACH_SQL_PORT}", file=sys.stderr)
                return True

            last_error = f"Port not yet listening"
        except subprocess.TimeoutExpired:
            last_error = "Port check timed out"
        except Exception as e:
            last_error = f"Port check error: {str(e)}"

        time.sleep(3)

    print(f"[!] CockroachDB did not become ready within {timeout_sec}s. Last error: {last_error}", file=sys.stderr)
    return False


def is_cockroach_running() -> tuple[bool, str | None]:
    """Check if CockroachDB is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "cockroachdb"],
            capture_output=True,
            text=True
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"


def init_cluster(local_tunnel_ip: str) -> bool:
    """Initialize CockroachDB cluster."""
    try:
        result = subprocess.run(
            [COCKROACH_BIN, "init", "--insecure", "--host", f"{local_tunnel_ip}:{COCKROACH_SQL_PORT}"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode != 0:
            # Check if already initialized
            if "cluster has already been initialized" in result.stderr.lower():
                print(f"[*] Cluster already initialized", file=sys.stderr)
                return True
            print(f"[!] Cluster initialization failed: {result.stderr}", file=sys.stderr)
            return False

        print(f"[*] CockroachDB cluster initialized successfully", file=sys.stderr)
        return True
    except Exception as e:
        print(f"[!] Failed to initialize CockroachDB cluster: {e}", file=sys.stderr)
        return False


def _cockroach_host_arg(local_tunnel_ip: str) -> str:
    return f"{local_tunnel_ip}:{COCKROACH_SQL_PORT}"


def _run_cockroach(args: list[str], local_tunnel_ip: str, timeout_sec: int = 120) -> subprocess.CompletedProcess:
    cmd = [COCKROACH_BIN, *args, "--insecure", "--host", _cockroach_host_arg(local_tunnel_ip)]
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_sec)


def read_local_cockroach_node_id(host: str) -> str | None:
    """Read this node's raft id from local SQL when CockroachDB is healthy."""
    try:
        result = _run_cockroach(
            ["sql", "--format=csv", "--execute", "SELECT * FROM crdb_internal.node_id();"],
            host,
            timeout_sec=15,
        )
        if result.returncode != 0:
            return None
        lines = [line.strip() for line in (result.stdout or "").strip().splitlines() if line.strip()]
        if len(lines) < 2:
            return None
        node_id = lines[1]
        return str(node_id) if node_id else None
    except (subprocess.TimeoutExpired, OSError, ValueError):
        return None


def resolve_stored_cockroach_node_id(
    local_state: dict,
    cockroach_props: list,
    local_node_id: str | None = None,
) -> str | None:
    """Resolve cached raft node id: local_state primary, plan properties fallback."""
    local_id = local_state.get("cockroach_node_id")
    if local_id is not None:
        return str(local_id)
    if not local_node_id:
        return None
    for prop in cockroach_props:
        if (
            prop.get("node_id") == local_node_id
            and prop.get("name") == "cockroachdb_node_id"
            and prop.get("value")
        ):
            return str(prop.get("value"))
    return None


def should_refresh_cockroach_node_id(
    prev_install_hash: str | None,
    install_hash: str,
    stored_id: str | None,
    live_id: str | None,
) -> bool:
    if live_id is None:
        return False
    if stored_id is None:
        return True
    if prev_install_hash != install_hash:
        return True
    return str(stored_id) != str(live_id)


def find_node_in_decommission_status(nodes: object, node_id: str) -> dict | None:
    if not isinstance(nodes, list):
        return None
    target = str(node_id)
    for node in nodes:
        if isinstance(node, dict) and str(node.get("id")) == target:
            return node
    return None


def _apply_cockroach_node_id_capture(
    local_state: dict,
    install_hash: str,
    prev_install_hash: str | None,
    local_tunnel_ip: str,
    node_properties: dict,
) -> tuple[dict, dict]:
    live_id = read_local_cockroach_node_id(local_tunnel_ip)
    stored_id = local_state.get("cockroach_node_id")
    if should_refresh_cockroach_node_id(prev_install_hash, install_hash, stored_id, live_id):
        local_state = {**local_state, "cockroach_node_id": live_id}
        node_properties = {**node_properties, "cockroachdb_node_id": str(live_id)}
    return local_state, node_properties


def _fetch_decommission_status_json(
    host_ip: str,
    *,
    timeout_sec: int = 30,
) -> tuple[list | None, str | None]:
    """Run `node status --decommission --format=json` on host_ip; return (nodes, error)."""
    try:
        result = _run_cockroach(
            ["node", "status", "--decommission", "--format=json"],
            host_ip,
            timeout_sec=timeout_sec,
        )
        if result.returncode != 0:
            return None, (result.stderr or result.stdout or "node status failed").strip()

        nodes = json.loads(result.stdout or "[]")
        if not isinstance(nodes, list):
            return None, "invalid node status json: expected list"
        return nodes, None
    except json.JSONDecodeError as e:
        return None, f"invalid node status json: {e}"
    except subprocess.TimeoutExpired:
        return None, "node status timed out"
    except Exception as e:
        return None, str(e)


def _find_local_node(nodes: object, local_tunnel_ip: str) -> dict | None:
    """`node status --decommission --format=json` returns a flat list of node dicts.

    Each row's `address`/`sql_address` is exactly `<ip>:<port>`, so an equality
    match is enough — no recursion or substring search needed.
    """
    if not isinstance(nodes, list):
        return None
    target = f"{local_tunnel_ip}:{COCKROACH_SQL_PORT}"
    for node in nodes:
        if isinstance(node, dict) and target in (node.get("address"), node.get("sql_address")):
            return node
    return None


def _membership_from_decommission_node(node: dict | None) -> str | None:
    if node is None:
        return None
    membership = node.get("membership")
    return membership if isinstance(membership, str) else None


def _is_decommission_rebalance_complete(node: dict) -> bool:
    """True when CRDB has drained replicas off the node (membership may still be decommissioning)."""
    membership = node.get("membership")
    if membership == "decommissioned":
        return True
    if membership != "decommissioning":
        return False

    for field in ("gossiped_replicas", "replicas"):
        value = node.get(field)
        if value is None:
            continue
        try:
            if int(value) == 0:
                return True
        except (TypeError, ValueError):
            continue

    blocking = node.get("blocking_ranges")
    if blocking is not None:
        try:
            if int(blocking) == 0:
                readiness = node.get("readiness")
                if readiness is None or readiness in ("ready", "already decommissioned"):
                    return True
        except (TypeError, ValueError):
            pass

    return False


def _decommission_finalize_complete(node: dict | None, membership: str | None) -> bool:
    if membership == "decommissioned":
        return True
    if node is not None and _is_decommission_rebalance_complete(node):
        return True
    return False


def _poll_decommission_node_by_id(
    node_id: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = 30,
) -> tuple[dict | None, str | None]:
    last_err: str | None = None
    for peer_ip in peer_tunnel_ips:
        nodes, err = _fetch_decommission_status_json(peer_ip, timeout_sec=timeout_sec)
        if err is not None:
            last_err = err
            continue
        node = find_node_in_decommission_status(nodes, node_id)
        if node is not None:
            return node, None
        last_err = "node id not found in cluster status"
    return None, last_err or "node id not found on any peer"


def get_node_decommission_status_by_id(
    peer_tunnel_ip: str,
    node_id: str,
    *,
    timeout_sec: int = 30,
) -> tuple[str | None, str | None]:
    """Returns (membership, error) for a raft node id via a peer."""
    nodes, err = _fetch_decommission_status_json(peer_tunnel_ip, timeout_sec=timeout_sec)
    if err is not None:
        return None, err

    node = find_node_in_decommission_status(nodes, node_id)
    if node is None:
        return None, "node id not found in cluster status"

    return _membership_from_decommission_node(node), None


def get_local_node_decommission_status(
    local_tunnel_ip: str,
    *,
    query_host: str | None = None,
    timeout_sec: int = 30,
) -> tuple[str | None, str | None]:
    """Returns (membership, error). `membership` is the single source of truth:
    active / decommissioning / decommissioned. Query via query_host or local_tunnel_ip.
    """
    host_ip = query_host or local_tunnel_ip
    nodes, err = _fetch_decommission_status_json(host_ip, timeout_sec=timeout_sec)
    if err is not None:
        return None, err

    node = _find_local_node(nodes, local_tunnel_ip)
    if node is None:
        return None, "local node not found in cluster status"

    membership = node.get("membership")
    return (membership if isinstance(membership, str) else None), None


def _decommission_already_in_progress(membership: str | None) -> bool:
    # is_decommissioning is derived from membership in v23.2, so membership alone is enough.
    return membership in ("decommissioning", "decommissioned")


def _decommission_command_succeeded(result: subprocess.CompletedProcess) -> bool:
    if result.returncode == 0:
        return True
    combined = f"{result.stderr}\n{result.stdout}".lower()
    if "already decommissioned" in combined or "already decommissioning" in combined:
        return True
    if "no node with node id" in combined and "decommissioned" in combined:
        return True
    return False


def _get_local_node_id_via_peer(peer_tunnel_ip: str, local_tunnel_ip: str) -> str | None:
    nodes, err = _fetch_decommission_status_json(peer_tunnel_ip, timeout_sec=30)
    if err is not None:
        return None

    node = _find_local_node(nodes, local_tunnel_ip)
    if not node:
        return None
    node_id = node.get("id")
    return str(node_id) if node_id is not None else None


def _decommission_cmd_args(cmd_args: list[str]) -> list[str]:
    """Ensure decommission returns after kick-off, not after full replica rebalance.

    Default CRDB --wait=all blocks until the target is online and fully drained;
    on a draining node that is already unavailable this hits our CLI timeout and
    finalize fails before membership flips to decommissioning.
    """
    if len(cmd_args) >= 2 and cmd_args[0] == "node" and cmd_args[1] == "decommission":
        rest = [arg for arg in cmd_args[2:] if not arg.startswith("--wait=")]
        return [cmd_args[0], cmd_args[1], "--wait=none", *rest]
    return cmd_args


def _try_decommission(
    cmd_args: list[str],
    run_host: str,
    local_tunnel_ip: str,
    *,
    status_host: str | None = None,
    status_node_id: str | None = None,
    timeout_sec: int = 60,
) -> tuple[bool, str | None]:
    """Run a decommission command; an already-progressing node counts as success.

    On timeout, re-read status (the command may have taken effect) before failing.
    """
    try:
        result = _run_cockroach(_decommission_cmd_args(cmd_args), run_host, timeout_sec=timeout_sec)
        if _decommission_command_succeeded(result):
            return True, None
        return False, (result.stderr or result.stdout or "decommission failed").strip()
    except subprocess.TimeoutExpired:
        if status_host and status_node_id:
            membership, err = get_node_decommission_status_by_id(status_host, status_node_id)
        else:
            membership, err = get_local_node_decommission_status(local_tunnel_ip, query_host=status_host)
        if _decommission_already_in_progress(membership):
            return True, None
        return False, err or "decommission timed out"


def start_decommission_by_id(
    peer_tunnel_ips: list[str],
    node_id: str,
    local_tunnel_ip: str | None = None,
) -> tuple[bool, str | None]:
    """Kick off decommission for a known raft node id (--wait=none, non-blocking).

    The Cockroach CLI always runs as a local subprocess on this host (the leaving
    VM). Each peer attempt uses ``--host=<peer_tunnel_ip>:26257`` so the local
    client dials that peer's SQL port — not remote execution on the peer.

    Peers are tried in order; if all fail and local_tunnel_ip is set, retries
    against the local tunnel address. Post-kick status is polled via status_host
    so an already-decommissioning target counts as success.
    """
    last_err: str | None = None
    node_id_str = str(node_id)
    for peer_ip in peer_tunnel_ips:
        if local_tunnel_ip and peer_ip == local_tunnel_ip:
            continue
        ok, err = _try_decommission(
            ["node", "decommission", node_id_str],
            peer_ip,
            local_tunnel_ip or peer_ip,
            status_host=peer_ip,
            status_node_id=node_id_str,
        )
        if ok:
            return True, None
        last_err = err
        if err and "lost quorum" in err.lower():
            return False, err

    if local_tunnel_ip:
        ok, err = _try_decommission(
            ["node", "decommission", node_id_str],
            local_tunnel_ip,
            local_tunnel_ip,
            status_host=local_tunnel_ip,
            status_node_id=node_id_str,
            timeout_sec=25,
        )
        if ok:
            return True, None
        last_err = err or last_err

    return False, last_err or "Failed to start decommission"


def _decommission_status_by_id_on_peers(
    node_id: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = 30,
):
    for peer_ip in peer_tunnel_ips:
        yield get_node_decommission_status_by_id(peer_ip, node_id, timeout_sec=timeout_sec)


def _poll_decommission_status_by_id(
    node_id: str,
    peer_tunnel_ips: list[str],
) -> tuple[str | None, str | None]:
    node, err = _poll_decommission_node_by_id(node_id, peer_tunnel_ips)
    if node is None:
        return None, err
    return _membership_from_decommission_node(node), err


def _get_local_decommission_node(
    local_tunnel_ip: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = FINALIZE_PEER_STATUS_TIMEOUT_SEC,
) -> tuple[dict | None, str | None]:
    for peer_ip in peer_tunnel_ips:
        nodes, err = _fetch_decommission_status_json(peer_ip, timeout_sec=timeout_sec)
        if err is not None:
            continue
        node = _find_local_node(nodes, local_tunnel_ip)
        if node is not None:
            return node, None

    nodes, err = _fetch_decommission_status_json(local_tunnel_ip, timeout_sec=timeout_sec)
    if err is not None:
        return None, err
    node = _find_local_node(nodes, local_tunnel_ip)
    if node is None:
        return None, "local node not found in cluster status"
    return node, None


def _finalize_decommission_poll_result(
    node: dict | None,
    membership: str | None,
    status_err: str | None,
    local_state: dict,
) -> PluginOutput | None:
    """Return completed/postponed when poll has a definitive answer; None to continue."""
    if _decommission_finalize_complete(node, membership):
        if membership == "decommissioning":
            print(
                "[*] Decommission rebalance complete (replicas drained), proceeding to destroy",
                file=sys.stderr,
            )
        elif membership == "decommissioned":
            print("[*] Node already decommissioned", file=sys.stderr)
        return PluginOutput(status="completed", local_state=local_state)

    if membership == "decommissioning":
        return PluginOutput(
            status="postponed",
            error_message=status_err or "Waiting for decommission to complete (replica rebalance)",
            local_state=local_state,
        )

    return None


def _is_node_absent_from_raft(
    node_id: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = 30,
) -> bool:
    if not peer_tunnel_ips:
        return False
    for membership, status_err in _decommission_status_by_id_on_peers(
        node_id,
        peer_tunnel_ips,
        timeout_sec=timeout_sec,
    ):
        if membership is not None:
            return False
        if status_err and "not found" not in status_err.lower():
            return False
    return True


def _all_peers_report_local_node_not_found(
    local_tunnel_ip: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = FINALIZE_PEER_STATUS_TIMEOUT_SEC,
) -> bool:
    if not peer_tunnel_ips:
        return False
    for peer_ip in peer_tunnel_ips:
        membership, status_err = get_local_node_decommission_status(
            local_tunnel_ip,
            query_host=peer_ip,
            timeout_sec=timeout_sec,
        )
        if membership is not None:
            return False
        if not status_err or "not found" not in status_err.lower():
            return False
    return True


def start_decommission(
    local_tunnel_ip: str,
    peer_tunnel_ips: list[str],
    *,
    node_id: str | None = None,
) -> tuple[bool, str | None]:
    """Kick off decommission for the local node without blocking on rebalance.

    When node_id is known (captured on apply), decommission by id from peers first.
    Otherwise resolve id via peer status by tunnel IP, then fall back to `--self`.
    """
    if node_id:
        return start_decommission_by_id(peer_tunnel_ips, node_id, local_tunnel_ip)

    membership, _ = get_local_node_decommission_status(local_tunnel_ip)
    if _decommission_already_in_progress(membership):
        return True, None

    last_err: str | None = None
    for peer_ip in peer_tunnel_ips:
        if peer_ip == local_tunnel_ip:
            continue
        node_id = _get_local_node_id_via_peer(peer_ip, local_tunnel_ip)
        if not node_id:
            continue
        ok, err = _try_decommission(
            ["node", "decommission", node_id],
            peer_ip,
            local_tunnel_ip,
            status_host=peer_ip,
            status_node_id=node_id,
        )
        if ok:
            return True, None
        last_err = err
        if err and "lost quorum" in err.lower():
            return False, err

    ok, err = _try_decommission(
        ["node", "decommission", "--self"],
        local_tunnel_ip,
        local_tunnel_ip,
        timeout_sec=25,
    )
    if ok:
        return True, None
    return False, err or last_err or "Failed to start decommission"


def check_node_in_cluster(local_tunnel_ip: str) -> tuple[bool, str | None]:
    """Check if local node is part of the cluster.
    Returns (is_in_cluster, error_message)
    """
    try:
        result = subprocess.run(
            [COCKROACH_BIN, "node", "status", "--insecure", "--host", f"{local_tunnel_ip}:{COCKROACH_SQL_PORT}"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0:
            return False, f"Failed to get node status: {result.stderr}"

        # If we can get node status, we're in the cluster
        return True, None
    except Exception as e:
        return False, f"Failed to check cluster status: {str(e)}"


NODE_READY_PROPERTIES = {"cockroachdb_node_ready": "true"}
CLUSTER_INIT_PROPERTIES = {"cockroachdb_cluster_initialized": "true"}


@dataclass
class ApplyBackfillContext:
    """Inputs for apply-time node property backfills (plugin local_state + SwarmDB plan snapshot)."""

    local_state: dict
    install_hash: str
    prev_install_hash: str | None
    local_tunnel_ip: str
    local_node_id: str
    cockroach_node_props: list
    cluster_initialized: bool
    in_cluster: bool | None = None


def _node_prop_present(ctx: ApplyBackfillContext, name: str) -> bool:
    for prop in ctx.cockroach_node_props:
        if prop.get("node_id") == ctx.local_node_id and prop.get("name") == name and prop.get("value"):
            return True
    return False


def _maybe_backfill_node_ready(ctx: ApplyBackfillContext) -> dict[str, str] | None:
    """Publish node_ready when CRDB reports membership and SwarmDB lacks the flag."""
    if _node_prop_present(ctx, "cockroachdb_node_ready"):
        return None
    if ctx.in_cluster is True:
        return dict(NODE_READY_PROPERTIES)
    if not ctx.cluster_initialized:
        return None
    in_cluster = ctx.in_cluster
    if in_cluster is None:
        in_cluster, _error = check_node_in_cluster(ctx.local_tunnel_ip)
    if not in_cluster:
        return None
    return dict(NODE_READY_PROPERTIES)


def _maybe_backfill_cockroach_node_id(ctx: ApplyBackfillContext) -> dict[str, str]:
    """Backfill raft node id in local_state and node_properties (skip-path and post-start)."""
    props: dict[str, str] = {}

    has_cached_id = ctx.local_state.get("cockroach_node_id") is not None
    if has_cached_id or is_cockroach_running()[0]:
        ctx.local_state, props = _apply_cockroach_node_id_capture(
            ctx.local_state,
            ctx.install_hash,
            ctx.prev_install_hash,
            ctx.local_tunnel_ip,
            {},
        )

    node_id = ctx.local_state.get("cockroach_node_id")
    if (
        node_id is not None
        and "cockroachdb_node_id" not in props
        and not _node_prop_present(ctx, "cockroachdb_node_id")
    ):
        props["cockroachdb_node_id"] = str(node_id)

    return props


def _merge_apply_backfill_node_properties(ctx: ApplyBackfillContext) -> tuple[dict, dict[str, str]]:
    """Run all apply backfills and merge node_properties to publish."""
    merged: dict[str, str] = {}

    ready = _maybe_backfill_node_ready(ctx)
    if ready:
        merged.update(ready)

    merged.update(_maybe_backfill_cockroach_node_id(ctx))

    return ctx.local_state, merged


# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize CockroachDB: install binary."""
    try:
        # Install CockroachDB if not present
        if not is_cockroach_available():
            install_cockroachdb()

        # Ensure directories exist
        COCKROACH_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        COCKROACH_DATA_DIR.mkdir(parents=True, exist_ok=True)

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply CockroachDB configuration and start the cluster."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    cockroach_node_props = state_json.get("cockroachNodeProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])
    cluster = state_json.get("cluster", {})

    wg_overlay_exempt = build_wg_overlay_exempt_node_ids(state_json)
    if not check_all_nodes_have_wg(cluster_nodes, wg_props, wg_overlay_exempt):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all nodes',
            local_state=local_state
        )

    # Allow single-node CockroachDB cluster (suitable for dev/single-node setups).
    # Swarm clustering policy still controls desired min/max size; here we are not blocking with len(cluster_nodes) == 1.
    if len(cluster_nodes) < 1:
        return PluginOutput(
            status='postponed',
            error_message=f'CockroachDB cluster requires at least 1 node, currently have {len(cluster_nodes)}',
            local_state=local_state
        )

    # Determine if this is leader node
    leader_node_id = get_leader_node(state_json)
    is_leader = (leader_node_id == local_node_id)
    cluster_properties = state_json.get("clusterProperties", [])
    cluster_initialized = is_cluster_initialized(cluster_properties)

    # Get local tunnel IP (plan state first; wg0 fallback when WG membership dropped before CRDB swap ends)
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        local_tunnel_ip = get_local_wg_ip()
    if not local_tunnel_ip:
        return PluginOutput(
            status='error',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state
        )

    # Compute install hash to detect config changes
    install_hash = compute_install_hash(state_json, COCKROACH_VERSION)

    # Check if we need to reconfigure
    prev_install_hash = local_state.get("install_hash")
    if prev_install_hash == install_hash and local_state.get("cockroach_ready"):
        backfill_ctx = ApplyBackfillContext(
            local_state=local_state,
            install_hash=install_hash,
            prev_install_hash=prev_install_hash,
            local_tunnel_ip=local_tunnel_ip,
            local_node_id=local_node_id,
            cockroach_node_props=cockroach_node_props,
            cluster_initialized=cluster_initialized,
        )
        updated_local_state, node_properties = _merge_apply_backfill_node_properties(backfill_ctx)
        if node_properties or updated_local_state != local_state:
            return PluginOutput(
                status='completed',
                node_properties=node_properties or None,
                local_state=updated_local_state,
            )
        return PluginOutput(status='completed', local_state=updated_local_state)

    # Build join addresses (all nodes)
    join_addresses = []
    for node in cluster_nodes:
        tunnel_ip = get_node_tunnel_ip(node.get("node_id"), wg_props)
        if tunnel_ip:
            join_addresses.append(f"{tunnel_ip}:{COCKROACH_SQL_PORT}")

    if not join_addresses:
        return PluginOutput(
            status='error',
            error_message='No WireGuard addresses available for cluster nodes',
            local_state=local_state
        )

    # Create systemd service
    try:
        create_systemd_service(local_tunnel_ip, join_addresses)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to create service: {str(e)}', local_state=local_state)

    # Start CockroachDB
    try:
        result = subprocess.run(["systemctl", "enable", "cockroachdb"], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(status='error', error_message=f'Failed to enable CockroachDB: {result.stderr}', local_state=local_state)

        result = subprocess.run(["systemctl", "restart", "cockroachdb"], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(status='error', error_message=f'Failed to start CockroachDB: {result.stderr}', local_state=local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to start CockroachDB: {str(e)}', local_state=local_state)

    # Wait for CockroachDB to become ready
    cockroach_ready = wait_for_cockroach_ready(local_tunnel_ip, timeout_sec=60)

    if not cockroach_ready:
        return PluginOutput(
            status='postponed',
            error_message='CockroachDB did not become ready within timeout',
            local_state={**local_state, "install_hash": install_hash, "cockroach_ready": False}
        )

    # Update local state
    new_local_state = {
        **local_state,
        "install_hash": install_hash,
        "cockroach_ready": cockroach_ready,
        "is_leader": is_leader
    }

    # If this is the leader node and cluster is not initialized, initialize it
    if is_leader and not cluster_initialized:
        # Wait a bit for all nodes to be ready
        time.sleep(5)

        # SwarmDB may lack the flag while an existing member already runs CRDB (e.g. after drain).
        if discover_cluster_initialized_on_peers(join_addresses, local_tunnel_ip):
            backfill_ctx = ApplyBackfillContext(
                local_state=new_local_state,
                install_hash=install_hash,
                prev_install_hash=prev_install_hash,
                local_tunnel_ip=local_tunnel_ip,
                local_node_id=local_node_id,
                cockroach_node_props=cockroach_node_props,
                cluster_initialized=True,
                in_cluster=True,
            )
            new_local_state, node_properties = _merge_apply_backfill_node_properties(backfill_ctx)
            return PluginOutput(
                status='completed',
                cluster_properties=dict(CLUSTER_INIT_PROPERTIES),
                node_properties=node_properties,
                local_state=new_local_state,
            )

        # Initialize cluster once for the whole membership set
        if init_cluster(local_tunnel_ip):
            backfill_ctx = ApplyBackfillContext(
                local_state=new_local_state,
                install_hash=install_hash,
                prev_install_hash=prev_install_hash,
                local_tunnel_ip=local_tunnel_ip,
                local_node_id=local_node_id,
                cockroach_node_props=cockroach_node_props,
                cluster_initialized=True,
                in_cluster=True,
            )
            new_local_state, node_properties = _merge_apply_backfill_node_properties(backfill_ctx)
            return PluginOutput(
                status='completed',
                cluster_properties=dict(CLUSTER_INIT_PROPERTIES),
                node_properties=node_properties,
                local_state=new_local_state,
            )

        return PluginOutput(
            status='postponed',
            error_message='Failed to initialize CockroachDB cluster',
            local_state=new_local_state,
        )

    # For non-leader nodes or already initialized cluster
    # Check if node is part of cluster
    if cluster_initialized:
        in_cluster, error = check_node_in_cluster(local_tunnel_ip)
        if in_cluster:
            backfill_ctx = ApplyBackfillContext(
                local_state=new_local_state,
                install_hash=install_hash,
                prev_install_hash=prev_install_hash,
                local_tunnel_ip=local_tunnel_ip,
                local_node_id=local_node_id,
                cockroach_node_props=cockroach_node_props,
                cluster_initialized=cluster_initialized,
                in_cluster=True,
            )
            new_local_state, node_properties = _merge_apply_backfill_node_properties(backfill_ctx)
            return PluginOutput(
                status='completed',
                node_properties=node_properties,
                local_state=new_local_state,
            )
        return PluginOutput(
            status='postponed',
            error_message=f'Node not in cluster yet: {error}',
            local_state=new_local_state,
        )

    # Wait for leader to initialize cluster
    return PluginOutput(
        status='postponed',
        error_message=f'Waiting for leader node {leader_node_id} to initialize cluster',
        local_state=new_local_state
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check CockroachDB health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    # Check if CockroachDB is running
    cockroach_running, cockroach_error = is_cockroach_running()
    if not cockroach_running:
        if cockroach_error and 'Failed to' in cockroach_error:
            # Real error checking status
            return PluginOutput(status='error', error_message=cockroach_error, local_state=local_state)
        else:
            # Service not running yet
            return PluginOutput(status='postponed', error_message=cockroach_error or 'CockroachDB service is not running', local_state=local_state)

    # Check node status
    wg_props = state_json.get("wgNodeProperties", []) if isinstance(state_json, dict) else []
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)

    if local_tunnel_ip:
        in_cluster, error = check_node_in_cluster(local_tunnel_ip)
        if not in_cluster:
            if error and 'Failed to' in error:
                # Real error
                return PluginOutput(status='error', error_message=error, local_state=local_state)
            else:
                # Not in cluster yet
                return PluginOutput(status='postponed', error_message=error or 'Node not in cluster', local_state=local_state)

    return PluginOutput(status='completed', local_state=local_state)


def _query_local_decommission_membership(
    local_tunnel_ip: str,
    peer_tunnel_ips: list[str],
    *,
    timeout_sec: int = 15,
) -> tuple[str | None, str | None]:
    membership, status_err = get_local_node_decommission_status(
        local_tunnel_ip,
        timeout_sec=timeout_sec,
    )
    if membership is None and peer_tunnel_ips:
        for peer_ip in peer_tunnel_ips:
            membership, status_err = get_local_node_decommission_status(
                local_tunnel_ip,
                query_host=peer_ip,
                timeout_sec=timeout_sec,
            )
            if membership is not None:
                break
    return membership, status_err


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Gracefully remove this node from the CockroachDB cluster before destroy."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = dict(input_data.local_state or {})

    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cockroach_props = state_json.get("cockroachNodeProperties", [])
    cockroach_node_id = resolve_stored_cockroach_node_id(local_state, cockroach_props, local_node_id)

    wg_props = state_json.get("wgNodeProperties", [])
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        # A drained node is already removed from membership/WG plan state, so its
        # tunnel_ip is gone here even though wg0 and CockroachDB are still up.
        # Fall back to the live interface IP so peer-based decommission can run.
        local_tunnel_ip = get_local_wg_ip()

    cockroach_running, cockroach_error = is_cockroach_running()
    if not cockroach_running:
        print(f"[*] CockroachDB not running, skipping decommission: {cockroach_error}", file=sys.stderr)
        return PluginOutput(status='completed', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    peer_tunnel_ips = []
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if node_id == local_node_id:
            continue
        peer_ip = get_node_tunnel_ip(node_id, wg_props)
        if peer_ip:
            peer_tunnel_ips.append(peer_ip)

    peer_status_timeout = FINALIZE_PEER_STATUS_TIMEOUT_SEC

    decommission_node: dict | None = None
    membership: str | None = None
    status_err: str | None = None
    id_status_polled = False

    # Phase 1: raft id + peers — terminal states and in-progress decommission without local_tunnel_ip.
    if cockroach_node_id and peer_tunnel_ips:
        decommission_node, status_err = _poll_decommission_node_by_id(
            cockroach_node_id,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        )
        membership = _membership_from_decommission_node(decommission_node)
        id_status_polled = True
        poll_result = _finalize_decommission_poll_result(
            decommission_node, membership, status_err, local_state,
        )
        if poll_result is not None:
            return poll_result
        if membership is None and _is_node_absent_from_raft(
            cockroach_node_id,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        ):
            print(f"[*] Node already absent from raft, proceeding to destroy path", file=sys.stderr)
            return PluginOutput(status='completed', local_state=local_state)

    if not cockroach_node_id and peer_tunnel_ips and _all_peers_report_local_node_not_found(
        local_tunnel_ip or "",
        peer_tunnel_ips,
        timeout_sec=peer_status_timeout,
    ):
        return PluginOutput(
            status='postponed',
            error_message=(
                'Cached raft node id missing and local node not found by IP on peers; '
                'retrying decommission'
            ),
            local_state=local_state,
        )

    if not local_tunnel_ip:
        return PluginOutput(
            status='postponed',
            error_message='Local WireGuard tunnel IP unavailable; retrying before decommission',
            local_state=local_state,
        )

    # Phase 2: pre-start status (id path without peers, or legacy IP path).
    if cockroach_node_id:
        if not id_status_polled:
            decommission_node, status_err = _poll_decommission_node_by_id(
                cockroach_node_id,
                peer_tunnel_ips,
                timeout_sec=peer_status_timeout,
            )
            membership = _membership_from_decommission_node(decommission_node)
            poll_result = _finalize_decommission_poll_result(
                decommission_node, membership, status_err, local_state,
            )
            if poll_result is not None:
                return poll_result
    else:
        decommission_node, status_err = _get_local_decommission_node(
            local_tunnel_ip,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        )
        membership = _membership_from_decommission_node(decommission_node)
        if membership is None and status_err:
            if "lost quorum" in status_err.lower():
                return PluginOutput(
                    status='postponed',
                    error_message=f'Waiting for cluster quorum before decommission: {status_err}',
                    local_state=local_state,
                )
            if "not found" in status_err.lower():
                return PluginOutput(
                    status='postponed',
                    error_message=(
                        f'Cached raft node id missing; cannot confirm raft absence by IP: {status_err}'
                    ),
                    local_state=local_state,
                )
            return PluginOutput(
                status='postponed',
                error_message=f'Cannot read node status yet: {status_err}',
                local_state=local_state,
            )
        poll_result = _finalize_decommission_poll_result(
            decommission_node, membership, status_err, local_state,
        )
        if poll_result is not None:
            return poll_result

    if not local_state.get("decommission_started"):
        ok, decommission_err = start_decommission(
            local_tunnel_ip,
            peer_tunnel_ips,
            node_id=cockroach_node_id,
        )
        if not ok:
            if decommission_err and "lost quorum" in decommission_err.lower():
                return PluginOutput(
                    status='postponed',
                    error_message=decommission_err,
                    local_state=local_state,
                )
            return PluginOutput(
                status='error',
                error_message=decommission_err or 'Failed to start decommission',
                local_state=local_state,
            )
        local_state["decommission_started"] = True
        if cockroach_node_id:
            print(f"[*] Started cockroach node decommission {cockroach_node_id}", file=sys.stderr)
        else:
            print(f"[*] Started cockroach node decommission", file=sys.stderr)

    # Phase 3: post-start status.
    if cockroach_node_id:
        decommission_node, status_err = _poll_decommission_node_by_id(
            cockroach_node_id,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        )
        membership = _membership_from_decommission_node(decommission_node)
        if membership is None and _is_node_absent_from_raft(
            cockroach_node_id,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        ):
            print(f"[*] Node already absent from raft, proceeding to destroy path", file=sys.stderr)
            return PluginOutput(status='completed', local_state=local_state)
    else:
        decommission_node, status_err = _get_local_decommission_node(
            local_tunnel_ip,
            peer_tunnel_ips,
            timeout_sec=peer_status_timeout,
        )
        membership = _membership_from_decommission_node(decommission_node)

    poll_result = _finalize_decommission_poll_result(
        decommission_node, membership, status_err, local_state,
    )
    if poll_result is not None:
        return poll_result

    if local_state.get("decommission_started"):
        return PluginOutput(
            status='postponed',
            error_message=status_err or 'Waiting for decommission membership=decommissioned',
            local_state=local_state,
        )

    return PluginOutput(
        status='postponed',
        error_message=status_err or f'Unexpected membership state: {membership}',
        local_state=local_state,
    )


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy CockroachDB installation and clean up."""
    try:
        # Stop and disable CockroachDB
        subprocess.run(["systemctl", "stop", "cockroachdb"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "cockroachdb"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Remove systemd service file
        service_path = "/etc/systemd/system/cockroachdb.service"
        if os.path.exists(service_path):
            os.remove(service_path)
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        # Remove config and data directories
        if COCKROACH_CONFIG_DIR.exists():
            shutil.rmtree(COCKROACH_CONFIG_DIR, ignore_errors=True)
        if COCKROACH_DATA_DIR.exists():
            shutil.rmtree(COCKROACH_DATA_DIR, ignore_errors=True)

        node_properties = {
            "cockroachdb_node_ready": None,
            "cockroachdb_cluster_initialized": None,
            "cockroachdb_node_id": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy CockroachDB: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
