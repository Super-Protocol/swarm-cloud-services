#!/usr/bin/env python3
"""Unit tests for cockroachdb/main.py pure helpers."""

import io
import sys
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402


def _backfill_ctx(**overrides) -> main.ApplyBackfillContext:
    defaults = {
        "local_state": {},
        "install_hash": "hash",
        "prev_install_hash": "hash",
        "local_tunnel_ip": "10.0.0.1",
        "local_node_id": "node-a",
        "cockroach_node_props": [],
        "cluster_initialized": True,
    }
    defaults.update(overrides)
    return main.ApplyBackfillContext(**defaults)
from provision_plugin_sdk import PluginInput  # noqa: E402


class IsClusterInitializedTests(unittest.TestCase):
    def test_false_when_empty(self):
        self.assertFalse(main.is_cluster_initialized([]))

    def test_true_when_cluster_property_set(self):
        props = [{"name": "cockroachdb_cluster_initialized", "value": "true"}]
        self.assertTrue(main.is_cluster_initialized(props))

    def test_false_when_value_not_true(self):
        props = [{"name": "cockroachdb_cluster_initialized", "value": "false"}]
        self.assertFalse(main.is_cluster_initialized(props))


class DiscoverClusterInitializedOnPeersTests(unittest.TestCase):
    def test_skips_local_join_address(self):
        with mock.patch.object(main, "peer_has_running_cluster", return_value=False) as probe:
            self.assertFalse(
                main.discover_cluster_initialized_on_peers(
                    ["10.0.0.1:26257", "10.0.0.2:26257"],
                    "10.0.0.1",
                )
            )
        probe.assert_called_once_with("10.0.0.2:26257")

    def test_returns_true_when_peer_has_cluster(self):
        with mock.patch.object(main, "peer_has_running_cluster", side_effect=[False, True]):
            found = main.discover_cluster_initialized_on_peers(
                ["10.0.0.1:26257", "10.0.0.2:26257", "10.0.0.3:26257"],
                "10.0.0.1",
            )
        self.assertTrue(found)

    def test_returns_false_when_no_peer_responds(self):
        with mock.patch.object(main, "peer_has_running_cluster", return_value=False):
            found = main.discover_cluster_initialized_on_peers(
                ["10.0.0.1:26257", "10.0.0.2:26257"],
                "10.0.0.1",
            )
        self.assertFalse(found)


class PeerHasRunningClusterTests(unittest.TestCase):
    def test_true_on_zero_exit(self):
        completed = mock.Mock(returncode=0, stderr="", stdout="")
        with mock.patch.object(main.subprocess, "run", return_value=completed):
            self.assertTrue(main.peer_has_running_cluster("10.0.0.2:26257"))

    def test_false_and_logs_on_nonzero_exit(self):
        completed = mock.Mock(returncode=1, stderr="connection refused\n", stdout="")
        stderr = io.StringIO()
        with mock.patch.object(main.subprocess, "run", return_value=completed):
            with mock.patch.object(sys, "stderr", stderr):
                self.assertFalse(main.peer_has_running_cluster("10.0.0.2:26257"))
        self.assertIn("probe failed (exit 1)", stderr.getvalue())
        self.assertIn("connection refused", stderr.getvalue())


class MaybeBackfillNodeReadyTests(unittest.TestCase):
    def test_none_when_cluster_not_initialized(self):
        with mock.patch.object(main, "check_node_in_cluster") as check:
            self.assertIsNone(main._maybe_backfill_node_ready(_backfill_ctx(cluster_initialized=False)))
        check.assert_not_called()

    def test_none_when_not_in_cluster(self):
        with mock.patch.object(main, "check_node_in_cluster", return_value=(False, "not yet")):
            self.assertIsNone(main._maybe_backfill_node_ready(_backfill_ctx()))

    def test_ready_when_in_cluster(self):
        with mock.patch.object(main, "check_node_in_cluster", return_value=(True, None)):
            props = main._maybe_backfill_node_ready(_backfill_ctx())
        self.assertEqual(props, main.NODE_READY_PROPERTIES)

    def test_skips_membership_probe_when_in_cluster_passed(self):
        with mock.patch.object(main, "check_node_in_cluster") as check:
            props = main._maybe_backfill_node_ready(_backfill_ctx(in_cluster=True))
        check.assert_not_called()
        self.assertEqual(props, main.NODE_READY_PROPERTIES)

    def test_skips_when_ready_already_in_plan(self):
        props = main._maybe_backfill_node_ready(
            _backfill_ctx(
                cockroach_node_props=[
                    {"node_id": "node-a", "name": "cockroachdb_node_ready", "value": "true"},
                ],
            )
        )
        self.assertIsNone(props)


class MergeApplyBackfillNodePropertiesTests(unittest.TestCase):
    def test_delegates_to_all_backfills(self):
        with (
            mock.patch.object(
                main,
                "_maybe_backfill_node_ready",
                return_value=main.NODE_READY_PROPERTIES,
            ) as ready,
            mock.patch.object(
                main,
                "_maybe_backfill_cockroach_node_id",
                return_value={"cockroachdb_node_id": "3"},
            ) as node_id,
        ):
            state, merged = main._merge_apply_backfill_node_properties(_backfill_ctx())
        ready.assert_called_once()
        node_id.assert_called_once()
        self.assertEqual(merged, {**main.NODE_READY_PROPERTIES, "cockroachdb_node_id": "3"})

    def test_empty_when_no_backfills(self):
        with (
            mock.patch.object(main, "_maybe_backfill_node_ready", return_value=None),
            mock.patch.object(main, "_maybe_backfill_cockroach_node_id", return_value={}),
        ):
            _state, merged = main._merge_apply_backfill_node_properties(_backfill_ctx())
        self.assertEqual(merged, {})


class CheckAllNodesHaveWgTests(unittest.TestCase):
    WG = [{"node_id": "node-a", "name": "tunnel_ip", "value": "10.13.1.1"}]

    def test_requires_wg_for_all_overlay_members(self):
        nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
        self.assertFalse(main.check_all_nodes_have_wg(nodes, self.WG))

    def test_passes_when_exempt_node_lacks_wg(self):
        nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
        self.assertTrue(main.check_all_nodes_have_wg(nodes, self.WG, {"node-b"}))

    def test_passes_when_all_have_wg(self):
        nodes = [{"node_id": "node-a"}]
        self.assertTrue(main.check_all_nodes_have_wg(nodes, self.WG))


class BuildWgOverlayExemptNodeIdsTests(unittest.TestCase):
    def test_collects_exempt_ids_from_plan(self):
        state = {"wgOverlayExemptNodeIds": ["node-a", "node-b"]}
        self.assertEqual(main.build_wg_overlay_exempt_node_ids(state), {"node-a", "node-b"})


class ShouldRefreshCockroachNodeIdTests(unittest.TestCase):
    def test_true_when_install_hash_changed(self):
        self.assertTrue(
            main.should_refresh_cockroach_node_id("old-hash", "new-hash", "2", "2")
        )

    def test_false_when_same_hash_and_same_id(self):
        self.assertFalse(
            main.should_refresh_cockroach_node_id("same-hash", "same-hash", "2", "2")
        )

    def test_true_when_stored_id_missing(self):
        self.assertTrue(
            main.should_refresh_cockroach_node_id("same-hash", "same-hash", None, "2")
        )

    def test_true_when_live_id_differs(self):
        self.assertTrue(
            main.should_refresh_cockroach_node_id("same-hash", "same-hash", "2", "3")
        )

    def test_false_when_live_id_missing(self):
        self.assertFalse(
            main.should_refresh_cockroach_node_id("same-hash", "same-hash", None, None)
        )


class ResolveStoredCockroachNodeIdTests(unittest.TestCase):
    def test_prefers_local_state(self):
        props = [
            {
                "node_id": "node-a",
                "name": "cockroachdb_node_id",
                "value": "9",
            }
        ]
        self.assertEqual(
            main.resolve_stored_cockroach_node_id(
                {"cockroach_node_id": "2"},
                props,
                "node-a",
            ),
            "2",
        )

    def test_falls_back_to_cluster_node_property(self):
        props = [
            {
                "node_id": "node-a",
                "name": "cockroachdb_node_id",
                "value": "2",
            }
        ]
        self.assertEqual(
            main.resolve_stored_cockroach_node_id({}, props, "node-a"),
            "2",
        )


class FindNodeInDecommissionStatusTests(unittest.TestCase):
    NODES = [
        {"id": 1, "address": "10.13.1.1:26257", "membership": "active"},
        {"id": 2, "address": None, "membership": "active"},
    ]

    def test_finds_node_by_id_with_null_address(self):
        node = main.find_node_in_decommission_status(self.NODES, "2")
        self.assertIsNotNone(node)
        self.assertEqual(node["id"], 2)
        self.assertIsNone(node["address"])

    def test_returns_none_for_missing_id(self):
        self.assertIsNone(main.find_node_in_decommission_status(self.NODES, "9"))


class ReadLocalCockroachNodeIdTests(unittest.TestCase):
    def test_parses_crdb_internal_node_id_csv(self):
        result = mock.Mock(returncode=0, stdout="crdb_internal.node_id\n3\n")
        with mock.patch.object(main, "_run_cockroach", return_value=result):
            self.assertEqual(main.read_local_cockroach_node_id("10.13.1.1"), "3")


class ApplyCockroachNodeIdCaptureTests(unittest.TestCase):
    def test_capture_writes_local_state_and_property(self):
        with mock.patch.object(main, "read_local_cockroach_node_id", return_value="2"):
            local_state, props = main._apply_cockroach_node_id_capture(
                {},
                "hash-a",
                None,
                "10.13.1.1",
                {"cockroachdb_node_ready": "true"},
            )
        self.assertEqual(local_state["cockroach_node_id"], "2")
        self.assertEqual(props["cockroachdb_node_id"], "2")
        self.assertEqual(props["cockroachdb_node_ready"], "true")

    def test_skips_capture_when_unchanged(self):
        with mock.patch.object(main, "read_local_cockroach_node_id", return_value="2"):
            local_state, props = main._apply_cockroach_node_id_capture(
                {"cockroach_node_id": "2"},
                "hash-a",
                "hash-a",
                "10.13.1.1",
                {"cockroachdb_node_ready": "true"},
            )
        self.assertEqual(local_state["cockroach_node_id"], "2")
        self.assertNotIn("cockroachdb_node_id", props)


class StartDecommissionTests(unittest.TestCase):
    def test_delegates_to_by_id_when_node_id_known(self):
        with mock.patch.object(main, "start_decommission_by_id", return_value=(True, None)) as by_id_mock:
            ok, err = main.start_decommission("10.13.1.1", ["10.13.1.2"], node_id="2")
        self.assertTrue(ok)
        self.assertIsNone(err)
        by_id_mock.assert_called_once_with(["10.13.1.2"], "2", "10.13.1.1")


class StartDecommissionByIdTests(unittest.TestCase):
    def test_peer_decommission_uses_node_id(self):
        with mock.patch.object(main, "_try_decommission", return_value=(True, None)) as try_mock:
            ok, err = main.start_decommission_by_id(["10.13.1.2"], "2", "10.13.1.1")
        self.assertTrue(ok)
        self.assertIsNone(err)
        try_mock.assert_called_once_with(
            ["node", "decommission", "2"],
            "10.13.1.2",
            "10.13.1.1",
            status_host="10.13.1.2",
            status_node_id="2",
        )

    def test_falls_back_to_local_when_peers_fail(self):
        with mock.patch.object(
            main,
            "_try_decommission",
            side_effect=[(False, "peer fail"), (True, None)],
        ) as try_mock:
            ok, err = main.start_decommission_by_id(["10.13.1.2"], "2", "10.13.1.1")
        self.assertTrue(ok)
        self.assertEqual(try_mock.call_count, 2)
        self.assertEqual(try_mock.call_args_list[1].args[1], "10.13.1.1")


class CaptureOnSteadyApplyTests(unittest.TestCase):
    def test_backfills_missing_id_on_steady_apply(self):
        ctx = _backfill_ctx(
            local_state={"cockroach_ready": True, "install_hash": "abc"},
            install_hash="abc",
            prev_install_hash="abc",
            local_tunnel_ip="10.13.1.1",
        )
        with (
            mock.patch.object(main, "is_cockroach_running", return_value=(True, None)),
            mock.patch.object(main, "read_local_cockroach_node_id", return_value="3"),
        ):
            props = main._maybe_backfill_cockroach_node_id(ctx)
        self.assertEqual(ctx.local_state["cockroach_node_id"], "3")
        self.assertEqual(props["cockroachdb_node_id"], "3")

    def test_syncs_prop_when_id_cached_locally_but_missing_in_plan(self):
        ctx = _backfill_ctx(
            local_state={"cockroach_node_id": "5"},
            install_hash="abc",
            prev_install_hash="abc",
            local_tunnel_ip="10.13.1.2",
            local_node_id="node-b",
            cockroach_node_props=[{"node_id": "node-b", "name": "cockroachdb_node_ready", "value": "true"}],
        )
        props = main._maybe_backfill_cockroach_node_id(ctx)
        self.assertEqual(props["cockroachdb_node_id"], "5")

    def test_no_props_when_id_already_in_plan(self):
        ctx = _backfill_ctx(
            local_state={"cockroach_node_id": "2"},
            install_hash="abc",
            prev_install_hash="abc",
            local_tunnel_ip="10.13.1.1",
            cockroach_node_props=[{"node_id": "node-a", "name": "cockroachdb_node_id", "value": "2"}],
        )
        props = main._maybe_backfill_cockroach_node_id(ctx)
        self.assertEqual(ctx.local_state["cockroach_node_id"], "2")
        self.assertEqual(props, {})


class DecommissionCmdArgsTests(unittest.TestCase):
    def test_injects_wait_none(self):
        self.assertEqual(
            main._decommission_cmd_args(["node", "decommission", "3"]),
            ["node", "decommission", "--wait=none", "3"],
        )

    def test_replaces_other_wait_flag(self):
        self.assertEqual(
            main._decommission_cmd_args(["node", "decommission", "--wait=all", "3"]),
            ["node", "decommission", "--wait=none", "3"],
        )

    def test_idempotent_when_wait_none_present(self):
        self.assertEqual(
            main._decommission_cmd_args(["node", "decommission", "--wait=none", "3"]),
            ["node", "decommission", "--wait=none", "3"],
        )


class DecommissionRebalanceCompleteTests(unittest.TestCase):
    def test_decommissioned_membership(self):
        self.assertTrue(
            main._is_decommission_rebalance_complete({"membership": "decommissioned"}),
        )

    def test_decommissioning_with_zero_gossiped_replicas(self):
        self.assertTrue(
            main._is_decommission_rebalance_complete(
                {"membership": "decommissioning", "gossiped_replicas": 0},
            ),
        )

    def test_decommissioning_with_remaining_replicas(self):
        self.assertFalse(
            main._is_decommission_rebalance_complete(
                {"membership": "decommissioning", "gossiped_replicas": 12},
            ),
        )

    def test_decommissioning_with_zero_blocking_ranges_and_ready(self):
        self.assertTrue(
            main._is_decommission_rebalance_complete(
                {
                    "membership": "decommissioning",
                    "blocking_ranges": 0,
                    "readiness": "ready",
                },
            ),
        )


class FinalizeOrphanTests(unittest.TestCase):
    def _finalize_input(self, **overrides):
        base = {
            "local_node_id": "node-leaving",
            "state": {
                "clusterNodes": [
                    {"node_id": "node-leaving"},
                    {"node_id": "node-peer"},
                ],
                "wgNodeProperties": [
                    {"node_id": "node-peer", "name": "tunnel_ip", "value": "10.13.1.2"},
                ],
                "cockroachNodeProperties": [],
            },
            "local_state": {"cockroach_node_id": "2"},
        }
        base.update(overrides)
        return PluginInput(**base)

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    @mock.patch.object(main, "get_local_wg_ip", return_value="10.13.1.169")
    def test_orphan_completed_when_id_absent_from_raft(self, *_mocks):
        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return None

        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(main, "_poll_decommission_node_by_id", return_value=(None, "node id not found in cluster status")),
            mock.patch.object(main, "_is_node_absent_from_raft", return_value=True),
        ):
            result = main.handle_finalize(self._finalize_input())
        self.assertEqual(result.status, "completed")

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    def test_unknown_id_postponed_when_peer_status_has_no_ip_match(self, *_mocks):
        local_ip = "10.13.1.169"
        peer_nodes = [
            {"id": "1", "address": "10.13.1.2:26257", "membership": "active"},
            {"id": "3", "address": None, "sql_address": None, "membership": "active", "is_live": False},
        ]

        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return local_ip

        def fetch_status(_host_ip, *, timeout_sec=30):
            return peer_nodes, None

        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(main, "_fetch_decommission_status_json", side_effect=fetch_status),
            mock.patch.object(main, "get_local_wg_ip", return_value=local_ip),
        ):
            result = main.handle_finalize(self._finalize_input(local_state={}))
        self.assertEqual(result.status, "postponed")
        self.assertIn("Cached raft node id missing", result.error_message or "")

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    def test_unknown_id_postponed_on_legacy_ip_path_not_found(self, *_mocks):
        local_ip = "10.13.1.169"

        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return local_ip

        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(main, "get_local_wg_ip", return_value=local_ip),
            mock.patch.object(
                main,
                "_get_local_decommission_node",
                return_value=(None, "local node not found in cluster status"),
            ),
        ):
            result = main.handle_finalize(self._finalize_input(local_state={}))
        self.assertEqual(result.status, "postponed")
        self.assertIn("cannot confirm raft absence by ip", (result.error_message or "").lower())

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    def test_finalize_peer_by_id_starts_decommission(self, *_mocks):
        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return "10.13.1.169"

        poll_mock = mock.Mock(side_effect=[
            (None, "node id not found in cluster status"),
            ({"membership": "decommissioning", "gossiped_replicas": 59}, None),
        ])
        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(main, "_poll_decommission_node_by_id", poll_mock),
            mock.patch.object(main, "_is_node_absent_from_raft", return_value=False),
            mock.patch.object(main, "start_decommission", return_value=(True, None)) as start_mock,
        ):
            result = main.handle_finalize(self._finalize_input())
        start_mock.assert_called_once_with("10.13.1.169", ["10.13.1.2"], node_id="2")
        self.assertEqual(result.status, "postponed")
        poll_mock.assert_called_with(
            "2",
            ["10.13.1.2"],
            timeout_sec=main.FINALIZE_PEER_STATUS_TIMEOUT_SEC,
        )

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    def test_finalize_rebalance_complete_while_decommissioning(self, *_mocks):
        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return "10.13.1.169"

        poll_mock = mock.Mock(side_effect=[
            (None, "node id not found in cluster status"),
            ({"membership": "decommissioning", "gossiped_replicas": 0, "readiness": "ready"}, None),
        ])
        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(main, "_poll_decommission_node_by_id", poll_mock),
            mock.patch.object(main, "_is_node_absent_from_raft", return_value=False),
            mock.patch.object(main, "start_decommission", return_value=(True, None)) as start_mock,
        ):
            result = main.handle_finalize(self._finalize_input())
        start_mock.assert_called_once()
        self.assertEqual(result.status, "completed")

    @mock.patch.object(main, "is_cockroach_running", return_value=(True, None))
    def test_finalize_rebalance_complete_before_start(self, *_mocks):
        def tunnel_ip_side_effect(node_id, _wg):
            if node_id == "node-peer":
                return "10.13.1.2"
            return "10.13.1.169"

        with (
            mock.patch.object(main, "get_node_tunnel_ip", side_effect=tunnel_ip_side_effect),
            mock.patch.object(
                main,
                "_poll_decommission_node_by_id",
                return_value=(
                    {"membership": "decommissioning", "gossiped_replicas": 0},
                    None,
                ),
            ),
            mock.patch.object(main, "start_decommission") as start_mock,
        ):
            result = main.handle_finalize(self._finalize_input())
        start_mock.assert_not_called()
        self.assertEqual(result.status, "completed")


class DestroyWipeTests(unittest.TestCase):
    @mock.patch("main.subprocess.run")
    @mock.patch("main.shutil.rmtree")
    @mock.patch("main.os.path.exists", return_value=False)
    def test_destroy_clears_cached_node_id(self, *_mocks):
        result = main.handle_destroy(PluginInput(local_state={"cockroach_node_id": "2", "decommission_started": True}))
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.local_state, {})
        self.assertIsNone(result.node_properties["cockroachdb_node_id"])


if __name__ == "__main__":
    unittest.main()
