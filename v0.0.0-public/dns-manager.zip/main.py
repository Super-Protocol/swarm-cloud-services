#!/usr/bin/env python3

from __future__ import annotations

import hashlib
import subprocess
import sys
from typing import Optional

import requests

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

plugin = ProvisionPlugin()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def log(msg: str) -> None:
    print(f"[dns-manager] {msg}", file=sys.stderr)


def get_swarm_secret(state: dict, secret_id: str) -> str | None:
    swarm_secrets = state.get("swarmSecrets", [])
    if not isinstance(swarm_secrets, list):
        return None
    for secret in swarm_secrets:
        if isinstance(secret, dict) and secret.get("id") == secret_id:
            value = secret.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def resolve_global_id(state: dict) -> str | None:
    global_id = state.get("globalId")
    if isinstance(global_id, str) and global_id.strip():
        return global_id.strip()
    return None


def resolve_dynamic_gateway_hostname(state: dict) -> str | None:
    global_id = resolve_global_id(state)
    base_domain = get_swarm_secret(state, "base_domain")
    if global_id and base_domain:
        return f"gw.dyn.{global_id}.{base_domain.rstrip('.')}"
    return None


def resolve_static_gateway_hostname(state: dict) -> str | None:
    custom = get_swarm_secret(state, "gateway_hostname")
    if custom:
        return custom.rstrip(".")
    return None


def resolve_delegation_gateway_hostname(state: dict) -> str | None:
    """CNAME target for users: static gateway when configured, else dynamic."""
    static = resolve_static_gateway_hostname(state)
    if static:
        return static
    return resolve_dynamic_gateway_hostname(state)


def node_id_to_ns_name(node_id: str) -> str:
    """Convert node_id to DNS-compatible name using MD5 hash in base36 (mirrors knot logic)."""
    md5_hash = hashlib.md5(node_id.encode()).hexdigest()
    hash_int = int(md5_hash, 16)
    base36_chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    if hash_int == 0:
        return "0"
    base36 = []
    while hash_int:
        hash_int, remainder = divmod(hash_int, 36)
        base36.append(base36_chars[remainder])
    return "".join(reversed(base36))


def get_knot_leader(state: dict) -> Optional[dict]:
    """Return the ready knot leader node entry, or None."""
    for svc in state.get("knotServices", []):
        if svc.get("is_leader") and svc.get("ready") == "true":
            return svc
    return None


def get_knot_dns_server(knot_leader: dict) -> str:
    """Prefer tap/external IP for DNS queries and updates (reachable from gateway host)."""
    external_ip = knot_leader.get("external_ip")
    if isinstance(external_ip, str) and external_ip.strip():
        return external_ip.strip()
    return knot_leader["ip"]


def knot_update_owner(hostname: str, zone_name: str) -> str:
    """Build FQDN owner for Knot RFC2136 updates.

    Knot rejects BIND nsupdate when the owner is zone-relative (e.g. ``gw.`` inside
    ``dyn.{global_id}.{base_domain}``) with NOTZONE / "name does not belong to the zone".
    Use the fully qualified owner name instead (e.g. ``gw.dyn.example.com.``).
    """
    zone = zone_name.rstrip(".")
    owner = hostname.rstrip(".")
    if owner == zone or owner.endswith(f".{zone}"):
        fqdn = owner
    else:
        fqdn = f"{owner}.{zone}"
    return f"{fqdn}."


def get_knot_tsig_key(state: dict) -> Optional[tuple[str, str]]:
    """Return (tsig_key_name, tsig_key_secret) from knotClusterProperties."""
    name = secret = None
    for prop in state.get("knotClusterProperties", []):
        if prop.get("name") == "knot_tsig_key_name":
            name = prop.get("value")
        elif prop.get("name") == "knot_tsig_key_secret":
            secret = prop.get("value")
    if name and secret:
        return name, secret
    return None


def any_ready(nodes: list) -> bool:
    return any(n.get("ready") == "true" for n in nodes)


# ---------------------------------------------------------------------------
# PowerDNS API helpers
# ---------------------------------------------------------------------------

def pdns_get_rrsets(api_url: str, api_key: str, zone: str) -> Optional[list]:
    zone_id = zone.rstrip(".") + "."
    log(f"PowerDNS: fetching rrsets for zone {zone_id}")
    try:
        resp = requests.get(
            f"{api_url}/api/v1/servers/localhost/zones/{zone_id}",
            headers={"X-API-Key": api_key},
            timeout=10,
        )
        if resp.status_code != 200:
            log(f"PowerDNS GET zone {zone} failed: HTTP {resp.status_code}: {resp.text}")
            return None
        rrsets = resp.json().get("rrsets", [])
        log(f"PowerDNS: got {len(rrsets)} rrsets from zone {zone_id}")
        return rrsets
    except requests.exceptions.RequestException as e:
        log(f"PowerDNS connection error (GET {zone_id}): {e}")
        return None


def pdns_patch_zone(api_url: str, api_key: str, zone: str, rrsets: list) -> bool:
    zone_id = zone.rstrip(".") + "."
    log(f"PowerDNS: patching zone {zone_id} with {len(rrsets)} rrset change(s)")
    for r in rrsets:
        log(f"  {r.get('changetype')} {r.get('type')} {r.get('name')} "
            f"{[rec.get('content') for rec in r.get('records', [])] or ''}")
    try:
        resp = requests.patch(
            f"{api_url}/api/v1/servers/localhost/zones/{zone_id}",
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            json={"rrsets": rrsets},
            timeout=10,
        )
        if resp.status_code not in (200, 204):
            log(f"PowerDNS PATCH zone {zone} failed: HTTP {resp.status_code}: {resp.text}")
            return False
        log(f"PowerDNS: zone {zone_id} patched successfully")
        return True
    except requests.exceptions.RequestException as e:
        log(f"PowerDNS connection error (PATCH {zone_id}): {e}")
        return False


# ---------------------------------------------------------------------------
# nsupdate helper
# ---------------------------------------------------------------------------

def query_dns_records(knot_server: str, hostname: str, record_type: str) -> list[str]:
    """Query current DNS records from Knot via dig. Returns sorted list of record values."""
    try:
        result = subprocess.run(
            ["dig", f"@{knot_server}", hostname, record_type, "+short", "+time=2", "+tries=1"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []
        return sorted(line.strip().rstrip(".") for line in result.stdout.splitlines() if line.strip())
    except Exception:
        return []


def send_dns_replace_records(
    knot_server: str,
    zone_name: str,
    hostname: str,
    delete_types: list[str],
    record_type: str,
    records: list[str],
    tsig_key_name: str,
    tsig_key_secret: str,
    ttl: int = 300,
) -> bool:
    """Delete prior record types, then add records of record_type."""
    owner = knot_update_owner(hostname, zone_name)
    log(
        f"nsupdate: replace {owner} with {record_type} -> {records} "
        f"(delete {delete_types}, zone={zone_name}., server={knot_server})"
    )
    try:
        script = (
            f"server {knot_server}\n"
            f"key hmac-sha256:{tsig_key_name} {tsig_key_secret}\n"
            f"zone {zone_name}.\n"
        )
        for delete_type in delete_types:
            script += f"update delete {owner} {delete_type}\n"
        for record in records:
            script += f"update add {owner} {ttl} {record_type} {record}\n"
        script += "send\n"

        safe_script = script.replace(tsig_key_secret, "***")
        log(f"nsupdate script:\n{safe_script.rstrip()}")

        result = subprocess.run(
            ["nsupdate"],
            input=script,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            log(f"nsupdate failed for {owner} (rc={result.returncode})")
            if result.stderr:
                log(f"nsupdate stderr: {result.stderr.strip()}")
            if result.stdout:
                log(f"nsupdate stdout: {result.stdout.strip()}")
            return False
        log(f"nsupdate OK: {owner} {record_type} -> {records}")
        return True
    except subprocess.TimeoutExpired:
        log(f"nsupdate timeout for {owner}")
        return False
    except Exception as e:
        log(f"nsupdate unexpected error for {owner}: {e}")
        return False


def send_dns_update(
    knot_server: str,
    zone_name: str,
    hostname: str,
    record_type: str,
    records: list[str],
    tsig_key_name: str,
    tsig_key_secret: str,
    ttl: int = 300,
) -> bool:
    owner = knot_update_owner(hostname, zone_name)
    log(f"nsupdate: {owner} {record_type} -> {records} (zone={zone_name}., server={knot_server})")
    try:
        script = (
            f"server {knot_server}\n"
            f"key hmac-sha256:{tsig_key_name} {tsig_key_secret}\n"
            f"zone {zone_name}.\n"
            f"update delete {owner} {record_type}\n"
        )
        for record in records:
            script += f"update add {owner} {ttl} {record_type} {record}\n"
        script += "send\n"

        # Log script without secret
        safe_script = script.replace(tsig_key_secret, "***")
        log(f"nsupdate script:\n{safe_script.rstrip()}")

        result = subprocess.run(
            ["nsupdate"],
            input=script,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            log(f"nsupdate failed for {owner} (rc={result.returncode})")
            if result.stderr:
                log(f"nsupdate stderr: {result.stderr.strip()}")
            if result.stdout:
                log(f"nsupdate stdout: {result.stdout.strip()}")
            return False
        log(f"nsupdate OK: {owner} {record_type} -> {records}")
        return True
    except subprocess.TimeoutExpired:
        log(f"nsupdate timeout for {owner}")
        return False
    except Exception as e:
        log(f"nsupdate unexpected error for {owner}: {e}")
        return False


# ---------------------------------------------------------------------------
# Sync operations
# ---------------------------------------------------------------------------

def uses_custom_gateway_dns(state: dict) -> bool:
    """Custom gateway + global_id: wildcard CNAME in PowerDNS, A records on Knot."""
    return bool(resolve_static_gateway_hostname(state) and resolve_global_id(state))


def get_openresty_ready_ips(state: dict) -> list[str]:
    return sorted({
        svc["external_ip"]
        for svc in state.get("openrestyServices", [])
        if svc.get("ready") == "true" and svc.get("external_ip")
    })


def is_under_cluster_zone(hostname: str, global_id: str, base_domain: str) -> bool:
    """True for labels under {global_id}.{base_domain}, excluding the zone apex."""
    cluster_zone = f"{global_id.strip()}.{base_domain.strip().rstrip('.')}"
    normalized = hostname.rstrip(".")
    if normalized == cluster_zone:
        return False
    return normalized.endswith(f".{cluster_zone}")


def _powerdns_delete_delegation_glue_patch(
    rrsets: list,
    delegated_zone: str,
    log_prefix: str,
) -> list[dict]:
    """Build DELETE patches for NS at zone apex and glue A records under delegated_zone."""
    delegated_zone_fqdn = f"{delegated_zone}."
    patch: list[dict] = []

    ns_rrset = next(
        (r for r in rrsets if r.get("name") == delegated_zone_fqdn and r.get("type") == "NS"),
        None,
    )
    if ns_rrset:
        patch.append({
            "name": delegated_zone_fqdn,
            "type": "NS",
            "changetype": "DELETE",
        })
        log(f"{log_prefix}: will remove NS at {delegated_zone_fqdn}")

    for rrset in rrsets:
        if rrset.get("type") != "A":
            continue
        if not rrset["name"].endswith(f".{delegated_zone}."):
            continue
        patch.append({
            "name": rrset["name"],
            "type": "A",
            "changetype": "DELETE",
        })
        log(f"{log_prefix}: will remove glue A {rrset['name']}")

    return patch


def sync_cluster_wildcard_gateway_in_powerdns(
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
    gateway_hostname: str,
) -> bool:
    """Set *.{global_id}.{base_domain} CNAME to gateway_hostname; remove knot NS/glue."""
    cluster_zone = f"{global_id}.{base_domain.rstrip('.')}"
    dyn_zone = f"dyn.{cluster_zone}"
    wildcard_fqdn = f"*.{cluster_zone}."
    cname_target_fqdn = gateway_hostname.rstrip(".") + "."

    log(
        "sync_wildcard_gateway: "
        f"want {wildcard_fqdn} CNAME -> {cname_target_fqdn}; "
        f"clear delegation glue for {cluster_zone} and {dyn_zone}"
    )

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    patch: list[dict] = []
    patch.extend(_powerdns_delete_delegation_glue_patch(rrsets, cluster_zone, "sync_wildcard_gateway"))
    patch.extend(_powerdns_delete_delegation_glue_patch(rrsets, dyn_zone, "sync_wildcard_gateway"))

    wildcard_correct = any(
        rrset.get("name") == wildcard_fqdn
        and rrset.get("type") == "CNAME"
        and any(r.get("content") == cname_target_fqdn for r in rrset.get("records", []))
        for rrset in rrsets
    )

    if not wildcard_correct:
        for rrset in rrsets:
            if rrset.get("name") == wildcard_fqdn and rrset.get("type") in ("A", "CNAME"):
                patch.append({
                    "name": rrset["name"],
                    "type": rrset["type"],
                    "changetype": "DELETE",
                })
        patch.append({
            "name": wildcard_fqdn,
            "type": "CNAME",
            "ttl": 300,
            "changetype": "REPLACE",
            "records": [{"content": cname_target_fqdn, "disabled": False}],
        })
    elif not patch:
        log("sync_wildcard_gateway: already correct, no changes needed")
        return True

    return pdns_patch_zone(api_url, api_key, base_domain, patch)


def sync_knot_delegation_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    base_domain: str,
    delegated_zone: str,
    log_prefix: str,
) -> bool:
    """Actualize NS and glue A records for delegated_zone in PowerDNS base_domain zone."""
    delegated_zone_fqdn = f"{delegated_zone}."

    log(f"{log_prefix}: delegated zone={delegated_zone_fqdn}")

    desired: dict[str, str] = {}
    for svc in state.get("knotServices", []):
        if svc.get("ready") == "true" and svc.get("external_ip"):
            ns_name = node_id_to_ns_name(svc["node_id"])
            ns_fqdn = f"{ns_name}.{delegated_zone}."
            desired[ns_fqdn] = svc["external_ip"]
            log(f"{log_prefix}: desired NS {ns_fqdn} -> {svc['external_ip']} (node={svc['node_id']})")

    if not desired:
        log(f"{log_prefix}: no ready knot nodes, skipping")
        return True

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    ns_rrset = next(
        (r for r in rrsets if r.get("name") == delegated_zone_fqdn and r.get("type") == "NS"),
        None,
    )
    current_ns_fqdns: set[str] = {
        r["content"] for r in (ns_rrset or {}).get("records", [])
    }
    log(f"{log_prefix}: current NS records: {sorted(current_ns_fqdns) or '(none)'}")

    current_a: dict[str, str] = {}
    for rrset in rrsets:
        if rrset.get("type") == "A" and rrset["name"].endswith(f".{delegated_zone}."):
            for rec in rrset.get("records", []):
                current_a[rrset["name"]] = rec["content"]
    log(f"{log_prefix}: current glue A records: {current_a or '(none)'}")

    desired_ns_fqdns = set(desired.keys())
    stale_ns_fqdns = current_ns_fqdns - desired_ns_fqdns
    new_ns_fqdns = desired_ns_fqdns - current_ns_fqdns
    if stale_ns_fqdns:
        log(f"{log_prefix}: stale NS to remove: {sorted(stale_ns_fqdns)}")
    if new_ns_fqdns:
        log(f"{log_prefix}: new NS to add: {sorted(new_ns_fqdns)}")

    if (
        current_ns_fqdns == desired_ns_fqdns
        and all(current_a.get(ns) == ip for ns, ip in desired.items())
    ):
        log(f"{log_prefix}: already up to date, no changes needed")
        return True

    patch = [{
        "name": delegated_zone_fqdn,
        "type": "NS",
        "ttl": 300,
        "changetype": "REPLACE",
        "records": [{"content": ns, "disabled": False} for ns in sorted(desired_ns_fqdns)],
    }]

    for stale_ns in stale_ns_fqdns:
        patch.append({"name": stale_ns, "type": "A", "changetype": "DELETE"})

    for ns_fqdn, ip in desired.items():
        patch.append({
            "name": ns_fqdn,
            "type": "A",
            "ttl": 300,
            "changetype": "REPLACE",
            "records": [{"content": ip, "disabled": False}],
        })

    log(f"{log_prefix}: applying patch ({len(desired)} nodes, {len(stale_ns_fqdns)} stale removed)")
    return pdns_patch_zone(api_url, api_key, base_domain, patch)


def sync_knot_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
) -> bool:
    """Actualize NS and glue A records for {global_id}.{base_domain} in PowerDNS."""
    return sync_knot_delegation_glue_in_powerdns(
        state,
        api_url,
        api_key,
        base_domain,
        f"{global_id}.{base_domain}",
        "sync_knot_glue",
    )


def sync_dyn_knot_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
) -> bool:
    """Delegate dyn.{global_id}.{base_domain} to knot (required for public gw.dyn resolution)."""
    return sync_knot_delegation_glue_in_powerdns(
        state,
        api_url,
        api_key,
        base_domain,
        f"dyn.{global_id}.{base_domain}",
        "sync_dyn_glue",
    )


def sync_domain_cname(
    api_url: str,
    api_key: str,
    domain_name: str,
    base_domain: str,
    cname_target: str,
    domain_label: str,
) -> bool:
    """Ensure <domain_name> CNAME -> cname_target in PowerDNS."""
    log(f"sync_domain_cname[{domain_label}]: domain={domain_name}, base_domain={base_domain}")

    normalized_domain = domain_name.rstrip(".")
    normalized_base_domain = base_domain.rstrip(".")

    if normalized_domain == normalized_base_domain:
        log(
            f"sync_domain_cname[{domain_label}]: domain equals base_domain; "
            "skipping apex CNAME because the base zone apex already has SOA/NS, "
            "and Knot is authoritative only for delegated zones under base_domain"
        )
        return True

    if not normalized_domain.endswith(f".{normalized_base_domain}"):
        log(f"sync_domain_cname[{domain_label}]: {domain_name} is not under {base_domain}, skipping")
        return True

    cname_target_fqdn = cname_target.rstrip(".") + "."
    domain_fqdn = normalized_domain + "."
    log(f"sync_domain_cname[{domain_label}]: want {domain_fqdn} CNAME -> {cname_target_fqdn}")

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    # Already correct?
    for rrset in rrsets:
        if rrset.get("name") == domain_fqdn and rrset.get("type") == "CNAME":
            if any(r.get("content") == cname_target_fqdn for r in rrset.get("records", [])):
                log(f"sync_domain_cname[{domain_label}]: already correct, no changes needed")
                return True

    patch = [
        {"name": rrset["name"], "type": rrset["type"], "changetype": "DELETE"}
        for rrset in rrsets
        if rrset.get("name") == domain_fqdn and rrset.get("type") in ("A", "CNAME")
    ]
    if patch:
        log(f"sync_domain_cname[{domain_label}]: removing {len(patch)} conflicting record(s) for {domain_fqdn}")

    patch.append({
        "name": domain_fqdn,
        "type": "CNAME",
        "ttl": 300,
        "changetype": "REPLACE",
        "records": [{"content": cname_target_fqdn, "disabled": False}],
    })

    return pdns_patch_zone(api_url, api_key, base_domain, patch)


def sync_gw_dyn_records(
    state: dict,
    knot_server: str,
    tsig_key_name: str,
    tsig_key_secret: str,
    global_id: str,
    base_domain: str,
) -> bool:
    """Set A records for gw.dyn.{global_id}.{base_domain} from ready openresty nodes."""
    ready_ips = get_openresty_ready_ips(state)

    if not ready_ips:
        openresty_nodes = state.get("openrestyServices", [])
        log(
            "sync_gw_dyn: no ready openresty nodes with external_ip, skipping "
            f"(nodes={len(openresty_nodes)}, "
            f"ready={[n.get('node_id') for n in openresty_nodes if n.get('ready') == 'true']}, "
            f"ips={[n.get('external_ip') for n in openresty_nodes if n.get('ready') == 'true']})"
        )
        return True

    dyn_zone = f"dyn.{global_id}.{base_domain}"
    gw_hostname = f"gw.{dyn_zone}"
    gw_owner = "gw"
    log(f"sync_gw_dyn: {gw_hostname} A -> {ready_ips}")

    current = query_dns_records(knot_server, gw_hostname, "A")
    if current == ready_ips:
        log(f"sync_gw_dyn: already correct ({current}), skipping")
        return True

    return send_dns_update(
        knot_server=knot_server,
        zone_name=dyn_zone,
        hostname=gw_owner,
        record_type="A",
        records=ready_ips,
        tsig_key_name=tsig_key_name,
        tsig_key_secret=tsig_key_secret,
    )


def sync_hostname_a_records(
    knot_server: str,
    tsig_key_name: str,
    tsig_key_secret: str,
    hostname: str,
    global_id: str,
    base_domain: str,
    ips: list[str],
) -> bool:
    """Set A records for an internal hostname; remove any stale CNAME."""
    zone = f"{global_id}.{base_domain}"
    log(f"sync_a: {hostname} A -> {ips}")

    current_a = query_dns_records(knot_server, hostname, "A")
    current_cname = query_dns_records(knot_server, hostname, "CNAME")
    if current_a == ips and not current_cname:
        log(f"sync_a: {hostname} already correct, skipping")
        return True

    delete_types = ["A"]
    if current_cname:
        delete_types.append("CNAME")

    return send_dns_replace_records(
        knot_server=knot_server,
        zone_name=zone,
        hostname=hostname,
        delete_types=delete_types,
        record_type="A",
        records=ips,
        tsig_key_name=tsig_key_name,
        tsig_key_secret=tsig_key_secret,
    )


def sync_cname(
    knot_server: str,
    tsig_key_name: str,
    tsig_key_secret: str,
    hostname: str,
    global_id: str,
    base_domain: str,
    cname_target: str,
) -> bool:
    """Set CNAME: hostname -> cname_target."""
    zone = f"{global_id}.{base_domain}"
    gw_domain = cname_target.rstrip(".")
    log(f"sync_cname: {hostname} CNAME -> {gw_domain}.")

    current = query_dns_records(knot_server, hostname, "CNAME")
    if current == [gw_domain]:
        log(f"sync_cname: {hostname} already correct, skipping")
        return True

    return send_dns_update(
        knot_server=knot_server,
        zone_name=zone,
        hostname=hostname,
        record_type="CNAME",
        records=[f"{gw_domain}."],
        tsig_key_name=tsig_key_name,
        tsig_key_secret=tsig_key_secret,
    )


# ---------------------------------------------------------------------------
# Plugin commands
# ---------------------------------------------------------------------------

@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    state = input_data.state or {}
    local_state = input_data.local_state or {}

    global_id = resolve_global_id(state)
    base_domain = get_swarm_secret(state, "base_domain")
    api_url = get_swarm_secret(state, "powerdns_api_url")
    api_key = get_swarm_secret(state, "powerdns_api_key")
    full_zone = f"{global_id}.{base_domain}" if global_id and base_domain else None

    swarm_domain = get_swarm_secret(state, "swarm_domain") or state.get("swarmDomain")
    if not swarm_domain:
        swarm_domain = f"app.{global_id}.{base_domain}"
        log(f"apply: swarm_domain not set, using computed: {swarm_domain}")

    pki_domain = get_swarm_secret(state, "pki_domain") or state.get("pkiDomain")
    if not pki_domain:
        pki_domain = f"ca.{global_id}.{base_domain}"
        log(f"apply: pki_domain not set, using computed: {pki_domain}")

    log(f"apply: global_id={global_id}, base_domain={base_domain}, "
        f"powerdns={'yes' if api_url else 'no'}")
    log(f"apply: knot nodes={len(state.get('knotServices', []))}, "
        f"openresty nodes={len(state.get('openrestyServices', []))}")

    if not global_id or not base_domain:
        log("apply: postponed — missing globalId or base_domain")
        return PluginOutput(
            status="postponed",
            error_message="Waiting for globalId and base_domain",
            local_state=local_state,
        )

    custom_gateway_dns = uses_custom_gateway_dns(state)
    static_gateway_hostname = resolve_static_gateway_hostname(state)
    dynamic_gateway_hostname = resolve_dynamic_gateway_hostname(state)
    delegation_gateway_hostname = resolve_delegation_gateway_hostname(state)

    if custom_gateway_dns:
        if not static_gateway_hostname:
            log("apply: postponed — custom gateway mode requires gateway_hostname")
            return PluginOutput(
                status="postponed",
                error_message="Waiting for gateway_hostname",
                local_state=local_state,
            )
        log(f"apply: custom gateway DNS mode, gateway_hostname={static_gateway_hostname}")
    else:
        if not dynamic_gateway_hostname:
            log("apply: postponed — unable to resolve dynamic gateway hostname")
            return PluginOutput(
                status="postponed",
                error_message="Waiting for dynamic gateway hostname",
                local_state=local_state,
            )
        if not delegation_gateway_hostname:
            log("apply: postponed — unable to resolve delegation gateway hostname")
            return PluginOutput(
                status="postponed",
                error_message="Waiting for delegation gateway hostname",
                local_state=local_state,
            )
        log(f"apply: dynamic_gateway_hostname={dynamic_gateway_hostname}")
        log(f"apply: delegation_gateway_hostname={delegation_gateway_hostname}")

    # --- PowerDNS ---
    if api_url and api_key:
        if custom_gateway_dns:
            if not sync_cluster_wildcard_gateway_in_powerdns(
                api_url, api_key, global_id, base_domain, static_gateway_hostname
            ):
                return PluginOutput(
                    status="postponed",
                    error_message="Failed to sync cluster wildcard gateway CNAME in PowerDNS",
                    local_state=local_state,
                )

            if not is_under_cluster_zone(swarm_domain, global_id, base_domain):
                if not sync_domain_cname(
                    api_url, api_key, swarm_domain, base_domain, static_gateway_hostname, "swarm"
                ):
                    return PluginOutput(
                        status="postponed",
                        error_message="Failed to sync swarm_domain CNAME in PowerDNS",
                        local_state=local_state,
                    )
            else:
                log(f"apply: swarm_domain {swarm_domain} covered by cluster wildcard, skipping")

            if not is_under_cluster_zone(pki_domain, global_id, base_domain):
                if not sync_domain_cname(
                    api_url, api_key, pki_domain, base_domain, static_gateway_hostname, "pki"
                ):
                    return PluginOutput(
                        status="postponed",
                        error_message="Failed to sync pki_domain CNAME in PowerDNS",
                        local_state=local_state,
                    )
            else:
                log(f"apply: pki_domain {pki_domain} covered by cluster wildcard, skipping")
        else:
            if not sync_knot_glue_in_powerdns(state, api_url, api_key, global_id, base_domain):
                return PluginOutput(
                    status="postponed",
                    error_message="Failed to sync knot glue records in PowerDNS",
                    local_state=local_state,
                )

            if not sync_dyn_knot_glue_in_powerdns(state, api_url, api_key, global_id, base_domain):
                return PluginOutput(
                    status="postponed",
                    error_message="Failed to sync dyn zone glue records in PowerDNS",
                    local_state=local_state,
                )

            if not sync_domain_cname(
                api_url, api_key, swarm_domain, base_domain, delegation_gateway_hostname, "swarm"
            ):
                return PluginOutput(
                    status="postponed",
                    error_message="Failed to sync swarm_domain CNAME in PowerDNS",
                    local_state=local_state,
                )

            pki_in_delegated_zone = (
                isinstance(full_zone, str)
                and (pki_domain == full_zone or pki_domain.endswith(f".{full_zone}"))
            )
            if not pki_in_delegated_zone:
                if not sync_domain_cname(
                    api_url, api_key, pki_domain, base_domain, delegation_gateway_hostname, "pki"
                ):
                    return PluginOutput(
                        status="postponed",
                        error_message="Failed to sync pki_domain CNAME in PowerDNS",
                        local_state=local_state,
                    )
            else:
                log(f"apply: pki_domain is in delegated zone {full_zone}, will sync via Knot")
    else:
        log("apply: powerdns_api_url or powerdns_api_key missing, skipping PowerDNS operations")

    # --- Knot DNS (nsupdate) ---
    knot_leader = get_knot_leader(state)
    if not knot_leader:
        knot_nodes = state.get("knotServices", [])
        leaders = [s for s in knot_nodes if s.get("is_leader")]
        log(f"apply: postponed — no ready knot leader "
            f"(total nodes={len(knot_nodes)}, leaders={len(leaders)}, "
            f"ready leaders={sum(1 for s in leaders if s.get('ready') == 'true')})")
        return PluginOutput(
            status="postponed",
            error_message="Waiting for knot leader to be ready",
            local_state=local_state,
        )

    log(f"apply: knot leader node_id={knot_leader.get('node_id')}, ip={knot_leader.get('ip')}")

    tsig = get_knot_tsig_key(state)
    if not tsig:
        props = [p.get("name") for p in state.get("knotClusterProperties", [])]
        log(f"apply: postponed — TSIG key not available (knotClusterProperties keys: {props})")
        return PluginOutput(
            status="postponed",
            error_message="Waiting for knot TSIG key",
            local_state=local_state,
        )

    knot_server = get_knot_dns_server(knot_leader)
    tsig_key_name, tsig_key_secret = tsig
    log(
        f"apply: using TSIG key={tsig_key_name}, "
        f"knot_server={knot_server} (leader tap={knot_leader.get('external_ip')}, "
        f"wg={knot_leader.get('ip')})"
    )

    if not sync_gw_dyn_records(state, knot_server, tsig_key_name, tsig_key_secret, global_id, base_domain):
        return PluginOutput(
            status="postponed",
            error_message="Failed to sync gw.dyn A records",
            local_state=local_state,
        )

    cname_services = [
        ("auth",              state.get("authServiceNodes", [])),
        ("api",               state.get("swarmCloudApiNodes", [])),
        ("app",               state.get("swarmCloudUiNodes", [])),
        ("gatekeeper-s3",     state.get("swarmGatekeeperS3Nodes", [])),
        ("gatekeeper-harbor", state.get("swarmGatekeeperHarborNodes", [])),
    ]

    k8s_hostnames = {
        node["k8s_external_hostname"]
        for node in state.get("k8sNodes", [])
        if node.get("ready") == "true" and node.get("k8s_external_hostname")
    }

    if custom_gateway_dns:
        openresty_ips = get_openresty_ready_ips(state)
        internal_hostnames: list[str] = []

        for prefix, nodes in cname_services:
            ready_count = sum(1 for n in nodes if n.get("ready") == "true")
            log(f"apply: service={prefix}, nodes={len(nodes)}, ready={ready_count}")
            if not any_ready(nodes):
                log(f"apply: no ready nodes for {prefix}, skipping internal A record")
                continue
            internal_hostnames.append(f"{prefix}.{full_zone}")

        if pki_domain == full_zone or pki_domain.endswith(f".{full_zone}"):
            internal_hostnames.append(pki_domain)

        internal_hostnames.extend(sorted(k8s_hostnames))
        log(f"apply: custom gateway — internal A hostnames: {internal_hostnames or '(none)'}")

        if internal_hostnames and not openresty_ips:
            openresty_nodes = state.get("openrestyServices", [])
            log(
                "apply: postponed — waiting for ready openresty nodes with external_ip "
                f"(nodes={len(openresty_nodes)}, "
                f"ready={[n.get('node_id') for n in openresty_nodes if n.get('ready') == 'true']})"
            )
            return PluginOutput(
                status="postponed",
                error_message="Waiting for ready openresty nodes for internal A records",
                local_state=local_state,
            )

        for hostname in internal_hostnames:
            if not sync_hostname_a_records(
                knot_server, tsig_key_name, tsig_key_secret, hostname, global_id, base_domain, openresty_ips
            ):
                return PluginOutput(
                    status="postponed",
                    error_message=f"Failed to sync internal A record for {hostname}",
                    local_state=local_state,
                )
    else:
        for prefix, nodes in cname_services:
            ready_count = sum(1 for n in nodes if n.get("ready") == "true")
            log(f"apply: service={prefix}, nodes={len(nodes)}, ready={ready_count}")
            if not any_ready(nodes):
                log(f"apply: no ready nodes for {prefix}, skipping CNAME")
                continue
            hostname = f"{prefix}.{full_zone}"
            if not sync_cname(
                knot_server, tsig_key_name, tsig_key_secret, hostname, global_id, base_domain, delegation_gateway_hostname
            ):
                return PluginOutput(
                    status="postponed",
                    error_message=f"Failed to sync CNAME for {prefix}",
                    local_state=local_state,
                )

        if pki_domain == full_zone or pki_domain.endswith(f".{full_zone}"):
            if not sync_cname(
                knot_server, tsig_key_name, tsig_key_secret, pki_domain, global_id, base_domain, delegation_gateway_hostname
            ):
                return PluginOutput(
                    status="postponed",
                    error_message="Failed to sync pki_domain CNAME in delegated zone",
                    local_state=local_state,
                )

        log(f"apply: k8s hostnames to sync: {sorted(k8s_hostnames) or '(none)'}")
        for hostname in sorted(k8s_hostnames):
            if not sync_cname(
                knot_server, tsig_key_name, tsig_key_secret, hostname, global_id, base_domain, delegation_gateway_hostname
            ):
                return PluginOutput(
                    status="postponed",
                    error_message=f"Failed to sync k8s CNAME for {hostname}",
                    local_state=local_state,
                )

    log("apply: completed successfully")
    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("destroy")
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    log("destroy: completed")
    return PluginOutput(status="completed", local_state={})


if __name__ == "__main__":
    plugin.run()
