#!/usr/bin/env python3
"""Unit tests for swarm-cloud-api/main.py — the rendered /etc/swarm-cloud-api/config.yaml.

A real node never reads `conf/api.yaml`; it reads what `create_config_file` renders here.
SUP-368: `kubeEventSync` was added to the compose config and to the Zod schema (whose
default is `enabled: false`) but not to this renderer, so the worker logged "disabled by
config" on every cluster and `clusterSpaceEvents` could only ever answer from the API
server's own 1h window. The drift test below is the guard: any worker the schema knows
about must appear in the rendered block.

    cd services/swarm-cloud-api && python3 -m unittest test_main -v
"""

import re
import sys
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent
WORKERS_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/workers/workers.config.ts"
DB_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/db/config.ts"

sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    # main.py imports the plugin SDK at module scope and instantiates a ProvisionPlugin.
    # None of the config rendering needs it, so a stub keeps the SDK off the test host.
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0-test"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

LOCAL_NODE_ID = "node-1"
PEER_NODE_ID = "node-2"


def build_state(leader_node_id: str) -> dict:
    return {
        "cluster": {"leader_node": leader_node_id},
        "wgNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.1"},
            {"node_id": PEER_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.2"},
        ],
        "cockroachClusterNodes": [{"node_id": LOCAL_NODE_ID}, {"node_id": PEER_NODE_ID}],
        "cockroachNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"},
        ],
        "globalId": "abc123",
        "baseDomain": "swarm.superprotocol.dev",
        "pkiAuthorityNodes": [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
        ],
        "swarmSecrets": [{"id": "pki_auth_token", "value": "tok"}],
        "evidenceTypeMeasurements": [
            {"node": LOCAL_NODE_ID, "value": "tdx"},
            {"node": PEER_NODE_ID, "value": "sev-snp"},
        ],
    }


NETWORK_ID = "swarm-net-1"

# On a real node `pki_authority.networkID` comes from /sp/swarm/config.yaml,
# written into the sp-vm image. Every evidenceSigner render reads it, and
# without it the non-token challenges render nothing, so the whole module runs
# with it present and the tests that care about its absence remove it.
_provider_dir: tempfile.TemporaryDirectory | None = None
_original_provider_config = None


def setUpModule():
    global _provider_dir, _original_provider_config
    _provider_dir = tempfile.TemporaryDirectory()
    path = Path(_provider_dir.name) / "config.yaml"
    path.write_text(yaml.safe_dump({"pki_authority": {"networkID": NETWORK_ID}}))
    _original_provider_config = main.SWARM_PROVIDER_CONFIG
    main.SWARM_PROVIDER_CONFIG = path


def tearDownModule():
    main.SWARM_PROVIDER_CONFIG = _original_provider_config
    if _provider_dir is not None:
        _provider_dir.cleanup()


@contextmanager
def provider_config(content: object):
    """Replace the provider config for one test. `None` removes the file."""
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "config.yaml"
        if content is not None:
            path.write_text(yaml.safe_dump(content))
        original = main.SWARM_PROVIDER_CONFIG
        main.SWARM_PROVIDER_CONFIG = path
        try:
            yield
        finally:
            main.SWARM_PROVIDER_CONFIG = original


def render_config(leader_node_id: str) -> dict:
    """Render config.yaml the way the plugin does on a node and parse it back."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "swarm-cloud-api" / "config.yaml"
        original = main.API_CONFIG_FILE
        original_probe = main.is_cockroach_endpoint_reachable
        main.API_CONFIG_FILE = config_path
        # The renderer TCP-probes CockroachDB candidates; no test host answers on 26257.
        main.is_cockroach_endpoint_reachable = lambda *_args, **_kwargs: True
        try:
            main.create_config_file(
                LOCAL_NODE_ID, build_state(leader_node_id), "http://10.10.0.1:3002"
            )
            return yaml.safe_load(config_path.read_text())
        finally:
            main.API_CONFIG_FILE = original
            main.is_cockroach_endpoint_reachable = original_probe


def schema_worker_keys() -> set[str]:
    """The worker names WorkersConfigSchema declares, read straight off the Zod schema."""
    source = WORKERS_CONFIG_TS.read_text()
    body = re.search(
        r"export const WorkersConfigSchema = BaseConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find WorkersConfigSchema in {WORKERS_CONFIG_TS}"
    return set(re.findall(r"^  (\w+):", body.group(1), re.MULTILINE))


class RenderedWorkersTest(unittest.TestCase):
    def test_every_worker_in_the_schema_is_rendered(self):
        """A worker the renderer forgets defaults to enabled:false and silently never runs."""
        rendered = render_config(LOCAL_NODE_ID)["workers"]
        missing = schema_worker_keys() - set(rendered)
        self.assertEqual(
            set(),
            missing,
            f"workers declared in workers.config.ts but absent from the rendered config: {sorted(missing)}",
        )

    def test_kube_event_sync_runs_on_the_leader(self):
        workers = render_config(LOCAL_NODE_ID)["workers"]
        self.assertEqual(
            {"enabled": True, "checkInterval": 30000, "retentionHours": 48},
            workers["kubeEventSync"],
        )

    def test_workers_are_leader_gated(self):
        """Every worker — kubeEventSync included — is off on a follower node."""
        workers = render_config(PEER_NODE_ID)["workers"]
        self.assertFalse(workers["kubeEventSync"]["enabled"])
        for name, worker in workers.items():
            self.assertFalse(worker["enabled"], f"{name} must not run on a follower")


class RenderedEvidenceSignerTest(unittest.TestCase):
    """SUP-636: without this block the API falls back to `http://127.0.0.1:8000`,
    which only resolves when the API node happens to co-host a PKI authority. On
    every other node each `sign()` throws, no host gets a
    `/.well-known/swarm-evidence` bundle, and a cluster-space publish rolls back.
    """

    def test_renders_the_pki_endpoints_the_api_can_actually_reach(self):
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual([f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], signer["pkiBaseUrls"])

    def test_renders_the_hardware_challenge_this_node_can_actually_produce(self):
        # SUP-660: the challenge follows the node's own sp_vm_evidence_type, so
        # the certificate binds the signing key to this guest's quote.
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual("tdx", signer["challenge"])

    def test_renders_the_platform_variant_rather_than_the_family(self):
        # tdx-google and sev-snp-azure need different native calls; collapsing
        # them to `tdx` / `sev-snp` would produce evidence the authority rejects.
        for evidence_type in ("tdx-google", "tdx-azure", "sev-snp", "sev-snp-azure"):
            with self.subTest(evidence_type=evidence_type):
                state = build_state(LOCAL_NODE_ID)
                state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": evidence_type}]
                section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
                self.assertEqual(evidence_type, section["evidenceSigner"]["challenge"])

    def test_falls_back_to_token_only_on_a_node_with_no_tee(self):
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "untrusted"}]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual("token", section["evidenceSigner"]["challenge"])

    def test_renders_nothing_until_the_node_has_been_measured(self):
        # An unmeasured node that silently rendered `token` would come up with
        # the weaker binding and nothing would say so.
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_for_an_evidence_type_we_cannot_quote(self):
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "sgx"}]
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    # SUP-660 / QA: the authority's `ignoreNetworkIDChallenges` lists `token`
    # and nothing else, so every other challenge is refused outright without a
    # matching network ID. As first shipped the block carried the challenge but
    # not the ID, and a real SEV-SNP cloud served no bundle at all for its
    # whole life — a 404 on /.well-known/swarm-evidence was the only symptom.
    def test_renders_the_network_id_the_authority_demands(self):
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual(NETWORK_ID, signer["networkId"])

    def test_renders_the_network_id_for_every_hardware_challenge(self):
        for evidence_type in main.HARDWARE_EVIDENCE_TYPES:
            with self.subTest(evidence_type=evidence_type):
                state = build_state(LOCAL_NODE_ID)
                state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": evidence_type}]
                section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
                self.assertEqual(NETWORK_ID, section["evidenceSigner"]["networkId"])

    def test_a_hardware_challenge_without_a_network_id_still_renders_the_block(self):
        # SUP-691: rendering nothing would start the API in its unsigned mode,
        # so a trusted cloud missing one provider-config line would publish
        # unsigned statements with every node green. The block without the ID
        # trips the API's own guard instead — it refuses to start and says why.
        state = build_state(LOCAL_NODE_ID)
        for content in (None, {}, {"pki_authority": {}}, {"pki_authority": {"networkID": "  "}}):
            with self.subTest(content=content), provider_config(content):
                section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
                self.assertEqual("tdx", section["evidenceSigner"]["challenge"])
                self.assertNotIn("networkId", section["evidenceSigner"])

    def test_the_token_path_still_renders_without_a_network_id(self):
        # The authority ignores the network ID for `token`, and an untrusted
        # stand may legitimately have no provider config; refusing to render
        # there would be a regression against what SUP-636 shipped.
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "untrusted"}]
        with provider_config(None):
            section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual("token", section["evidenceSigner"]["challenge"])
        self.assertNotIn("networkId", section["evidenceSigner"])

    def test_reads_the_same_field_the_pki_authority_plugin_reads(self):
        # services/pki-authority/helpers.py get_pki_authority_param() reads
        # pki_authority.<name> from the same file; the two must not drift, or
        # the API would present an ID the authority does not recognise.
        self.assertEqual(NETWORK_ID, main.get_pki_network_id())
        with provider_config({"pki_authority": {"networkID": "other-net"}}):
            self.assertEqual("other-net", main.get_pki_network_id())

    def test_a_malformed_provider_config_is_not_a_network_id(self):
        for content in ("", [1, 2, 3], {"pki_authority": "not-a-mapping"}, {"pki_authority": {"networkID": 7}}):
            with self.subTest(content=content), provider_config(content):
                self.assertIsNone(main.get_pki_network_id())

    def test_reads_this_node_s_measurement_not_a_peer_s(self):
        state = build_state(LOCAL_NODE_ID)
        self.assertEqual("tdx", main.get_node_evidence_type(LOCAL_NODE_ID, state))
        self.assertEqual("sev-snp", main.get_node_evidence_type(PEER_NODE_ID, state))

    def test_the_rendered_challenge_is_one_the_authority_template_allows(self):
        template = yaml.safe_load(
            (REPO_ROOT / "services/pki-authority/pki-authority-template.yaml").read_text()
        )
        allowed = template["pki"]["allowedChallenges"]
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertIn(signer["challenge"], allowed)

    def test_prefers_loopback_when_this_node_hosts_a_pki_authority(self):
        # Issuance must not depend on the WireGuard mesh being up at the moment a
        # leader comes back, so a co-hosted authority is tried first.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
            {"id": f"pki:{LOCAL_NODE_ID}", "node_id": LOCAL_NODE_ID, "ip": "10.10.0.1", "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://127.0.0.1:{main.PKI_API_HTTP_PORT}", f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"],
            section["evidenceSigner"]["pkiBaseUrls"],
        )

    def test_skips_an_authority_that_is_not_ready(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": "pki:node-3", "node_id": "node-3", "ip": "10.10.0.3", "ready": None},
        ]
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_on_a_cloud_with_no_pki_authority(self):
        # The legacy non-sp-vm shape: leave evidence signing unconfigured rather
        # than point it at an endpoint that does not exist.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_until_the_auth_token_secret_exists(self):
        # Only the token path needs the secret; a hardware challenge does not.
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "untrusted"}]
        state["swarmSecrets"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_a_hardware_challenge_does_not_need_the_shared_token(self):
        state = build_state(LOCAL_NODE_ID)
        state["swarmSecrets"] = []
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual("tdx", section["evidenceSigner"]["challenge"])

    def test_falls_back_to_wg_properties_when_the_node_carries_no_ip(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": None, "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], section["evidenceSigner"]["pkiBaseUrls"]
        )


class ApiContainerQuoteDelegationTest(unittest.TestCase):
    """SUP-922: the API container is not a quote owner.

    SUP-660 passed `--device /dev/tdx_guest` into it and widened the device
    with chgrp/chmod so the in-process addon could read it. On TDX that cannot
    work at all — `libtdx_attest` needs configfs-tsm or the host QGS over
    `AF_VSOCK` — so the quote moved to pki-vm-measurements on the host and the
    container reaches it over loopback. These assertions are what stops the
    device plumbing from coming back one mount at a time."""

    def _render_unit(self) -> str:
        with tempfile.TemporaryDirectory() as tmp:
            unit_path = Path(tmp) / "swarm-cloud-api.service"
            original_write = main._write_file_if_changed
            captured = {}

            def capture(path, content, label):
                captured["content"] = content
                return original_write(unit_path, content, label)

            main._write_file_if_changed = capture
            original_run = main.subprocess.run
            main.subprocess.run = lambda *a, **k: None
            try:
                main.create_systemd_service("v1", "10.10.0.1")
            finally:
                main._write_file_if_changed = original_write
                main.subprocess.run = original_run
            return captured["content"]

    def test_passes_no_tee_device_into_the_container(self):
        unit = self._render_unit()
        self.assertNotIn("--device", unit)
        self.assertNotIn("/dev/tdx_guest", unit)
        self.assertNotIn("/dev/sev-guest", unit)
        self.assertNotIn("/dev/tpm", unit)

    def test_never_renders_privileged(self):
        self.assertNotIn("--privileged", self._render_unit())

    def test_does_not_widen_any_device_on_the_host(self):
        unit = self._render_unit()
        self.assertNotIn("chgrp", unit)
        self.assertNotIn("chmod", unit)

    def test_mounts_nothing_but_the_api_config(self):
        """A configfs or /etc/tdx-attest.conf bind-mount is the other way to
        make the in-process path work, and the one the CTO ruled out: it makes
        the container a second quote owner on the node."""
        unit = self._render_unit()
        mounts = [part for part in unit.split() if part.startswith(f"{main.API_CONFIG_DIR}")]
        self.assertEqual([f"{main.API_CONFIG_DIR}:{main.API_CONFIG_DIR}:ro"], mounts)
        self.assertNotIn("/sys/kernel/config", unit)
        self.assertNotIn("tdx-attest.conf", unit)

    def test_keeps_host_networking_which_is_how_loopback_is_reached(self):
        """The delegation channel is 127.0.0.1 on the host, so this flag is
        load-bearing rather than incidental."""
        self.assertIn("--network=host", self._render_unit())

    def test_the_challenge_table_matches_the_one_the_api_accepts(self):
        """A type rendered here that the API does not accept leaves the cloud
        unsigned with every node green, which is how SUP-660 shipped broken."""
        source = (
            REPO_ROOT
            / "apps/swarm-cloud-api/src/app/evidence-signer/node-quote-challenge-provider.ts"
        ).read_text()
        body = re.search(
            r"HARDWARE_CHALLENGE_TYPES = \[(.*?)\] as const;", source, re.DOTALL
        )
        self.assertIsNotNone(body, "could not find HARDWARE_CHALLENGE_TYPES in the provider")
        from_ts = re.findall(r"'([^']+)'", body.group(1))
        self.assertEqual(sorted(main.HARDWARE_EVIDENCE_TYPES), sorted(from_ts))


class EvidenceSignerManifestTest(unittest.TestCase):
    def test_the_manifest_supplies_what_the_renderer_reads(self):
        """The renderer reads `pkiAuthorityNodes` and the `pki_auth_token` secret; a
        stateExpr that does not select them renders an empty block on every node."""
        manifest = yaml.safe_load((HERE / "manifest.yaml").read_text())
        query = manifest["stateExpr"]["query"]
        self.assertIn("pkiAuthorityNodes:", query)
        self.assertIn('cluster_policy == "pki-authority"', query)
        self.assertIn("pki_authority_node_ready", query)
        self.assertIn("pki_auth_token", query)
        # SUP-660: the challenge is chosen from this measurement.
        self.assertIn("evidenceTypeMeasurements:", query)
        self.assertIn("sp_vm_evidence_type", query)


def postgres_timeout_keys() -> set[str]:
    """The `*TimeoutMs` bounds PostgresqlConfigSchema declares, read off the Zod schema."""
    source = DB_CONFIG_TS.read_text()
    body = re.search(
        r"export const PostgresqlConfigSchema = BaseDbConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find PostgresqlConfigSchema in {DB_CONFIG_TS}"
    return {name for name in re.findall(r"^  (\w+):", body.group(1), re.MULTILINE) if name.endswith("TimeoutMs")}


class RenderedDbBoundsTest(unittest.TestCase):
    """SUP-759: an unbounded primary-database pool turns an unreachable CockroachDB into an
    indefinite hang on every request that touches it, authenticated or not."""

    def test_every_timeout_the_schema_declares_is_rendered(self):
        rendered = render_config(LOCAL_NODE_ID)["db"]["config"]
        for key in postgres_timeout_keys():
            self.assertIn(key, rendered, f"{key} is declared by the schema but not rendered")

    def test_the_rendered_timeouts_are_positive(self):
        rendered = render_config(LOCAL_NODE_ID)["db"]["config"]
        for key in ("connectTimeoutMs", "queryTimeoutMs"):
            # 0 is how node-postgres spells "wait forever", which is the defect.
            self.assertGreater(rendered[key], 0, f"{key} must bound the wait")


class CockroachEndpointSelectionTest(unittest.TestCase):
    """The rendered host is never re-resolved while the container runs, so picking one that
    does not answer wedges the API until the next provision run."""

    def select(self, state: dict, answers: dict[str, bool]) -> tuple[dict | None, list[tuple[str, int]]]:
        probed: list[tuple[str, int]] = []

        def probe(host: str, port: int) -> bool:
            probed.append((host, port))
            return answers.get(host, False)

        return main.get_cockroach_connection_info(LOCAL_NODE_ID, state, probe=probe), probed

    def test_prefers_the_local_node_when_it_answers(self):
        info, probed = self.select(build_state(LOCAL_NODE_ID), {"10.10.0.1": True})

        self.assertEqual(info["host"], "10.10.0.1")
        self.assertEqual(info["port"], main.COCKROACH_SQL_PORT)
        self.assertEqual(probed, [("10.10.0.1", main.COCKROACH_SQL_PORT)])

    def test_skips_a_ready_node_that_does_not_answer(self):
        """A node rebuilt onto a new WireGuard IP leaves `cockroachdb_node_ready` behind on its
        old identity; that stale row is what must not be rendered."""
        state = build_state(LOCAL_NODE_ID)
        state["cockroachNodeProperties"].append(
            {"node_id": PEER_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"}
        )

        info, probed = self.select(state, {"10.10.0.2": True})

        self.assertEqual(info["host"], "10.10.0.2")
        self.assertEqual(
            probed,
            [("10.10.0.1", main.COCKROACH_SQL_PORT), ("10.10.0.2", main.COCKROACH_SQL_PORT)],
        )

    def test_falls_back_to_the_preferred_candidate_when_nothing_answers(self):
        """The probe may itself be wrong — a mesh still settling — so provisioning continues on
        the preferred host rather than failing the plugin."""
        info, _ = self.select(build_state(LOCAL_NODE_ID), {})

        self.assertEqual(info["host"], "10.10.0.1")

    def test_ignores_a_node_that_is_not_ready(self):
        state = build_state(LOCAL_NODE_ID)
        state["cockroachNodeProperties"] = []

        info, probed = self.select(state, {"10.10.0.1": True, "10.10.0.2": True})

        self.assertIsNone(info)
        self.assertEqual(probed, [])

    def test_ignores_a_ready_node_with_no_tunnel_ip(self):
        state = build_state(LOCAL_NODE_ID)
        state["wgNodeProperties"] = []

        info, probed = self.select(state, {"10.10.0.1": True})

        self.assertIsNone(info)
        self.assertEqual(probed, [])

    def test_probes_each_candidate_once(self):
        state = build_state(LOCAL_NODE_ID)
        state["cockroachClusterNodes"].append({"node_id": LOCAL_NODE_ID})

        _, probed = self.select(state, {})

        self.assertEqual(probed.count(("10.10.0.1", main.COCKROACH_SQL_PORT)), 1)


if __name__ == "__main__":
    unittest.main()
