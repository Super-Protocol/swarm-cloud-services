#!/usr/bin/env python3
"""Unit tests for pki-authority/helpers.py (SUP-653).

The authority signs every node certificate with the device-enrollment subroot that the
bootstrap node minted once and nothing renews. tee-pki stamps each node certificate as
`now + pki.certParams.lifetimeDays` without looking at that signer, so the plugin is the
only place that can notice the subroot running out — and the only place that can refuse
to configure an authority whose subroot has already lapsed.

    cd services/pki-authority && python3 -m unittest test_helpers -v
"""

import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest import mock

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import helpers  # noqa: E402

NOW = datetime(2026, 11, 12, 12, 0, 0, tzinfo=timezone.utc)


def write_cert(directory: Path, filename: str, *, not_before: datetime, not_after: datetime) -> Path:
    """Write a self-signed CA certificate with the given validity window."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Super Swarm Device Enrollment Subroot CA")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(not_before)
        .not_valid_after(not_after)
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    path = directory / filename
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return path


class LoadIssuerCertificateTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.storage = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

    def test_reads_the_expiry_back_as_an_aware_datetime(self):
        not_after = NOW + timedelta(days=90, hours=1)
        path = write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=10),
            not_after=not_after,
        )
        read_back = helpers.cert_not_after_utc(helpers.load_issuer_certificate(path))
        self.assertIsNotNone(read_back.tzinfo)
        self.assertEqual(read_back, not_after)

    def test_raises_when_the_certificate_is_missing(self):
        with self.assertRaises(FileNotFoundError):
            helpers.load_issuer_certificate(self.storage / "absent.pem")


class CheckIssuedCertLifetimeTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.storage = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

    def _subroot(self, remaining_days: int) -> Path:
        return write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=365),
            not_after=NOW + timedelta(days=remaining_days, hours=1),
        )

    def test_returns_the_remaining_days_of_a_healthy_subroot(self):
        path = self._subroot(3649)
        self.assertEqual(helpers.check_issued_cert_lifetime(3650, path, NOW), 3649)

    def test_counts_whole_days_and_discards_the_part_day(self):
        path = self._subroot(90)
        self.assertEqual(helpers.check_issued_cert_lifetime(3650, path, NOW), 90)

    def test_treats_a_naive_reference_as_utc(self):
        path = self._subroot(5)
        self.assertEqual(helpers.check_issued_cert_lifetime(3650, path, NOW.replace(tzinfo=None)), 5)

    def test_raises_when_the_subroot_is_missing(self):
        with self.assertRaises(FileNotFoundError):
            helpers.check_issued_cert_lifetime(3650, self.storage / "absent.pem", NOW)

    def test_raises_for_an_expired_subroot(self):
        path = write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=100),
            not_after=NOW - timedelta(seconds=1),
        )
        with self.assertRaises(ValueError) as caught:
            helpers.check_issued_cert_lifetime(3650, path, NOW)
        self.assertIn("expired at", str(caught.exception))

    def test_raises_on_the_last_day_rather_than_issuing_against_it(self):
        # Under a day left is not enough to stamp a certificate anybody will accept.
        path = write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=89),
            not_after=NOW + timedelta(hours=1),
        )
        with self.assertRaises(ValueError):
            helpers.check_issued_cert_lifetime(3650, path, NOW)

    def test_warns_as_the_subroot_approaches_expiry(self):
        path = self._subroot(helpers.ISSUER_EXPIRY_WARNING_DAYS - 1)
        with mock.patch.object(helpers, "log") as logged:
            helpers.check_issued_cert_lifetime(3650, path, NOW)
        warnings = [c.args[1] for c in logged.call_args_list if c.args[0] is helpers.LogLevel.WARN]
        self.assertTrue(any("expires in" in message for message in warnings), warnings)

    def test_does_not_warn_about_expiry_while_the_subroot_is_long_lived(self):
        path = self._subroot(3649)
        with mock.patch.object(helpers, "log") as logged:
            helpers.check_issued_cert_lifetime(3650, path, NOW)
        warnings = [c.args[1] for c in logged.call_args_list if c.args[0] is helpers.LogLevel.WARN]
        self.assertFalse(any("expires in" in message for message in warnings), warnings)

    def test_reports_the_date_the_chain_stops_validating(self):
        # The number an operator needs is the subroot's expiry, not the lifetime stamped
        # on the leaf: a node certificate issued for 3650 days under a subroot with 100
        # left validates for 100.
        path = self._subroot(100)
        with mock.patch.object(helpers, "log") as logged:
            helpers.check_issued_cert_lifetime(3650, path, NOW)
        infos = [c.args[1] for c in logged.call_args_list if c.args[0] is helpers.LogLevel.INFO]
        self.assertTrue(
            any("stamped for 3650 days and chain-validate for 100 day(s)" in m for m in infos),
            infos,
        )

    def test_reports_the_configured_lifetime_when_it_fits_inside_the_issuer(self):
        path = self._subroot(3649)
        with mock.patch.object(helpers, "log") as logged:
            helpers.check_issued_cert_lifetime(365, path, NOW)
        infos = [c.args[1] for c in logged.call_args_list if c.args[0] is helpers.LogLevel.INFO]
        warnings = [c.args[1] for c in logged.call_args_list if c.args[0] is helpers.LogLevel.WARN]
        self.assertEqual(warnings, [])
        self.assertTrue(
            any("stamped for 365 days and chain-validate for 365 day(s)" in m for m in infos),
            infos,
        )

    def test_rejects_a_configured_lifetime_that_is_not_a_positive_integer(self):
        path = self._subroot(3649)
        for configured in (None, 0, -1, "3650", 3650.0, True):
            with self.subTest(configured=configured):
                with self.assertRaises(ValueError):
                    helpers.check_issued_cert_lifetime(configured, path, NOW)


class PatchYamlConfigLifetimeTest(unittest.TestCase):
    """The check has to run on the apply path, not just as a standalone helper."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        self.storage = self.root / "swarm-storage"
        self.storage.mkdir()
        base_dir = self.root / "etc"
        patcher = mock.patch.multiple(
            helpers,
            BASE_DIR=base_dir,
            APP_CONFIG_PATH=base_dir / "app-config.yaml",
        )
        patcher.start()
        self.addCleanup(patcher.stop)

    def _patch(self, *, remaining_days: int) -> bool:
        write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=365),
            not_after=NOW + timedelta(days=remaining_days, hours=1),
        )
        return helpers.patch_yaml_config(
            network_type=helpers.NetworkType.TRUSTED,
            network_id="network-id",
            swarm_key="a" * 64,
            tunnel_ip=None,
            storage_path=self.storage,
            now=NOW,
        )

    def test_writes_the_config_for_a_healthy_subroot(self):
        self.assertTrue(self._patch(remaining_days=3649))
        written = helpers.yaml.safe_load(helpers.APP_CONFIG_PATH.read_text(encoding="utf-8"))
        self.assertEqual(written["pki"]["mode"]["networkSettings"]["networkID"], "network-id")

    def test_leaves_the_configured_lifetime_alone(self):
        # Rewriting it to the issuer's remaining days would change the file every day and
        # restart the authority on every apply tick.
        template = helpers.yaml.safe_load(helpers.TEMPLATE_YAML.read_text(encoding="utf-8"))
        self._patch(remaining_days=3649)
        written = helpers.yaml.safe_load(helpers.APP_CONFIG_PATH.read_text(encoding="utf-8"))
        self.assertEqual(
            written["pki"]["certParams"]["lifetimeDays"],
            template["pki"]["certParams"]["lifetimeDays"],
        )

    def test_the_config_is_byte_identical_across_days(self):
        self._patch(remaining_days=3649)
        first = helpers.APP_CONFIG_PATH.read_text(encoding="utf-8")
        write_cert(
            self.storage,
            helpers.DEVICE_SUBROOT_CERT_FILE,
            not_before=NOW - timedelta(days=365),
            not_after=NOW + timedelta(days=3649, hours=1),
        )
        changed = helpers.patch_yaml_config(
            network_type=helpers.NetworkType.TRUSTED,
            network_id="network-id",
            swarm_key="a" * 64,
            tunnel_ip=None,
            storage_path=self.storage,
            now=NOW + timedelta(days=400),
        )
        self.assertFalse(changed, "an apply 400 days later must not restart the authority")
        self.assertEqual(helpers.APP_CONFIG_PATH.read_text(encoding="utf-8"), first)

    def test_refuses_to_configure_an_authority_whose_subroot_expired(self):
        with self.assertRaises(ValueError) as caught:
            self._patch(remaining_days=-10)
        self.assertIn("expired at", str(caught.exception))
        self.assertFalse(helpers.APP_CONFIG_PATH.exists())

    def test_fails_when_the_subroot_has_not_been_synced_yet(self):
        with self.assertRaises(FileNotFoundError):
            helpers.patch_yaml_config(
                network_type=helpers.NetworkType.TRUSTED,
                network_id="network-id",
                swarm_key="a" * 64,
                tunnel_ip=None,
                storage_path=self.storage,
                now=NOW,
            )


class ShippedTemplateTest(unittest.TestCase):
    def test_node_certificate_lifetime_is_a_positive_integer(self):
        template = helpers.yaml.safe_load(helpers.TEMPLATE_YAML.read_text(encoding="utf-8"))
        lifetime = template["pki"]["certParams"]["lifetimeDays"]
        self.assertIsInstance(lifetime, int)
        self.assertGreaterEqual(lifetime, 1)

    def test_node_certificate_lifetime_does_not_exceed_the_chain_it_is_signed_under(self):
        # The sp-vm cert-gen template mints the whole chain — roots and both subroots —
        # for 3650 days (sp-vm `src/rootfs/files/configs/pki-service/conf/
        # cert-gen-config-template.yaml`). A node certificate configured longer than that
        # could never fit inside its issuer, not even on the day the cloud bootstraps.
        chain_lifetime_days = 3650
        template = helpers.yaml.safe_load(helpers.TEMPLATE_YAML.read_text(encoding="utf-8"))
        self.assertLessEqual(template["pki"]["certParams"]["lifetimeDays"], chain_lifetime_days)


if __name__ == "__main__":
    unittest.main()
