"""Unit tests for the restricted Pod Security Admission config writer (SUP-634)."""

from __future__ import annotations

import importlib.util
import subprocess
import sys
import time
from pathlib import Path
from contextlib import contextmanager
from unittest.mock import MagicMock, patch

import yaml

RKE2_DIR = Path(__file__).resolve().parents[1]


def _load_pss_module():
    mod_path = RKE2_DIR / "pod_security_admission.py"
    spec = importlib.util.spec_from_file_location("pod_security_admission", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _pod_security_plugin(module) -> dict:
    parsed = yaml.safe_load(module.render_pod_security_admission_config())
    plugins = [p for p in parsed["plugins"] if p["name"] == "PodSecurity"]
    assert len(plugins) == 1
    return plugins[0]["configuration"]


# ---------------------------------------------------------------- rendered config


def test_rendered_config_is_a_valid_admission_configuration():
    module = _load_pss_module()
    parsed = yaml.safe_load(module.render_pod_security_admission_config())

    assert parsed["apiVersion"] == "apiserver.config.k8s.io/v1"
    assert parsed["kind"] == "AdmissionConfiguration"
    config = _pod_security_plugin(module)
    assert config["apiVersion"] == "pod-security.admission.config.k8s.io/v1"
    assert config["kind"] == "PodSecurityConfiguration"


def test_enforces_the_level_that_closes_sup_634():
    module = _load_pss_module()
    defaults = _pod_security_plugin(module)["defaults"]

    # `privileged` is what the issue reports as the effective default and is never acceptable.
    assert defaults["enforce"] in ("baseline", "restricted")
    assert defaults["enforce"] == module.PSS_ENFORCE_LEVEL
    assert defaults["enforce-version"] == "latest"


def test_audits_and_warns_against_the_stricter_target_level():
    module = _load_pss_module()
    defaults = _pod_security_plugin(module)["defaults"]

    assert module.PSS_TARGET_LEVEL == "restricted"
    assert defaults["audit"] == "restricted"
    assert defaults["warn"] == "restricted"
    assert defaults["audit-version"] == "latest"
    assert defaults["warn-version"] == "latest"


def test_exempts_only_system_namespaces_and_never_a_user_or_runtime_class():
    module = _load_pss_module()
    exemptions = _pod_security_plugin(module)["exemptions"]

    # Username / RuntimeClass exemptions would be inheritable by a tenant; namespaces are not.
    assert exemptions["usernames"] == []
    assert exemptions["runtimeClasses"] == []
    assert sorted(exemptions["namespaces"]) == [
        "kube-system",
        "local-path-storage",
        "opa-authz-system",
    ]


def test_no_tenant_namespace_prefix_is_exempt():
    module = _load_pss_module()
    # Tenant namespaces are `user-*`; nothing matching that may ever be exempt.
    assert not any(ns.startswith("user-") for ns in module.PSS_EXEMPT_NAMESPACES)


def test_config_is_rendered_deterministically():
    module = _load_pss_module()
    assert module.render_pod_security_admission_config() == module.render_pod_security_admission_config()
    assert module.pod_security_admission_digest().startswith("sha256/")


# ---------------------------------------------------------------- file writer


def test_write_creates_the_file_root_only(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "nested" / "swarm-pss.yaml"

    assert module.write_pod_security_admission_config(dest) is True
    assert dest.read_text() == module.render_pod_security_admission_config()
    assert dest.stat().st_mode & 0o777 == 0o600


def test_write_is_idempotent(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"

    assert module.write_pod_security_admission_config(dest) is True
    assert module.write_pod_security_admission_config(dest) is False


def test_write_repairs_a_tampered_config(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    dest.write_text("apiVersion: apiserver.config.k8s.io/v1\nkind: AdmissionConfiguration\nplugins: []\n")

    assert module.write_pod_security_admission_config(dest) is True
    assert "restricted" in dest.read_text()


# ---------------------------------------------------------------- rke2 config option


def test_rke2_config_option_is_appended_when_absent(tmp_path):
    module = _load_pss_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text("token: t\nnode-ip: 10.0.0.1\ncni: canal\n")

    assert module.ensure_rke2_pss_option(cfg, Path("/etc/rancher/rke2/swarm-pss.yaml")) is True
    parsed = yaml.safe_load(cfg.read_text())
    assert parsed["pod-security-admission-config-file"] == "/etc/rancher/rke2/swarm-pss.yaml"
    # The pre-existing keys survive the merge.
    assert parsed["token"] == "t"
    assert parsed["cni"] == "canal"


def test_rke2_config_option_merge_is_idempotent(tmp_path):
    module = _load_pss_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text(f"token: t\n{module.rke2_pss_config_line()}\n")

    assert module.ensure_rke2_pss_option(cfg) is False


def test_rke2_config_option_merge_preserves_kube_apiserver_arg_block(tmp_path):
    module = _load_pss_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "token: t\n"
        "\n"
        "kube-apiserver-arg:\n"
        '  - "authorization-config=/etc/rancher/rke2/authz-config.yaml"\n'
    )

    assert module.ensure_rke2_pss_option(cfg) is True
    parsed = yaml.safe_load(cfg.read_text())
    assert parsed["kube-apiserver-arg"] == ["authorization-config=/etc/rancher/rke2/authz-config.yaml"]
    assert parsed["pod-security-admission-config-file"] == str(module.PSS_CONFIG_FILE)


def test_rke2_config_option_merge_never_authors_a_config(tmp_path):
    """A config.yaml holding only this option would break the node on the restart that follows."""
    module = _load_pss_module()
    missing = tmp_path / "config.yaml"
    assert module.ensure_rke2_pss_option(missing) is False
    assert not missing.exists()

    empty = tmp_path / "empty.yaml"
    empty.write_text("\n  \n")
    assert module.ensure_rke2_pss_option(empty) is False
    assert "pod-security" not in empty.read_text()


def test_an_option_pointing_elsewhere_is_repaired_not_duplicated(tmp_path):
    """Presence is not enough: an option left on another path means another config is loaded."""
    module = _load_pss_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text(f"token: t\n{module.PSS_RKE2_OPTION}: /etc/rancher/rke2/rke2-pss.yaml\ncni: canal\n")

    assert module.ensure_rke2_pss_option(cfg) is True
    text = cfg.read_text()
    assert text.count(f"{module.PSS_RKE2_OPTION}:") == 1
    parsed = yaml.safe_load(text)
    assert parsed[module.PSS_RKE2_OPTION] == str(module.PSS_CONFIG_FILE)
    assert parsed["token"] == "t"
    assert parsed["cni"] == "canal"


def test_a_quoted_option_value_is_recognised(tmp_path):
    module = _load_pss_module()
    cfg = tmp_path / "config.yaml"
    cfg.write_text(f'token: t\n{module.PSS_RKE2_OPTION}: "{module.PSS_CONFIG_FILE}"\n')
    assert module.ensure_rke2_pss_option(cfg) is False


def test_health_check_rejects_an_option_pointing_elsewhere(tmp_path):
    module = _load_pss_module()
    pss = tmp_path / "swarm-pss.yaml"
    cfg = tmp_path / "config.yaml"
    pss.write_text(module.render_pod_security_admission_config())
    cfg.write_text(f"token: t\n{module.PSS_RKE2_OPTION}: /etc/rancher/rke2/rke2-pss.yaml\n")

    with patch.object(module, "PSS_CONFIG_FILE", pss), patch.object(module, "RKE2_CONFIG_FILE", cfg):
        ok, err, _ = module.health_check_pod_security_admission()

    assert ok is False
    assert "points at /etc/rancher/rke2/rke2-pss.yaml" in err


# ---------------------------------------------------------------- live enforcement probe


def _ns_json(labels: dict | None = None) -> subprocess.CompletedProcess[str]:
    import json as _json

    body = {"metadata": {"name": "default", "labels": labels or {}}}
    return subprocess.CompletedProcess(args=[], returncode=0, stdout=_json.dumps(body), stderr="")


def _probe(module, *, returncode: int, stderr: str = "", ns_labels: dict | None = None):
    """Canned responses for the probe's two kubectl calls: read the namespace, then apply."""
    applied = subprocess.CompletedProcess(args=[], returncode=returncode, stdout="", stderr=stderr)
    return patch.object(module, "_kubectl", side_effect=[_ns_json(ns_labels), applied])


def test_probe_reads_a_podsecurity_rejection_as_enforced(tmp_path):
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with (
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
        _probe(module, returncode=1, stderr='pods "swarm-pss-probe" is forbidden: violates PodSecurity "baseline:latest"'),
    ):
        assert module.pod_security_admission_enforced() is True


def test_probe_reads_an_accepted_privileged_pod_as_not_enforced(tmp_path):
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with patch.object(module, "RKE2_KUBECONFIG", kubeconfig), _probe(module, returncode=0):
        assert module.pod_security_admission_enforced() is False


def test_probe_reads_an_unrelated_failure_as_unknown(tmp_path):
    """An apiserver we cannot reach is not evidence that enforcement is off."""
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with (
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
        _probe(module, returncode=1, stderr="The connection to the server was refused"),
    ):
        assert module.pod_security_admission_enforced() is None


def test_probe_is_unknown_when_the_probe_namespace_overrides_the_level(tmp_path):
    """One stray label on the probe namespace must not restart every node in the cluster."""
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with (
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
        _probe(module, returncode=0, ns_labels={module.ENFORCE_LABEL: "privileged"}),
    ):
        assert module.pod_security_admission_enforced() is None


def test_even_a_matching_label_disqualifies_the_probe(tmp_path):
    """A labelled probe namespace measures the label, not the config.

    A node whose kube-apiserver still has RKE2's `enforce: privileged` config loaded would
    self-certify off a `default` namespace labelled `enforce=baseline`, skip the rolling
    restart, and publish its digest as in force.
    """
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with (
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
        _probe(
            module,
            returncode=1,
            stderr='violates PodSecurity "baseline:latest"',
            ns_labels={module.ENFORCE_LABEL: module.PSS_ENFORCE_LEVEL},
        ),
    ):
        assert module.pod_security_admission_enforced() is None


def test_an_unlabelled_probe_namespace_measures_the_cluster_default(tmp_path):
    module = _load_pss_module()
    kubeconfig = tmp_path / "rke2.yaml"
    kubeconfig.write_text("apiVersion: v1\n")

    with (
        patch.object(module, "RKE2_KUBECONFIG", kubeconfig),
        _probe(module, returncode=1, stderr='violates PodSecurity "baseline:latest"', ns_labels={}),
    ):
        assert module.pod_security_admission_enforced() is True


def test_kubectl_never_raises():
    """An escaping TimeoutExpired reaches the SDK as a terminal error with no localState."""
    module = _load_pss_module()
    for boom in (subprocess.TimeoutExpired(cmd="kubectl", timeout=1), FileNotFoundError("kubectl")):
        with patch.object(module.subprocess, "run", side_effect=boom):
            result = module._kubectl(["get", "namespaces"])
        assert result.returncode != 0
        assert result.stdout == ""


def test_probe_is_unknown_without_a_kubeconfig(tmp_path):
    module = _load_pss_module()
    with patch.object(module, "RKE2_KUBECONFIG", tmp_path / "absent.yaml"):
        assert module.pod_security_admission_enforced() is None


def test_probe_runs_in_a_namespace_that_is_not_exempt():
    module = _load_pss_module()
    assert module.PSS_PROBE_NAMESPACE not in module.PSS_EXEMPT_NAMESPACES


# ---------------------------------------------------------------- is the file in force


def _systemd_active_since(micros: int) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(args=[], returncode=0, stdout=f"{micros}\n", stderr="")


def test_a_config_written_before_the_service_started_counts_as_loaded(tmp_path, monkeypatch):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)
    # Config is an hour old; the service started a minute ago.
    import os as _os

    _os.utime(dest, (time.time() - 3600, time.time() - 3600))

    with (
        patch.object(module, "PSS_CONFIG_FILE", dest),
        patch.object(module.subprocess, "run", return_value=_systemd_active_since(60_000_000)),
        patch("builtins.open", _uptime_open(120.0, module)),
    ):
        assert module.config_loaded_by_running_server() is True


def test_a_config_written_after_the_service_started_counts_as_not_loaded(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)  # mtime = now

    # Service entered active 10 minutes into a 20-minute uptime, i.e. 10 minutes ago.
    with (
        patch.object(module, "PSS_CONFIG_FILE", dest),
        patch.object(module.subprocess, "run", return_value=_systemd_active_since(600_000_000)),
        patch("builtins.open", _uptime_open(1200.0, module)),
    ):
        assert module.config_loaded_by_running_server() is False


def test_the_load_check_is_unknown_when_systemd_says_nothing(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)

    for stdout in ("", "0\n", "not-a-number\n"):
        reply = subprocess.CompletedProcess(args=[], returncode=0, stdout=stdout, stderr="")
        with (
            patch.object(module, "PSS_CONFIG_FILE", dest),
            patch.object(module.subprocess, "run", return_value=reply),
        ):
            assert module.config_loaded_by_running_server() is None

    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="no such unit")
    with (
        patch.object(module, "PSS_CONFIG_FILE", dest),
        patch.object(module.subprocess, "run", return_value=failed),
    ):
        assert module.config_loaded_by_running_server() is None


def test_the_load_check_never_raises(tmp_path):
    """Neither call site sits in a try; an escaping exception loses the tick's local_state."""
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)

    for boom in (subprocess.TimeoutExpired(cmd="systemctl", timeout=1), FileNotFoundError("systemctl")):
        with (
            patch.object(module, "PSS_CONFIG_FILE", dest),
            patch.object(module.subprocess, "run", side_effect=boom),
        ):
            assert module.config_loaded_by_running_server() is None


def test_the_load_check_is_unknown_without_a_config_file(tmp_path):
    module = _load_pss_module()
    with patch.object(module, "PSS_CONFIG_FILE", tmp_path / "absent.yaml"):
        assert module.config_loaded_by_running_server() is None


def test_the_load_check_tolerates_a_clock_that_stepped(tmp_path):
    """A negative age on either side means the comparison is meaningless, not False."""
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)
    import os as _os

    _os.utime(dest, (time.time() + 3600, time.time() + 3600))  # mtime in the future

    with (
        patch.object(module, "PSS_CONFIG_FILE", dest),
        patch.object(module.subprocess, "run", return_value=_systemd_active_since(60_000_000)),
        patch("builtins.open", _uptime_open(120.0, module)),
    ):
        assert module.config_loaded_by_running_server() is None


def _uptime_open(uptime: float, module):
    """Patch /proc/uptime only; let every other open through."""
    import builtins

    real_open = builtins.open

    def fake_open(path, *args, **kwargs):
        if str(path) == "/proc/uptime":
            import io

            return io.StringIO(f"{uptime} {uptime}\n")
        return real_open(path, *args, **kwargs)

    return fake_open


# ---------------------------------------------------------------- namespace label sweep


def _ns_list(*namespaces: dict) -> subprocess.CompletedProcess[str]:
    import json as _json

    return subprocess.CompletedProcess(
        args=[], returncode=0, stdout=_json.dumps({"items": list(namespaces)}), stderr=""
    )


def _ns(name: str, labels: dict | None = None) -> dict:
    return {"metadata": {"name": name, "labels": labels or {}}}


def test_tenant_namespace_labels_are_restated_when_missing():
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc")), ok]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert err is None
    assert relabelled == 1
    label_args = kubectl.call_args_list[1][0][0]
    assert label_args[:4] == ["label", "namespace", "user-abc", "--overwrite"]
    assert f"pod-security.kubernetes.io/enforce={module.PSS_ENFORCE_LEVEL}" in label_args


def test_a_stale_level_is_overwritten():
    """The flip to a stricter level has to reach namespaces created under the old one."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    stale = {**module.pod_security_namespace_labels(), module.ENFORCE_LABEL: "privileged"}

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc", stale)), ok]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert (relabelled, err) == (1, None)


def test_an_already_labelled_namespace_is_not_patched_again():
    module = _load_pss_module()

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc", module.pod_security_namespace_labels()))]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert (relabelled, err) == (0, None)
    assert kubectl.call_count == 1


def test_the_credentials_namespace_is_swept_too():
    """`user-<uuid>-secret` matches the same prefix, so it is covered by construction."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc-secret")), ok]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert (relabelled, err) == (1, None)


def test_exempt_namespaces_are_never_touched():
    module = _load_pss_module()

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [
            _ns_list(_ns("kube-system"), _ns("opa-authz-system"), _ns("local-path-storage"))
        ]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert (relabelled, err) == (0, None)
    assert kubectl.call_count == 1


def test_an_unrelated_namespace_is_not_touched():
    module = _load_pss_module()

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("someone-elses-namespace"))]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert (relabelled, err) == (0, None)
    assert kubectl.call_count == 1


def test_namespace_labels_mirror_the_admission_config():
    module = _load_pss_module()
    labels = module.pod_security_namespace_labels()
    defaults = _pod_security_plugin(module)["defaults"]

    assert labels[module.ENFORCE_LABEL] == defaults["enforce"]
    assert labels["pod-security.kubernetes.io/audit"] == defaults["audit"]
    assert labels["pod-security.kubernetes.io/warn"] == defaults["warn"]


def test_a_label_failure_is_reported_not_raised():
    module = _load_pss_module()
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="forbidden")

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc")), failed]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert relabelled == 0
    assert "forbidden" in err


def test_the_sweep_continues_past_a_namespace_it_cannot_label():
    """One terminating namespace must not stop every namespace behind it, every reconcile."""
    module = _load_pss_module()
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="terminating")
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-a"), _ns("user-b")), failed, ok]
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert relabelled == 1
    assert "terminating" in err


def test_an_unlistable_cluster_is_reported_not_raised():
    module = _load_pss_module()
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="connection refused")

    with patch.object(module, "_kubectl", return_value=failed):
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert relabelled == 0
    assert "could not list namespaces" in err


def test_a_stray_label_on_the_probe_namespace_is_stripped_not_set():
    """The probe has to measure the cluster default there, which any label would override."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    stray = {module.ENFORCE_LABEL: "privileged", "pod-security.kubernetes.io/warn": "baseline"}

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns(module.PSS_PROBE_NAMESPACE, stray)), ok]
        changed, err = module.reconcile_tenant_namespace_pss_labels()

    assert (changed, err) == (1, None)
    args = kubectl.call_args_list[1][0][0]
    assert args[:3] == ["label", "namespace", module.PSS_PROBE_NAMESPACE]
    # Removals (`key-`), never assignments.
    assert all(a.endswith("-") for a in args[3:])
    assert not any("=" in a for a in args[3:])
    assert f"{module.ENFORCE_LABEL}-" in args


def test_a_mistyped_pss_label_on_the_probe_namespace_is_stripped_too():
    """The probe disqualifies on any such key, so a key we would not set must still go."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    stray = {"pod-security.kubernetes.io/enfore": "baseline"}

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns(module.PSS_PROBE_NAMESPACE, stray)), ok]
        changed, err = module.reconcile_tenant_namespace_pss_labels()

    assert (changed, err) == (1, None)
    assert "pod-security.kubernetes.io/enfore-" in kubectl.call_args_list[1][0][0]


def test_an_unlabelled_probe_namespace_is_left_alone():
    module = _load_pss_module()

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns(module.PSS_PROBE_NAMESPACE))]
        changed, err = module.reconcile_tenant_namespace_pss_labels()

    assert (changed, err) == (0, None)
    assert kubectl.call_count == 1


def test_the_sweep_never_sets_a_label_on_the_probe_namespace():
    """Belt and braces on the self-certification trap: assignments here defeat the probe."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    desired = module.pod_security_namespace_labels()

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns(module.PSS_PROBE_NAMESPACE, desired)), ok]
        module.reconcile_tenant_namespace_pss_labels()

    for call in kubectl.call_args_list[1:]:
        assert not any("=" in a for a in call[0][0][3:])


def test_the_label_sweep_is_bounded_per_tick():
    """An unbounded run of kubectl calls on the leader's apply path can get the tick killed."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    many = [_ns(f"user-{i:04d}") for i in range(module.PSS_LABEL_SWEEP_LIMIT + 10)]

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(*many)] + [ok] * len(many)
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert err is None
    assert relabelled == module.PSS_LABEL_SWEEP_LIMIT
    # One list call plus exactly the budget of label calls.
    assert kubectl.call_count == module.PSS_LABEL_SWEEP_LIMIT + 1


def test_the_budget_counts_attempts_not_successes():
    """A namespace that fails still costs a call, so failures have to spend budget too."""
    module = _load_pss_module()
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="terminating")
    many = [_ns(f"user-{i:04d}") for i in range(module.PSS_LABEL_SWEEP_LIMIT + 10)]

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(*many)] + [failed] * len(many)
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()

    assert relabelled == 0
    assert err is not None
    assert kubectl.call_count == module.PSS_LABEL_SWEEP_LIMIT + 1


def test_every_sweep_call_is_bounded():
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(_ns("user-abc")), ok]
        module.reconcile_tenant_namespace_pss_labels()

    for call in kubectl.call_args_list:
        assert call.kwargs["timeout"] == module.PSS_LABEL_TIMEOUT_SEC


def test_the_sweep_stops_when_its_time_budget_is_gone():
    """The count cap is a proxy; wall time is the actual constraint on the apply tick."""
    module = _load_pss_module()
    ok = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
    many = [_ns(f"user-{i:04d}") for i in range(module.PSS_LABEL_SWEEP_LIMIT)]

    with patch.object(module, "_kubectl") as kubectl:
        kubectl.side_effect = [_ns_list(*many)] + [ok] * len(many)
        # A budget already spent: the list call happens, no label call does.
        relabelled, err = module.reconcile_tenant_namespace_pss_labels(budget_sec=0)

    assert (relabelled, err) == (0, None)
    assert kubectl.call_count == 1


def test_the_sweep_budget_leaves_room_for_the_restart_on_the_same_tick():
    module = _load_pss_module()
    restart = module.PSS_RESTART_TIMEOUT_SEC + module.PSS_API_WAIT_SEC
    sweep = module.PSS_LABEL_SWEEP_BUDGET_SEC + module.PSS_LABEL_TIMEOUT_SEC
    assert restart + sweep < 300


def test_the_label_sweep_survives_a_kubectl_that_cannot_run():
    module = _load_pss_module()
    with patch.object(module.subprocess, "run", side_effect=FileNotFoundError("kubectl")):
        relabelled, err = module.reconcile_tenant_namespace_pss_labels()
    assert relabelled == 0
    assert "could not list namespaces" in err


# ---------------------------------------------------------------- reconcile


def _reconcile_env(module, tmp_path, *, pss_installed: bool, option_present: bool, enforced=None):
    """Put the module's on-disk state where a test needs it. Returns (config, rke2 config)."""
    pss = tmp_path / "swarm-pss.yaml"
    cfg = tmp_path / "config.yaml"
    if pss_installed:
        pss.write_text(module.render_pod_security_admission_config())
    cfg.write_text(
        f"token: t\n{module.PSS_RKE2_OPTION}: {pss}\n" if option_present else "token: t\ncni: canal\n"
    )
    return pss, cfg


# Every reconcile call in these tests passes an api wait, as main.py does.
_READY = {"wait_api_ready": lambda: True}
_NOT_READY = {"wait_api_ready": lambda: False}


@contextmanager
def _node(module, tmp_path, *, pss_installed=True, option_present=True, verdict=None, run=None, loaded=None):
    """Patch the module onto this test's tmp_path, with a canned probe verdict.

    The on-disk restart marker is redirected too: it is the guard that survives a killed
    plugin, so a test must not read or write the host's real one. `config_loaded_by_running_server`
    is stubbed because it shells out to systemd; `loaded=None` is its "cannot tell" answer,
    which leaves the level probe as the only signal — the behaviour most tests here are about.
    """
    pss, cfg = _reconcile_env(
        module, tmp_path, pss_installed=pss_installed, option_present=option_present
    )
    run_mock = MagicMock(return_value=run) if run is not None else MagicMock()
    with (
        patch.object(module, "PSS_CONFIG_FILE", pss),
        patch.object(module, "RKE2_CONFIG_FILE", cfg),
        patch.object(module, "PSS_RESTART_MARKER_FILE", tmp_path / ".swarm-pss-restarted"),
        patch.object(module, "pod_security_admission_enforced", return_value=verdict) as probe,
        patch.object(module, "config_loaded_by_running_server", return_value=loaded),
        patch.object(module.subprocess, "run", run_mock),
    ):
        yield pss, cfg, probe, run_mock


def test_reconcile_restarts_when_the_config_is_newly_installed(tmp_path):
    module = _load_pss_module()
    with _node(
        module, tmp_path, pss_installed=False, option_present=False, verdict=True, run=_OK
    ) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is None
    assert state[module.PSS_RESTART_STATE_KEY] == module.pod_security_admission_digest()
    assert run.call_args[0][0] == ["systemctl", "restart", "rke2-server"]


def test_the_restart_guard_is_recorded_on_disk_before_the_api_wait(tmp_path):
    """local_state is only persisted if the command returns; a killed plugin returns nothing.

    The api wait is where a plugin is most likely to be killed, so without an on-disk record
    it would lose the "at most one restart per config version" guard and restart the
    apiserver on every reconcile.
    """
    module = _load_pss_module()
    marker = tmp_path / ".swarm-pss-restarted"
    digest = module.pod_security_admission_digest()
    seen: list[str] = []

    def record_at_wait() -> bool:
        seen.append(marker.read_text() if marker.is_file() else "")
        return True

    with _node(
        module, tmp_path, pss_installed=False, option_present=False, verdict=True, run=_OK
    ):
        module.reconcile_pod_security_admission({}, wait_api_ready=record_at_wait)

    assert seen == [digest]
    assert marker.read_text() == digest

    # And a reconcile that reads that marker treats the restart as already attempted, with
    # nothing in local_state.
    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        assert module.already_restarted_for({}, digest) is True
        err, _, _ = module.reconcile_pod_security_admission({})
        run.assert_not_called()
    assert "not in force" in err


def test_the_on_disk_guard_stops_a_second_restart_without_local_state(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    marker = tmp_path / ".swarm-pss-restarted"
    marker.write_text(digest)

    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({})

    assert err is not None
    assert "not in force" in err
    run.assert_not_called()


def test_reconcile_restarts_when_the_config_is_installed_but_not_in_force(tmp_path):
    """The reinstall path writes config.yaml, then `systemctl start` no-ops on a live node."""
    module = _load_pss_module()
    with _node(module, tmp_path, verdict=False, run=_OK) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({})

    assert run.call_args[0][0] == ["systemctl", "restart", "rke2-server"]
    assert state[module.PSS_RESTART_STATE_KEY] == module.pod_security_admission_digest()


def test_reconcile_is_a_no_op_on_a_steady_enforcing_node(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({})

    assert err is None
    # Nothing had to change and the probe confirms the level, so this node vouches for the
    # config it is running and the nodes behind it in the order are cleared to go.
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    assert state[module.PSS_IN_FORCE_STATE_KEY] == digest
    # The restart guard is released on convergence, so a later repair can restart again.
    assert state[module.PSS_RESTART_STATE_KEY] is None
    run.assert_not_called()


def test_the_restart_guard_is_released_once_the_level_is_in_force(tmp_path):
    """A one-shot-per-digest guard would stop a later repair from ever loading its fix."""
    module = _load_pss_module()
    marker = tmp_path / ".swarm-pss-restarted"
    digest = module.pod_security_admission_digest()
    marker.write_text(digest)

    with _node(module, tmp_path, verdict=True) as (_, _, _, run):
        assert module.already_restarted_for({}, digest) is True
        err, _props, state = module.reconcile_pod_security_admission({}, **_READY)
        assert module.already_restarted_for({}, digest) is False

    assert err is None
    assert state[module.PSS_RESTART_STATE_KEY] is None
    assert not marker.exists()
    run.assert_not_called()


def test_a_repaired_config_can_be_restarted_for_again(tmp_path):
    """The whole point of releasing the guard: health repairs the file, reconcile loads it."""
    module = _load_pss_module()

    # Converge, which releases the guard.
    with _node(module, tmp_path, verdict=True):
        _, _, state = module.reconcile_pod_security_admission({}, **_READY)

    # Someone edits the config on the host; health rewrites it; the node is permissive again.
    # The restart happens — that is what was being locked out before — and the node reports
    # that it has not confirmed the level, because this stub keeps answering `false`.
    with _node(module, tmp_path, verdict=False, run=_OK) as (pss, _cfg, _probe, run):
        pss.write_text("apiVersion: v1\nkind: AdmissionConfiguration\nplugins: []\n")
        _, _, repaired = module.health_check_pod_security_admission(state)
        err, _props, _st = module.reconcile_pod_security_admission({**state, **repaired}, **_READY)

    run.assert_called_once()
    assert err is not None
    assert "has not confirmed the level yet" in err


def test_a_config_that_postdates_the_running_server_forces_a_restart(tmp_path):
    """The level probe cannot see a level-neutral change — an edited exemption list, say."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True, loaded=False, run=_OK) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    run.assert_called_once()
    assert run.call_args[0][0] == ["systemctl", "restart", "rke2-server"]
    # And it does not get to claim the digest in the tick it loaded it.
    assert props[module.PSS_ENFORCED_PROPERTY] != module.pod_security_admission_digest()
    assert state[module.PSS_IN_FORCE_STATE_KEY] is None


def test_a_config_the_running_server_did_read_needs_no_restart(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True, loaded=True) as (_, _, _, run):
        err, props, _ = module.reconcile_pod_security_admission({}, **_READY)

    assert err is None
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    run.assert_not_called()


def test_an_unknowable_load_state_falls_back_to_the_level_probe(tmp_path):
    """A signal we cannot read is no reason to restart an apiserver."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True, loaded=None) as (_, _, _, run):
        err, props, _ = module.reconcile_pod_security_admission({}, **_READY)

    assert err is None
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    run.assert_not_called()


def test_health_fails_a_node_whose_server_never_read_the_config(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True, loaded=False):
        ok, err, state = module.health_check_pod_security_admission({}, deep=True)

    assert ok is False
    assert "postdates the running rke2-server" in err
    assert state[module.PSS_IN_FORCE_STATE_KEY] is None


def test_the_reconcile_does_not_raise_on_an_unwritable_config(tmp_path):
    """An escaping OSError costs the tick its local_state, including the restart guard."""
    module = _load_pss_module()

    with _node(module, tmp_path) as (_, _, _, run):
        with patch.object(module, "write_pod_security_admission_config", side_effect=OSError("read-only fs")):
            err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is not None
    assert "read-only fs" in err
    assert (props, state) == ({}, {})
    run.assert_not_called()


def test_the_health_check_does_not_raise_on_an_unreadable_config(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path):
        with patch.object(module.Path, "read_text", side_effect=OSError("io error")):
            ok, err, state = module.health_check_pod_security_admission({}, deep=True)

    assert ok is False
    assert "io error" in err
    assert state == {}


def test_a_server_that_never_came_up_with_the_config_is_not_a_dead_end(tmp_path):
    """A restart that timed out must not escalate to a permanent error on the next tick."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    spent = {module.PSS_RESTART_STATE_KEY: digest}

    with _node(module, tmp_path, verdict=False, loaded=False) as (_, _, _, run):
        err, _props, _state = module.reconcile_pod_security_admission(spent, **_READY)

    assert err is not None
    assert "has not come up with" in err
    # And no second restart: that would be a loop on every apply retry.
    run.assert_not_called()


def test_a_server_that_did_read_the_config_and_is_still_permissive_is_reported(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    spent = {module.PSS_RESTART_STATE_KEY: digest}

    with _node(module, tmp_path, verdict=False, loaded=True) as (_, _, _, run):
        err, _props, _state = module.reconcile_pod_security_admission(spent, **_READY)

    assert err is not None
    assert "not in force" in err
    run.assert_not_called()


def test_a_spent_attempt_is_not_restarted_for_again_after_a_config_rewrite(tmp_path):
    """The guard is consulted on the config-changed branch too, not only on a false probe."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    spent = {module.PSS_RESTART_STATE_KEY: digest}

    # pss_installed=False forces config_changed=True on this tick.
    with _node(module, tmp_path, pss_installed=False, loaded=False, verdict=None) as (_, _, _, run):
        err, _props, _state = module.reconcile_pod_security_admission(spent, **_READY)

    assert err is not None
    run.assert_not_called()


def test_reconcile_does_not_restart_on_an_unreadable_apiserver(tmp_path):
    """An unknown probe must not be read as "permissive" and bounce the apiserver."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=None) as (_, _, _, run):
        err, props, state = module.reconcile_pod_security_admission({})

    assert err is None
    assert props == {module.PSS_ENFORCED_PROPERTY: module.PSS_ENFORCED_UNKNOWN}
    assert module.PSS_RESTART_STATE_KEY not in state
    run.assert_not_called()


def test_reconcile_restarts_at_most_once_per_config_version(tmp_path):
    """If a restart did not fix it, report the node rather than bouncing it every reconcile."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        state_in = {module.PSS_RESTART_STATE_KEY: module.pod_security_admission_digest()}
        err, props, state = module.reconcile_pod_security_admission(state_in)

    assert err is not None
    assert "not in force" in err
    run.assert_not_called()


def test_reconcile_reports_a_failed_restart(tmp_path):
    module = _load_pss_module()
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="unit not found")

    with _node(module, tmp_path, pss_installed=False, option_present=False, run=failed):
        err, props, state = module.reconcile_pod_security_admission({})

    assert err is not None
    assert "unit not found" in err


def test_reconcile_turns_a_restart_timeout_into_a_postpone(tmp_path):
    """A raised TimeoutExpired would reach the SDK as a terminal error instead of a retry."""
    module = _load_pss_module()

    with _node(module, tmp_path, pss_installed=False, option_present=False) as (_, _, _, run):
        run.side_effect = subprocess.TimeoutExpired(cmd="systemctl", timeout=120)
        err, props, state = module.reconcile_pod_security_admission({})

    assert err is not None
    assert "did not finish" in err
    assert state[module.PSS_RESTART_STATE_KEY] == module.pod_security_admission_digest()


def test_the_whole_restart_step_is_bounded(tmp_path):
    """It has to leave room for the probes and the label sweep on the same tick."""
    module = _load_pss_module()
    assert module.PSS_RESTART_TIMEOUT_SEC + module.PSS_API_WAIT_SEC < module.pss_worst_case_seconds()
    assert module.pss_worst_case_seconds() < 300


# ---------------------------------------------------------------- rolling restart order

_OK = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

D1 = "sha256/config-one"
D2 = "sha256/config-two"


def test_restart_order_is_sorted_node_ids():
    module = _load_pss_module()
    assert module.pss_restart_order(["node-c", "node-a", "node-b"]) == ["node-a", "node-b", "node-c"]


def test_restart_order_is_identical_on_every_node_that_computes_it():
    """No lock: serialisation only works if every node derives the same sequence."""
    module = _load_pss_module()
    from itertools import permutations

    members = ["node-c", "node-a", "node-b"]
    orders = {tuple(module.pss_restart_order(list(p))) for p in permutations(members)}
    assert len(orders) == 1


def test_restart_order_does_not_depend_on_the_elected_leader():
    """A handover makes two nodes read different leaders; leader-first would put both first."""
    module = _load_pss_module()
    import inspect

    assert "leader" not in inspect.signature(module.pss_restart_order).parameters


def test_the_first_node_in_the_order_restarts_immediately():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b"])
    assert module.pss_restart_blocked_by(order, "node-a", {}, D1) is None


def test_a_later_node_waits_for_the_one_ahead_of_it():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b"])
    assert module.pss_restart_blocked_by(order, "node-b", {}, D1) == "node-a"
    assert module.pss_restart_blocked_by(order, "node-b", {"node-a": D1}, D1) is None


def test_the_gate_keys_on_the_config_digest_not_a_boolean():
    """Raising the enforced level changes the digest; a boolean would clear every node at once.

    A node still running the previous config keeps rejecting the probe, so a boolean verdict
    would read 'done' on every predecessor the moment the level is raised and let the whole
    control plane restart together.
    """
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b", "node-c"])
    # Everyone finished the previous rollout.
    previous = {"node-a": D1, "node-b": D1, "node-c": D1}

    # New config version: only the first node may go.
    cleared = [n for n in order if module.pss_restart_blocked_by(order, n, previous, D2) is None]
    assert cleared == ["node-a"]

    previous["node-a"] = D2
    cleared = [n for n in order if module.pss_restart_blocked_by(order, n, previous, D2) is None]
    assert cleared == ["node-a", "node-b"]


def test_only_one_pending_node_at_a_time_may_restart():
    """Three control-plane nodes restarting together costs the cluster its etcd quorum."""
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b", "node-c"])

    def cleared_and_pending(done: dict) -> list[str]:
        return [
            n
            for n in order
            if done.get(n) != D1 and module.pss_restart_blocked_by(order, n, done, D1) is None
        ]

    done: dict = {}
    assert cleared_and_pending(done) == ["node-a"]
    done["node-a"] = D1
    assert cleared_and_pending(done) == ["node-b"]
    done["node-b"] = D1
    assert cleared_and_pending(done) == ["node-c"]
    done["node-c"] = D1
    assert cleared_and_pending(done) == []


def test_a_node_waits_on_a_predecessor_that_is_not_enforcing():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b"])
    for value in (module.PSS_ENFORCED_FALSE, module.PSS_ENFORCED_UNKNOWN, D2):
        assert module.pss_restart_blocked_by(order, "node-b", {"node-a": value}, D1) == "node-a"


def test_a_node_outside_the_published_membership_is_not_gated():
    """A joining node is not serving the cluster, so it cannot cost quorum."""
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a"])
    assert module.pss_restart_blocked_by(order, "joining-node", {}, D1) is None


def test_the_wait_is_scoped_to_the_config_version_it_was_recorded_for():
    module = _load_pss_module()
    ancient = time.time() - 30 * 86400

    assert module.pss_gate_wait_started({"digest": D1, "at": ancient}, D1) == ancient
    assert module.pss_gate_wait_started({"digest": D1, "at": ancient}, D2) is None
    # Shapes a previous release could have left behind.
    assert module.pss_gate_wait_started(ancient, D1) is None
    assert module.pss_gate_wait_started(None, D1) is None
    assert module.pss_gate_wait_started({"digest": D1, "at": "soon"}, D1) is None


def test_the_gate_times_out_rather_than_wedging_forever():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b"])
    fresh = time.time()
    assert module.pss_restart_blocked_by(order, "node-b", {}, D1, waiting_since=fresh) == "node-a"

    index = order.index("node-b")
    expired = time.time() - (module.PSS_GATE_TIMEOUT_SEC + index * module.PSS_GATE_STAGGER_SEC) - 1
    assert module.pss_restart_blocked_by(order, "node-b", {}, D1, waiting_since=expired) is None


def test_the_timeout_is_staggered_so_two_nodes_never_expire_together():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b", "node-c"])
    # All three started waiting at the same moment; node-b's deadline (index 1) has passed,
    # node-c's (index 2, one stagger later) has not.
    since = time.time() - (module.PSS_GATE_TIMEOUT_SEC + module.PSS_GATE_STAGGER_SEC) - 1
    cleared = [
        n for n in order[1:] if module.pss_restart_blocked_by(order, n, {}, D1, waiting_since=since) is None
    ]
    assert cleared == ["node-b"]
    assert module.PSS_GATE_STAGGER_SEC > 0


def test_the_stagger_is_at_least_a_whole_worst_case_restart():
    """Two nodes reaching the bypass must not have overlapping restarts.

    They go one stagger apart. If the first is still coming back when the second fires, two
    etcd members are down at once — the quorum loss the gate exists to prevent. So the
    stagger is derived from the restart budget and neither may be raised on its own.
    """
    module = _load_pss_module()
    restart = module.PSS_RESTART_TIMEOUT_SEC + module.PSS_API_WAIT_SEC
    assert module.PSS_GATE_STAGGER_SEC >= restart


def test_the_gate_timeout_beats_a_legitimate_restart_by_a_margin():
    """It should only fire for a member that is genuinely stuck, not a slow one."""
    module = _load_pss_module()
    restart = module.PSS_RESTART_TIMEOUT_SEC + module.PSS_API_WAIT_SEC
    assert module.PSS_GATE_TIMEOUT_SEC > restart * 2


def test_a_node_that_never_waited_is_not_timed_out():
    module = _load_pss_module()
    order = module.pss_restart_order(["node-a", "node-b"])
    assert module.pss_restart_blocked_by(order, "node-b", {}, D1, waiting_since=None) == "node-a"


# ---------------------------------------------------------------- reconcile and the gate


def test_reconcile_does_not_restart_while_the_gate_is_closed(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=False) as (
        _, _, _, run
    ):
        err, props, state = module.reconcile_pod_security_admission(
            {}, restart_blocked_by=lambda digest: "other-node"
        )

    assert err is not None
    assert "other-node" in err
    run.assert_not_called()
    assert module.PSS_RESTART_STATE_KEY not in state
    waiting = state[module.PSS_GATE_WAIT_SINCE_STATE_KEY]
    assert waiting["digest"] == module.pod_security_admission_digest()
    assert isinstance(waiting["at"], float)


def test_reconcile_keeps_the_original_wait_start_across_ticks(tmp_path):
    module = _load_pss_module()
    started = time.time() - 120

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=False):
        digest = module.pod_security_admission_digest()
        _, _, state = module.reconcile_pod_security_admission(
            {module.PSS_GATE_WAIT_SINCE_STATE_KEY: {"digest": digest, "at": started}},
            restart_blocked_by=lambda d: "other-node",
        )

    assert state[module.PSS_GATE_WAIT_SINCE_STATE_KEY] == {"digest": digest, "at": started}


def test_reconcile_clears_the_wait_on_every_unblocked_path(tmp_path):
    """A wait left behind would make the timeout bypass fire on the next config version."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    stale = {module.PSS_GATE_WAIT_SINCE_STATE_KEY: {"digest": digest, "at": time.time() - 99}}

    # An inconclusive probe is deliberately NOT in this list: clearing the wait on a blip
    # would let intermittent failures reset the timeout forever, so a node behind a stuck
    # predecessor would never get its bypass.
    for extra in (
        {},
        {module.PSS_IN_FORCE_STATE_KEY: digest, module.PSS_PROBE_AT_STATE_KEY: time.time()},
    ):
        with _node(module, tmp_path, verdict=True):
            _, _, state = module.reconcile_pod_security_admission({**stale, **extra})

        assert state[module.PSS_GATE_WAIT_SINCE_STATE_KEY] is None


def test_an_inconclusive_probe_keeps_the_accumulated_wait(tmp_path):
    """Otherwise intermittent blips reset the timeout and the bypass never fires."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    waiting = {"digest": digest, "at": time.time() - 99}

    with _node(module, tmp_path, verdict=None):
        _, _, state = module.reconcile_pod_security_admission(
            {module.PSS_GATE_WAIT_SINCE_STATE_KEY: waiting}
        )

    assert module.PSS_GATE_WAIT_SINCE_STATE_KEY not in state


def test_reconcile_restarts_once_the_gate_opens(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=True, run=_OK) as (
        _, _, _, run
    ):
        err, props, state = module.reconcile_pod_security_admission(
            {}, restart_blocked_by=lambda digest: None
        )

    assert run.call_args[0][0] == ["systemctl", "restart", "rke2-server"]
    assert state[module.PSS_GATE_WAIT_SINCE_STATE_KEY] is None


def test_the_gate_callback_receives_the_current_config_digest(tmp_path):
    module = _load_pss_module()
    seen: list[str] = []

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=False):
        module.reconcile_pod_security_admission(
            {}, restart_blocked_by=lambda digest: seen.append(digest) or "other"
        )

    assert seen == [module.pod_security_admission_digest()]


def test_three_nodes_roll_through_the_gate_without_any_timeout_firing(tmp_path):
    """The rollout has to advance on the gate, not on the bypass.

    This is the regression test for the version that published `unknown` on the restarting
    tick and left the digest to "the next reconcile": from the third node onwards every node
    then advanced only when `PSS_GATE_TIMEOUT_SEC` expired, which is the opposite of a gate.
    Here the whole cluster converges with `waiting_since` pinned to *now*, so the bypass
    cannot fire — if it has to, this test fails.
    """
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    nodes = ["node-a", "node-b", "node-c"]
    order = module.pss_restart_order(nodes)

    published: dict[str, str] = {}
    restarts: list[str] = []
    # One directory per node: each has its own config file and its own restart marker.
    dirs = {n: tmp_path / n for n in nodes}
    for d in dirs.values():
        d.mkdir()
    local_state = {n: {} for n in nodes}

    def gate(node):
        # `waiting_since` is always "just now", so the timeout bypass can never apply.
        return lambda d: module.pss_restart_blocked_by(
            order, node, published, d, waiting_since=time.time()
        )

    # Converge the cluster, one reconcile per node per round, in a stable order.
    for _round in range(len(nodes) + 2):
        for node in nodes:
            installed = published.get(node) == digest
            with _node(
                module,
                dirs[node],
                pss_installed=installed,
                option_present=installed,
                verdict=True,
                loaded=True,
                run=_OK,
            ) as (_, _, _, run):
                _err, props, st = module.reconcile_pod_security_admission(
                    local_state[node], restart_blocked_by=gate(node), **_READY
                )
                if run.call_args_list:
                    restarts.append(node)
            local_state[node] = {**local_state[node], **st}
            # The reconcile returns node properties keyed by property *name*; SwarmDB holds
            # them per node, which is what the gate reads.
            published[node] = props.get(module.PSS_ENFORCED_PROPERTY)
        if all(published.get(n) == digest for n in nodes):
            break

    assert published == {n: digest for n in nodes}, published
    # Each node restarted exactly once, and in the published order.
    assert restarts == order


def test_a_node_vouches_in_the_same_tick_the_probe_confirms(tmp_path):
    """There is no guaranteed next reconcile, so deferring the claim stalls the rollout.

    A successful restart returns `completed`, and a steady member re-applies only on a plan
    change — so a node that published `unknown` here could sit on it, and every successor
    would advance on the gate's *timeout* instead of on the gate. The claim is sound in this
    tick: `systemctl restart` returned, `wait_api_ready` passed, the probe confirms the
    level, and the load check agrees the file predates the running server.
    """
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(
        module, tmp_path, pss_installed=False, option_present=False, verdict=True, loaded=True, run=_OK
    ):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is None
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    assert state[module.PSS_IN_FORCE_STATE_KEY] == digest


def test_a_node_withholds_the_claim_when_the_load_check_contradicts_the_probe(tmp_path):
    """Three agreeing signals is not a guess; two agreeing and one dissenting is."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(
        module, tmp_path, pss_installed=False, option_present=False, verdict=True, loaded=False, run=_OK
    ):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is not None
    assert props[module.PSS_ENFORCED_PROPERTY] != digest
    assert state.get(module.PSS_IN_FORCE_STATE_KEY) is None


def test_a_node_that_cannot_confirm_after_the_restart_postpones_itself(tmp_path):
    """So there *is* a next tick, rather than waiting for someone else's plan to move."""
    module = _load_pss_module()

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=None, run=_OK):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is not None
    assert "has not confirmed the level yet" in err
    assert props == {module.PSS_ENFORCED_PROPERTY: module.PSS_ENFORCED_UNKNOWN}
    # And the inconclusive verdict is not cached, so that next tick really re-measures.
    assert state[module.PSS_PROBE_VERDICT_STATE_KEY] is None


def test_reconcile_drops_a_stale_in_force_claim_when_the_config_changes(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, pss_installed=False, option_present=False, verdict=True) as (
        _, _, _, run
    ):
        _, props, state = module.reconcile_pod_security_admission(
            {module.PSS_IN_FORCE_STATE_KEY: "sha256/some-older-config"},
            restart_blocked_by=lambda d: "other-node",
        )

    assert state[module.PSS_IN_FORCE_STATE_KEY] is None
    # A verdict measured against the previous config is discarded with it.
    assert state[module.PSS_PROBE_VERDICT_STATE_KEY] is None
    assert props[module.PSS_ENFORCED_PROPERTY] != digest
    run.assert_not_called()


def test_a_permissive_probe_withdraws_the_in_force_claim(tmp_path):
    """Leaving it would let the next throttled tick republish the digest for a permissive node."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=False, run=_OK):
        err, props, state = module.reconcile_pod_security_admission(
            {module.PSS_IN_FORCE_STATE_KEY: digest}
        )

    assert props[module.PSS_ENFORCED_PROPERTY] == module.PSS_ENFORCED_FALSE
    assert state[module.PSS_IN_FORCE_STATE_KEY] is None

    # Tick 2: the throttle has not elapsed, but the claim is gone, so the node must not
    # publish the digest — and the one-restart-per-version report must fire.
    with _node(module, tmp_path, verdict=False, run=_OK):
        err2, props2, _ = module.reconcile_pod_security_admission(state)

    assert props2[module.PSS_ENFORCED_PROPERTY] != digest
    assert err2 is not None
    assert "not in force" in err2


def test_reconcile_skips_the_probe_on_a_confirmed_steady_node(tmp_path):
    """Each probe is a rejected mutating request; one per tick is a stream of audit denials."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, run):
        err, props, state = module.reconcile_pod_security_admission(
            {
                module.PSS_IN_FORCE_STATE_KEY: digest,
                module.PSS_PROBE_AT_STATE_KEY: time.time(),
            }
        )

    assert err is None
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    assert state == {module.PSS_GATE_WAIT_SINCE_STATE_KEY: None}
    probe.assert_not_called()
    run.assert_not_called()


def test_reconcile_re_probes_a_steady_node_once_the_interval_elapses(tmp_path):
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        _, props, state = module.reconcile_pod_security_admission(
            {
                module.PSS_IN_FORCE_STATE_KEY: digest,
                module.PSS_PROBE_AT_STATE_KEY: time.time() - module.PSS_PROBE_INTERVAL_SEC - 1,
            }
        )

    probe.assert_called_once()
    assert props == {module.PSS_ENFORCED_PROPERTY: digest}
    assert state[module.PSS_PROBE_AT_STATE_KEY] > 0


def test_reconcile_probes_a_node_that_has_not_confirmed_this_config_yet(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        module.reconcile_pod_security_admission({module.PSS_PROBE_AT_STATE_KEY: time.time()})

    probe.assert_called_once()


# ---------------------------------------------------------------- probe throttle


def test_the_deep_probe_is_throttled(tmp_path):
    """One rejected mutating request per node per minute would bury a real attempt."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        state_in = {
            module.PSS_PROBE_AT_STATE_KEY: time.time(),
            module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_TRUE_VERDICT,
            module.PSS_IN_FORCE_STATE_KEY: digest,
        }
        ok, err, _ = module.health_check_pod_security_admission(state_in, deep=True)

    assert (ok, err) == (True, None)
    probe.assert_not_called()


def test_the_throttle_covers_an_inconclusive_verdict_too(tmp_path):
    """Unthrottled, a stray label on the probe namespace meant a probe every 60s forever."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=None) as (_, _, probe, _run):
        state_in = {
            module.PSS_PROBE_AT_STATE_KEY: time.time(),
            module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_UNKNOWN,
            module.PSS_IN_FORCE_STATE_KEY: digest,
        }
        ok, err, _ = module.health_check_pod_security_admission(state_in, deep=True)

    assert (ok, err) == (True, None)
    probe.assert_not_called()


def test_the_throttle_reuses_a_permissive_verdict_rather_than_reporting_healthy(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=False) as (_, _, probe, _run):
        state_in = {
            module.PSS_PROBE_AT_STATE_KEY: time.time(),
            module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_FALSE,
        }
        ok, err, _ = module.health_check_pod_security_admission(state_in, deep=True)

    probe.assert_not_called()
    assert ok is False
    assert "not in force" in err


def test_the_deep_probe_runs_again_once_the_interval_elapses(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        state_in = {
            module.PSS_PROBE_AT_STATE_KEY: time.time() - module.PSS_PROBE_INTERVAL_SEC - 1,
            module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_TRUE_VERDICT,
        }
        _, _, state = module.health_check_pod_security_admission(state_in, deep=True)

    probe.assert_called_once()
    assert module.PSS_PROBE_AT_STATE_KEY in state
    assert state[module.PSS_PROBE_VERDICT_STATE_KEY] == module.PSS_ENFORCED_TRUE_VERDICT


def test_a_probe_with_no_recorded_verdict_always_runs(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        module.health_check_pod_security_admission(
            {module.PSS_PROBE_AT_STATE_KEY: time.time()}, deep=True
        )

    probe.assert_called_once()


def test_a_clock_that_moved_backwards_does_not_suppress_the_probe(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        module.health_check_pod_security_admission(
            {
                module.PSS_PROBE_AT_STATE_KEY: time.time() + 86400,
                module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_TRUE_VERDICT,
            },
            deep=True,
        )

    probe.assert_called_once()


def test_a_garbage_probe_timestamp_does_not_suppress_the_probe(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=True) as (_, _, probe, _run):
        module.health_check_pod_security_admission(
            {module.PSS_PROBE_AT_STATE_KEY: "soon"}, deep=True
        )

    probe.assert_called_once()


def test_the_deep_health_probe_fits_inside_the_health_command_budget():
    """A deep tick makes three bounded calls: the load check, the ns read, the dry-run."""
    module = _load_pss_module()
    assert module.PSS_PROBE_CALLS == 3
    assert module.PSS_PROBE_TIMEOUT_SEC * module.PSS_PROBE_CALLS <= 20


def test_everything_this_module_can_do_on_one_tick_fits_the_command_budget():
    """The restart, its readiness wait, the probes and the label sweep share one apply tick.

    Overrunning gets the tick killed by the host agent, which discards its local_state —
    including the restart guard and install_hash. Asserted here so raising any one budget
    past what the others leave room for fails loudly.
    """
    module = _load_pss_module()
    assert module.pss_worst_case_seconds() < 300


# ---------------------------------------------------------------- health check


def test_the_restart_discards_the_verdict_measured_against_the_old_apiserver(tmp_path):
    """Replaying a cached `false` would hit the restart-once guard and stall every successor."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=False, run=_OK) as (_, _, probe, _run):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    # Probed twice: once before the restart, once after, against the new apiserver. The
    # stub answers `false` both times, so the node cannot vouch and postpones itself.
    assert probe.call_count == 2
    assert err is not None
    assert "has not confirmed the level yet" in err

    # A post-restart verdict that is not True is not cached at all: one slow kubectl just
    # after the apiserver came back must not pin this node — or the nodes behind it in the
    # rolling restart — for the whole probe interval.
    assert state[module.PSS_PROBE_VERDICT_STATE_KEY] is None
    assert state[module.PSS_PROBE_AT_STATE_KEY] is None

    # So the next tick measures again, and the level it finds is the one it acts on.
    with _node(module, tmp_path, verdict=True) as (_, _, probe2, run):
        err2, props2, _state2 = module.reconcile_pod_security_admission(state, **_READY)

    probe2.assert_called_once()
    assert err2 is None
    assert props2 == {module.PSS_ENFORCED_PROPERTY: module.pod_security_admission_digest()}
    run.assert_not_called()


def test_an_apiserver_that_does_not_come_back_withdraws_k8s_node_ready(tmp_path):
    """A joining follower gates on that property; this node cannot serve it."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=False, run=_OK):
        err, props, _ = module.reconcile_pod_security_admission({}, **_NOT_READY)

    assert "did not recover" in err
    assert props[module.K8S_NODE_READY_PROPERTY] is None


def test_a_restart_timeout_also_withdraws_k8s_node_ready(tmp_path):
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        run.side_effect = subprocess.TimeoutExpired(cmd="systemctl", timeout=120)
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert "did not finish" in err
    assert props[module.K8S_NODE_READY_PROPERTY] is None
    # systemctl may still be finishing, so the attempt counts.
    assert state[module.PSS_RESTART_STATE_KEY] == module.pod_security_admission_digest()


def test_a_tick_that_did_not_restart_leaves_k8s_node_ready_alone(tmp_path):
    module = _load_pss_module()

    for verdict in (True, None):
        with _node(module, tmp_path, verdict=verdict) as (_, _, _, run):
            _, props, _ = module.reconcile_pod_security_admission({}, **_READY)
        assert module.K8S_NODE_READY_PROPERTY not in props
        run.assert_not_called()

    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        _, props, _ = module.reconcile_pod_security_admission(
            {}, restart_blocked_by=lambda d: "other-node", **_READY
        )
    assert module.K8S_NODE_READY_PROPERTY not in props
    run.assert_not_called()


def test_a_missing_systemctl_does_not_spend_the_attempt(tmp_path):
    """Nothing ran, so it is retryable — and an escaping OSError would lose the tick's state."""
    module = _load_pss_module()
    marker = tmp_path / ".swarm-pss-restarted"

    with _node(module, tmp_path, verdict=False) as (_, _, _, run):
        run.side_effect = FileNotFoundError("systemctl")
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert err is not None
    assert "Could not run systemctl" in err
    assert module.PSS_RESTART_STATE_KEY not in state
    assert module.K8S_NODE_READY_PROPERTY not in props
    assert not marker.exists()


def test_a_failed_restart_does_not_spend_the_single_attempt(tmp_path):
    """systemctl refused, so nothing restarted: a transient failure must stay retryable."""
    module = _load_pss_module()
    marker = tmp_path / ".swarm-pss-restarted"
    failed = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="unit not found")

    with _node(module, tmp_path, verdict=False, run=failed):
        err, props, state = module.reconcile_pod_security_admission({}, **_READY)

    assert "unit not found" in err
    assert module.K8S_NODE_READY_PROPERTY not in props
    assert module.PSS_RESTART_STATE_KEY not in state
    assert not marker.exists()

    # Next tick retries rather than reporting the node permanently not-in-force.
    with _node(module, tmp_path, verdict=False, run=_OK) as (_, _, _, run):
        module.reconcile_pod_security_admission(state, **_READY)
    run.assert_called_once()


def test_health_repair_withdraws_the_in_force_claim(tmp_path):
    """Otherwise reconcile republishes the digest for a node health calls unhealthy."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()
    claimed = {
        module.PSS_IN_FORCE_STATE_KEY: digest,
        module.PSS_PROBE_VERDICT_STATE_KEY: module.PSS_ENFORCED_TRUE_VERDICT,
        module.PSS_PROBE_AT_STATE_KEY: time.time(),
    }

    for break_it in ("missing", "drift"):
        with _node(module, tmp_path) as (pss, _cfg, _probe, _run):
            if break_it == "missing":
                pss.unlink()
            else:
                pss.write_text("apiVersion: v1\nkind: AdmissionConfiguration\nplugins: []\n")
            ok, _err, state = module.health_check_pod_security_admission(claimed)

        assert ok is False
        assert state[module.PSS_IN_FORCE_STATE_KEY] is None
        assert state[module.PSS_PROBE_VERDICT_STATE_KEY] is None
        assert state[module.PSS_PROBE_AT_STATE_KEY] is None


def test_health_check_passes_on_a_correctly_configured_node(tmp_path):
    module = _load_pss_module()
    with _node(module, tmp_path):
        assert module.health_check_pod_security_admission() == (True, None, {})


def test_health_check_installs_a_missing_config_rather_than_only_reporting_it(tmp_path):
    """Only apply installs the file; a node must not sit Degraded waiting for one."""
    module = _load_pss_module()
    with _node(module, tmp_path, pss_installed=False) as (pss, _cfg, _probe, _run):
        ok, err, _ = module.health_check_pod_security_admission()

        assert ok is False
        assert "installed the missing" in err
        assert pss.read_text() == module.render_pod_security_admission_config()


def test_health_check_repairs_a_drifted_config(tmp_path):
    module = _load_pss_module()
    with _node(module, tmp_path) as (pss, _cfg, _probe, _run):
        pss.write_text(
            module.render_pod_security_admission_config().replace(module.PSS_ENFORCE_LEVEL, "privileged")
        )
        ok, err, _ = module.health_check_pod_security_admission()

        assert ok is False
        assert "drifted" in err
        assert pss.read_text() == module.render_pod_security_admission_config()


def test_health_check_fails_when_rke2_is_not_pointed_at_the_config(tmp_path):
    module = _load_pss_module()
    with _node(module, tmp_path, option_present=False):
        ok, err, _ = module.health_check_pod_security_admission()

    assert ok is False
    assert module.PSS_RKE2_OPTION in err


def test_deep_health_check_fails_a_node_whose_apiserver_admits_a_privileged_pod(tmp_path):
    """Installed but never loaded is exactly what a file-only check cannot see."""
    module = _load_pss_module()
    with _node(module, tmp_path, verdict=False):
        ok, err, _ = module.health_check_pod_security_admission({}, deep=True)

    assert ok is False
    assert "not in force" in err


def test_deep_health_check_passes_when_the_apiserver_enforces(tmp_path):
    module = _load_pss_module()
    with _node(module, tmp_path, verdict=True):
        ok, err, state = module.health_check_pod_security_admission({}, deep=True)

    assert (ok, err) == (True, None)
    assert state[module.PSS_IN_FORCE_STATE_KEY] == module.pod_security_admission_digest()


def test_an_inconclusive_probe_keeps_an_already_confirmed_node_healthy(tmp_path):
    """An unreachable apiserver is not evidence that enforcement stopped."""
    module = _load_pss_module()
    confirmed = {module.PSS_IN_FORCE_STATE_KEY: module.pod_security_admission_digest()}

    with _node(module, tmp_path, verdict=None):
        assert module.health_check_pod_security_admission(confirmed, deep=True)[:2] == (True, None)


def test_an_unverifiable_node_that_never_confirmed_is_not_healthy(tmp_path):
    """The reconcile will not restart on an inconclusive probe either, so reporting ok would
    leave a node that never loaded the config looking fine indefinitely."""
    module = _load_pss_module()

    with _node(module, tmp_path, verdict=None):
        ok, err, _ = module.health_check_pod_security_admission({}, deep=True)

    assert ok is False
    assert "Could not verify" in err


def test_health_distinguishes_a_queued_node_from_a_broken_one(tmp_path):
    """Every node in a normal rollout is briefly permissive; the message has to say which."""
    module = _load_pss_module()
    digest = module.pod_security_admission_digest()

    with _node(module, tmp_path, verdict=False):
        queued = {module.PSS_GATE_WAIT_SINCE_STATE_KEY: {"digest": digest, "at": time.time() - 42}}
        ok, err, _ = module.health_check_pod_security_admission(queued, deep=True)

    assert ok is False
    assert "Queued" in err
    assert "still permissive" in err


def test_health_reports_a_node_that_is_not_queued_as_not_in_force(tmp_path):
    module = _load_pss_module()
    with _node(module, tmp_path, verdict=False):
        ok, err, _ = module.health_check_pod_security_admission({}, deep=True)

    assert ok is False
    assert "not in force" in err
    assert "Queued" not in err


# ---------------------------------------------------------------- evidence


def test_evidence_states_the_enforced_level_and_exemptions(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)

    with patch.object(module, "PSS_CONFIG_FILE", dest):
        evidence = module.pod_security_admission_evidence()

    assert evidence["defaults"]["enforce"] == module.PSS_ENFORCE_LEVEL
    assert evidence["defaults"]["audit"] == module.PSS_TARGET_LEVEL
    assert evidence["defaults"]["warn"] == module.PSS_TARGET_LEVEL
    assert evidence["defaults"]["enforceVersion"] == "latest"
    assert evidence["exemptions"]["namespaces"] == list(module.PSS_EXEMPT_NAMESPACES)
    assert evidence["exemptions"]["usernames"] == []


def test_evidence_digest_matches_the_file_the_apiserver_reads(tmp_path):
    """An external verifier must be able to recompute the digest from the installed file."""
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)

    import base64
    import hashlib

    raw = hashlib.sha256(dest.read_bytes()).digest()
    expected = "sha256/" + base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

    with patch.object(module, "PSS_CONFIG_FILE", dest):
        assert module.pod_security_admission_evidence()["configDigest"] == expected
        assert module.installed_pod_security_admission_digest() == expected


def test_evidence_is_omitted_when_the_config_is_not_installed(tmp_path):
    """Publishing a level we cannot bind to a file would assert more than we know."""
    module = _load_pss_module()
    with patch.object(module, "PSS_CONFIG_FILE", tmp_path / "absent.yaml"):
        assert module.pod_security_admission_evidence() is None
        assert module.installed_pod_security_admission_digest() is None


def test_evidence_digest_tracks_a_tampered_file(tmp_path):
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)
    with patch.object(module, "PSS_CONFIG_FILE", dest):
        clean = module.pod_security_admission_evidence()["configDigest"]
        dest.write_text(dest.read_text().replace(module.PSS_ENFORCE_LEVEL, "privileged"))
        assert module.pod_security_admission_evidence()["configDigest"] != clean


def test_rollout_evidence_counts_the_nodes_actually_enforcing():
    module = _load_pss_module()
    digest = "sha256/current"
    rollout = module.pod_security_rollout_evidence(
        ["node-a", "node-b", "node-c"],
        {"node-a": digest, "node-b": "sha256/previous", "node-c": module.PSS_ENFORCED_FALSE},
        digest,
    )
    assert rollout == {"nodeCount": 3, "nodesInForce": 1, "inForceEverywhere": False}


def test_rollout_evidence_reports_full_coverage_only_when_every_node_agrees():
    module = _load_pss_module()
    digest = "sha256/current"
    nodes = ["node-a", "node-b"]
    assert module.pod_security_rollout_evidence(nodes, dict.fromkeys(nodes, digest), digest) == {
        "nodeCount": 2,
        "nodesInForce": 2,
        "inForceEverywhere": True,
    }
    # An empty membership is not "everywhere".
    assert module.pod_security_rollout_evidence([], {}, digest)["inForceEverywhere"] is False


def test_evidence_carries_the_rollout_when_it_is_known(tmp_path):
    """The leader's own file says what the image enforces, not what every node is running."""
    module = _load_pss_module()
    dest = tmp_path / "swarm-pss.yaml"
    module.write_pod_security_admission_config(dest)
    rollout = {"nodeCount": 3, "nodesInForce": 1, "inForceEverywhere": False}

    with patch.object(module, "PSS_CONFIG_FILE", dest):
        assert module.pod_security_admission_evidence(rollout)["rollout"] == rollout
        assert "rollout" not in module.pod_security_admission_evidence()


# ---------------------------------------------------------------- main.py wiring


def _load_main_module():
    """Load main.py with the provision SDK stubbed, as the other rke2 suites do."""
    sdk = MagicMock()
    sdk.ProvisionPlugin.return_value = MagicMock()
    sys.modules.setdefault("provision_plugin_sdk", sdk)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("main", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    sys.path.insert(0, str(RKE2_DIR))
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.remove(str(RKE2_DIR))
    return module


def test_the_signed_snapshot_reports_partial_enforcement(tmp_path):
    pss = _load_pss_module()
    main = _load_main_module()
    installed = tmp_path / "swarm-pss.yaml"
    pss.write_pod_security_admission_config(installed)
    digest = pss.pod_security_admission_digest()
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
    enforced_by_node = {"node-a": digest}
    workloads = {
        "items": [
            {
                "metadata": {"name": "canal", "namespace": "kube-system", "generation": 1},
                "spec": {"template": {"spec": {"containers": [{"name": "calico", "image": "calico:v1"}]}}},
            }
        ]
    }

    with (
        patch.object(main, "_kubectl_json", return_value=workloads),
        patch.object(main, "collect_kube_system_image_digests", return_value={}),
        patch.object(pss, "PSS_CONFIG_FILE", installed),
    ):
        properties, _ = main.build_kube_system_evidence_properties(
            {}, "install-hash", cluster_nodes, enforced_by_node
        )

    import json

    rollout = json.loads(properties["kube_system_snapshot_json"])["podSecurity"]["rollout"]
    assert rollout == {"nodeCount": 2, "nodesInForce": 1, "inForceEverywhere": False}


def test_both_call_sites_wait_for_the_apiserver_after_the_restart():
    """Returning with it down would make every caller special-case a half-restarted node."""
    pss = _load_pss_module()
    source = (RKE2_DIR / "main.py").read_text()

    assert source.count("wait_api_ready=lambda: wait_for_api_ready(timeout_sec=PSS_API_WAIT_SEC)") == 2
    assert pss.PSS_API_WAIT_SEC > 0


def test_the_rollout_count_includes_what_this_tick_publishes():
    """rke2_props is the pre-apply snapshot; without the overlay the count lags a reconcile."""
    pss = _load_pss_module()
    main = _load_main_module()
    digest = "sha256/current"
    rke2_props = [{"node_id": "node-a", "name": pss.PSS_ENFORCED_PROPERTY, "value": digest}]

    without = main.pss_enforced_by_node(rke2_props)
    assert "node-b" not in without

    with_overlay = main.pss_enforced_now(
        rke2_props, "node-b", {pss.PSS_ENFORCED_PROPERTY: digest}
    )
    assert with_overlay == {"node-a": digest, "node-b": digest}

    rollout = pss.pod_security_rollout_evidence(["node-a", "node-b"], with_overlay, digest)
    assert rollout["inForceEverywhere"] is True


def test_the_overlay_is_a_no_op_when_this_node_published_nothing():
    pss = _load_pss_module()
    main = _load_main_module()
    rke2_props = [{"node_id": "node-a", "name": pss.PSS_ENFORCED_PROPERTY, "value": "d"}]
    assert main.pss_enforced_now(rke2_props, "node-b", {}) == {"node-a": "d"}


def test_the_restart_gate_stays_closed_with_nothing_published():
    """With no digests published, every node but the first has to wait."""
    main = _load_main_module()
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}, {"node_id": "node-c"}]

    assert main.build_pss_restart_gate(cluster_nodes, [], "node-a", {})("d") is None
    for node in ("node-b", "node-c"):
        assert main.build_pss_restart_gate(cluster_nodes, [], node, {})("d") == "node-a"


def test_the_gate_does_not_consult_node_readiness():
    """A NotReady predecessor is the one mid-restart: skipping it is backwards.

    Liveness comes from the membership — `remove_stale_nodes` reaps a node that is really
    gone — and a present-but-stuck member is handled by the timeout.
    """
    main = _load_main_module()
    import inspect

    assert not hasattr(main, "k8s_ready_node_ids")
    pss = _load_pss_module()
    assert "ready_nodes" not in inspect.signature(pss.pss_restart_blocked_by).parameters


def test_build_pss_restart_gate_reads_the_published_digests():
    pss = _load_pss_module()
    main = _load_main_module()
    digest = "sha256/current"
    cluster_nodes = [{"node_id": "node-c"}, {"node_id": "node-a"}, {"node_id": "node-b"}]
    rke2_props = [
        {"node_id": "node-a", "name": pss.PSS_ENFORCED_PROPERTY, "value": digest},
        {"node_id": "node-a", "name": "k8s_node_ready", "value": "true"},
        {"node_id": "node-b", "name": "k8s_node_ready", "value": "true"},
        {"node_id": "node-c", "name": "k8s_node_ready", "value": "true"},
    ]

    assert main.build_pss_restart_gate(cluster_nodes, rke2_props, "node-a", {})(digest) is None
    assert main.build_pss_restart_gate(cluster_nodes, rke2_props, "node-b", {})(digest) is None
    assert main.build_pss_restart_gate(cluster_nodes, rke2_props, "node-c", {})(digest) == "node-b"


def test_build_pss_restart_gate_holds_everyone_behind_the_first_node():
    main = _load_main_module()
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}, {"node_id": "node-c"}]
    ready = [
        {"node_id": n, "name": "k8s_node_ready", "value": "true"} for n in ("node-a", "node-b", "node-c")
    ]

    assert main.build_pss_restart_gate(cluster_nodes, ready, "node-a", {})("d") is None
    for node in ("node-b", "node-c"):
        assert main.build_pss_restart_gate(cluster_nodes, ready, node, {})("d") == "node-a"


def test_build_pss_restart_gate_passes_the_recorded_wait_start():
    pss = _load_pss_module()
    main = _load_main_module()
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
    expired = time.time() - (pss.PSS_GATE_TIMEOUT_SEC + pss.PSS_GATE_STAGGER_SEC) - 1

    assert main.build_pss_restart_gate(cluster_nodes, [], "node-b", {})("d") == "node-a"

    waiting = {pss.PSS_GATE_WAIT_SINCE_STATE_KEY: {"digest": "d", "at": expired}}
    assert main.build_pss_restart_gate(cluster_nodes, [], "node-b", waiting)("d") is None


def test_a_wait_recorded_for_an_older_config_version_is_ignored():
    """Otherwise a node that converged out of band fires the bypass instantly on the next
    version — on every such node at once, which is the restart storm the gate prevents."""
    pss = _load_pss_module()
    main = _load_main_module()
    cluster_nodes = [{"node_id": "node-a"}, {"node_id": "node-b"}]
    ancient = time.time() - 30 * 86400

    stale = {pss.PSS_GATE_WAIT_SINCE_STATE_KEY: {"digest": "old-config", "at": ancient}}
    assert main.build_pss_restart_gate(cluster_nodes, [], "node-b", stale)("new-config") == "node-a"

    # A bare timestamp from an older release is ignored for the same reason.
    legacy = {pss.PSS_GATE_WAIT_SINCE_STATE_KEY: ancient}
    assert main.build_pss_restart_gate(cluster_nodes, [], "node-b", legacy)("new-config") == "node-a"


def test_the_enforced_property_uses_a_prefix_the_plugin_state_expr_selects():
    """stateExpr only forwards k8s_/rke2_/kube_system_ properties; a gate cannot see others."""
    pss = _load_pss_module()
    assert pss.PSS_ENFORCED_PROPERTY.startswith(("k8s_", "rke2_", "kube_system_"))
    manifest = (RKE2_DIR / "manifest.yaml").read_text()
    prefix = pss.PSS_ENFORCED_PROPERTY.split("_")[0] + "_"
    assert f'startswith("{prefix}")' in manifest


def test_destroy_requests_deletion_of_the_enforced_property():
    pss = _load_pss_module()
    main = _load_main_module()
    source = (RKE2_DIR / "main.py").read_text()
    assert "PSS_ENFORCED_PROPERTY: None" in source
    assert pss.PSS_ENFORCED_PROPERTY == "k8s_pss_enforced"
    assert main.PSS_ENFORCED_PROPERTY == pss.PSS_ENFORCED_PROPERTY


def test_write_rke2_config_points_the_apiserver_at_the_restricted_config(tmp_path):
    main = _load_main_module()
    cfg = tmp_path / "config.yaml"

    with patch.object(main, "RKE2_CONFIG_DIR", tmp_path), patch.object(main, "RKE2_CONFIG_FILE", cfg):
        main.write_rke2_config("node-1", "10.13.0.1", True, None, ["10.13.0.1"], "k8s.example.test")

    parsed = yaml.safe_load(cfg.read_text())
    assert parsed["pod-security-admission-config-file"] == str(_load_pss_module().PSS_CONFIG_FILE)
    # Still a valid RKE2 server config otherwise.
    assert parsed["cni"] == "canal"
    assert parsed["node-ip"] == "10.13.0.1"


def test_write_rke2_config_keeps_the_option_across_rewrites(tmp_path):
    main = _load_main_module()
    cfg = tmp_path / "config.yaml"

    with patch.object(main, "RKE2_CONFIG_DIR", tmp_path), patch.object(main, "RKE2_CONFIG_FILE", cfg):
        main.write_rke2_config("node-1", "10.13.0.1", True, None, ["10.13.0.1"])
        main.write_rke2_config("node-1", "10.13.0.1", False, "10.13.0.2", ["10.13.0.1", "10.13.0.2"])

    text = cfg.read_text()
    assert text.count("pod-security-admission-config-file:") == 1
    assert yaml.safe_load(text)["pod-security-admission-config-file"] == str(_load_pss_module().PSS_CONFIG_FILE)


def test_kube_system_snapshot_carries_the_enforced_pss_level(tmp_path):
    # Load the pss module first: main.py binds whichever instance is in sys.modules when it
    # is imported, so patching a later instance would patch something main never calls.
    pss = _load_pss_module()
    main = _load_main_module()
    installed = tmp_path / "swarm-pss.yaml"
    pss.write_pod_security_admission_config(installed)

    with (
        patch.object(main, "_kubectl_json", return_value={"items": []}),
        patch.object(pss, "PSS_CONFIG_FILE", installed),
    ):
        snapshot = main.collect_kube_system_workload_snapshot()

    assert snapshot["podSecurity"]["defaults"]["enforce"] == pss.PSS_ENFORCE_LEVEL
    assert snapshot["podSecurity"]["exemptions"]["namespaces"] == list(pss.PSS_EXEMPT_NAMESPACES)


def test_kube_system_snapshot_omits_pss_when_the_config_is_not_installed(tmp_path):
    pss = _load_pss_module()
    main = _load_main_module()

    with (
        patch.object(main, "_kubectl_json", return_value={"items": []}),
        patch.object(pss, "PSS_CONFIG_FILE", tmp_path / "absent.yaml"),
    ):
        snapshot = main.collect_kube_system_workload_snapshot()

    assert "podSecurity" not in snapshot


def test_evidence_properties_publish_the_pss_level_inside_the_signed_snapshot(tmp_path):
    pss = _load_pss_module()
    main = _load_main_module()
    installed = tmp_path / "swarm-pss.yaml"
    pss.write_pod_security_admission_config(installed)
    workloads = {
        "items": [
            {
                "metadata": {"name": "canal", "namespace": "kube-system", "generation": 1},
                "spec": {"template": {"spec": {"containers": [{"name": "calico", "image": "calico:v1"}]}}},
            }
        ]
    }

    with (
        patch.object(main, "_kubectl_json", return_value=workloads),
        patch.object(main, "collect_kube_system_image_digests", return_value={}),
        patch.object(pss, "PSS_CONFIG_FILE", installed),
    ):
        properties, _ = main.build_kube_system_evidence_properties({}, "install-hash")

    import json

    body = json.loads(properties["kube_system_snapshot_json"])
    assert body["podSecurity"]["defaults"]["enforce"] == pss.PSS_ENFORCE_LEVEL
    assert body["podSecurity"]["configDigest"] == pss.installed_pod_security_admission_digest(installed)
    # The published digest must be reproducible from the published body.
    assert properties["kube_system_snapshot_digest"] == main._sha256_b64url(
        main._canonical_json(body).encode("utf-8")
    )
