#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import hashlib
import secrets
import time
import stat
import urllib.request
import urllib.error
from pathlib import Path

from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

# Configuration
MINIO_IMAGE = os.environ.get("MINIO_IMAGE", "cgr.dev/chainguard/minio:latest")
MINIO_CLIENT_IMAGE = os.environ.get("MINIO_CLIENT_IMAGE", "cgr.dev/chainguard/minio-client:latest")
MINIO_PORT = 9000
MINIO_CONSOLE_PORT = 9001
MINIO_CONFIG_DIR = Path("/etc/minio")
MINIO_HOST_DATA_DIR = Path("/var/lib/minio/data")
MINIO_CONTAINER_DATA_DIR = "/data"
MINIO_ENV_FILE = MINIO_CONFIG_DIR / "minio.env"
MINIO_SERVICE_UNIT = "minio.service"
MINIO_SERVICE_NAME = MINIO_SERVICE_UNIT.removesuffix(".service")
MINIO_CONTAINER_NAME = "minio"
MINIO_CONTAINER_UID = 65532
MINIO_CONTAINER_GID = 65532

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions

def compute_install_hash(state_json: dict) -> str:
    """Compute hash of cluster configuration to detect changes."""
    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])

    node_ids = sorted([n["node_id"] for n in cluster_nodes])

    tunnel_ip_map = {}
    for prop in wg_props:
        if prop.get("name") == "tunnel_ip":
            tunnel_ip_map[prop.get("node_id")] = prop.get("value")

    wg_addresses = []
    for node_id in node_ids:
        tunnel_ip = tunnel_ip_map.get(node_id, "unknown")
        wg_addresses.append(f"{node_id}={tunnel_ip}")

    payload = (
        "|".join(node_ids)
        + "|"
        + "|".join(wg_addresses)
        + "|"
        + str(MINIO_PORT)
        + "|"
        + MINIO_IMAGE
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def is_cluster_initialized(minio_props: list) -> bool:
    """Check if cluster is already initialized by any node."""
    for prop in minio_props:
        if prop.get("name") == "minio_cluster_initialized" and prop.get("value") == "true":
            return True
    return False


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")


def pull_image(image_ref: str):
    """Pull container image with podman."""
    result = subprocess.run(
        ["podman", "pull", image_ref],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if result.returncode != 0:
        error = result.stderr.strip() or result.stdout.strip()
        raise Exception(f"Failed to pull image {image_ref}: {error}")


def reconcile_owner_and_mode(path: str | Path, expected_mode: int):
    """Apply owner/mode only when path metadata does not match."""
    st = os.stat(path, follow_symlinks=False)
    if st.st_uid != MINIO_CONTAINER_UID or st.st_gid != MINIO_CONTAINER_GID:
        os.chown(path, MINIO_CONTAINER_UID, MINIO_CONTAINER_GID)
    if stat.S_IMODE(st.st_mode) != expected_mode:
        os.chmod(path, expected_mode)


def ensure_data_dir_permissions(recursive: bool = False):
    """Ensure mounted data dir is writable for MinIO container user."""
    MINIO_HOST_DATA_DIR.mkdir(parents=True, exist_ok=True)
    reconcile_owner_and_mode(MINIO_HOST_DATA_DIR, 0o750)

    if not recursive:
        return

    # MinIO may fail if pre-existing files are owned by root from older runs.
    for root, dirs, files in os.walk(MINIO_HOST_DATA_DIR):
        reconcile_owner_and_mode(root, 0o750)
        for d in dirs:
            p = os.path.join(root, d)
            reconcile_owner_and_mode(p, 0o750)
        for f in files:
            p = os.path.join(root, f)
            reconcile_owner_and_mode(p, 0o640)


def generate_credentials() -> tuple[str, str]:
    """Generate root credentials for MinIO."""
    root_user = "minioadmin"
    root_password = secrets.token_urlsafe(32)
    return root_user, root_password


def get_leader_credentials(minio_props: list) -> tuple[str | None, str | None]:
    """Read root credentials published by the leader node."""
    root_user = None
    root_password = None
    for prop in minio_props:
        if prop.get("name") == "minio_root_user":
            root_user = prop.get("value")
        elif prop.get("name") == "minio_root_password":
            root_password = prop.get("value")
    return root_user, root_password


def build_volume_string(cluster_nodes: list, wg_props: list) -> str:
    """Build MinIO volume string for distributed or standalone mode.

    Deterministic across all nodes: sorted by node_id.
    - 1 node:  local container path (standalone)
    - 2+ nodes: space-separated http://{ip}:9000/data
    """
    node_ids = sorted([n["node_id"] for n in cluster_nodes])

    if len(node_ids) == 1:
        return MINIO_CONTAINER_DATA_DIR

    tunnel_ip_map = {}
    for prop in wg_props:
        if prop.get("name") == "tunnel_ip":
            tunnel_ip_map[prop.get("node_id")] = prop.get("value")

    endpoints = []
    for node_id in node_ids:
        ip = tunnel_ip_map.get(node_id)
        if ip:
            endpoints.append(f"http://{ip}:{MINIO_PORT}{MINIO_CONTAINER_DATA_DIR}")

    return " ".join(endpoints)


def write_minio_env(root_user: str, root_password: str):
    """Write /etc/minio/minio.env with credentials."""
    MINIO_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    content = (
        f'MINIO_ROOT_USER="{root_user}"\n'
        f'MINIO_ROOT_PASSWORD="{root_password}"\n'
    )

    MINIO_ENV_FILE.write_text(content)
    os.chmod(MINIO_ENV_FILE, 0o600)


def create_systemd_service(tunnel_ip: str, volumes: str):
    """Create systemd service unit for MinIO container."""
    if not tunnel_ip:
        raise ValueError("tunnel_ip is required")
    if not volumes:
        raise ValueError("volumes are required")

    minio_args = f"server --address {tunnel_ip}:{MINIO_PORT} --console-address {tunnel_ip}:{MINIO_CONSOLE_PORT} {volumes}"
    service_content = f"""[Unit]
Description=MinIO Object Storage (Podman)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile={MINIO_ENV_FILE}
ExecStartPre=-/usr/bin/podman stop {MINIO_CONTAINER_NAME}
ExecStartPre=-/usr/bin/podman rm {MINIO_CONTAINER_NAME}
ExecStart=/usr/bin/podman run \\
    --name {MINIO_CONTAINER_NAME} \\
    --rm \\
    --pull=never \\
    --network=host \\
    -v {MINIO_HOST_DATA_DIR}:{MINIO_CONTAINER_DATA_DIR}:z \\
    -e MINIO_ROOT_USER=${{MINIO_ROOT_USER}} \\
    -e MINIO_ROOT_PASSWORD=${{MINIO_ROOT_PASSWORD}} \\
    {MINIO_IMAGE} \\
    {minio_args}
ExecStop=/usr/bin/podman stop {MINIO_CONTAINER_NAME}
Restart=always
RestartSec=10
LimitNOFILE=65536
TimeoutStopSec=120
User=root
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    service_path = f"/etc/systemd/system/{MINIO_SERVICE_UNIT}"
    with open(service_path, "w") as f:
        f.write(service_content)

    subprocess.run(["systemctl", "daemon-reload"], check=False)


def wait_for_minio_ready(tunnel_ip: str, timeout_sec: int = 60) -> bool:
    """Wait for MinIO to become ready via HTTP health endpoint."""
    start_time = time.time()
    last_error = None
    url = f"http://{tunnel_ip}:{MINIO_PORT}/minio/health/live"

    while time.time() - start_time < timeout_sec:
        try:
            result = subprocess.run(
                ["systemctl", "is-active", MINIO_SERVICE_NAME],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.stdout.strip() != "active":
                last_error = f"Service not active: {result.stdout.strip()}"
                time.sleep(3)
                continue

            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    print(f"[*] MinIO is ready on {tunnel_ip}:{MINIO_PORT}", file=sys.stderr)
                    return True
                last_error = f"Health check returned {resp.status}"
        except urllib.error.URLError as e:
            last_error = f"Health check error: {e}"
        except subprocess.TimeoutExpired:
            last_error = "Service check timed out"
        except Exception as e:
            last_error = f"Health check error: {e}"

        time.sleep(3)

    print(f"[!] MinIO did not become ready within {timeout_sec}s. Last error: {last_error}", file=sys.stderr)
    return False


def check_minio_health(tunnel_ip: str, cluster_nodes_count: int) -> tuple[bool, str | None]:
    """Check MinIO health via HTTP endpoints.

    Uses /minio/health/cluster for distributed mode (2+ nodes),
    falls back to /minio/health/live for standalone.
    """
    if cluster_nodes_count >= 2:
        url = f"http://{tunnel_ip}:{MINIO_PORT}/minio/health/cluster"
    else:
        url = f"http://{tunnel_ip}:{MINIO_PORT}/minio/health/live"

    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status == 200:
                return True, None
            return False, f"Health endpoint returned {resp.status}"
    except Exception as e:
        return False, f"Health check failed: {e}"


def is_minio_running() -> tuple[bool, str | None]:
    """Check if MinIO service is running."""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", MINIO_SERVICE_NAME],
            capture_output=True,
            text=True,
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {e}"


# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize MinIO: pull images and create directories."""
    try:
        pull_image(MINIO_IMAGE)
        pull_image(MINIO_CLIENT_IMAGE)

        MINIO_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ensure_data_dir_permissions(recursive=True)

        return PluginOutput(status='completed', local_state=input_data.local_state)
    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=input_data.local_state)


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply MinIO configuration and start the service."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    if not isinstance(state_json, dict):
        return PluginOutput(status='error', error_message='Invalid state format', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", [])
    minio_props = state_json.get("minioNodeProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])

    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return PluginOutput(
            status='postponed',
            error_message='Waiting for WireGuard to be configured on all nodes',
            local_state=local_state,
        )

    if len(cluster_nodes) < 1:
        return PluginOutput(
            status='postponed',
            error_message=f'MinIO requires at least 1 node, currently have {len(cluster_nodes)}',
            local_state=local_state,
        )

    leader_node_id = get_leader_node(state_json)
    is_leader = (leader_node_id == local_node_id)

    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not local_tunnel_ip:
        return PluginOutput(
            status='error',
            error_message='Local node has no WireGuard tunnel IP',
            local_state=local_state,
        )

    install_hash = compute_install_hash(state_json)

    prev_install_hash = local_state.get("install_hash")
    if prev_install_hash == install_hash and local_state.get("minio_ready"):
        is_running, _ = is_minio_running()
        if is_running:
            return PluginOutput(status='completed', local_state=local_state)

    # Credentials: leader generates, others read from leader's properties
    if is_leader:
        root_user = local_state.get("root_user")
        root_password = local_state.get("root_password")
        if not root_user or not root_password:
            root_user, root_password = generate_credentials()
            local_state["root_user"] = root_user
            local_state["root_password"] = root_password
    else:
        root_user, root_password = get_leader_credentials(minio_props)
        if not root_user or not root_password:
            return PluginOutput(
                status='postponed',
                error_message='Waiting for leader to publish credentials',
                local_state=local_state,
            )

    volumes = build_volume_string(cluster_nodes, wg_props)
    if not volumes:
        return PluginOutput(
            status='error',
            error_message='Failed to build volume string: no WireGuard addresses',
            local_state=local_state,
        )

    try:
        ensure_data_dir_permissions(recursive=False)
        write_minio_env(root_user, root_password)
        create_systemd_service(local_tunnel_ip, volumes)
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to write config: {e}',
            local_state=local_state,
        )

    try:
        pull_image(MINIO_IMAGE)
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to pull MinIO image: {e}',
            local_state=local_state,
        )

    try:
        result = subprocess.run(["systemctl", "enable", MINIO_SERVICE_NAME], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(
                status='error',
                error_message=f'Failed to enable MinIO: {result.stderr}',
                local_state=local_state,
            )

        result = subprocess.run(["systemctl", "restart", MINIO_SERVICE_NAME], capture_output=True, text=True)
        if result.returncode != 0:
            return PluginOutput(
                status='error',
                error_message=f'Failed to start MinIO: {result.stderr}',
                local_state=local_state,
            )
    except Exception as e:
        return PluginOutput(
            status='error',
            error_message=f'Failed to start MinIO: {e}',
            local_state=local_state,
        )

    minio_ready = wait_for_minio_ready(local_tunnel_ip, timeout_sec=240)

    if not minio_ready:
        return PluginOutput(
            status='postponed',
            error_message='MinIO did not become ready within timeout',
            local_state={**local_state, "install_hash": install_hash, "minio_ready": False},
        )

    new_local_state = {
        **local_state,
        "install_hash": install_hash,
        "minio_ready": True,
        "is_leader": is_leader,
    }

    node_properties = {"minio_node_ready": "true"}
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    _evidence_manifest_version = read_manifest_version(Path(__file__).parent)
    node_properties.update(
        build_image_evidence_props(
            prefix="minio",
            image_ref=MINIO_IMAGE,
            manifest_version=_evidence_manifest_version,
        )
    )
    node_properties.update(
        build_image_evidence_props(
            prefix="minio_client",
            image_ref=MINIO_CLIENT_IMAGE,
            manifest_version=_evidence_manifest_version,
        )
    )

    if is_leader:
        node_properties["minio_cluster_initialized"] = "true"
        node_properties["minio_root_user"] = root_user
        node_properties["minio_root_password"] = root_password
        node_properties["minio_api_endpoint"] = f"http://{local_tunnel_ip}:{MINIO_PORT}"
        node_properties["minio_console_endpoint"] = f"http://{local_tunnel_ip}:{MINIO_CONSOLE_PORT}"

    return PluginOutput(
        status='completed',
        node_properties=node_properties,
        local_state=new_local_state,
    )


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check MinIO health."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}

    minio_running, minio_error = is_minio_running()
    if not minio_running:
        if minio_error and 'Failed to' in minio_error:
            return PluginOutput(status='error', error_message=minio_error, local_state=local_state)
        return PluginOutput(
            status='postponed',
            error_message=minio_error or 'MinIO service is not running',
            local_state=local_state,
        )

    wg_props = state_json.get("wgNodeProperties", []) if isinstance(state_json, dict) else []
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)

    if not local_tunnel_ip:
        return PluginOutput(status='postponed', error_message='No tunnel IP available', local_state=local_state)

    cluster_nodes = state_json.get("clusterNodes", []) if isinstance(state_json, dict) else []
    healthy, error = check_minio_health(local_tunnel_ip, len(cluster_nodes))
    if not healthy:
        return PluginOutput(status='postponed', error_message=error, local_state=local_state)

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal. MinIO erasure coding survives node loss."""
    local_state = input_data.local_state or {}

    subprocess.run(
        ["systemctl", "stop", MINIO_SERVICE_NAME],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('destroy')
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    """Destroy MinIO installation and clean up (host data preserved)."""
    try:
        subprocess.run(
            ["systemctl", "stop", MINIO_SERVICE_NAME],
            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["systemctl", "disable", MINIO_SERVICE_NAME],
            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

        service_path = f"/etc/systemd/system/{MINIO_SERVICE_NAME}.service"
        if os.path.exists(service_path):
            os.remove(service_path)
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        if MINIO_CONFIG_DIR.exists():
            shutil.rmtree(MINIO_CONFIG_DIR, ignore_errors=True)

        subprocess.run(
            ["podman", "stop", MINIO_CONTAINER_NAME],
            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["podman", "rm", MINIO_CONTAINER_NAME],
            check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

        node_properties = {
            "minio_node_ready": None,
            "minio_cluster_initialized": None,
            "minio_root_user": None,
            "minio_root_password": None,
            "minio_api_endpoint": None,
            "minio_console_endpoint": None,
        }

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={},
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy MinIO: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
