#!/usr/bin/env python3
"""
Harbor provision helpers: embedded config/docker-compose content and write_embedded_files.
Values from input (e.g. EXT_ENDPOINT) are inlined into strings, no replace().

External Swarm Redis uses Harbor-native Sentinel wiring:
- Core: _REDIS_URL_* as redis+sentinel://…/redis-master/{db} (DBs start at 1, not 0)
- Jobservice: redis_pool.redis_url with the same scheme
- Registry: redis.addr = comma-separated sentinel host:26379 + sentinelMasterSet
"""

import secrets
import subprocess
import yaml
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from provision_plugin_sdk import PluginInput

HARBOR_PROXY_PORT = 8082

# Harbor admin credentials (must match embedded core env)
HARBOR_ADMIN_USERNAME = "admin"
HARBOR_ADMIN_PASSWORD = "Harbor12345"

# Harbor component images — single place to bump version
HARBOR_IMAGE_TAG = "v2.14.2"

# Swarm Redis via Sentinel (Harbor native: redis+sentinel:// in core/jobservice; registry addr + sentinelMasterSet)
REDIS_SENTINEL_PORT = 26379
REDIS_MASTER_NAME = "redis-master"

# Logical Redis DB indices on the Sentinel-backed master (avoid db 0 for Swarm/Harbor isolation)
HARBOR_REDIS_DB_CORE = 1
HARBOR_REDIS_DB_REGISTRY = 2
HARBOR_REDIS_DB_JOBSERVICE = 3

# Docker-compose.yml: single install dir, ./data/ for volumes
DOCKER_COMPOSE_YML = """services:
  log:
    image: goharbor/harbor-log:{HARBOR_IMAGE_TAG}
    container_name: harbor-log
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - DAC_OVERRIDE
      - SETGID
      - SETUID
    volumes:
      - /var/log/harbor/:/var/log/docker/:z
      - type: bind
        source: ./common/config/log/logrotate.conf
        target: /etc/logrotate.d/logrotate.conf
      - type: bind
        source: ./common/config/log/rsyslog_docker.conf
        target: /etc/rsyslog.d/rsyslog_docker.conf
    ports:
      - 127.0.0.1:1514:10514
    networks:
      - harbor
  registry:
    image: goharbor/registry-photon:{HARBOR_IMAGE_TAG}
    container_name: registry
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
    volumes:
      - ./data/registry:/storage:z
      - ./common/config/registry/:/etc/registry/:z
      - type: bind
        source: ./common/config/shared/trust-certificates
        target: /harbor_cust_cert
    networks:
      - harbor
    depends_on:
      - log
  registryctl:
    image: goharbor/harbor-registryctl:{HARBOR_IMAGE_TAG}
    container_name: registryctl
    env_file:
      - ./common/config/registryctl/env
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
    volumes:
      - ./data/registry:/storage:z
      - ./common/config/registry/:/etc/registry/:z
      - type: bind
        source: ./common/config/registryctl/config.yml
        target: /etc/registryctl/config.yml
      - type: bind
        source: ./common/config/shared/trust-certificates
        target: /harbor_cust_cert
    networks:
      - harbor
    depends_on:
      - log
  postgresql:
    image: goharbor/harbor-db:{HARBOR_IMAGE_TAG}
    container_name: harbor-db
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - DAC_OVERRIDE
      - SETGID
      - SETUID
    volumes:
      - ./data/database:/var/lib/postgresql/data:z
    networks:
      harbor:
    env_file:
      - ./common/config/db/env
    depends_on:
      - log
    shm_size: '1gb'
  core:
    image: goharbor/harbor-core:{HARBOR_IMAGE_TAG}
    container_name: harbor-core
    env_file:
      - ./common/config/core/env
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - SETGID
      - SETUID
    volumes:
      - ./data/ca_download/:/etc/core/ca/:z
      - ./data/:/data/:z
      - ./common/config/core/certificates/:/etc/core/certificates/:z
      - type: bind
        source: ./common/config/core/app.conf
        target: /etc/core/app.conf
      - type: bind
        source: ./data/secret/core/private_key.pem
        target: /etc/core/private_key.pem
      - type: bind
        source: ./data/secret/keys/secretkey
        target: /etc/core/key
      - type: bind
        source: ./common/config/shared/trust-certificates
        target: /harbor_cust_cert
    networks:
      harbor:
    depends_on:
      - log
      - registry
      - postgresql
  portal:
    image: goharbor/harbor-portal:{HARBOR_IMAGE_TAG}
    container_name: harbor-portal
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
      - NET_BIND_SERVICE
    volumes:
      - type: bind
        source: ./common/config/portal/nginx.conf
        target: /etc/nginx/nginx.conf
    networks:
      - harbor
    depends_on:
      - log
  jobservice:
    image: goharbor/harbor-jobservice:{HARBOR_IMAGE_TAG}
    container_name: harbor-jobservice
    env_file:
      - ./common/config/jobservice/env
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
    volumes:
      - ./data/job_logs:/var/log/jobs:z
      - type: bind
        source: ./common/config/jobservice/config.yml
        target: /etc/jobservice/config.yml
      - type: bind
        source: ./common/config/shared/trust-certificates
        target: /harbor_cust_cert
    networks:
      - harbor
    depends_on:
      - core
  proxy:
    image: goharbor/nginx-photon:{HARBOR_IMAGE_TAG}
    container_name: nginx
    restart: always
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
      - NET_BIND_SERVICE
    volumes:
      - ./common/config/nginx:/etc/nginx:z
      - type: bind
        source: ./common/config/shared/trust-certificates
        target: /harbor_cust_cert
    networks:
      - harbor
    ports: []
    depends_on:
      - registry
      - core
      - portal
      - log
networks:
  harbor:
    external: false
""".format(HARBOR_IMAGE_TAG=HARBOR_IMAGE_TAG)


def _get_local_tunnel_ip(state: dict | None, local_node_id: str | None) -> str | None:
    """Get WireGuard tunnel IP for the local node from state (wgNodeProperties)."""
    if not state or not local_node_id:
        return None
    wg_props = state.get("wgNodeProperties") or []
    for p in wg_props:
        if p.get("node_id") == local_node_id and p.get("name") == "tunnel_ip":
            return p.get("value")
    return None


def _get_proxy_ports(tunnel_ip: str) -> list[str]:
    """Proxy ports for compose: bind only on WireGuard tunnel IP; host 8082 -> container 8080 (default nginx)."""
    return [f"{tunnel_ip}:{HARBOR_PROXY_PORT}:8080"]


def get_local_tunnel_ip(state: dict | None, local_node_id: str | None) -> str | None:
    """Get WireGuard tunnel IP for the local node from state (wgNodeProperties). Exported for main."""
    return _get_local_tunnel_ip(state, local_node_id)


def _get_node_tunnel_ip_for_sentinel(node_id: str, wg_props: list) -> str | None:
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            v = prop.get("value")
            if v is None:
                return None
            s = str(v).strip()
            return s or None
    return None


def get_sentinel_tunnel_ips(state: dict | None) -> list[str]:
    """WireGuard tunnel IPs for Sentinel nodes that report redis_sentinel_node_ready (swarm-gatekeeper-harbor pattern)."""
    if not state:
        return []
    sentinel_props = state.get("sentinelNodeProperties") or []
    wg_props = state.get("sentinelWgNodeProperties") or []
    hosts: list[str] = []
    for prop in sentinel_props:
        if prop.get("name") == "redis_sentinel_node_ready" and prop.get("value") == "true":
            node_id = prop.get("node_id")
            if not node_id:
                continue
            tunnel_ip = _get_node_tunnel_ip_for_sentinel(str(node_id), wg_props)
            if tunnel_ip:
                hosts.append(tunnel_ip)
    return sorted(set(hosts))


def _sentinel_endpoints_csv(sentinel_tunnel_ips: list[str]) -> str:
    """Comma-separated host:26379 for Harbor registry addr and redis+sentinel URLs."""
    return ",".join(f"{ip}:{REDIS_SENTINEL_PORT}" for ip in sentinel_tunnel_ips)


def build_harbor_redis_sentinel_url(sentinel_tunnel_ips: list[str], db_index: int) -> str:
    """Harbor Core/Jobservice redis+sentinel:// URL (no password; Swarm Redis has no requirepass)."""
    addrs = _sentinel_endpoints_csv(sentinel_tunnel_ips)
    return f"redis+sentinel://{addrs}/{REDIS_MASTER_NAME}/{db_index}?idle_timeout_seconds=30"


def _get_ext_endpoint_from_state(state: dict | None) -> str:
    """Derive EXT_ENDPOINT from state (nodeAddrs) or return default."""
    if not state:
        return "http://host.docker.internal"
    node_addrs = state.get("nodeAddrs") or []
    if not node_addrs or not isinstance(node_addrs[0], dict):
        return "http://host.docker.internal"
    addr = node_addrs[0].get("addr")
    if not addr:
        return "http://host.docker.internal"
    return f"http://{addr}:{HARBOR_PROXY_PORT}"


def _get_log_configs() -> dict[str, str]:
    """Log configs: logrotate, rsyslog."""
    return {
        "common/config/log/logrotate.conf": """/var/log/docker/*.log {
        rotate 50
        size 200M
        copytruncate
        compress
        missingok
        nodateext
}
""",
        "common/config/log/rsyslog_docker.conf": """# Rsyslog configuration file for docker.

template(name="DynaFile" type="string" string="/var/log/docker/%programname%.log")

if $programname != "rsyslogd" then {
\taction(type="omfile" dynaFile="DynaFile")
}
""",
    }


def _get_registry_configs(sentinel_tunnel_ips: list[str]) -> dict[str, str]:
    """Registry config.yml and passwd (Docker Distribution Redis Sentinel)."""
    redis_addr = _sentinel_endpoints_csv(sentinel_tunnel_ips)
    return {
        "common/config/registry/config.yml": f"""version: 0.1
log:
  level: info
  fields:
    service: registry
storage:
  cache:
    layerinfo: redis
  filesystem:
    rootdirectory: /storage
  maintenance:
    uploadpurging:
      enabled: true
      age: 168h
      interval: 24h
      dryrun: false
  delete:
    enabled: true
redis:
  addr: {redis_addr}
  sentinelMasterSet: {REDIS_MASTER_NAME}
  readtimeout: 10s
  writetimeout: 10s
  dialtimeout: 10s
  db: {HARBOR_REDIS_DB_REGISTRY}
  enableTLS: false
  pool:
    maxidle: 100
    maxactive: 500
    idletimeout: 60s
http:
  addr: :5000
  secret: placeholder
  debug:
    addr: localhost:5001
auth:
  htpasswd:
    realm: harbor-registry-basic-realm
    path: /etc/registry/passwd
validation:
  disabled: true
compatibility:
  schema1:
    enabled: true
""",
        "common/config/registry/passwd": "harbor_registry_user:$2y$05$4ayqY0OW/PcWfzt4KqWwqOpzXRwVpMmw9ZFn2/4Qe1ZIiSqWbntmq\n",
    }


def _get_db_and_registryctl_configs() -> dict[str, str]:
    """DB and registryctl env/config."""
    return {
        "common/config/db/env": "POSTGRES_PASSWORD=root123\n",
        "common/config/registryctl/env": """CORE_SECRET=ACrURSXsnwDHldC9
JOBSERVICE_SECRET=H8KjJeLAbPrtBhNt
""",
        "common/config/registryctl/config.yml": """---
protocol: "http"
port: 8080
log_level: info
registry_config: "/etc/registry/config.yml"
""",
    }


def _get_core_configs(ext_endpoint: str, sentinel_tunnel_ips: list[str]) -> dict[str, str]:
    """Core env (with inlined ext_endpoint) and app.conf."""
    url_core = build_harbor_redis_sentinel_url(sentinel_tunnel_ips, HARBOR_REDIS_DB_CORE)
    url_reg = build_harbor_redis_sentinel_url(sentinel_tunnel_ips, HARBOR_REDIS_DB_REGISTRY)
    no_proxy_sentinels = ",".join(sentinel_tunnel_ips)
    core_env = f"""CONFIG_PATH=/etc/core/app.conf
UAA_CA_ROOT=/etc/core/certificates/uaa_ca.pem
_REDIS_URL_CORE={url_core}
SYNC_QUOTA=true
_REDIS_URL_REG={url_reg}

LOG_LEVEL=info
EXT_ENDPOINT={ext_endpoint}
DATABASE_TYPE=postgresql
POSTGRESQL_HOST=postgresql
POSTGRESQL_PORT=5432
POSTGRESQL_USERNAME=postgres
POSTGRESQL_PASSWORD=root123
POSTGRESQL_DATABASE=registry
POSTGRESQL_SSLMODE=disable
POSTGRESQL_MAX_IDLE_CONNS=100
POSTGRESQL_MAX_OPEN_CONNS=900
POSTGRESQL_CONN_MAX_LIFETIME=5m
POSTGRESQL_CONN_MAX_IDLE_TIME=0
REGISTRY_URL=http://registry:5000
PORTAL_URL=http://portal:8080
TOKEN_SERVICE_URL=http://core:8080/service/token
HARBOR_ADMIN_PASSWORD={HARBOR_ADMIN_PASSWORD}
MAX_JOB_WORKERS=10
CORE_SECRET=ACrURSXsnwDHldC9
JOBSERVICE_SECRET=H8KjJeLAbPrtBhNt
WITH_TRIVY=False
CORE_URL=http://core:8080
CORE_LOCAL_URL=http://127.0.0.1:8080
JOBSERVICE_URL=http://jobservice:8080
TRIVY_ADAPTER_URL=http://trivy-adapter:8080
REGISTRY_STORAGE_PROVIDER_NAME=filesystem
READ_ONLY=false
RELOAD_KEY=
REGISTRY_CONTROLLER_URL=http://registryctl:8080
REGISTRY_CREDENTIAL_USERNAME=harbor_registry_user
REGISTRY_CREDENTIAL_PASSWORD=Mx79nFZnkF7kuZjdd4WieB7c4iKq9QZN
CSRF_KEY=2tbbDyfh3q7N3aCQt6JNdPuKtLYzzS6y
ROBOT_SCANNER_NAME_PREFIX=p8rEOCx0
PERMITTED_REGISTRY_TYPES_FOR_PROXY_CACHE=docker-hub,harbor,azure-acr,ali-acr,aws-ecr,google-gcr,docker-registry,github-ghcr,jfrog-artifactory
REPLICATION_ADAPTER_WHITELIST=ali-acr,aws-ecr,azure-acr,docker-hub,docker-registry,github-ghcr,google-gcr,harbor,huawei-SWR,jfrog-artifactory,tencent-tcr,volcengine-cr

HTTP_PROXY=
HTTPS_PROXY=
NO_PROXY=core,jobservice,log,registryctl,postgresql,.internal,registry,portal,127.0.0.1,nginx,trivy-adapter,localhost,exporter,.local,db,{no_proxy_sentinels}

PORT=8080




QUOTA_UPDATE_PROVIDER=db
"""
    return {
        "common/config/core/env": core_env,
        "common/config/core/app.conf": """appname = Harbor
runmode = prod
enablegzip = true

[prod]
httpport = 8080
""",
    }


def _get_portal_configs() -> dict[str, str]:
    """Portal nginx.conf."""
    return {
        "common/config/portal/nginx.conf": """
worker_processes auto;
pid /tmp/nginx.pid;

events {
    worker_connections  1024;
}

http {

    client_body_temp_path /tmp/client_body_temp;
    proxy_temp_path /tmp/proxy_temp;
    fastcgi_temp_path /tmp/fastcgi_temp;
    uwsgi_temp_path /tmp/uwsgi_temp;
    scgi_temp_path /tmp/scgi_temp;

    server {
        listen 8080;
        server_name  localhost;

        root   /usr/share/nginx/html;
        index  index.html index.htm;
        include /etc/nginx/mime.types;

        gzip on;
        gzip_min_length 1000;
        gzip_proxied expired no-cache no-store private auth;
        gzip_types text/plain text/css application/json application/javascript application/x-javascript text/xml application/xml application/xml+rss text/javascript;

        location /devcenter-api-2.0 {
            try_files $uri $uri/ /swagger-ui-index.html;
        }

        location / {
            try_files $uri $uri/ /index.html;
        }

        location = /index.html {
            add_header Cache-Control "no-store, no-cache, must-revalidate";
        }
    }
}
""",
    }


def _get_jobservice_configs(sentinel_tunnel_ips: list[str]) -> dict[str, str]:
    """Jobservice config.yml and env."""
    redis_url = build_harbor_redis_sentinel_url(sentinel_tunnel_ips, HARBOR_REDIS_DB_JOBSERVICE)
    no_proxy_sentinels = ",".join(sentinel_tunnel_ips)
    return {
        "common/config/jobservice/config.yml": f"""---
#Protocol used to serve
protocol: "http"

#Server listening port
port: 8080

#Worker pool
worker_pool:
  #Worker concurrency
  workers: 10
  backend: "redis"
  #Additional config if use 'redis' backend
  redis_pool:
    # redis+sentinel://host:26379,.../master_name/db?params
    redis_url: {redis_url}
    namespace: "harbor_job_service_namespace"
    idle_timeout_second: 3600
#Loggers for the running job
job_loggers:
  # The jobLoggers backend name, only support "STD_OUTPUT", "FILE" and/or "DB"
  - name: "STD_OUTPUT"
    level: "INFO" # INFO/DEBUG/WARNING/ERROR/FATAL
  - name: "FILE"
    level: "INFO"
    settings: # Customized settings of logger
      base_dir: "/var/log/jobs"
    sweeper:
      duration: 1 #days
      settings: # Customized settings of sweeper
        work_dir: "/var/log/jobs"

#Loggers for the job service
loggers:
  - name: "STD_OUTPUT" # Same with above
    level: "INFO"


reaper:
  # the max time to wait for a task to finish, if unfinished after max_update_hours, the task will be mark as error, but the task will continue to run, default value is 24,
  max_update_hours: 24
  # the max time for execution in running state without new task created
  max_dangling_hours: 168

# the max size of job log returned by API, default is 10M
max_retrieve_size_mb: 10
""",
        "common/config/jobservice/env": f"""CORE_SECRET=ACrURSXsnwDHldC9
REGISTRY_URL=http://registry:5000
JOBSERVICE_SECRET=H8KjJeLAbPrtBhNt
CORE_URL=http://core:8080
REGISTRY_CONTROLLER_URL=http://registryctl:8080
JOBSERVICE_WEBHOOK_JOB_MAX_RETRY=3
JOBSERVICE_WEBHOOK_JOB_HTTP_CLIENT_TIMEOUT=3

LOG_LEVEL=info


HTTP_PROXY=
HTTPS_PROXY=
NO_PROXY=core,jobservice,log,registryctl,postgresql,.internal,registry,portal,127.0.0.1,nginx,trivy-adapter,localhost,exporter,.local,db,{no_proxy_sentinels}
REGISTRY_CREDENTIAL_USERNAME=harbor_registry_user
REGISTRY_CREDENTIAL_PASSWORD=Mx79nFZnkF7kuZjdd4WieB7c4iKq9QZN



""",
    }


def _get_nginx_configs() -> dict[str, str]:
    """Main nginx config and extra conf."""
    return {
        "common/config/nginx/nginx.conf": """worker_processes auto;
pid /tmp/nginx.pid;

events {
  worker_connections 3096;
  use epoll;
  multi_accept on;
}

http {
  client_body_temp_path /tmp/client_body_temp;
  proxy_temp_path /tmp/proxy_temp;
  fastcgi_temp_path /tmp/fastcgi_temp;
  uwsgi_temp_path /tmp/uwsgi_temp;
  scgi_temp_path /tmp/scgi_temp;
  tcp_nodelay on;

  # this is necessary for us to be able to disable request buffering in all cases
  proxy_http_version 1.1;

  upstream core {
    server core:8080;
  }

  upstream portal {
    server portal:8080;
  }

  log_format timed_combined '$remote_addr - '
    '"$request" $status $body_bytes_sent '
    '"$http_referer" "$http_user_agent" '
    '$request_time $upstream_response_time $pipe';

  access_log /dev/stdout timed_combined;

  map $http_x_forwarded_proto $x_forwarded_proto {
    default $http_x_forwarded_proto;
    ""      $scheme;
  }

  server {
    listen __PROXY_LISTEN_PORT__;
    server_tokens off;
    # disable any limits to avoid HTTP 413 for large image uploads
    client_max_body_size 0;

    # Add extra headers
    add_header X-Frame-Options DENY;
    add_header Content-Security-Policy "frame-ancestors 'none'";

    # customized location config file can place to /etc/nginx/etc with prefix harbor.http. and suffix .conf
    include /etc/nginx/conf.d/harbor.http.*.conf;

    location / {
      proxy_pass http://portal/;
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $x_forwarded_proto;

      proxy_buffering off;
      proxy_request_buffering off;
    }

    location /c/ {
      proxy_pass http://core/c/;
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $x_forwarded_proto;

      proxy_buffering off;
      proxy_request_buffering off;

      proxy_send_timeout 900;
      proxy_read_timeout 900;
    }

    location /api/ {
      proxy_pass http://core/api/;
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $x_forwarded_proto;

      proxy_buffering off;
      proxy_request_buffering off;
    }

    location /v1/ {
      return 404;
    }

    location /v2/ {
      proxy_pass http://core/v2/;
      proxy_set_header Host $http_host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $x_forwarded_proto;
      proxy_buffering off;
      proxy_request_buffering off;

      proxy_send_timeout 900;
      proxy_read_timeout 900;
    }

    location /service/ {
      proxy_pass http://core/service/;
      proxy_set_header Host $host;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto $x_forwarded_proto;

      proxy_buffering off;
      proxy_request_buffering off;
    }

    location /service/notifications {
      return 404;
    }
  }
}
""".replace("__PROXY_LISTEN_PORT__", "8080"),
        "common/config/nginx/conf.d/harbor.http.extra.conf": "# optional extra config\n",
    }


def _get_placeholder_configs() -> dict[str, str]:
    """Empty placeholder files (.gitkeep)."""
    return {
        "common/config/shared/trust-certificates/.gitkeep": "",
        "common/config/core/certificates/.gitkeep": "",
    }


def _resolve_harbor_secret_key(install_dir: Path) -> str:
    """Return a Harbor AES key with valid length (16/24/32 bytes).

    Preserve existing valid key to avoid rotating secrets on every apply.
    """
    key_path = install_dir / "data/secret/keys/secretkey"
    if key_path.exists():
        existing_key = key_path.read_text(encoding="utf-8").strip()
        if len(existing_key) in {16, 24, 32}:
            return existing_key

    # Use fixed-size ASCII key compatible with Harbor AES requirements.
    return secrets.token_hex(16)


def _get_secret_configs(install_dir: Path) -> dict[str, str]:
    """Secret key material (private_key.pem, secretkey). Generated on-the-fly via openssl and secrets.
    -traditional forces PKCS#1 (RSA PRIVATE KEY) so Harbor core token service can parse it."""
    try:
        result = subprocess.run(
            ["openssl", "genrsa", "-traditional", "4096"],
            capture_output=True,
            check=True,
            timeout=60,
        )
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        raise RuntimeError("openssl required for secret generation") from e
    pem_str = result.stdout.decode("utf-8")
    secretkey_str = _resolve_harbor_secret_key(install_dir)
    return {
        "data/secret/core/private_key.pem": pem_str,
        "data/secret/keys/secretkey": secretkey_str,
    }


def _get_embedded_files(
    ext_endpoint: str,
    sentinel_tunnel_ips: list[str],
    install_dir: Path,
) -> dict[str, str]:
    """Build path -> content dict by merging all config groups."""
    return (
        _get_log_configs()
        | _get_registry_configs(sentinel_tunnel_ips)
        | _get_db_and_registryctl_configs()
        | _get_core_configs(ext_endpoint, sentinel_tunnel_ips)
        | _get_portal_configs()
        | _get_jobservice_configs(sentinel_tunnel_ips)
        | _get_nginx_configs()
        | _get_placeholder_configs()
        | _get_secret_configs(install_dir)
    )


def _apply_image_registry(compose_data: dict, image_registry: str) -> None:
    """Prefix goharbor/ image names with image_registry (e.g. docker.io) for Podman compatibility."""
    if not image_registry:
        return
    prefix = f"{image_registry.rstrip('/')}/"
    for svc_name, svc_def in compose_data.get("services", {}).items():
        image = svc_def.get("image")
        if image and image.startswith("goharbor/"):
            svc_def["image"] = prefix + image


def write_embedded_files(
    install_dir: Path,
    input_data: "PluginInput",
    tunnel_ip: str,
    sentinel_tunnel_ips: list[str],
    image_registry: str = "docker.io",
) -> None:
    """Write all embedded file content into install_dir. tunnel_ip required (proxy binds only on WG)."""
    install_dir = Path(install_dir)
    state = input_data.state if input_data else None
    ext_endpoint = _get_ext_endpoint_from_state(state)
    compose_data = yaml.safe_load(DOCKER_COMPOSE_YML)
    _apply_image_registry(compose_data, image_registry)
    compose_data["services"]["proxy"]["ports"] = _get_proxy_ports(tunnel_ip)
    compose_yml = yaml.dump(compose_data, default_flow_style=False, sort_keys=False, allow_unicode=True)

    files = _get_embedded_files(ext_endpoint, sentinel_tunnel_ips, install_dir)
    for rel_path, content in files.items():
        path = install_dir / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    (install_dir / "docker-compose.yml").write_text(compose_yml, encoding="utf-8")
