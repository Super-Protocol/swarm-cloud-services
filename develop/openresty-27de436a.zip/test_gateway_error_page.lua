-- Behavioural tests for the gateway error-page body (SUP-766).
--
-- Run as `luajit test_gateway_error_page.lua <path-to-gateway_error_page.lua>`.
-- `test_main.py` writes GATEWAY_ERROR_PAGE_LUA out of main.py into a temp file
-- and drives this script, skipping when no luajit is installed -- the Python
-- string assertions stay the always-on guard, these are the ones that actually
-- execute the negotiation and both rendering paths against a fake ngx.

local module_path = arg and arg[1]
if not module_path then
    io.stderr:write("usage: luajit test_gateway_error_page.lua <gateway_error_page.lua>\n")
    os.exit(2)
end

local failures = 0

local function check(name, ok, detail)
    if ok then
        print("ok   - " .. name)
    else
        failures = failures + 1
        print("FAIL - " .. name .. (detail and (": " .. tostring(detail)) or ""))
    end
end

local function eq(name, actual, expected)
    check(name, actual == expected, string.format("got %s, want %s", tostring(actual), tostring(expected)))
end

-- ── fake ngx ────────────────────────────────────────────────────────────────
-- `ngx.exit` only records: the real one unwinds the request by raising, which a
-- test cannot resume from, and every call site in the module is a tail call.

local ngx = {
    OK = 0,
    ERR = 4,
    var = {},
    header = {},
    status = 200,
    exited = nil,
    printed = nil,
}

function ngx.print(body)
    ngx.printed = (ngx.printed or "") .. body
end

function ngx.exit(status)
    ngx.exited = status
end

function ngx.log() end

_G.ngx = ngx

local chunk = assert(loadfile(module_path))
local error_page = chunk()

-- ── the negotiation ─────────────────────────────────────────────────────────
-- (accept, content_type, uri) -> wants JSON. Table-driven because the point of
-- the function is the whole truth table, not any one row of it.

local negotiation = {
    -- An OpenAI-compatible SDK: explicit JSON.
    { "application/json", nil, "/v1/chat/completions", true, "an explicit application/json Accept" },
    -- A streamed completion that fails before the first token.
    { "text/event-stream", nil, "/v1/chat/completions", true, "a streaming Accept" },
    -- Real clients send a q-list, not one bare type.
    { "application/json, text/plain, */*", nil, "/", true, "a JSON q-list" },
    -- Header values are case-insensitive.
    { "APPLICATION/JSON", nil, "/", true, "an upper-case Accept" },
    -- curl and several SDKs send no usable Accept at all.
    { nil, "application/json", "/", true, "a JSON request body with no Accept" },
    { "*/*", "application/json; charset=utf-8", "/", true, "a charset-qualified JSON content type" },
    { "*/*", nil, "/v1/models", true, "an API path with a wildcard Accept" },
    { nil, nil, "/v1/chat/completions", true, "an API path with no headers at all" },
    -- A browser on a console hostname keeps its readable page.
    { "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", nil, "/", false, "a browser Accept" },
    { "*/*", nil, "/", false, "a wildcard Accept on a non-API path" },
    { nil, nil, "/", false, "a request with nothing to go on" },
    { nil, "application/x-www-form-urlencoded", "/login", false, "a form post" },
    -- The prefix is `/v1/`: the console's own paths must not collide with it.
    { nil, nil, "/v1beta/models", false, "a path that only starts like the API" },
    { "text/html", nil, "/v1/chat/completions", true, "an API path wins over an HTML Accept" },
}

for _, row in ipairs(negotiation) do
    local accept, content_type, uri, want, name = row[1], row[2], row[3], row[4], row[5]
    eq(name, error_page.wants_json(accept, content_type, uri), want)
end

-- ── rendering ───────────────────────────────────────────────────────────────

local function render(vars)
    ngx.var = vars
    ngx.header = {}
    ngx.status = 200
    ngx.printed = nil
    ngx.exited = nil
    error_page.render()
end

-- An API client gets the OpenAI error shape at the status the gateway produced.
render({ status = "502", http_accept = "application/json", uri = "/v1/chat/completions" })
eq("the JSON path keeps the gateway's status", ngx.status, 502)
eq("the JSON path sets the content type", ngx.header["Content-Type"], "application/json; charset=utf-8")
eq("the JSON path forbids caching", ngx.header["Cache-Control"], "no-store")
eq("the JSON path marks the answer as the gateway's", ngx.header["X-Swarm-Gateway-Error"], "502")
eq("the JSON path finishes the response itself", ngx.exited, ngx.OK)
eq(
    "the body is the OpenAI error shape",
    ngx.printed,
    '{"error":{"message":"The gateway could not reach the service behind this hostname.",'
        .. '"type":"upstream_error","code":"gateway_unavailable"}}'
)

-- Every status `error_page` routes here comes back unchanged.
for _, status in ipairs({ 502, 503, 504 }) do
    render({ status = tostring(status), http_accept = "application/json", uri = "/v1/models" })
    eq("status " .. status .. " is passed through", ngx.status, status)
    eq("status " .. status .. " is named in the header", ngx.header["X-Swarm-Gateway-Error"], tostring(status))
end

-- A browser falls back to nginx's own page: `ngx.exit` at the same status,
-- with nothing written by this module.
render({ status = "502", http_accept = "text/html", uri = "/" })
eq("the HTML path hands the status back to nginx", ngx.exited, 502)
eq("the HTML path writes no body of its own", ngx.printed, nil)
eq("the HTML path sets no content type", ngx.header["Content-Type"], nil)
eq("the HTML path leaves no gateway marker", ngx.header["X-Swarm-Gateway-Error"], nil)

-- `$status` is always set by nginx inside an error_page handler; a missing or
-- unparsable one must still produce a 5xx rather than a 200 with an error body.
render({ http_accept = "application/json", uri = "/v1/models" })
eq("an unreadable status falls back to 502", ngx.status, 502)
eq("the fallback status is reported too", ngx.header["X-Swarm-Gateway-Error"], "502")

render({ status = "not-a-number", http_accept = "text/html", uri = "/" })
eq("the HTML path falls back to 502 as well", ngx.exited, 502)

if failures > 0 then
    print(string.format("\n%d check(s) failed", failures))
    os.exit(1)
end
print("\nall checks passed")
