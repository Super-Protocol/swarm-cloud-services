#!/usr/bin/env python3
"""Unit tests for swarm-cloud-api/main.py — the rendered /etc/swarm-cloud-api/config.yaml.

A real node never reads `conf/api.yaml`; it reads what `create_config_file` renders here.
SUP-368: `kubeEventSync` was added to the compose config and to the Zod schema (whose
default is `enabled: false`) but not to this renderer, so the worker logged "disabled by
config" on every cluster and `clusterSpaceEvents` could only ever answer from the API
server's own 1h window. The drift test below is the guard: any worker the schema knows
about must appear in the rendered block.

    cd services/swarm-cloud-api && python3 -m unittest test_main -v
"""

import re
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent
WORKERS_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/workers/workers.config.ts"

sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    # main.py imports the plugin SDK at module scope and instantiates a ProvisionPlugin.
    # None of the config rendering needs it, so a stub keeps the SDK off the test host.
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0-test"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

LOCAL_NODE_ID = "node-1"
PEER_NODE_ID = "node-2"


def build_state(leader_node_id: str) -> dict:
    return {
        "cluster": {"leader_node": leader_node_id},
        "wgNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.1"},
            {"node_id": PEER_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.2"},
        ],
        "cockroachClusterNodes": [{"node_id": LOCAL_NODE_ID}, {"node_id": PEER_NODE_ID}],
        "cockroachNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"},
        ],
        "globalId": "abc123",
        "baseDomain": "swarm.superprotocol.dev",
        "pkiAuthorityNodes": [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
        ],
        "swarmSecrets": [{"id": "pki_auth_token", "value": "tok"}],
    }


def render_config(leader_node_id: str) -> dict:
    """Render config.yaml the way the plugin does on a node and parse it back."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "swarm-cloud-api" / "config.yaml"
        original = main.API_CONFIG_FILE
        main.API_CONFIG_FILE = config_path
        try:
            main.create_config_file(
                LOCAL_NODE_ID, build_state(leader_node_id), "http://10.10.0.1:3002"
            )
            return yaml.safe_load(config_path.read_text())
        finally:
            main.API_CONFIG_FILE = original


def schema_worker_keys() -> set[str]:
    """The worker names WorkersConfigSchema declares, read straight off the Zod schema."""
    source = WORKERS_CONFIG_TS.read_text()
    body = re.search(
        r"export const WorkersConfigSchema = BaseConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find WorkersConfigSchema in {WORKERS_CONFIG_TS}"
    return set(re.findall(r"^  (\w+):", body.group(1), re.MULTILINE))


class RenderedWorkersTest(unittest.TestCase):
    def test_every_worker_in_the_schema_is_rendered(self):
        """A worker the renderer forgets defaults to enabled:false and silently never runs."""
        rendered = render_config(LOCAL_NODE_ID)["workers"]
        missing = schema_worker_keys() - set(rendered)
        self.assertEqual(
            set(),
            missing,
            f"workers declared in workers.config.ts but absent from the rendered config: {sorted(missing)}",
        )

    def test_kube_event_sync_runs_on_the_leader(self):
        workers = render_config(LOCAL_NODE_ID)["workers"]
        self.assertEqual(
            {"enabled": True, "checkInterval": 30000, "retentionHours": 48},
            workers["kubeEventSync"],
        )

    def test_workers_are_leader_gated(self):
        """Every worker — kubeEventSync included — is off on a follower node."""
        workers = render_config(PEER_NODE_ID)["workers"]
        self.assertFalse(workers["kubeEventSync"]["enabled"])
        for name, worker in workers.items():
            self.assertFalse(worker["enabled"], f"{name} must not run on a follower")


class RenderedEvidenceSignerTest(unittest.TestCase):
    """SUP-636: without this block the API falls back to `http://127.0.0.1:8000`,
    which only resolves when the API node happens to co-host a PKI authority. On
    every other node each `sign()` throws, no host gets a
    `/.well-known/swarm-evidence` bundle, and a cluster-space publish rolls back.
    """

    def test_renders_the_pki_endpoints_the_api_can_actually_reach(self):
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual([f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], signer["pkiBaseUrls"])

    def test_uses_the_token_challenge_the_authority_actually_allows(self):
        # `allowedChallenges` in services/pki-authority/pki-authority-template.yaml
        # has token + the hardware types; `certificate` is not among them, so a
        # `certificate` default would be refused by every cloud we provision.
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual("token", signer["challenge"])

    def test_the_rendered_challenge_is_one_the_authority_template_allows(self):
        template = yaml.safe_load(
            (REPO_ROOT / "services/pki-authority/pki-authority-template.yaml").read_text()
        )
        allowed = template["pki"]["allowedChallenges"]
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertIn(signer["challenge"], allowed)

    def test_prefers_loopback_when_this_node_hosts_a_pki_authority(self):
        # Issuance must not depend on the WireGuard mesh being up at the moment a
        # leader comes back, so a co-hosted authority is tried first.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
            {"id": f"pki:{LOCAL_NODE_ID}", "node_id": LOCAL_NODE_ID, "ip": "10.10.0.1", "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://127.0.0.1:{main.PKI_API_HTTP_PORT}", f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"],
            section["evidenceSigner"]["pkiBaseUrls"],
        )

    def test_skips_an_authority_that_is_not_ready(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": "pki:node-3", "node_id": "node-3", "ip": "10.10.0.3", "ready": None},
        ]
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_on_a_cloud_with_no_pki_authority(self):
        # The legacy non-sp-vm shape: leave evidence signing unconfigured rather
        # than point it at an endpoint that does not exist.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_until_the_auth_token_secret_exists(self):
        state = build_state(LOCAL_NODE_ID)
        state["swarmSecrets"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_falls_back_to_wg_properties_when_the_node_carries_no_ip(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": None, "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], section["evidenceSigner"]["pkiBaseUrls"]
        )


class EvidenceSignerManifestTest(unittest.TestCase):
    def test_the_manifest_supplies_what_the_renderer_reads(self):
        """The renderer reads `pkiAuthorityNodes` and the `pki_auth_token` secret; a
        stateExpr that does not select them renders an empty block on every node."""
        manifest = yaml.safe_load((HERE / "manifest.yaml").read_text())
        query = manifest["stateExpr"]["query"]
        self.assertIn("pkiAuthorityNodes:", query)
        self.assertIn('cluster_policy == "pki-authority"', query)
        self.assertIn("pki_authority_node_ready", query)
        self.assertIn("pki_auth_token", query)


if __name__ == "__main__":
    unittest.main()
