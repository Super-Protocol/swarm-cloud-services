#!/usr/bin/env python3

import sys
import os
import shutil
import subprocess
import time
import hashlib
from pathlib import Path


from provision_plugin_sdk import (
    ProvisionPlugin, PluginInput, PluginOutput,
    build_image_evidence_props, read_manifest_version,
)

# Configuration
API_CONTAINER_NAME = "swarm-cloud-api"
API_CONFIG_DIR = Path("/etc/swarm-cloud-api")
API_CONFIG_FILE = API_CONFIG_DIR / "config.yaml"
DEFAULT_API_PORT = 3001


# Auth Service
AUTH_SERVICE_PORT = 3002

NODE_READY_PROPERTY = "swarm_cloud_api_node_ready"
API_IMAGE_REGISTRY = "ghcr.io"
API_IMAGE_REPO = "super-protocol/swarm-cloud/swarm-cloud-backend"
DEFAULT_SWARMDB_HOST = os.environ.get("SWARMDB_HOST", "127.0.0.1")
LOG_PREFIX = "[swarm-cloud-api]"
GRAPHQL_INTROSPECTION_ENV = "SWARM_CLOUD_API_GRAPHQL_INTROSPECTION"

# Plugin setup
plugin = ProvisionPlugin()


# Helper functions

def _log(level: str, message: str) -> None:
    print(f"{LOG_PREFIX} {level}: {message}", file=sys.stderr)


def log_info(message: str) -> None:
    _log("INFO", message)


def log_warn(message: str) -> None:
    _log("WARN", message)


def log_error(message: str) -> None:
    _log("ERROR", message)


def _sha256_text(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _write_file_if_changed(path: Path, content: str, label: str) -> tuple[bool, str]:
    new_hash = _sha256_text(content)
    old_hash = None

    if path.exists():
        try:
            old_hash = _sha256_text(path.read_text())
        except Exception as e:
            log_warn(f"Failed to read existing {label} at {path}: {e}")

    if old_hash == new_hash:
        log_info(f"{label} unchanged (sha256={new_hash[:12]})")
        return False, new_hash

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    if old_hash:
        log_info(f"{label} updated (old={old_hash[:12]}, new={new_hash[:12]})")
    else:
        log_info(f"{label} created (sha256={new_hash[:12]})")
    return True, new_hash

def _node_ready_props(value: str | None) -> dict:
    return {NODE_READY_PROPERTY: value}

def get_api_port() -> int:
    """Return Swarm Cloud API port.

    Port is currently fixed to DEFAULT_API_PORT.
    """
    return DEFAULT_API_PORT


def _normalize_domain(domain: str) -> str:
    d = domain.strip()
    if d.startswith("https://"):
        d = d[len("https://"):]
    elif d.startswith("http://"):
        d = d[len("http://"):]
    return d.strip().strip("/")



def build_auth_service_url_from_auth_node_ip(auth_node_ip: str) -> str:
    host = _normalize_domain(auth_node_ip)
    if not host:
        raise ValueError("auth service ip is empty")
    return f"http://{host}:{AUTH_SERVICE_PORT}"


def get_first_ready_auth_service_ip(state_json: dict) -> str:
    nodes = state_json.get("authServiceNodes", [])
    if not isinstance(nodes, list):
        raise ValueError("Waiting for dependency authServiceNodes")

    for node in nodes:
        if not isinstance(node, dict):
            continue
        ready = node.get("ready")
        if isinstance(ready, bool):
            is_ready = ready
        else:
            is_ready = str(ready).lower() == "true"

        if not is_ready:
            continue

        ip = node.get("ip")
        if isinstance(ip, str) and ip.strip():
            return ip.strip()

    raise ValueError("Waiting for at least one auth-service node to be ready")

def get_node_tunnel_ip(node_id: str, wg_props: list) -> str | None:
    """Get WireGuard tunnel IP for a node."""
    for prop in wg_props:
        if prop.get("node_id") == node_id and prop.get("name") == "tunnel_ip":
            return prop.get("value")
    return None


def check_all_nodes_have_wg(cluster_nodes: list, wg_props: list) -> bool:
    """Check if all cluster nodes have WireGuard tunnel IPs."""
    for node in cluster_nodes:
        node_id = node.get("node_id")
        if not get_node_tunnel_ip(node_id, wg_props):
            return False
    return True


def get_leader_node(state_json: dict) -> str | None:
    """Get leader node ID from cluster info."""
    cluster = state_json.get("cluster", {})
    return cluster.get("leader_node")


def is_local_node_leader(local_node_id: str, state_json: dict) -> bool:
    """Check if local node is the leader."""
    leader_node_id = get_leader_node(state_json)
    return leader_node_id == local_node_id


def get_image_tag_from_env() -> str:
    """Get image tag from environment variable or manifest."""
    tag = os.environ.get("SWARM_CLOUD_API_TAG")
    if tag:
        return tag

    # Fallback to reading from manifest
    try:
        manifest_path = Path(__file__).parent / "manifest.yaml"
        if manifest_path.exists():
            import yaml
            with open(manifest_path, 'r') as f:
                manifest = yaml.safe_load(f)
            return manifest.get('version', 'latest')
    except Exception as e:
        log_warn(f"Failed to read manifest version: {e}")

    return "latest"


def get_graphql_introspection_from_env() -> bool | None:
    raw = os.environ.get(GRAPHQL_INTROSPECTION_ENV)
    if raw is None:
        return None

    value = raw.strip().lower()
    if value == "":
        return None
    if value in {"true", "1", "yes", "on"}:
        return True
    if value in {"false", "0", "no", "off"}:
        return False

    log_warn(
        f"Ignoring invalid {GRAPHQL_INTROSPECTION_ENV} value: {raw!r}. "
        "Expected one of: true/false, 1/0, yes/no, on/off."
    )
    return None


def pull_api_image(tag: str) -> None:
    """Pull swarm-cloud-backend Docker image using podman."""
    image_url = f"{API_IMAGE_REGISTRY}/{API_IMAGE_REPO}:{tag}"
    log_info(f"Pulling Docker image: {image_url}")

    result = subprocess.run(
        ["podman", "pull", image_url],
        capture_output=True,
        text=True,
        timeout=600  # 10 minutes timeout
    )

    if result.returncode != 0:
        raise Exception(f"Failed to pull image: {result.stderr}")

    if result.stdout:
        log_info(result.stdout.strip())
    log_info("Docker image pulled successfully")


def get_cockroach_connection_info(local_node_id: str, state_json: dict) -> dict | None:
    """Get CockroachDB connection info, preferring local node.
    Returns dict with host, port, username, database or None if no nodes available.
    """
    cockroach_nodes = state_json.get("cockroachClusterNodes", [])
    cockroach_props = state_json.get("cockroachNodeProperties", [])
    wg_props = state_json.get("wgNodeProperties", [])

    # Check which nodes have CockroachDB ready
    ready_nodes = set()
    for prop in cockroach_props:
        if prop.get("name") == "cockroachdb_node_ready" and prop.get("value") == "true":
            ready_nodes.add(prop.get("node_id"))

    # Try local node first if available
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if local_node_id in ready_nodes and local_tunnel_ip:
        return {
            "host": local_tunnel_ip,
            "port": 26257,
            "username": "root",
            "database": "defaultdb"
        }

    # Try other nodes
    for node in cockroach_nodes:
        node_id = node.get("node_id")
        if node_id not in ready_nodes:
            continue
        tunnel_ip = get_node_tunnel_ip(node_id, wg_props)
        if tunnel_ip:
            return {
                "host": tunnel_ip,
                "port": 26257,
                "username": "root",
                "database": "defaultdb"
            }

    return None


def _build_pull_attestation_section(global_id, base_domain, swarm_domain=None) -> str:
    """Render the `pullAttestation` block of api.yaml from cluster identity.

    These URLs are baked into the `swarm-pull` Secret and the `swarm-regcred`
    dockerconfigjson at ClusterSpace creation time. They MUST point at the
    public openresty-fronted hosts — the placeholder `*.swarm-cloud.svc`
    defaults from the Zod schema do not resolve in real deployments (SUP-16).

    evidenceUrl preference:
      1. `https://{swarmDomain}/v1/evidence` when swarm_domain is set (e.g. from
         terraform `swarm_domain` / SwarmSecrets.swarm_domain)
      2. else `https://app.{globalId}.{baseDomain}/v1/evidence`

    gatewayUrl / registryHost always use `{globalId}.{baseDomain}` suffixes.

    Returns an empty string when `globalId` or `baseDomain` are missing (gateway
    and registry hosts cannot be rendered). `swarm_domain` only overrides
    `evidenceUrl`; it does not replace the need for globalId/baseDomain.
    """
    normalized_global_id = global_id.strip() if isinstance(global_id, str) else ""
    normalized_base_domain = (
        base_domain.strip().rstrip(".") if isinstance(base_domain, str) else ""
    )
    normalized_swarm_domain = (
        swarm_domain.strip().rstrip(".") if isinstance(swarm_domain, str) else ""
    )

    if normalized_swarm_domain:
        # Allow values with or without scheme; store host-only for evidence URL.
        if "://" in normalized_swarm_domain:
            normalized_swarm_domain = normalized_swarm_domain.split("://", 1)[1]
        normalized_swarm_domain = normalized_swarm_domain.split("/", 1)[0].rstrip(".")
        evidence_url = f"https://{normalized_swarm_domain}/v1/evidence"
    elif normalized_global_id and normalized_base_domain:
        evidence_url = f"https://app.{normalized_global_id}.{normalized_base_domain}/v1/evidence"
    else:
        log_warn(
            "swarmDomain/globalId/baseDomain unavailable — pullAttestation URLs not rendered; "
            "falling back to schema defaults (createClusterSpace will issue Secrets "
            "with unresolvable hosts until cluster identity is populated)"
        )
        return ""

    if not normalized_global_id or not normalized_base_domain:
        log_warn(
            "globalId/baseDomain unavailable — cannot render gatewayUrl/registryHost; "
            "falling back to schema defaults"
        )
        return ""

    suffix = f"{normalized_global_id}.{normalized_base_domain}"
    gateway_url = f"https://gatekeeper-s3.{suffix}"
    registry_host = f"gatekeeper-harbor.{suffix}"
    return (
        "\npullAttestation:\n"
        f"  registryHost: {registry_host}\n"
        f"  gatewayUrl: {gateway_url}\n"
        f"  evidenceUrl: {evidence_url}\n"
    )


# PKI authority's plaintext API port, published on loopback and on the node's
# WireGuard tunnel IP (`services/pki-authority/helpers.py` PKI_API_HTTP_PORT and
# the endpoint list it renders). The HTTPS port 9443 is served with the swarm's
# own chain, which the API would have to be taught to trust; over WireGuard the
# plaintext port is already confidential, so it is the one used here.
PKI_API_HTTP_PORT = 8000


def _build_evidence_signer_section(local_node_id: str, state_json: dict) -> str:
    """Render `evidenceSigner` — where the API gets its statement-signing certificate.

    SUP-636: the API generates its statement-signing key in-process and has the
    PKI authority certify it. Without this block the API falls back to the
    schema default of `http://127.0.0.1:8000`, which only resolves when the API
    node happens to co-host a PKI authority; on every other node each `sign()`
    throws and a cluster-space publish rolls back.

    Endpoint order is deliberate: loopback first when this node runs a PKI
    authority itself, so issuance does not depend on the WireGuard mesh being up
    at the moment a leader comes back, then the other authorities' tunnel IPs.

    `challenge: token` is the interim mechanism. The hardware challenges
    (`tdx`, `sev-snp`, …) are what actually bind the key to measured hardware,
    but they need the native attestation addon and device access inside the API
    container, and the `certificate` challenge is not in the authority's
    `allowedChallenges` at all (`services/pki-authority/pki-authority-template.yaml`).
    `token` proves possession of `pki_auth_token`, a swarm-wide secret — the
    chain is real and verifiable, the hardware binding is not yet. See SUP-660.

    Returns an empty string on a cloud with no pki-authority (the legacy
    non-sp-vm shape), leaving evidence signing unconfigured rather than pointing
    it at an endpoint that does not exist.
    """
    pki_nodes = state_json.get("pkiAuthorityNodes") or []
    wg_props = state_json.get("wgNodeProperties", [])

    local_endpoints: list[str] = []
    remote_endpoints: list[str] = []
    for node in pki_nodes:
        if not isinstance(node, dict):
            continue
        if str(node.get("ready", "")).lower() != "true":
            continue
        node_id = node.get("node_id")
        if node_id == local_node_id:
            local_endpoints.append(f"http://127.0.0.1:{PKI_API_HTTP_PORT}")
            continue
        ip = node.get("ip") or get_node_tunnel_ip(node_id, wg_props)
        if ip:
            remote_endpoints.append(f"http://{ip}:{PKI_API_HTTP_PORT}")

    endpoints = local_endpoints + remote_endpoints
    if not endpoints:
        log_warn(
            "No ready pki-authority node found — `evidenceSigner` not rendered. "
            "Deployment evidence and workload statements will not be signed on this node "
            "until a PKI authority is provisioned and reports pki_authority_node_ready."
        )
        return ""

    if not get_secret_from_swarmdb(state_json, "pki_auth_token"):
        log_warn(
            "pki_auth_token is not in SwarmSecrets — `evidenceSigner` not rendered. "
            "The token challenge cannot be built without it; the pki-authority plugin "
            "publishes this secret once it has synced its storage."
        )
        return ""

    rendered = "\n".join(f"    - {endpoint}" for endpoint in endpoints)
    log_info(f"evidenceSigner configured with {len(endpoints)} PKI endpoint(s)")
    return (
        "\nevidenceSigner:\n"
        "  pkiBaseUrls:\n"
        f"{rendered}\n"
        "  challenge: token\n"
    )


def _build_introspection_section(state_json: dict) -> str:
    """Render `authService.introspection` — the credentials that open the stable /api/v1.

    The API validates every stable-API bearer token by calling the auth-service's RFC 7662
    introspection endpoint, and that endpoint only answers resource servers it knows. Without
    these credentials /api/v1 stays closed (503), which is the right default: a cloud that is
    not meant to be integrated with should not be reachable by external products.

    The same pair has to appear in the auth-service's
    `betterAuth.oidcProvider.introspectionClients`; terraform renders both from one variable so
    they cannot drift.
    """
    client_id = get_secret_from_swarmdb(state_json, "api_introspection_client_id")
    client_secret = get_secret_from_swarmdb(state_json, "api_introspection_client_secret")

    if not isinstance(client_id, str) or not client_id.strip():
        return ""
    if not isinstance(client_secret, str) or not client_secret.strip():
        log_warn(
            "api_introspection_client_id is set but api_introspection_client_secret is not — "
            "leaving the stable /api/v1 closed"
        )
        return ""

    return (
        "  introspection:\n"
        f"    clientId: \"{client_id.strip()}\"\n"
        f"    clientSecret: \"{client_secret.strip()}\"\n"
    )


def create_config_file(local_node_id: str, state_json: dict, auth_service_url: str) -> tuple[bool, str]:
    """Create configuration file for swarm-cloud-api."""
    is_leader = is_local_node_leader(local_node_id, state_json)
    cockroach_info = get_cockroach_connection_info(local_node_id, state_json)
    api_port = get_api_port()

    wg_props = state_json.get("wgNodeProperties", [])
    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not isinstance(local_tunnel_ip, str) or not local_tunnel_ip.strip():
        raise RuntimeError("No WireGuard tunnel IP available on local node")

    if not cockroach_info:
        raise RuntimeError("No CockroachDB nodes available")


    minio_cluster_nodes = state_json.get("minioClusterNodes", [])
    has_minio = isinstance(minio_cluster_nodes, list) and len(minio_cluster_nodes) > 0

    minio_section = ""
    if has_minio:
        minio_endpoint, minio_access_key, minio_secret_key = get_minio_connection_from_state(state_json)
        # Fallbacks match development config in conf/api.yaml
        if not isinstance(minio_endpoint, str) or not minio_endpoint.strip():
            minio_endpoint = "http://localhost:9000"
        if not isinstance(minio_access_key, str) or not minio_access_key.strip():
            minio_access_key = "minioadmin"
        if not isinstance(minio_secret_key, str) or not minio_secret_key.strip():
            minio_secret_key = "minioadmin"
        minio_section = f"""
minio:
  endpoint: {minio_endpoint}
  accessKey: {minio_access_key}
  secretKey: {minio_secret_key}
  region: us-east-1
"""

    harbor_cfg = get_harbor_connection_from_state(state_json)
    introspection_section = _build_introspection_section(state_json)
    evidence_signer_section = _build_evidence_signer_section(local_node_id, state_json)
    graphql_introspection = get_graphql_introspection_from_env()
    pull_attestation_section = _build_pull_attestation_section(
        state_json.get("globalId"),
        state_json.get("baseDomain"),
        state_json.get("swarmDomain"),
    )

    config_content = f"""port: {api_port}
host: 0.0.0.0

clusterPlacement:
  measurementTtlMs: 300000
  placementPolicy: best-fit
  provisioningTimeoutMs: 600000
  gpuResourceName: nvidia.com/gpu

db:
  type: postgresql
  config:
    host: {cockroach_info['host']}
    port: {cockroach_info['port']}
    username: {cockroach_info['username']}
    password: ""
    database: {cockroach_info['database']}
    synchronize: false
    autoLoadEntities: true
    logging: false
    statementTimeoutMs: 30000
    idleInTransactionSessionTimeoutMs: 60000
    keepAlive: true
    keepAliveInitialDelayMs: 10000

swarmDb:
  host: {DEFAULT_SWARMDB_HOST}
  port: 3306
  username: root
  password: ""
  database: swarmdb
  synchronize: false
  autoLoadEntities: true
  logging: false
  connectTimeoutMs: 10000
  enableKeepAlive: true
  keepAliveInitialDelayMs: 10000
{minio_section}
validClientOrigins:
  - "*"

authService:
  baseUrl: {auth_service_url}
{introspection_section}
redis:
  mode: sentinel
  discovery: auto
  masterName: "redis-master"
  sentinelPort: 26379

workers:
  domainVerification:
    enabled: {str(is_leader).lower()}
    checkInterval: 10000
  ingressSync:
    enabled: {str(is_leader).lower()}
    checkInterval: 10000
  gatewaySync:
    enabled: {str(is_leader).lower()}
    checkInterval: 10000
  saExpiry:
    enabled: {str(is_leader).lower()}
    checkInterval: 3600000
    gracePeriodMs: 3600000
  clusterStatsSync:
    enabled: {str(is_leader).lower()}
    checkInterval: 60000
  attestationBundleSync:
    enabled: {str(is_leader).lower()}
    checkInterval: 60000
  controlPlaneEvidence:
    enabled: {str(is_leader).lower()}
    checkInterval: 60000
  k8sControlPlaneEvidence:
    enabled: {str(is_leader).lower()}
    checkInterval: 60000
  provisioningTimeout:
    enabled: {str(is_leader).lower()}
    checkInterval: 60000
  kubeEventSync:
    enabled: {str(is_leader).lower()}
    checkInterval: 30000
    retentionHours: 48
{pull_attestation_section}{evidence_signer_section}"""

    if harbor_cfg:
        config_content += f"""
harbor:
  endpoint: {harbor_cfg['endpoint']}
  username: {harbor_cfg['username']}
  password: {harbor_cfg['password']}
"""
    else:
        config_content += """
harbor:
  endpoint: http://localhost
  username: ''
  password: ''
"""

    if graphql_introspection is not None:
        config_content += f"""
graphql:
  introspection: {str(graphql_introspection).lower()}
"""

    changed, content_hash = _write_file_if_changed(API_CONFIG_FILE, config_content, "API config")

    if changed:
        log_info(f"Configuration file written at {API_CONFIG_FILE}")
    log_info(f"Workers enabled: {is_leader} (leader: {is_leader})")
    return changed, content_hash


def create_systemd_service(image_tag: str, host_bind_ip: str) -> tuple[bool, str]:
    """Create systemd service for swarm-cloud-api using podman with host port binding."""
    if not isinstance(host_bind_ip, str) or not host_bind_ip.strip():
        raise ValueError("host_bind_ip is required (local WireGuard tunnel IP)")

    host_bind_ip = host_bind_ip.strip()
    image_url = f"{API_IMAGE_REGISTRY}/{API_IMAGE_REPO}:{image_tag}"

    service_content = f"""[Unit]
Description=Swarm Cloud API Service (Podman Container)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=-/usr/bin/podman stop {API_CONTAINER_NAME}
ExecStartPre=-/usr/bin/podman rm {API_CONTAINER_NAME}
ExecStart=/usr/bin/podman run \\
    --name {API_CONTAINER_NAME} \\
    --rm \\
    --network=host \
    -v {API_CONFIG_DIR}:{API_CONFIG_DIR}:ro \\
    -e NODE_ENV=production \\
    -e SWC_API_CONFIG_PATH={API_CONFIG_FILE} \\
    {image_url} \\
    apps/swarm-cloud-api/dist/main.js
ExecStop=/usr/bin/podman stop {API_CONTAINER_NAME}
Restart=always
RestartSec=10
User=root
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    service_path = Path("/etc/systemd/system/swarm-cloud-api.service")
    changed, service_hash = _write_file_if_changed(service_path, service_content, "systemd service")

    # Reload systemd
    if changed:
        subprocess.run(["systemctl", "daemon-reload"], check=False)
        log_info("systemd daemon reloaded (service file changed)")
    else:
        log_info("systemd daemon reload skipped (service file unchanged)")

    return changed, service_hash


def is_systemd_service_enabled(service_name: str) -> tuple[bool, str | None]:
    try:
        result = subprocess.run(
            ["systemctl", "is-enabled", service_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        output = (result.stdout or "").strip()
        return output == "enabled", output or None
    except Exception as e:
        return False, str(e)


def _run_command_for_diagnostics(cmd: list[str], timeout: int = 10) -> str:
    """Run command and return combined output for diagnostics."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        output = (result.stdout or "").strip()
        err = (result.stderr or "").strip()
        combined = output
        if err:
            combined = f"{combined}\n{err}" if combined else err
        if not combined:
            combined = "<no output>"
        return combined
    except Exception as e:
        return f"<failed: {e}>"


def collect_api_startup_diagnostics(host: str) -> str:
    """Collect useful diagnostics when service didn't become ready."""
    api_port = get_api_port()
    diagnostics = []

    diagnostics.append("==== systemctl is-active ====")
    diagnostics.append(_run_command_for_diagnostics(["systemctl", "is-active", "swarm-cloud-api"], timeout=5))

    diagnostics.append("==== systemctl status (last 80 lines) ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            ["systemctl", "status", "swarm-cloud-api", "--no-pager", "-l", "-n", "80"],
            timeout=10,
        )
    )

    diagnostics.append("==== journalctl (last 120 lines) ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            ["journalctl", "-u", "swarm-cloud-api", "-n", "120", "--no-pager", "-l"],
            timeout=10,
        )
    )

    diagnostics.append("==== podman ps -a (swarm-cloud-api) ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            [
                "podman", "ps", "-a",
                "--filter", f"name={API_CONTAINER_NAME}",
                "--format", "table {{.ID}}\\t{{.Status}}\\t{{.Image}}\\t{{.Names}}"
            ],
            timeout=10,
        )
    )

    diagnostics.append("==== podman logs (last 120 lines) ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            ["podman", "logs", "--tail", "120", API_CONTAINER_NAME],
            timeout=10,
        )
    )

    diagnostics.append("==== listening sockets ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            ["ss", "-ltnp"],
            timeout=10,
        )
    )

    diagnostics.append("==== port probe ====")
    diagnostics.append(
        _run_command_for_diagnostics(
            ["nc", "-vz", host, str(api_port)],
            timeout=5,
        )
    )

    return "\n".join(diagnostics)


def wait_for_api_ready(host: str = "localhost", timeout_sec: int = 60) -> tuple[bool, str | None]:
    """Wait for API to start and listen on (host, port).

    Returns:
        (is_ready, diagnostics_if_failed)
    """
    start_time = time.time()
    last_error = None
    api_port = get_api_port()

    log_info(f"Waiting for API readiness on {host}:{api_port} (timeout={timeout_sec}s)")

    while time.time() - start_time < timeout_sec:
        try:
            # Check if service is active
            result = subprocess.run(
                ["systemctl", "is-active", "swarm-cloud-api"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.stdout.strip() != "active":
                last_error = f"Service not active: {result.stdout.strip()}"
                time.sleep(3)
                continue

            # Check if port is listening using nc (netcat)
            result = subprocess.run(
                ["nc", "-z", host, str(api_port)],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode == 0:
                log_info(f"Swarm-cloud-api is ready and listening on {host}:{api_port}")
                return True, None

            last_error = f"Port not yet listening"
        except subprocess.TimeoutExpired:
            last_error = "Port check timed out"
        except Exception as e:
            last_error = f"Port check error: {str(e)}"

        time.sleep(3)

    diagnostics = collect_api_startup_diagnostics(host)
    log_warn(f"Swarm-cloud-api did not become ready within {timeout_sec}s. Last error: {last_error}")
    log_warn(f"Startup diagnostics:\n{diagnostics}")
    return False, diagnostics


def is_api_running() -> tuple[bool, str | None]:
    """Check if swarm-cloud-api is running.
    Returns (is_running, error_message)
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "swarm-cloud-api"],
            capture_output=True,
            text=True
        )
        is_active = result.stdout.strip() == "active"
        return is_active, None if is_active else f"Service status: {result.stdout.strip()}"
    except Exception as e:
        return False, f"Failed to check service status: {str(e)}"




def get_secret_from_swarmdb(state_json: dict, secret_id: str) -> str | None:
    """Get secret value from SwarmSecrets table."""
    secrets = state_json.get("swarmSecrets", [])
    for secret in secrets:
        if secret.get("id") == secret_id:
            return secret.get("value")
    return None


def get_minio_connection_from_state(state_json: dict) -> tuple[str | None, str | None, str | None]:
    """Extract MinIO endpoint and credentials from state (if available).

    Values are published by the MinIO service on the leader node as
    clusternodeproperties:
      - minio_api_endpoint
      - minio_root_user
      - minio_root_password
    """
    minio_props = state_json.get("minioNodeProperties", [])
    if not isinstance(minio_props, list) or not minio_props:
        return None, None, None

    endpoint = None
    root_user = None
    root_password = None

    for prop in minio_props:
        name = prop.get("name")
        value = prop.get("value")
        if not isinstance(name, str):
            continue
        if name == "minio_api_endpoint" and isinstance(value, str) and value.strip():
            endpoint = value.strip()
        elif name == "minio_root_user" and isinstance(value, str) and value.strip():
            root_user = value.strip()
        elif name == "minio_root_password" and isinstance(value, str) and value.strip():
            root_password = value.strip()

    return endpoint, root_user, root_password


def get_harbor_connection_from_state(state_json: dict) -> dict | None:
    """Extract Harbor endpoint and admin credentials from cluster properties (if available).

    Values are published by the Harbor service as clusterproperties:
      - harbor_endpoint
      - harbor_admin_username
      - harbor_admin_password
    """
    harbor_props = state_json.get("harborClusterProperties", [])
    if not isinstance(harbor_props, list) or not harbor_props:
        return None

    props_map: dict[str, str] = {}
    for prop in harbor_props:
        name = prop.get("name")
        value = prop.get("value")
        if isinstance(name, str) and isinstance(value, str):
            props_map[name] = value

    endpoint = props_map.get("harbor_endpoint")
    username = props_map.get("harbor_admin_username")
    password = props_map.get("harbor_admin_password")

    if not endpoint or not username or not password:
        return None

    return {
        "endpoint": endpoint,
        "username": username,
        "password": password,
    }
# Plugin commands

@plugin.command('init')
def handle_init(input_data: PluginInput) -> PluginOutput:
    """Initialize swarm-cloud-api: pull Docker image and create systemd service."""
    local_state = input_data.local_state or {}

    try:
        image_tag = get_image_tag_from_env()
        log_info(f"Using image tag: {image_tag}")

        pull_api_image(image_tag)
        # Store image tag in local state for future reference
        local_state['image_tag'] = image_tag

    except Exception as e:
        return PluginOutput(status='error', error_message=str(e), local_state=local_state)

    return PluginOutput(status='completed', local_state=local_state)


def initialize_schema_if_needed(
    local_node_id: str,
    state_json: dict,
    api_node_props: list,
    image_tag: str
) -> tuple[bool, str | None, bool]:
    """Initialize database schema if not already done using a separate container.
    Returns (success, error_message, ran_sync).
    """
    # Check if schema is already initialized (from cluster properties in state)
    cluster_properties = state_json.get("clusterProperties", [])
    schema_initialized = any(
        prop.get("name") == "swarm_cloud_api_schema_initialized" and prop.get("value") == "true"
        for prop in cluster_properties
    )

    if schema_initialized:
        log_info("Database schema already initialized")
        return True, None, False

    schema_sync_done = any(
        prop.get("name") == "swarm_cloud_api_schema_sync_done" and
        prop.get("value") == "true" and
        prop.get("node_id") == local_node_id
        for prop in api_node_props
    )
    if schema_sync_done:
        log_info("Schema sync already performed on this node")
        return True, None, False

    # Only leader should initialize schema
    is_leader = is_local_node_leader(local_node_id, state_json)
    if not is_leader:
        log_info("Not a leader, skipping schema initialization")
        return False, "Waiting for leader to initialize schema", False

    log_info("Leader node, initializing database schema...")

    # Get CockroachDB connection info
    cockroach_info = get_cockroach_connection_info(local_node_id, state_json)
    if not cockroach_info:
        return False, "No CockroachDB connection available", False

    # Set environment variables for schema sync
    image_url = f"{API_IMAGE_REGISTRY}/{API_IMAGE_REPO}:{image_tag}"

    # Run schema sync in a separate container with host networking
    try:
        log_info(f"Running schema sync in container: {image_url}")
        result = subprocess.run(
            [
                "podman", "run", "--rm", "--network", "host",
                "-e", "DB_TYPE=postgres",
                "-e", f"DB_HOST={cockroach_info['host']}",
                "-e", f"DB_PORT={cockroach_info['port']}",
                "-e", f"DB_USERNAME={cockroach_info['username']}",
                "-e", f"DB_PASSWORD={cockroach_info.get('password', '')}",
                "-e", f"DB_DATABASE={cockroach_info['database']}",
                image_url,
                "apps/swarm-cloud-api/dist/cli/schema-sync.js"
            ],
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes timeout
        )

        if result.returncode != 0:
            error_msg = f"Schema sync failed: {result.stderr}"
            log_error(error_msg)
            return False, error_msg, False

        if result.stdout:
            log_info(result.stdout.strip())
        log_info("Database schema initialized successfully")
        return True, None, True

    except subprocess.TimeoutExpired:
        return False, "Schema sync timed out after 5 minutes", False
    except Exception as e:
        return False, f"Schema sync error: {str(e)}", False


@plugin.command('apply')
def handle_apply(input_data: PluginInput) -> PluginOutput:
    """Apply swarm-cloud-api configuration and start the service."""
    local_node_id = input_data.local_node_id
    state_json = input_data.state or {}
    local_state = input_data.local_state or {}
    node_properties = {}

    def out(status: str, error_message: str | None = None, cluster_properties: dict | None = None) -> PluginOutput:
        if error_message:
            log_info(f"apply result: status={status}, reason={error_message}")
        else:
            log_info(f"apply result: status={status}")
        return PluginOutput(
            status=status,
            error_message=error_message,
            local_state=local_state,
            node_properties=node_properties,
            cluster_properties=cluster_properties
        )

    # Ensure state_json is a dict
    if not isinstance(state_json, dict):
        return out(status='error', error_message='Invalid state format')

    is_leader = is_local_node_leader(local_node_id, state_json)

    try:
        auth_ip = get_first_ready_auth_service_ip(state_json)
        auth_service_url = build_auth_service_url_from_auth_node_ip(auth_ip)
    except Exception as e:
        return out(status='postponed', error_message=str(e))

    cluster_nodes = state_json.get("clusterNodes", [])
    wg_props = state_json.get("wgNodeProperties", [])
    cockroach_cluster = state_json.get("cockroachCluster", {})
    cockroach_props = state_json.get("cockroachNodeProperties", [])

    if not (isinstance(cluster_nodes, list) and cluster_nodes):
        return out(status='postponed', error_message='Waiting for dependency clusterNodes')

    # Check if all nodes have WireGuard configured
    if not check_all_nodes_have_wg(cluster_nodes, wg_props):
        return out(status='postponed', error_message='Waiting for WireGuard to be configured on all nodes')

    local_tunnel_ip = get_node_tunnel_ip(local_node_id, wg_props)
    if not isinstance(local_tunnel_ip, str) or not local_tunnel_ip.strip():
        return out(status='postponed', error_message='Waiting for WireGuard tunnel IP on local node')

    # Check if CockroachDB cluster exists
    if not cockroach_cluster.get("id"):
        return out(status='postponed', error_message='Waiting for CockroachDB cluster to be created')

    # Check if at least one CockroachDB node is ready
    ready_cockroach_nodes = [
        prop for prop in cockroach_props
        if prop.get("name") == "cockroachdb_node_ready" and prop.get("value") == "true"
    ]

    if not ready_cockroach_nodes:
        return out(status='postponed', error_message='Waiting for at least one CockroachDB node to be ready')

    # Get image tag
    image_tag = local_state.get("image_tag") or get_image_tag_from_env()

    # Initialize database schema if needed (only on leader, only once)
    api_node_props = state_json.get("apiNodeProperties", [])
    schema_success, schema_error, ran_schema_sync = initialize_schema_if_needed(
        local_node_id, state_json, api_node_props, image_tag
    )
    if not schema_success:
        return out(status='postponed', error_message=schema_error or 'Waiting for schema initialization')
    if ran_schema_sync:
        node_properties["swarm_cloud_api_schema_sync_done"] = "true"

    # Create configuration file
    try:
        config_changed, config_hash = create_config_file(local_node_id, state_json, auth_service_url)
    except Exception as e:
        return out(status='error', error_message=f'Failed to create config: {str(e)}')

    # Update systemd service with current image tag
    try:
        service_changed, service_hash = create_systemd_service(image_tag, local_tunnel_ip)
    except Exception as e:
        return out(status='error', error_message=f'Failed to create systemd service: {str(e)}')

    log_info(
        "apply artifacts: "
        f"config_changed={config_changed}, config_sha={config_hash[:12]}, "
        f"service_changed={service_changed}, service_sha={service_hash[:12]}"
    )

    # Ensure service enabled / restarted only when needed
    try:
        service_enabled, enabled_state = is_systemd_service_enabled("swarm-cloud-api")
        if not service_enabled:
            result = subprocess.run(["systemctl", "enable", "swarm-cloud-api"], capture_output=True, text=True)
            if result.returncode != 0:
                return out(status='error', error_message=f'Failed to enable swarm-cloud-api: {result.stderr}')
            log_info("systemd service enabled")
        else:
            log_info(f"systemd service already enabled ({enabled_state})")

        api_running, api_error = is_api_running()
        restart_reasons = []
        if not api_running:
            restart_reasons.append(f"service_not_active={api_error or 'unknown'}")
        if config_changed:
            restart_reasons.append("config_changed")
        if service_changed:
            restart_reasons.append("systemd_unit_changed")

        if restart_reasons:
            log_info(f"Restarting swarm-cloud-api: reasons={','.join(restart_reasons)}")
            result = subprocess.run(["systemctl", "restart", "swarm-cloud-api"], capture_output=True, text=True)
            if result.returncode != 0:
                return out(status='error', error_message=f'Failed to start swarm-cloud-api: {result.stderr}')
        else:
            log_info("Skipping restart: service active and no config/service changes")

    except Exception as e:
        return out(status='error', error_message=f'Failed to start swarm-cloud-api: {str(e)}')

    # Wait for API to become ready
    api_ready, api_startup_diagnostics = wait_for_api_ready(host=local_tunnel_ip, timeout_sec=60)

    if not api_ready:
        diagnostics_suffix = ""
        if api_startup_diagnostics:
            diagnostics_suffix = f"\nDiagnostics:\n{api_startup_diagnostics}"
        return out(status='postponed', error_message=f'Swarm-cloud-api did not become ready within timeout{diagnostics_suffix}')
    cluster_properties = {}

    # If we are the leader and schema was just initialized, mark it in cluster properties
    cluster_props = state_json.get("clusterProperties", [])
    schema_already_marked = any(
        prop.get("name") == "swarm_cloud_api_schema_initialized" and prop.get("value") == "true"
        for prop in cluster_props
    )

    if is_leader and not schema_already_marked:
        cluster_properties["swarm_cloud_api_schema_initialized"] = "true"

    # Prepare properties to return
    node_properties.update(_node_ready_props("true"))
    # SP-7700: publish image identity for the control-plane evidence aggregator.
    image_url = f"{API_IMAGE_REGISTRY}/{API_IMAGE_REPO}:{image_tag}"
    node_properties.update(
        build_image_evidence_props(
            prefix="swarm_cloud_api",
            image_ref=image_url,
            manifest_version=read_manifest_version(Path(__file__).parent),
        )
    )

    return out(status='completed', cluster_properties=cluster_properties if cluster_properties else None)


@plugin.command('health')
def handle_health(input_data: PluginInput) -> PluginOutput:
    """Check swarm-cloud-api health."""
    local_state = input_data.local_state or {}
    node_properties = _node_ready_props("false")

    # Check if API is running
    api_running, api_error = is_api_running()
    if not api_running:
        if api_error and 'Failed to' in api_error:
            # Real error checking status
            return PluginOutput(status='error', error_message=api_error, local_state=local_state, node_properties=node_properties)
        else:
            # Service not running yet
            return PluginOutput(status='postponed', error_message=api_error or 'Swarm-cloud-api service is not running', local_state=local_state, node_properties=node_properties)

    return PluginOutput(status='completed', local_state=local_state)


@plugin.command('finalize')
def handle_finalize(input_data: PluginInput) -> PluginOutput:
    """Finalize before node removal (graceful shutdown)."""
    local_state = input_data.local_state or {}
    node_properties = _node_ready_props("false")

    # Stop the service gracefully
    try:
        subprocess.run(["systemctl", "stop", "swarm-cloud-api"], check=False)
    except Exception as e:
        log_warn(f"Failed to stop swarm-cloud-api: {e}")

    return PluginOutput(status='completed', local_state=local_state, node_properties=node_properties)


@plugin.command('destroy')
def handle_destroy(_input_data: PluginInput) -> PluginOutput:
    """Destroy swarm-cloud-api installation and clean up."""
    try:
        # Stop and disable systemd service
        subprocess.run(["systemctl", "stop", "swarm-cloud-api"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["systemctl", "disable", "swarm-cloud-api"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Stop and remove podman container
        subprocess.run(["podman", "stop", API_CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["podman", "rm", API_CONTAINER_NAME], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Remove systemd service file
        service_path = "/etc/systemd/system/swarm-cloud-api.service"
        if os.path.exists(service_path):
            os.remove(service_path)
        subprocess.run(["systemctl", "daemon-reload"], check=False)

        # Remove config directory
        if API_CONFIG_DIR.exists():
            shutil.rmtree(API_CONFIG_DIR, ignore_errors=True)

        # Request deletion of node properties
        node_properties = _node_ready_props(None)

        return PluginOutput(
            status='completed',
            node_properties=node_properties,
            local_state={}
        )
    except Exception as e:
        return PluginOutput(status='error', error_message=f'Failed to destroy swarm-cloud-api: {e}', local_state={})


if __name__ == "__main__":
    plugin.run()
