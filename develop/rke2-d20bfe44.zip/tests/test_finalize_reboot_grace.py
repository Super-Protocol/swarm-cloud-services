"""Finalize must not read a still-starting rke2-server as a leave (SUP-703)."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load(name: str, path: Path):
    for p in (str(RKE2_DIR), str(SDK_DIR)):
        if p not in sys.path:
            sys.path.insert(0, p)
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def main_mod():
    return _load("rke2_main_finalize_grace", RKE2_DIR / "main.py")


def test_running_server_proceeds_to_member_removal(main_mod):
    action, state = main_mod.assess_finalize_server_start(
        running=True, remove_started=False, has_etcd_db=True, local_state={}, now=100.0
    )
    assert action == "proceed"
    assert state.get("finalize_server_down_since") is None


def test_remove_already_started_proceeds_even_with_unit_down(main_mod):
    action, _ = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=True,
        has_etcd_db=True,
        local_state={},
        now=100.0,
    )
    assert action == "proceed"


def test_first_tick_after_boot_waits_instead_of_destroying(main_mod):
    """Membership intact + rke2-server inactive right after boot = start and wait."""
    action, state = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=False,
        has_etcd_db=True,
        local_state={},
        now=100.0,
    )
    assert action == "wait"
    assert state["finalize_server_down_since"] == 100.0


def test_keeps_waiting_inside_the_grace(main_mod):
    action, state = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=False,
        has_etcd_db=True,
        local_state={"finalize_server_down_since": 100.0},
        now=100.0 + main_mod.FINALIZE_SERVER_START_GRACE_SEC - 1,
    )
    assert action == "wait"
    assert state["finalize_server_down_since"] == 100.0


def test_gives_up_after_the_grace_so_a_real_leave_can_finish(main_mod):
    action, state = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=False,
        has_etcd_db=True,
        local_state={"finalize_server_down_since": 100.0},
        now=100.0 + main_mod.FINALIZE_SERVER_START_GRACE_SEC,
    )
    assert action == "skip"
    assert state.get("finalize_server_down_since") is None


def test_no_local_etcd_data_is_positive_evidence_of_nothing_to_leave(main_mod):
    action, _ = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=False,
        has_etcd_db=False,
        local_state={},
        now=100.0,
    )
    assert action == "skip"


def test_marker_is_cleared_once_the_server_comes_up(main_mod):
    action, state = main_mod.assess_finalize_server_start(
        running=True,
        remove_started=False,
        has_etcd_db=True,
        local_state={"finalize_server_down_since": 100.0},
        now=200.0,
    )
    assert action == "proceed"
    assert state["finalize_server_down_since"] is None


def test_corrupt_marker_restarts_the_grace(main_mod):
    action, state = main_mod.assess_finalize_server_start(
        running=False,
        remove_started=False,
        has_etcd_db=True,
        local_state={"finalize_server_down_since": "not-a-number"},
        now=100.0,
    )
    assert action == "wait"
    assert state["finalize_server_down_since"] == 100.0


def test_finalize_postpones_and_starts_the_unit_after_a_reboot(main_mod, tmp_path):
    """End-to-end: no 'skip to destroy', the leave path is held, the unit is started."""
    etcd_dir = tmp_path / "db" / "etcd"
    etcd_dir.mkdir(parents=True)
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(False, "activating")),
        patch.object(main_mod, "RKE2_ETCD_DATA_DIR", etcd_dir),
        patch.object(main_mod, "start_rke2_server_unit", return_value=(True, None)) as start,
        patch.object(main_mod, "list_etcd_members") as members,
        patch.object(main_mod, "remove_etcd_member") as remove,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(
                local_node_id="node-a",
                state={"wgNodeProperties": []},
                local_state={"etcd_member_id": "abc123"},
            )
        )

    assert result.status == "postponed"
    assert result.local_state["finalize_server_down_since"] is not None
    # The member must survive the reboot untouched.
    assert result.local_state["etcd_member_id"] == "abc123"
    start.assert_called_once()
    members.assert_not_called()
    remove.assert_not_called()


def test_finalize_completes_when_the_data_dir_is_already_gone(main_mod, tmp_path):
    with (
        patch.object(main_mod, "is_rke2_available", return_value=True),
        patch.object(main_mod, "etcd_tls_ready", return_value=True),
        patch.object(main_mod, "is_rke2_running", return_value=(False, "inactive")),
        patch.object(main_mod, "RKE2_ETCD_DATA_DIR", tmp_path / "missing"),
        patch.object(main_mod, "start_rke2_server_unit") as start,
    ):
        result = main_mod.handle_finalize(
            SimpleNamespace(local_node_id="node-a", state={}, local_state={})
        )

    assert result.status == "completed"
    start.assert_not_called()


def test_apply_forgets_a_cancelled_start_grace(main_mod):
    """The window must not outlive the flap, or the next reboot reads it as expired."""
    state = main_mod.clear_finalize_start_grace({"finalize_server_down_since": 100.0})
    assert state["finalize_server_down_since"] is None


def test_clearing_an_unset_start_grace_is_a_no_op(main_mod):
    state = {"install_hash": "abc"}
    assert main_mod.clear_finalize_start_grace(state) is state


def test_destroy_keeps_local_state_on_failure(main_mod):
    """A retried leave still needs etcd_member_remove_started to skip the start grace."""
    with patch.object(main_mod.subprocess, "run", side_effect=OSError("systemctl gone")):
        result = main_mod.handle_destroy(
            SimpleNamespace(
                local_node_id="node-a",
                state={},
                local_state={"etcd_member_remove_started": True, "etcd_member_id": "abc123"},
            )
        )

    assert result.status == "error"
    assert result.local_state["etcd_member_remove_started"] is True
