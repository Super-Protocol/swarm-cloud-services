"""Admission e2e for the Pod Security config this plugin ships (SUP-634).

A unit test can only prove we render the YAML we meant to. What SUP-634 actually claims is a
statement about a *running* kube-apiserver: that the pod in the issue is rejected inside a
tenant namespace, that a conformant pod is not, and that an exempt namespace is unaffected.
So this suite boots a real Kubernetes control plane with the file
`render_pod_security_admission_config()` produces, mounted at the path RKE2 would mount it
from, and asks that apiserver.

The control plane is k3s rather than RKE2: RKE2 needs a systemd host, k3s runs in a container,
and the component under test — upstream kube-apiserver's PodSecurity admission plugin reading
`--admission-control-config-file` — is byte-identical between them. The RKE2-specific half
(that `pod-security-admission-config-file` is what puts our file on that flag, and that the
file is mounted into the static pod) is covered by the unit tests plus the upstream behaviour
quoted in `pod_security_admission.py`.

Set RKE2_PSS_E2E=1 to run; needs a Docker daemon that can start a privileged container.
"""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]

K3S_IMAGE = os.environ.get("RKE2_PSS_E2E_K3S_IMAGE", "rancher/k3s:v1.33.4-k3s1")
TENANT_NAMESPACE = "user-sup634"
EXEMPT_NAMESPACE = "kube-system"
CONTAINER_CONFIG_PATH = "/etc/rancher/k3s/swarm-pss.yaml"
READY_TIMEOUT_SEC = 240

def _docker_available() -> bool:
    try:
        return subprocess.run(
            ["docker", "info", "--format", "{{.ServerVersion}}"],
            capture_output=True,
            text=True,
            timeout=30,
        ).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


# Skipped unless explicitly asked for, and skipped rather than errored when the runner has no
# Docker daemon — the dedicated `pss-admission-e2e` CI job is where this is meant to run.
pytestmark = pytest.mark.skipif(
    os.environ.get("RKE2_PSS_E2E") != "1" or not _docker_available(),
    reason="needs RKE2_PSS_E2E=1 and a Docker daemon able to run a privileged container",
)

# The pod from the SUP-634 report, verbatim: hostPID plus a privileged container plus the
# node root as a hostPath is what lets a tenant read a published neighbour's process memory.
NEIGHBOUR_READER_POD = """
apiVersion: v1
kind: Pod
metadata:
  name: neighbour-reader
spec:
  hostPID: true
  containers:
    - name: x
      image: busybox
      securityContext: { privileged: true }
      volumeMounts: [{ name: root, mountPath: /host }]
  volumes: [{ name: root, hostPath: { path: / } }]
"""

CONFORMANT_POD = """
apiVersion: v1
kind: Pod
metadata:
  name: well-behaved
spec:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1000
    seccompProfile: { type: RuntimeDefault }
  containers:
    - name: app
      image: busybox
      command: ["sleep", "3600"]
      securityContext:
        allowPrivilegeEscalation: false
        capabilities: { drop: ["ALL"] }
"""

# A GPU workload asks for the card through the device plugin's extended resource; it needs no
# privilege. Asserted here because "GPU pods need privileged" is the usual reason a cluster
# ends up back on `enforce: privileged`.
CONFORMANT_GPU_POD = """
apiVersion: v1
kind: Pod
metadata:
  name: gpu-well-behaved
spec:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1000
    seccompProfile: { type: RuntimeDefault }
  containers:
    - name: app
      image: busybox
      command: ["sleep", "3600"]
      resources:
        limits:
          nvidia.com/gpu: "1"
      securityContext:
        allowPrivilegeEscalation: false
        capabilities: { drop: ["ALL"] }
"""


def _load_pss_module():
    mod_path = RKE2_DIR / "pod_security_admission.py"
    spec = importlib.util.spec_from_file_location("pod_security_admission", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def pss_module():
    return _load_pss_module()


@pytest.fixture(scope="module")
def cluster(tmp_path_factory, pss_module):
    """A k3s control plane running the admission config this plugin installs."""
    config_dir = tmp_path_factory.mktemp("pss")
    config_file = config_dir / "swarm-pss.yaml"
    pss_module.write_pod_security_admission_config(config_file)
    # The container reads it as a non-root-owned bind mount; 0600 from the writer would make it
    # unreadable inside, so relax it here only (on a host it is read by root).
    config_file.chmod(0o644)

    name = f"sup634-pss-{uuid.uuid4().hex[:8]}"
    run = subprocess.run(
        [
            "docker", "run", "-d", "--name", name, "--privileged",
            "-v", f"{config_file}:{CONTAINER_CONFIG_PATH}:ro",
            K3S_IMAGE, "server",
            "--disable=traefik,metrics-server,servicelb",
            f"--kube-apiserver-arg=admission-control-config-file={CONTAINER_CONFIG_PATH}",
        ],
        capture_output=True,
        text=True,
    )
    if run.returncode != 0:
        pytest.fail(f"could not start {K3S_IMAGE}: {run.stderr.strip()}")

    try:
        _wait_for_node(name)
        _kubectl(name, ["create", "namespace", TENANT_NAMESPACE])
        # swarm-cloud-api labels every tenant namespace it creates; mirror that here so the
        # assertions cover the labelled namespace, not just the cluster default.
        _kubectl(
            name,
            [
                "label", "namespace", TENANT_NAMESPACE,
                f"pod-security.kubernetes.io/enforce={pss_module.PSS_ENFORCE_LEVEL}",
                "pod-security.kubernetes.io/enforce-version=latest",
                f"pod-security.kubernetes.io/audit={pss_module.PSS_TARGET_LEVEL}",
                "pod-security.kubernetes.io/audit-version=latest",
                f"pod-security.kubernetes.io/warn={pss_module.PSS_TARGET_LEVEL}",
                "pod-security.kubernetes.io/warn-version=latest",
            ],
        )
        # The ServiceAccount admission plugin rejects a pod before PodSecurity gets to see it
        # while the namespace's `default` ServiceAccount has not been created yet, which would
        # make "rejected" mean the wrong thing.
        _wait_for_default_service_account(name, TENANT_NAMESPACE)
        yield name
    finally:
        subprocess.run(["docker", "rm", "-f", name], capture_output=True, text=True)


def _kubectl(container: str, args: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        ["docker", "exec", container, "kubectl", *args],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if check and result.returncode != 0:
        raise AssertionError(f"kubectl {' '.join(args)} failed: {result.stderr.strip()}")
    return result


def _apply(container: str, namespace: str, manifest: str) -> subprocess.CompletedProcess[str]:
    """Server-side dry-run apply: admission runs, nothing has to be scheduled or pulled."""
    return subprocess.run(
        [
            "docker", "exec", "-i", container,
            "kubectl", "apply", "-n", namespace, "--dry-run=server", "-f", "-",
        ],
        input=manifest,
        capture_output=True,
        text=True,
        timeout=120,
    )


def _wait_for_default_service_account(container: str, namespace: str) -> None:
    deadline = time.monotonic() + READY_TIMEOUT_SEC
    while time.monotonic() < deadline:
        result = _kubectl(container, ["-n", namespace, "get", "serviceaccount", "default"], check=False)
        if result.returncode == 0:
            return
        time.sleep(1)
    pytest.fail(f"default ServiceAccount never appeared in {namespace}")


def _wait_for_node(container: str) -> None:
    deadline = time.monotonic() + READY_TIMEOUT_SEC
    while time.monotonic() < deadline:
        result = _kubectl(container, ["get", "nodes", "-o", "json"], check=False)
        if result.returncode == 0:
            try:
                nodes = json.loads(result.stdout).get("items", [])
            except json.JSONDecodeError:
                nodes = []
            if nodes:
                return
        time.sleep(3)
    logs = subprocess.run(["docker", "logs", "--tail", "40", container], capture_output=True, text=True)
    pytest.fail(f"k3s did not become ready in {READY_TIMEOUT_SEC}s:\n{logs.stdout}\n{logs.stderr}")


# ------------------------------------------------------------------ the SUP-634 claim


def test_the_neighbour_reader_pod_is_rejected_in_a_tenant_namespace(cluster, pss_module):
    result = _apply(cluster, TENANT_NAMESPACE, NEIGHBOUR_READER_POD)

    assert result.returncode != 0, f"admission allowed the privileged pod:\n{result.stdout}"
    message = result.stderr
    assert f'violates PodSecurity "{pss_module.PSS_ENFORCE_LEVEL}:latest"' in message
    # All three escape routes named in the issue have to be the reason, not just one of them.
    assert "hostPID=true" in message
    assert "privileged" in message
    assert "hostPath" in message


def test_each_escape_vector_is_rejected_on_its_own(cluster):
    """Dropping any single field must not be enough to get the pod admitted."""
    only_host_pid = """
apiVersion: v1
kind: Pod
metadata:
  name: only-host-pid
spec:
  hostPID: true
  containers: [{ name: x, image: busybox, command: ["sleep", "1"] }]
"""
    only_privileged = """
apiVersion: v1
kind: Pod
metadata:
  name: only-privileged
spec:
  containers:
    - name: x
      image: busybox
      command: ["sleep", "1"]
      securityContext: { privileged: true }
"""
    only_host_path = """
apiVersion: v1
kind: Pod
metadata:
  name: only-host-path
spec:
  containers:
    - name: x
      image: busybox
      command: ["sleep", "1"]
      volumeMounts: [{ name: root, mountPath: /host }]
  volumes: [{ name: root, hostPath: { path: / } }]
"""
    for label, manifest in (
        ("hostPID", only_host_pid),
        ("privileged", only_privileged),
        ("hostPath", only_host_path),
    ):
        result = _apply(cluster, TENANT_NAMESPACE, manifest)
        assert result.returncode != 0, f"{label} alone was admitted:\n{result.stdout}"
        assert "violates PodSecurity" in result.stderr


def test_a_conformant_pod_still_schedules(cluster):
    result = _apply(cluster, TENANT_NAMESPACE, CONFORMANT_POD)
    assert result.returncode == 0, result.stderr
    # Not even a warning: a conformant pod must clear the stricter audit/warn level too, or
    # every tenant deploy would come back noisy.
    assert "PodSecurity" not in result.stderr


def test_a_gpu_pod_needs_no_privilege(cluster):
    result = _apply(cluster, TENANT_NAMESPACE, CONFORMANT_GPU_POD)
    assert result.returncode == 0, result.stderr
    assert "PodSecurity" not in result.stderr


def test_the_target_level_is_at_least_reported(cluster, pss_module):
    """The staging contract: a pod short of the target level is warned about, or rejected.

    While `enforce` is the weaker level, the gap to `PSS_TARGET_LEVEL` has to be *visible* —
    that is what keeps the work needed to flip it from silently never happening. Once the
    two levels are the same, the same pod is rejected outright. Asserted either way rather
    than skipped, so the CI job that requires this suite to actually run keeps working after
    the flip.

    The manifest is the module's own probe pod for the target level: conformant for
    `baseline` (no privilege, no host namespace, no hostPath) but short of `restricted` (runs
    as root, no seccomp profile, capabilities not dropped). Asserting on this exact pod is
    what proves the level-aware probe can tell the two levels apart — a privileged pod
    violates both, so it could not.
    """
    result = _apply(cluster, TENANT_NAMESPACE, pss_module.PSS_PROBE_PODS[pss_module.PSS_TARGET_LEVEL])
    target = pss_module.PSS_TARGET_LEVEL

    if pss_module.PSS_ENFORCE_LEVEL == target:
        assert result.returncode != 0, f"enforce is {target} but the pod was admitted"
        assert f'violates PodSecurity "{target}:latest"' in result.stderr
    else:
        assert result.returncode == 0, result.stderr
        assert f'would violate PodSecurity "{target}:latest"' in result.stderr


def test_the_probe_pod_for_the_enforced_level_is_rejected(cluster, pss_module):
    """What `pod_security_admission_enforced()` relies on, against a real apiserver."""
    result = _apply(cluster, TENANT_NAMESPACE, pss_module.pod_security_probe_pod())

    assert result.returncode != 0, f"the probe pod was admitted:\n{result.stdout}"
    assert f'violates PodSecurity "{pss_module.PSS_ENFORCE_LEVEL}:latest"' in result.stderr


def test_the_exempt_system_namespace_is_unaffected(cluster, pss_module):
    """kube-system runs canal and the NVIDIA device plugin; both need privileged + hostPath."""
    assert EXEMPT_NAMESPACE in pss_module.PSS_EXEMPT_NAMESPACES
    result = _apply(cluster, EXEMPT_NAMESPACE, NEIGHBOUR_READER_POD)
    assert result.returncode == 0, result.stderr


def test_a_namespace_not_on_the_exemption_list_is_enforced(cluster):
    """The exemption is by name: a namespace that merely looks system-ish gets no pass."""
    _kubectl(cluster, ["create", "namespace", "kube-system-lookalike"], check=False)
    _wait_for_default_service_account(cluster, "kube-system-lookalike")
    result = _apply(cluster, "kube-system-lookalike", NEIGHBOUR_READER_POD)
    assert result.returncode != 0, result.stdout
    assert "violates PodSecurity" in result.stderr


# ------------------------------------------------------------------ tenant cannot opt out


def test_the_tenant_cannot_relabel_its_namespace_out_of_enforcement(cluster):
    """`tenant-editor` has only get/list/watch on namespaces, so the label is not tenant-writable."""
    clusterrole = (RKE2_DIR / "configs" / "tenant-editor-clusterrole.yaml").read_text()
    apply_role = subprocess.run(
        ["docker", "exec", "-i", cluster, "kubectl", "apply", "-f", "-"],
        input=clusterrole,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert apply_role.returncode == 0, apply_role.stderr

    tenant = f"system:serviceaccount:{TENANT_NAMESPACE}:ns-editor"
    _kubectl(cluster, ["-n", TENANT_NAMESPACE, "create", "serviceaccount", "ns-editor"], check=False)
    _kubectl(
        cluster,
        [
            "-n", TENANT_NAMESPACE, "create", "rolebinding", "ns-editor-edit",
            "--clusterrole=tenant-editor",
            f"--serviceaccount={TENANT_NAMESPACE}:ns-editor",
        ],
        check=False,
    )

    # Sanity: the binding is live and the tenant really is a tenant.
    can_create_pods = _kubectl(
        cluster,
        ["auth", "can-i", "create", "pods", "-n", TENANT_NAMESPACE, f"--as={tenant}"],
        check=False,
    )
    assert can_create_pods.stdout.strip() == "yes", can_create_pods.stdout

    relabel = _kubectl(
        cluster,
        [
            "label", "namespace", TENANT_NAMESPACE,
            "pod-security.kubernetes.io/enforce=privileged", "--overwrite",
            f"--as={tenant}",
        ],
        check=False,
    )
    assert relabel.returncode != 0, "the tenant was able to relabel its own namespace"
    assert "forbidden" in relabel.stderr
    assert "namespaces" in relabel.stderr

    # And the pod is still rejected afterwards.
    assert _apply(cluster, TENANT_NAMESPACE, NEIGHBOUR_READER_POD).returncode != 0
