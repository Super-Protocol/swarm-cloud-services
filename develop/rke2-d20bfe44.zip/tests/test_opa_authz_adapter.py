"""Unit tests for authz webhook adapter (build_status, HTTP handler, policy integration)."""

from __future__ import annotations

import http.client
import importlib.util
import io
import json
import os
import sys
import threading
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import pytest

ADAPTER_DIR = Path(__file__).resolve().parents[1] / "configs" / "opa-authz-webhook" / "adapter"
DATA_JSON = Path(__file__).resolve().parents[1] / "configs" / "opa-authz-webhook" / "policies" / "data.json"


def _load_adapter_module():
    os.environ.setdefault("TLS_CERT_FILE", "/tmp/opa-authz-test.crt")
    os.environ.setdefault("TLS_KEY_FILE", "/tmp/opa-authz-test.key")
    os.environ.setdefault("CLIENT_CA_FILE", "/tmp/opa-authz-test-ca.crt")
    os.environ["POLICY_DATA_FILE"] = str(DATA_JSON)

    policy_spec = importlib.util.spec_from_file_location("authz_policy", ADAPTER_DIR / "policy.py")
    assert policy_spec and policy_spec.loader
    policy_mod = importlib.util.module_from_spec(policy_spec)
    sys.modules[policy_spec.name] = policy_mod
    policy_spec.loader.exec_module(policy_mod)

    adapter_spec = importlib.util.spec_from_file_location("authz_adapter", ADAPTER_DIR / "adapter.py")
    assert adapter_spec and adapter_spec.loader
    adapter_mod = importlib.util.module_from_spec(adapter_spec)
    sys.modules[adapter_spec.name] = adapter_mod
    adapter_spec.loader.exec_module(adapter_mod)
    return adapter_mod


@pytest.fixture
def adapter():
    return _load_adapter_module()


def _sample_review(*, verb: str = "get", name: str = "my-app", namespace: str = "user-abc") -> dict:
    attrs: dict[str, str] = {
        "namespace": namespace,
        "verb": verb,
        "group": "",
        "resource": "secrets",
    }
    if name:
        attrs["name"] = name
    return {
        "kind": "SubjectAccessReview",
        "spec": {
            "user": f"system:serviceaccount:{namespace}:ns-editor",
            "resourceAttributes": attrs,
        },
    }


def test_build_status_allow(adapter):
    review = _sample_review()
    status = adapter.build_status("allow", review)
    assert status["allowed"] is True
    assert status["denied"] is False
    assert "allowed" in status["reason"]


def test_build_status_deny(adapter):
    review = _sample_review(name="swarm-pull", verb="patch")
    status = adapter.build_status("deny", review)
    assert status["allowed"] is False
    assert status["denied"] is True
    assert "swarm-pull" in status["reason"]


def test_build_status_no_opinion(adapter):
    review = _sample_review(verb="deletecollection", name="")
    status = adapter.build_status("no_opinion", review)
    assert status["allowed"] is False
    assert status["denied"] is False
    assert "no opinion" in status["reason"]


def test_authorize_denies_patch_swarm_pull(adapter):
    body = json.dumps(_sample_review(verb="patch", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is True


def test_authorize_cross_tenant_secret_is_no_opinion(adapter):
    review = _sample_review(verb="get", name="swarm-pull", namespace="user-other-tenant")
    review["spec"]["user"] = "system:serviceaccount:user-abc:ns-editor"
    body = json.dumps(review).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is False


def test_authorize_allows_get_swarm_pull(adapter):
    body = json.dumps(_sample_review(verb="get", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is True
    assert status["denied"] is False


def test_authorize_degraded_fallback_on_policy_error(adapter):
    body = json.dumps(_sample_review(verb="patch", name="swarm-pull")).encode()
    request_bytes = (
        b"POST /authorize HTTP/1.1\r\n"
        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
        b"\r\n"
    ) + body

    class FakeSocket:
        def __init__(self, data: bytes):
            self._read = io.BytesIO(data)
            self.response = io.BytesIO()

        def makefile(self, mode: str, bufsize: int = -1):
            if "r" in mode:
                return self._read
            return self.response

        def sendall(self, data: bytes) -> None:
            self.response.write(data)

    sock = FakeSocket(request_bytes)
    with patch.object(adapter, "evaluate", side_effect=RuntimeError("policy boom")):
        adapter.Handler(sock, ("127.0.0.1", 9999), None)

    raw = sock.response.getvalue().decode()
    json_body = raw.split("\r\n\r\n", 1)[1]
    status = json.loads(json_body)["status"]
    assert status["allowed"] is False
    assert status["denied"] is True


@contextmanager
def _serving(adapter):
    """Run the real handler on a loopback port, so framing is exercised by a real client."""
    server = adapter.ReuseAddrHTTPServer(("127.0.0.1", 0), adapter.Handler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_healthz_response_is_framed_for_a_keepalive_client(adapter):
    """Without Content-Length on an HTTP/1.1 keep-alive response the client blocks until it times
    out — which is how the health probe hung for 10 s on every cycle (SUP-664). The read below is
    what regresses: it would raise a socket timeout instead of returning.
    """
    with _serving(adapter) as (host, port):
        conn = http.client.HTTPConnection(host, port, timeout=5)
        try:
            conn.request("GET", "/healthz")
            resp = conn.getresponse()
            assert resp.status == 200
            assert resp.getheader("Content-Length") == "3"
            assert resp.read() == b"ok\n"

            # Framed means the connection stays usable, which is the point of keep-alive.
            conn.request("GET", "/health")
            assert conn.getresponse().read() == b"ok\n"
        finally:
            conn.close()


@pytest.mark.parametrize(
    ("method", "path", "body", "expected"),
    [
        ("GET", "/nope", None, 404),
        ("POST", "/nope", b"{}", 404),
        ("POST", "/authorize", b"{not-json", 400),
        ("POST", "/authorize", b'{"kind": "Something"}', 400),
    ],
)
def test_empty_body_responses_are_framed(adapter, method, path, body, expected):
    """An empty body still needs Content-Length: 0, or the client waits for a body that never comes."""
    with _serving(adapter) as (host, port):
        conn = http.client.HTTPConnection(host, port, timeout=5)
        try:
            conn.request(method, path, body=body)
            resp = conn.getresponse()
            assert resp.status == expected
            assert resp.getheader("Content-Length") == "0"
            assert resp.read() == b""
        finally:
            conn.close()


def test_authorize_response_is_framed_and_connection_reusable(adapter):
    review = _sample_review(verb="patch", name="swarm-pull")
    with _serving(adapter) as (host, port):
        conn = http.client.HTTPConnection(host, port, timeout=5)
        try:
            for _ in range(2):
                conn.request("POST", "/authorize", body=json.dumps(review).encode())
                resp = conn.getresponse()
                assert resp.status == 200
                payload = resp.read()
                assert resp.getheader("Content-Length") == str(len(payload))
                assert json.loads(payload)["status"]["denied"] is True
        finally:
            conn.close()
