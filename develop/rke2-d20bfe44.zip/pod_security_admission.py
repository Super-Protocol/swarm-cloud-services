"""Pod Security Admission: enforce a Pod Security Standard cluster-wide (SUP-634).

Outside CIS mode RKE2 writes its own PodSecurity AdmissionConfiguration with
`defaults: {enforce: privileged}` on every server start (upstream `pkg/rke2/psa.go`), i.e.
admission allows everything. A holder of a tenant namespace token could therefore create a
`privileged` / `hostPID` / `hostPath` pod and read `/proc/<pid>/mem` of a *published* space's
pods scheduled on the same node — a capability the measured image is not supposed to hand to
the operator.

We do not switch RKE2 to `profile: cis` to pick up its restricted default: that also rewrites
kernel sysctls, the etcd user and the NetworkPolicy defaults, which is a separate decision.
Instead we ship our own AdmissionConfiguration and point RKE2's first-class
`pod-security-admission-config-file` server option at it. With that option set RKE2 skips
writing `rke2-pss.yaml` and passes our file to kube-apiserver as
`--admission-control-config-file`. The static-pod generator bind-mounts every absolute path it
finds in an apiserver argument (upstream `pkg/podtemplate/podtemplate.go:ReadFiles`), so the
file must already exist when rke2-server starts — hence `install_pod_security_admission()` runs
next to `write_rke2_config()`, before `systemctl start`.

Exemptions are by namespace only. A `usernames` or `runtimeClasses` exemption would be
inheritable by a tenant; a namespace one is not, and `tenant-editor` holds only
get/list/watch on `namespaces`, so a tenant cannot relabel its way out either.

See `PSS_ENFORCE_LEVEL` / `PSS_TARGET_LEVEL` for which level is enforced today and why.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable

RKE2_CONFIG_FILE = Path(os.environ.get("RKE2_CONFIG_FILE", "/etc/rancher/rke2/config.yaml"))
RKE2_KUBECONFIG = Path(os.environ.get("RKE2_KUBECONFIG", "/etc/rancher/rke2/rke2.yaml"))
KUBECTL_BIN = os.environ.get("RKE2_KUBECTL", "/var/lib/rancher/rke2/bin/kubectl")
# Our own filename: `rke2-pss.yaml` is owned by RKE2, which truncates it whenever
# `pod-security-admission-config-file` is unset.
PSS_CONFIG_FILE = Path(os.environ.get("RKE2_PSS_CONFIG_FILE", "/etc/rancher/rke2/swarm-pss.yaml"))

PSS_RKE2_OPTION = "pod-security-admission-config-file"

# The level admission ENFORCES. `baseline` is what closes SUP-634: it rejects `privileged`,
# host namespaces (hostPID / hostIPC / hostNetwork) and `hostPath` volumes, which is every
# vector by which a tenant pod could read a published neighbour's memory on the same node.
PSS_ENFORCE_LEVEL = "baseline"
# The level admission AUDITS and WARNS against: the target, one step stricter. `restricted`
# additionally demands runAsNonRoot, seccomp RuntimeDefault, no privilege escalation and
# dropped capabilities. Enforcing it today would reject every marketplace chart (verified
# against all 35 golden manifests in Super-Protocol/swarm-marketplace-catalog on a real
# v1.33 apiserver), so it is audited and warned first: operators and the apiserver audit log
# record the gap while the charts are brought up to it. Set PSS_ENFORCE_LEVEL to this value
# once they conform — nothing else in this module has to change.
PSS_TARGET_LEVEL = "restricted"
# `latest` pins enforcement to the PodSecurity version shipped with the running apiserver, so
# an RKE2 bump cannot silently relax a level by leaving us on an older ruleset.
PSS_VERSION = "latest"

# Namespaces whose workloads legitimately need more than the enforced level, and nothing else:
#   kube-system        canal, coredns, metrics-server, ingress-nginx, the NVIDIA device plugin
#                      (privileged + hostPath), RKE2's own helm-install jobs
#   local-path-storage local-path-provisioner and its hostPath helper pods
#   opa-authz-system   the authz webhook adapter, which uses hostNetwork to serve the
#                      apiserver over host loopback
# A tenant namespace never appears here: tenant namespaces are named `user-*` and are created
# by swarm-cloud-api, which has no way to add an entry to this list.
PSS_EXEMPT_NAMESPACES = ("kube-system", "local-path-storage", "opa-authz-system")

# Tenant namespaces, which the leader relabels so the labels cannot go stale against the
# cluster default (a namespace label overrides the default for that namespace).
TENANT_NS_PREFIX = "user-"

# local_state key holding the config digest this node has already restarted rke2-server for.
# Guards against a restart loop when a restart does not fix enforcement: we try once per
# config version, then report the node unhealthy instead of bouncing the apiserver forever.
PSS_RESTART_STATE_KEY = "pss_restart_attempted_digest"

# local_state key holding the monotonic timestamp of the last live probe, so the periodic
# health check re-probes on an interval instead of once a minute forever. Each probe is a
# rejected mutating request: at 60s intervals across every node that is a steady stream of
# admission denials in the audit log, which would bury a real privileged-pod attempt.
PSS_PROBE_AT_STATE_KEY = "pss_probed_at"
PSS_PROBE_VERDICT_STATE_KEY = "pss_probe_verdict"
PSS_PROBE_INTERVAL_SEC = int(os.environ.get("RKE2_PSS_PROBE_INTERVAL_SEC", "1800"))
# Time budgets. These are picked so the worst case of everything this module can do on one
# apply tick adds up to less than the plugin command timeout (300s) — see
# `pss_worst_case_seconds()` and the test that asserts it. A deep health tick is bounded
# separately by the three probe calls, which have to fit in 30s.
#
# That 300s is *shared*: the same apply tick also runs the OPA authz and credential-provider
# reconciles and, on the leader, the kube-system evidence collection. This module's worst case
# therefore has to leave room, not merely fit. It is on the generous side of that, which the
# on-disk restart marker makes survivable — a tick killed for overrunning still recorded its
# restart, so the node does not bounce its apiserver again.
#
# Each probe call is a dry-run admission check against a local apiserver: milliseconds when
# anything works at all, so the timeout is a liveness bound, not a work estimate. Three of
# them run on a deep health tick (the load check, the namespace read, the dry-run apply).
PSS_PROBE_TIMEOUT_SEC = int(os.environ.get("RKE2_PSS_PROBE_TIMEOUT_SEC", "5"))
PSS_PROBE_CALLS = 3
PSS_RESTART_TIMEOUT_SEC = int(os.environ.get("RKE2_PSS_RESTART_TIMEOUT_SEC", "120"))
# How long the caller waits for the local apiserver after the restart.
PSS_API_WAIT_SEC = int(os.environ.get("RKE2_PSS_API_WAIT_SEC", "90"))
# The leader's namespace label sweep runs on the same apply path as the restart, so it gets a
# wall-clock budget rather than only a count: the count is a proxy, the time is the actual
# constraint. Whatever it does not finish is picked up on the next reconcile.
PSS_LABEL_TIMEOUT_SEC = int(os.environ.get("RKE2_PSS_LABEL_TIMEOUT_SEC", "10"))
PSS_LABEL_SWEEP_BUDGET_SEC = int(os.environ.get("RKE2_PSS_LABEL_SWEEP_BUDGET_SEC", "30"))
PSS_LABEL_SWEEP_LIMIT = int(os.environ.get("RKE2_PSS_LABEL_SWEEP_LIMIT", "20"))

# Written next to the config before rke2-server is restarted, so the "at most one restart per
# config version" guard survives the plugin being killed mid-restart. local_state alone does
# not: it is only persisted when the command returns, and a killed plugin returns nothing —
# which would leave the node restarting its apiserver on every reconcile.
PSS_RESTART_MARKER_FILE = PSS_CONFIG_FILE.with_name(".swarm-pss-restarted")

# local_state key holding the config digest this node has observed in force, and when it
# first found itself blocked behind a predecessor. The wait records the digest it belongs to:
# an absolute timestamp alone would survive a node converging out of band (reboot, systemd
# Restart) and then fire the timeout bypass instantly on the next config version — on every
# such node at once, which is the simultaneous restart the gate exists to prevent.
PSS_IN_FORCE_STATE_KEY = "pss_in_force_digest"
PSS_GATE_WAIT_SINCE_STATE_KEY = "pss_gate_waiting_since"

# Node property (the `k8s_` prefix is what the plugin's stateExpr selects) carrying the
# digest of the config this node has observed *in force*, so a cluster-wide rolling restart
# can be ordered without a lock and so a node nobody can probe is visible rather than
# silently unverified. The value is the digest and not a boolean on purpose: raising the
# enforced level changes the digest while a node still running the old config keeps rejecting
# the probe, so a boolean would read "done" on every node at once and let them all restart
# together.
PSS_ENFORCED_PROPERTY = "k8s_pss_enforced"
# Published by build_core_node_properties when the local API answers. Cleared on the tick
# this module restarts rke2-server: the restart is not waited on, so the apiserver is down
# when the tick returns, and joining followers gate on this property.
K8S_NODE_READY_PROPERTY = "k8s_node_ready"
PSS_ENFORCED_FALSE = "false"
PSS_ENFORCED_UNKNOWN = "unknown"
# Stored verdict for the probe throttle. Not published as the property — the property carries
# the config digest when in force, which is what the rolling-restart gate keys on.
PSS_ENFORCED_TRUE_VERDICT = "true"

# Namespace the live enforcement probe runs a server-side dry-run in. `default` exists on
# every cluster, is not on the exemption list, and a dry-run creates nothing.
PSS_PROBE_NAMESPACE = "default"

# How long a node waits on a predecessor that never finishes before going ahead anyway, and
# the per-position stagger between those deadlines.
#
# The stagger has to be at least a whole worst-case restart. Two queued nodes that both reach
# the bypass restart one stagger apart; if the first is still coming back when the second
# fires, two etcd members are down at once — the exact quorum loss the gate exists to
# prevent. So it is derived from the restart budget rather than picked, with a margin, and a
# test asserts the relationship so neither can be raised independently.
PSS_GATE_STAGGER_SEC = int(
    os.environ.get(
        "RKE2_PSS_GATE_STAGGER_SEC",
        str(PSS_RESTART_TIMEOUT_SEC + PSS_API_WAIT_SEC + 30),
    )
)
# Ten minutes before the first bypass. A legitimate restart plus its readiness wait is a
# couple of minutes, so this only fires for a member that is genuinely stuck. Waiting ticks
# are `postponed` applies, which the provision worker backs off on — but a plan change clears
# the backoff, so a gate-driven node reacts to its turn immediately and only a stuck queue
# pays the wait.
PSS_GATE_TIMEOUT_SEC = int(os.environ.get("RKE2_PSS_GATE_TIMEOUT_SEC", "600"))

# One probe pod per enforce level, each violating *that* level and nothing weaker, so a True
# verdict means "this level is in force" rather than "some level is". `baseline` uses the pod
# from the SUP-634 report verbatim. `restricted` has to use a pod `baseline` would admit —
# the privileged pod violates both, so it could not tell a node still on `baseline` apart
# from one that had loaded `restricted`, which is what the rolling restart gates on.
PSS_PROBE_PODS = {
    "baseline": """apiVersion: v1
kind: Pod
metadata:
  name: swarm-pss-probe
spec:
  hostPID: true
  containers:
    - name: probe
      image: busybox
      securityContext: { privileged: true }
      volumeMounts: [{ name: root, mountPath: /host }]
  volumes: [{ name: root, hostPath: { path: / } }]
""",
    # Runs as root with no seccomp profile and undropped capabilities: admitted by
    # `baseline`, rejected by `restricted`. `restricted` is strictly stronger than
    # `baseline`, so proving it is in force proves the SUP-634 vectors are blocked too.
    "restricted": """apiVersion: v1
kind: Pod
metadata:
  name: swarm-pss-probe
spec:
  containers:
    - name: probe
      image: busybox
      command: ["sleep", "1"]
""",
}


def render_pod_security_admission_config() -> str:
    """Render the PodSecurity AdmissionConfiguration applied to every non-exempt namespace."""
    exemptions = ", ".join(PSS_EXEMPT_NAMESPACES)
    return "\n".join(
        [
            "# Managed by the swarm-cloud rke2 provision plugin (SUP-634) — do not edit on the host.",
            "apiVersion: apiserver.config.k8s.io/v1",
            "kind: AdmissionConfiguration",
            "plugins:",
            "  - name: PodSecurity",
            "    configuration:",
            "      apiVersion: pod-security.admission.config.k8s.io/v1",
            "      kind: PodSecurityConfiguration",
            "      defaults:",
            f'        enforce: "{PSS_ENFORCE_LEVEL}"',
            f'        enforce-version: "{PSS_VERSION}"',
            f'        audit: "{PSS_TARGET_LEVEL}"',
            f'        audit-version: "{PSS_VERSION}"',
            f'        warn: "{PSS_TARGET_LEVEL}"',
            f'        warn-version: "{PSS_VERSION}"',
            "      exemptions:",
            "        usernames: []",
            "        runtimeClasses: []",
            f"        namespaces: [{exemptions}]",
            "",
        ]
    )


def _sha256_b64url(data: bytes) -> str:
    """Wire-format digest used across the unified attestation contract."""
    return "sha256/" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode("ascii")


def pod_security_admission_digest() -> str:
    """Digest of the config this image renders — the version identifier for reconcile state."""
    return _sha256_b64url(render_pod_security_admission_config().encode("utf-8"))


def installed_pod_security_admission_digest(path: Path | None = None) -> str | None:
    """Digest of the config actually on disk, or None when it is not installed.

    This, not the rendered digest, is what evidence publishes: a relying party has to be able
    to bind the asserted level to the exact bytes kube-apiserver reads.
    """
    dest = path or PSS_CONFIG_FILE
    if not dest.is_file():
        return None
    return _sha256_b64url(dest.read_bytes())


def write_pod_security_admission_config(path: Path | None = None) -> bool:
    """Write the AdmissionConfiguration. Returns True when the on-disk content changed."""
    dest = path or PSS_CONFIG_FILE
    desired = render_pod_security_admission_config()
    if dest.exists() and dest.read_text() == desired:
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(desired)
    # The file is read by kube-apiserver through a bind mount; keep it root-only like RKE2 does.
    os.chmod(dest, 0o600)
    return True


def rke2_config_pss_option_value(text: str) -> str | None:
    """The path config.yaml points kube-apiserver at, or None when the option is absent."""
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{PSS_RKE2_OPTION}:"):
            return stripped.split(":", 1)[1].strip().strip('"\'')
    return None


def rke2_config_has_pss_option(text: str, pss_path: Path | None = None) -> bool:
    """True only when the option points at *our* file.

    Presence alone is not enough: an option left pointing at some other path (a half-finished
    edit, RKE2's own rke2-pss.yaml) would pass a presence check while kube-apiserver read a
    config we do not control.
    """
    return rke2_config_pss_option_value(text) == str(pss_path or PSS_CONFIG_FILE)


def rke2_pss_config_line(path: Path | None = None) -> str:
    return f"{PSS_RKE2_OPTION}: {path or PSS_CONFIG_FILE}"


def ensure_rke2_pss_option(config_path: Path | None = None, pss_path: Path | None = None) -> bool:
    """Add the `pod-security-admission-config-file` option to config.yaml if absent.

    `write_rke2_config()` emits the option itself, so this only matters for a node installed
    before SUP-634 whose config is not being rewritten on this reconcile. Returns True when
    the file was modified (the caller then has to restart rke2-server).

    Never authors a config.yaml: a file with only this option and no `token` / `node-ip` /
    `server` would break the node on the restart that follows. An absent or empty config is
    `write_rke2_config()`'s to create.
    """
    dest = config_path or RKE2_CONFIG_FILE
    if not dest.is_file():
        return False
    existing = dest.read_text()
    if not existing.strip():
        return False
    if rke2_config_has_pss_option(existing, pss_path):
        return False

    desired = rke2_pss_config_line(pss_path)
    if rke2_config_pss_option_value(existing) is not None:
        # Points somewhere else — replace the line rather than adding a second one, which
        # would leave the effective value up to YAML duplicate-key resolution.
        lines = [
            desired if line.strip().startswith(f"{PSS_RKE2_OPTION}:") else line
            for line in existing.splitlines()
        ]
        dest.write_text("\n".join(lines).rstrip() + "\n")
        return True

    dest.write_text(existing.rstrip() + "\n\n" + desired + "\n")
    return True


def install_pod_security_admission(pss_path: Path | None = None) -> None:
    """Pre-start install: the config file must exist before rke2-server generates the pod spec."""
    write_pod_security_admission_config(pss_path)


def _kubectl(args: list[str], *, input_text: str | None = None, timeout: int = 60, request_timeout: int = 30):
    """Run kubectl. Never raises: a timeout or a missing binary comes back as a failed run.

    Every caller here is advisory or tri-state, and both call sites in `main.py` sit outside
    a try — an escaping `TimeoutExpired` would reach the SDK as a terminal `error` with no
    `localState`, throwing away this tick's install_hash and restart bookkeeping.
    """
    env = os.environ.copy()
    env["KUBECONFIG"] = str(RKE2_KUBECONFIG)
    try:
        return subprocess.run(
            [KUBECTL_BIN, *args, f"--request-timeout={request_timeout}s"],
            env=env,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        return subprocess.CompletedProcess(args=args, returncode=-1, stdout="", stderr=str(e))


ENFORCE_LABEL = "pod-security.kubernetes.io/enforce"
PSS_LABEL_PREFIX = "pod-security.kubernetes.io/"


def _probe_namespace_unusable() -> str | None:
    """Why the probe namespace cannot be measured against the cluster default, or None.

    *Any* `pod-security.kubernetes.io/*` label disqualifies it, including one that happens to
    name the level we enforce. A namespace label overrides the AdmissionConfiguration for
    that namespace, so a labelled probe namespace measures the label — a node still running
    RKE2's `enforce: privileged` config would self-certify, skip the rolling restart and
    publish its digest as in force. The probe is only meaningful in a namespace with no
    label at all, which is why the leader's sweep *strips* labels here instead of setting
    them.

    A namespace we could not read is also unusable: reporting it as unlabelled would let the
    probe return a definitive "permissive" for a namespace that might be overridden, which
    costs a needless cluster-wide restart and then a hard error.

    Labels are read as JSON rather than through a jsonpath expression: the keys contain dots,
    which jsonpath needs escaped, and getting that wrong would silently return an empty
    string — i.e. "no label" — for every namespace.
    """
    result = _kubectl(["get", "namespace", PSS_PROBE_NAMESPACE, "-o", "json"], timeout=PSS_PROBE_TIMEOUT_SEC)
    if result.returncode != 0:
        return f"could not read namespace {PSS_PROBE_NAMESPACE}: {(result.stderr or '').strip()[:200]}"
    try:
        labels = (json.loads(result.stdout).get("metadata") or {}).get("labels") or {}
    except (json.JSONDecodeError, AttributeError) as e:
        return f"could not parse namespace {PSS_PROBE_NAMESPACE}: {e}"
    own = {k: v for k, v in labels.items() if k.startswith(PSS_LABEL_PREFIX)}
    if own:
        return (
            f"namespace {PSS_PROBE_NAMESPACE} carries its own {sorted(own)} label(s), which "
            f"override the cluster default there"
        )
    return None


def config_loaded_by_running_server() -> bool | None:
    """Whether the installed config predates the running rke2-server, or None if unknowable.

    The probe measures the enforced *level*, which is the right question for the SUP-634
    claim but blind to a level-neutral change: edit `PSS_EXEMPT_NAMESPACES`, keep `baseline`,
    and a node that never reloaded the file still rejects the probe pod. It would then
    publish the new digest as in force and the signed evidence would assert an exemption list
    kube-apiserver never read — a false security assertion, since removing an exemption is
    exactly the kind of tightening a relying party would check for.

    So compare the file's mtime with when rke2-server last entered active state. Both are
    read as *durations* back from now (the file via wall clock, the service via the monotonic
    timestamp systemd records), which avoids comparing two different clocks' epochs.

    None when either side cannot be read: a signal we cannot take is no reason to restart an
    apiserver, and the level probe still stands on its own.
    """
    try:
        mtime = PSS_CONFIG_FILE.stat().st_mtime
    except OSError:
        return None

    try:
        shown = subprocess.run(
            ["systemctl", "show", "rke2-server", "--property=ActiveEnterTimestampMonotonic", "--value"],
            capture_output=True,
            text=True,
            timeout=PSS_PROBE_TIMEOUT_SEC,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        # Neither call site sits in a try, and the SDK turns an escaping exception into a
        # terminal error with no localState — discarding this tick's install_hash and PSS
        # bookkeeping. An unanswerable question is just unknown.
        return None
    if shown.returncode != 0:
        return None
    raw = (shown.stdout or "").strip()
    if not raw.isdigit() or raw == "0":
        return None
    active_since_boot = int(raw) / 1_000_000  # systemd reports microseconds since boot

    try:
        with open("/proc/uptime", encoding="utf-8") as f:
            uptime = float(f.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None

    # Age of each, counted back from now, so no epoch is compared with another.
    config_age = time.time() - mtime
    service_age = uptime - active_since_boot
    if config_age < 0 or service_age < 0:
        return None
    # Written before the service started → the running apiserver read it. One second of
    # slack: the apply path writes the config and starts rke2-server in the same breath.
    return config_age >= service_age - 1


def pod_security_probe_pod() -> str:
    """The probe manifest for the level currently enforced."""
    return PSS_PROBE_PODS[PSS_ENFORCE_LEVEL]


def pod_security_admission_enforced() -> bool | None:
    """Ask the running kube-apiserver whether PSS_ENFORCE_LEVEL is actually in force.

    The file on disk is not the control: RKE2 passes it to kube-apiserver when it generates
    the static pod spec, so a config written while rke2-server was already running has no
    effect until the next restart. This is the only check that distinguishes "installed" from
    "in force".

    Tri-state on purpose:
      True  — the apiserver rejected the pod with a PodSecurity violation.
      False — the apiserver admitted it. Definitive: this node is still permissive.
      None  — could not tell (apiserver down, kubectl missing, unrelated rejection). Callers
              must not read this as either answer; a probe we cannot run is not evidence that
              enforcement is off, and must not trigger a restart.
    """
    if not RKE2_KUBECONFIG.is_file():
        return None

    # A label on the probe namespace overrides the cluster default for it, so a probe run
    # against an overridden namespace measures that label, not the config. Treat it as
    # inconclusive rather than as "permissive", which would restart every node in the
    # cluster over one stray label. The leader's label sweep restates it.
    unusable = _probe_namespace_unusable()
    if unusable is not None:
        print(f"[!] PodSecurity probe inconclusive: {unusable}", file=sys.stderr)
        return None

    result = _kubectl(
        ["apply", "-n", PSS_PROBE_NAMESPACE, "--dry-run=server", "-f", "-"],
        timeout=PSS_PROBE_TIMEOUT_SEC,
        input_text=pod_security_probe_pod(),
    )

    if result.returncode == 0:
        return False
    if "violates PodSecurity" in (result.stderr or ""):
        return True
    # Neither answer. Say so: a probe that silently never runs would quietly reduce the
    # "in force" guarantee back to a file check. The verdict is also published as
    # PSS_ENFORCED_PROPERTY so an unverifiable node is visible cluster-side.
    print(
        f"[!] PodSecurity probe inconclusive in namespace {PSS_PROBE_NAMESPACE}: "
        f"{(result.stderr or '').strip()[:300]}",
        file=sys.stderr,
    )
    return None


def pod_security_enforced_property(in_force_digest: str | None, enforced: bool | None) -> dict[str, str]:
    """Publish what this node has in force, so peers can order their restarts.

    `in_force_digest` is set only when the config on disk already matched the image's
    rendering *before* this reconcile touched anything and the probe confirmed the level —
    i.e. the running apiserver is the one this digest describes. A tick that had to write the
    config publishes `false` / `unknown` instead, which is what holds the nodes behind it.
    """
    if in_force_digest is not None:
        return {PSS_ENFORCED_PROPERTY: in_force_digest}
    if enforced is False:
        return {PSS_ENFORCED_PROPERTY: PSS_ENFORCED_FALSE}
    return {PSS_ENFORCED_PROPERTY: PSS_ENFORCED_UNKNOWN}


def pss_restart_order(node_ids: list[str]) -> list[str]:
    """Deterministic rolling-restart order, identical on every node that computes it.

    Sorted node ids and nothing else. An earlier version put the elected leader first, which
    is not stable: during a handover the old and the new leader each read a different
    `cluster.leader_node`, each placed itself at index 0, and both would have restarted.
    """
    return sorted(n for n in node_ids if n)


def pss_gate_wait_started(waiting: dict | None, digest: str) -> float | None:
    """When this node started waiting for *this* config version, if it is still waiting."""
    if not isinstance(waiting, dict) or waiting.get("digest") != digest:
        return None
    at = waiting.get("at")
    return at if isinstance(at, (int, float)) else None


def pss_restart_blocked_by(
    order: list[str],
    local_node_id: str,
    enforced_by_node: dict[str, str],
    digest: str,
    *,
    waiting_since: float | None = None,
) -> str | None:
    """The node this one is waiting on before it may restart, or None when it is its turn.

    Every control-plane node runs an etcd member, so restarting them together costs the
    cluster its quorum and its API. A node restarts only once every node ahead of it in the
    order reports *this* config digest in force, which turns an upgrade into a rolling
    restart: at most one apiserver is down at a time, driven by published state rather than
    by timing.

    Liveness comes from the membership itself, not from a readiness check: a node that is
    really gone is reaped from `clusternodes` by `remove_stale_nodes` and so leaves `order`.
    Skipping a *NotReady* predecessor would be backwards — a node mid-restart is exactly the
    one whose restart must not overlap ours.

    A member that is present but stuck is handled by the timeout: after
    `PSS_GATE_TIMEOUT_SEC`, plus a per-position stagger so two nodes never expire on the same
    tick, the node goes ahead regardless and logs that it did.
    """
    if local_node_id not in order:
        # Not in the published membership yet — a joining node restarts on its own account
        # only; it is not serving the cluster, so it cannot cost quorum.
        return None

    index = order.index(local_node_id)
    blockers = [node_id for node_id in order[:index] if enforced_by_node.get(node_id) != digest]
    if not blockers:
        return None

    if waiting_since is not None:
        deadline = PSS_GATE_TIMEOUT_SEC + index * PSS_GATE_STAGGER_SEC
        waited = time.time() - waiting_since
        if waited >= deadline:
            print(
                f"[!] Waited {int(waited)}s on {blockers[0]} to enforce PodSecurity "
                f"{PSS_ENFORCE_LEVEL}; restarting this node anyway",
                file=sys.stderr,
            )
            return None

    return blockers[0]


def reconcile_tenant_namespace_pss_labels(budget_sec: float | None = None) -> tuple[int, str | None]:
    """Leader-only: keep the `pod-security.kubernetes.io/*` labels where they belong.

    Two jobs, both because a namespace label *overrides* the AdmissionConfiguration for that
    namespace:

    - Tenant namespaces get the labels restated. swarm-cloud-api sets them at creation, but a
      namespace created before SUP-634 carries none (and silently relies on the default), and
      one created under an older level would pin that older level after the level is raised.
    - The probe namespace gets them *removed*. `pod_security_admission_enforced()` has to
      measure the cluster default there; a label would make the probe measure itself, and a
      node still running RKE2's permissive config would self-certify.

    Returns (namespaces_changed, error_message). Advisory: the cluster default already covers
    every namespace, so a failure here is reported, not fatal.
    """
    listed = _kubectl(["get", "namespaces", "-o", "json"], timeout=PSS_LABEL_TIMEOUT_SEC)
    if listed.returncode != 0:
        return 0, f"could not list namespaces: {listed.stderr.strip()}"
    try:
        items = json.loads(listed.stdout).get("items", [])
    except (json.JSONDecodeError, AttributeError) as e:
        return 0, f"could not parse namespace list: {e}"

    desired = pod_security_namespace_labels()
    deadline = time.monotonic() + (PSS_LABEL_SWEEP_BUDGET_SEC if budget_sec is None else budget_sec)
    relabelled = 0
    attempted = 0
    failures: list[str] = []
    for item in items:
        # Bounded per tick, by time and by count. The first sweep after this release can
        # touch every tenant namespace at once, and an unbounded run of kubectl calls on the
        # leader's apply path can outlive the plugin's command budget — which would get the
        # tick killed and throw away its install_hash and PSS bookkeeping. Whatever is left
        # is picked up on the next reconcile.
        #
        # Attempts, not successes: a namespace that fails still costs a call, so counting
        # only successes would let N failing namespaces run N calls past the bound.
        if attempted >= PSS_LABEL_SWEEP_LIMIT or time.monotonic() >= deadline:
            print(
                f"[*] PSS label sweep used its budget after {attempted} namespace(s); "
                f"continuing next reconcile",
                file=sys.stderr,
            )
            break
        meta = item.get("metadata") or {}
        name = meta.get("name") or ""
        labels = meta.get("labels") or {}

        if name == PSS_PROBE_NAMESPACE:
            # Strip, not set: the enforcement probe runs here and has to measure the cluster
            # default, which a label on this namespace would override. Every
            # `pod-security.kubernetes.io/*` key goes, not just the ones we would have set —
            # the probe disqualifies itself on any of them, so leaving a stray or mistyped
            # one would wedge this node at "could not verify" for good.
            stray = sorted(k for k in labels if k.startswith(PSS_LABEL_PREFIX))
            if not stray:
                continue
            args = ["label", "namespace", name] + [f"{k}-" for k in stray]
        elif name.startswith(TENANT_NS_PREFIX) and name not in PSS_EXEMPT_NAMESPACES:
            if all(labels.get(k) == v for k, v in desired.items()):
                continue
            args = ["label", "namespace", name, "--overwrite"] + [f"{k}={v}" for k, v in desired.items()]
        else:
            continue

        attempted += 1
        result = _kubectl(args, timeout=PSS_LABEL_TIMEOUT_SEC)
        if result.returncode != 0:
            # Keep going: one namespace that cannot be labelled (terminating, admission
            # webhook) must not stop every namespace behind it from being relabelled on
            # every reconcile from here on.
            failures.append(f"{name}: {result.stderr.strip()}")
            continue
        relabelled += 1
    if failures:
        return relabelled, f"could not label {len(failures)} namespace(s): {'; '.join(failures[:3])}"
    return relabelled, None


def pss_worst_case_seconds() -> int:
    """Worst case for everything this module can do on one apply tick.

    Kept as code rather than a comment so the test that compares it with the plugin command
    timeout fails if any one of the budgets is raised past what the others leave room for.
    """
    probe = PSS_PROBE_TIMEOUT_SEC * PSS_PROBE_CALLS
    restart = PSS_RESTART_TIMEOUT_SEC + PSS_API_WAIT_SEC + probe
    sweep = PSS_LABEL_SWEEP_BUDGET_SEC + PSS_LABEL_TIMEOUT_SEC  # one call may start just under
    return probe + restart + sweep


def pod_security_namespace_labels() -> dict[str, str]:
    """The `pod-security.kubernetes.io/*` labels that restate the cluster default.

    Mirrors POD_SECURITY_LABELS in `libs/kubernetes/src/lib/namespace-provisioning.service.ts`;
    a unit test there fails if the two drift.
    """
    return {
        "pod-security.kubernetes.io/enforce": PSS_ENFORCE_LEVEL,
        "pod-security.kubernetes.io/enforce-version": PSS_VERSION,
        "pod-security.kubernetes.io/audit": PSS_TARGET_LEVEL,
        "pod-security.kubernetes.io/audit-version": PSS_VERSION,
        "pod-security.kubernetes.io/warn": PSS_TARGET_LEVEL,
        "pod-security.kubernetes.io/warn-version": PSS_VERSION,
    }


def pod_security_rollout_evidence(
    node_ids: list[str],
    enforced_by_node: dict[str, str],
    digest: str | None = None,
) -> dict:
    """How far the enforced level has actually reached across the cluster.

    The leader's own config file says what the *image* enforces; it says nothing about a
    follower still queued behind the rolling-restart gate with the previous config loaded.
    Publishing only the file digest would assert the level cluster-wide while a node was
    still permissive, so the signed snapshot carries the count too and a relying party can
    see that enforcement is partial.
    """
    target = digest or pod_security_admission_digest()
    members = [n for n in node_ids if n]
    in_force = [n for n in members if enforced_by_node.get(n) == target]
    return {
        "nodeCount": len(members),
        "nodesInForce": len(in_force),
        "inForceEverywhere": len(members) > 0 and len(in_force) == len(members),
    }


def pod_security_admission_evidence(rollout: dict | None = None) -> dict | None:
    """The enforced PSS level, as carried in the control-plane evidence snapshot.

    An external verifier reads this to confirm that the measured image bounds what the
    operator can do to a published workload: `enforce` is what admission applies to every
    namespace that is not named in `exemptions.namespaces`, and `audit` / `warn` state the
    stricter level the same namespaces are being measured against.

    `configDigest` is the digest of the installed file, so the asserted level is bound to the
    bytes kube-apiserver reads. Returns None when the file is not installed — publishing a
    level we cannot point at a file for would assert more than we know.
    """
    installed = installed_pod_security_admission_digest()
    if installed is None:
        return None
    evidence = {
        "mode": "admission-configuration",
        "configFile": str(PSS_CONFIG_FILE),
        "configDigest": installed,
        "defaults": {
            "enforce": PSS_ENFORCE_LEVEL,
            "enforceVersion": PSS_VERSION,
            "audit": PSS_TARGET_LEVEL,
            "auditVersion": PSS_VERSION,
            "warn": PSS_TARGET_LEVEL,
            "warnVersion": PSS_VERSION,
        },
        "exemptions": {
            "namespaces": list(PSS_EXEMPT_NAMESPACES),
            "usernames": [],
            "runtimeClasses": [],
        },
    }
    if rollout is not None:
        evidence["rollout"] = rollout
    return evidence


def _restart_marker_digest() -> str | None:
    """The config version this node already restarted rke2-server for, from disk."""
    try:
        return PSS_RESTART_MARKER_FILE.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def _write_restart_marker(digest: str) -> None:
    try:
        PSS_RESTART_MARKER_FILE.parent.mkdir(parents=True, exist_ok=True)
        PSS_RESTART_MARKER_FILE.write_text(digest)
    except OSError as e:
        # Not fatal, but worth saying: without the marker the local_state copy of the guard
        # is all that stands between a killed plugin and an apiserver restart loop.
        print(f"[!] Could not record the PodSecurity restart marker: {e}", file=sys.stderr)


def already_restarted_for(local_state: dict, digest: str) -> bool:
    return _restart_marker_digest() == digest or local_state.get(PSS_RESTART_STATE_KEY) == digest


def _clear_restart_marker() -> None:
    """Drop the guard once the level is in force.

    Without this the guard is a one-shot per config version for the lifetime of the node: a
    later repair (health rewriting a config edited on the host) could never restart to load
    it, and the node would report permissive forever.
    """
    try:
        PSS_RESTART_MARKER_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def reconcile_pod_security_admission(
    local_state: dict,
    *,
    restart_blocked_by: Callable[[str], str | None] | None = None,
    wait_api_ready: Callable[[], bool] | None = None,
) -> tuple[str | None, dict, dict]:
    """Keep the PSS config installed and *in force* on an already-running node.

    Returns `(error_message, node_properties, local_state_fragment)`.

    The node is restarted when the config had to be written or the option added, and also
    when the live probe says the running apiserver is still permissive — the case a file-only
    check misses, because a config written while rke2-server was already up does not reach
    kube-apiserver until the static pod spec is regenerated.

    `restart_blocked_by` is called with this config's digest and serialises the restarts
    across the cluster (see `pss_restart_blocked_by`): bouncing every control-plane node on
    the same tick would cost the cluster its etcd quorum.

    The restart *is* waited on, bounded by PSS_RESTART_TIMEOUT_SEC plus the caller's
    readiness wait. Returning while the apiserver is down would mean publishing node
    properties for a node that cannot serve, leaving the leader's kubectl work to fail
    against it, and making the next tick's probe inconclusive — three things every caller
    would then have to special-case. The "restarted once for this config version" guard is
    written to disk before the wait, which is where a plugin is most likely to be killed.
    """
    digest = pod_security_admission_digest()
    try:
        config_changed = write_pod_security_admission_config()
        option_added = ensure_rke2_pss_option()
    except OSError as e:
        # Neither call site sits in a try, and the SDK turns an escaping exception into a
        # terminal error with no localState — discarding this tick's install_hash and PSS
        # bookkeeping. A disk that cannot be written is a postpone, not a lost tick.
        return f"Could not install {PSS_CONFIG_FILE}: {e}", {}, {}
    # A file the running server never read is not in force, whatever the level probe says.
    stale_on_disk = config_loaded_by_running_server() is False
    state: dict = {}

    if not (config_changed or option_added or stale_on_disk):
        # Steady node: reuse the last verdict until the probe interval elapses. Each probe is
        # a rejected mutating request, so one per node per reconcile tick would be a
        # continuous stream of admission denials.
        already = local_state.get(PSS_IN_FORCE_STATE_KEY) == digest
        if already and not _probe_due(local_state):
            # In force and confirmed: nothing to wait for any more.
            return None, {PSS_ENFORCED_PROPERTY: digest}, {PSS_GATE_WAIT_SINCE_STATE_KEY: None}

        enforced, probe_state = probe_or_cached(local_state)
        state.update(probe_state)
        if enforced is True:
            state[PSS_IN_FORCE_STATE_KEY] = digest
            # Converged, however it got there: drop any wait so the timeout cannot fire
            # later, and release the restart guard so a future repair can restart again.
            state[PSS_GATE_WAIT_SINCE_STATE_KEY] = None
            state[PSS_RESTART_STATE_KEY] = None
            _clear_restart_marker()
            return None, {PSS_ENFORCED_PROPERTY: digest}, state
        if enforced is None:
            # Inconclusive. Do not restart on no information — and do not withdraw a
            # confirmation already held, or a probe blip would stall the rolling restart of
            # every node behind this one. The accumulated gate wait is deliberately left
            # untouched: clearing it here would let intermittent blips reset the timeout
            # forever, so a node behind a stuck predecessor would never get its bypass.
            return None, pod_security_enforced_property(digest if already else None, None), state
        # Definitively permissive. Withdraw the claim *before* anything reads it: leaving it
        # would let the next throttled tick take the early return above and publish the
        # digest again, so successors would unblock and signed evidence would report
        # inForceEverywhere for a node that admits the SUP-634 pod.
        state[PSS_IN_FORCE_STATE_KEY] = None
    else:
        # The config we are about to load is not the one running — either we just wrote it,
        # or it postdates the running server. Drop any stale claim and any verdict measured
        # against the previous one.
        enforced = None
        state[PSS_IN_FORCE_STATE_KEY] = None
        state[PSS_PROBE_VERDICT_STATE_KEY] = None
        state[PSS_PROBE_AT_STATE_KEY] = None
        if stale_on_disk and not (config_changed or option_added):
            print(
                f"[*] {PSS_CONFIG_FILE} postdates the running rke2-server; it has to be "
                f"reloaded before the level it sets is in force",
                file=sys.stderr,
            )

    node_properties = pod_security_enforced_property(None, enforced)

    if already_restarted_for(local_state, digest):
        # We have already spent this config version's restart. Whether that is a dead end or
        # something to retry depends on *why* it is still not in force:
        if enforced is False and not stale_on_disk:
            # The server did restart, did read this file, and still admits the pod. That is
            # not transient — report it rather than bouncing the apiserver every reconcile.
            return (
                f"kube-apiserver still admits a pod that violates PodSecurity "
                f"{PSS_ENFORCE_LEVEL} after a restart for {PSS_CONFIG_FILE}; the level is "
                f"not in force",
                node_properties,
                state,
            )
        if stale_on_disk:
            # The server never came up with this file — a restart that timed out, or one
            # that is still failing to start. Another immediate restart would just be a loop
            # on every apply retry; wait for the one we asked for.
            return (
                f"rke2-server has not come up with {PSS_CONFIG_FILE} since the restart this "
                f"node already performed for it",
                node_properties,
                state,
            )

    if restart_blocked_by is not None:
        waiting_on = restart_blocked_by(digest)
        if waiting_on:
            # Remember when the wait for *this config version* started, so the gate can time
            # out rather than wedge — and so a wait recorded for an older version can never
            # make the timeout fire immediately.
            started = pss_gate_wait_started(local_state.get(PSS_GATE_WAIT_SINCE_STATE_KEY), digest)
            state[PSS_GATE_WAIT_SINCE_STATE_KEY] = {
                "digest": digest,
                "at": started if started is not None else time.time(),
            }
            return (
                f"Waiting for node {waiting_on} to enforce PodSecurity {PSS_ENFORCE_LEVEL} "
                f"before restarting this node's kube-apiserver",
                node_properties,
                state,
            )
    # Past the gate: the wait is over however it ended.
    state[PSS_GATE_WAIT_SINCE_STATE_KEY] = None

    # Whatever the probe said was measured against the apiserver we are about to replace.
    state[PSS_PROBE_VERDICT_STATE_KEY] = None
    state[PSS_PROBE_AT_STATE_KEY] = None

    print(f"[*] Restarting rke2-server to enforce PodSecurity {PSS_ENFORCE_LEVEL}", file=sys.stderr)
    try:
        result = subprocess.run(
            ["systemctl", "restart", "rke2-server"],
            capture_output=True,
            text=True,
            timeout=PSS_RESTART_TIMEOUT_SEC,
        )
    except subprocess.TimeoutExpired:
        # systemctl may still be finishing, so the attempt has to count; the next reconcile
        # re-probes. A raised TimeoutExpired would reach the SDK as a terminal failure
        # instead of a retry.
        _write_restart_marker(digest)
        state[PSS_RESTART_STATE_KEY] = digest
        return (
            f"rke2-server restart for PodSecurity admission did not finish in "
            f"{PSS_RESTART_TIMEOUT_SEC}s",
            {**node_properties, K8S_NODE_READY_PROPERTY: None},
            state,
        )
    except OSError as e:
        # No systemctl to run, so nothing restarted: retryable, and the attempt is not spent.
        return (
            f"Could not run systemctl to restart rke2-server for PodSecurity admission: {e}",
            node_properties,
            state,
        )
    if result.returncode != 0:
        # systemctl refused, so nothing was restarted: do not spend this config version's
        # single attempt on a transient failure, or the node would report "not in force"
        # forever and never try again.
        return (
            f"Failed to restart rke2-server for PodSecurity admission: {result.stderr}",
            node_properties,
            state,
        )

    _write_restart_marker(digest)
    state[PSS_RESTART_STATE_KEY] = digest

    if wait_api_ready is not None and not wait_api_ready():
        return (
            "RKE2 API did not recover after the PodSecurity admission restart",
            {**node_properties, K8S_NODE_READY_PROPERTY: None},
            state,
        )

    # Re-probe now that the apiserver is back, and vouch for the digest *in this tick* when
    # it confirms.
    #
    # An earlier version deliberately published `unknown` here and left the digest to "the
    # next reconcile", on the principle that a node should not vouch for a config it had just
    # installed. There is no guaranteed next reconcile: a steady member re-applies on a plan
    # change or after a non-completed apply, and a successful restart returns `completed`, so
    # the node could sit on `unknown` and every successor would advance on the gate's timeout
    # instead of on the gate — which is the opposite of what the rolling restart is for.
    #
    # And the principle does not actually apply once the restart has been waited on: the
    # apiserver that answered the probe is the one that came up after `systemctl restart`
    # returned and `wait_api_ready` passed, and `config_loaded_by_running_server()`
    # independently confirms the file predates that process. Three agreeing signals is not a
    # guess. Only a definitive `False` from the load check withholds the claim.
    enforced, probe_state = probe_or_cached({})
    state.update(probe_state)
    if enforced is True and config_loaded_by_running_server() is not False:
        print(f"[*] PodSecurity {PSS_ENFORCE_LEVEL} admission config active", file=sys.stderr)
        state[PSS_IN_FORCE_STATE_KEY] = digest
        return None, {PSS_ENFORCED_PROPERTY: digest}, state

    # One slow kubectl just after the apiserver came back must not pin this node at
    # `unknown` — or at a `false` that escalates against the restart guard — for the whole
    # probe interval, holding every node behind it at the gate. Re-probe next tick, and
    # postpone so there *is* a next tick rather than waiting for someone else's plan to move.
    state[PSS_PROBE_AT_STATE_KEY] = None
    state[PSS_PROBE_VERDICT_STATE_KEY] = None
    return (
        f"Restarted rke2-server for PodSecurity {PSS_ENFORCE_LEVEL}; the apiserver has not "
        f"confirmed the level yet",
        pod_security_enforced_property(None, enforced),
        state,
    )


def health_check_pod_security_admission(
    local_state: dict | None = None,
    *,
    deep: bool = False,
) -> tuple[bool, str | None, dict]:
    """Confirm this node's kube-apiserver is enforcing the PSS config we ship.

    Returns `(ok, message, local_state_fragment)`.

    The file is content-compared rather than existence-checked, and the RKE2 option is
    value-compared rather than presence-checked: a config that drifted from what the image
    renders, or an option left pointing elsewhere, is the failure mode that silently puts the
    cluster back on `privileged`. A missing file is written back here rather than only
    reported, so a node cannot sit on a missing config waiting for an apply that may not come.

    `deep=True` also asks the running apiserver, which is the only way to catch a config that
    is installed but was never loaded. That probe is throttled to PSS_PROBE_INTERVAL_SEC. A
    probe that comes back inconclusive leaves a previously confirmed node healthy and a node
    that has never confirmed this config unhealthy — unverified is not the same as fine.
    """
    state_in = local_state or {}
    try:
        return _health_check_pod_security_admission(state_in, deep=deep)
    except OSError as e:
        # Same hazard as in the reconcile: an escaping OSError costs the tick its local_state.
        return False, f"Could not read the PodSecurity config: {e}", {}


def _health_check_pod_security_admission(state_in: dict, *, deep: bool) -> tuple[bool, str | None, dict]:
    # A repaired file is not the file the running apiserver loaded, so any claim that this
    # node has the current config in force — and any verdict measured against the old one —
    # has to go, or the reconcile's throttled path would republish the digest and the
    # leader's evidence would report inForceEverywhere for a node health calls unhealthy.
    repaired = {
        PSS_IN_FORCE_STATE_KEY: None,
        PSS_PROBE_VERDICT_STATE_KEY: None,
        PSS_PROBE_AT_STATE_KEY: None,
    }
    if not PSS_CONFIG_FILE.is_file():
        write_pod_security_admission_config()
        return (
            False,
            f"installed the missing {PSS_CONFIG_FILE}; rke2-server has yet to load it",
            repaired,
        )
    if PSS_CONFIG_FILE.read_text(encoding="utf-8") != render_pod_security_admission_config():
        write_pod_security_admission_config()
        return (
            False,
            f"{PSS_CONFIG_FILE} had drifted from the PSS config this image enforces",
            repaired,
        )
    if not RKE2_CONFIG_FILE.is_file():
        return False, f"missing {RKE2_CONFIG_FILE}", repaired
    config_text = RKE2_CONFIG_FILE.read_text(encoding="utf-8")
    if not rke2_config_has_pss_option(config_text):
        pointing_at = rke2_config_pss_option_value(config_text)
        if pointing_at is None:
            return False, f"RKE2 config missing {PSS_RKE2_OPTION}", repaired
        return (
            False,
            f"{PSS_RKE2_OPTION} points at {pointing_at}, not {PSS_CONFIG_FILE}",
            repaired,
        )

    if not deep:
        return True, None, {}

    if config_loaded_by_running_server() is False:
        # The level probe cannot see this: a config the running server never read may still
        # set the same level, so it would pass while the exemption list in force is another
        # file's. The reconcile restarts for it; say so here rather than reporting healthy.
        return (
            False,
            f"{PSS_CONFIG_FILE} postdates the running rke2-server, so the apiserver has not "
            f"loaded it",
            repaired,
        )

    enforced, state = probe_or_cached(state_in)
    if enforced is False:
        state[PSS_IN_FORCE_STATE_KEY] = None
        # A node queued behind its predecessor in the rolling restart really is still
        # permissive, so it stays unhealthy — but say which of the two it is, or every node
        # in a normal rollout reads as a broken one.
        waiting = pss_gate_wait_started(
            state_in.get(PSS_GATE_WAIT_SINCE_STATE_KEY), pod_security_admission_digest()
        )
        if waiting is not None:
            return (
                False,
                f"Queued for the PodSecurity {PSS_ENFORCE_LEVEL} rolling restart for "
                f"{int(time.time() - waiting)}s; this node's kube-apiserver is still permissive",
                state,
            )
        return (
            False,
            f"kube-apiserver admits a pod that violates PodSecurity {PSS_ENFORCE_LEVEL}: "
            f"the level is not in force",
            state,
        )
    if enforced is True:
        state[PSS_IN_FORCE_STATE_KEY] = pod_security_admission_digest()
        return True, None, state

    # Inconclusive. A node that has confirmed this config before keeps its pass — a probe
    # blip is not a regression. One that never has is *unverified*, not healthy: the
    # reconcile will not restart on an inconclusive probe either, so reporting ok here would
    # leave a node that never loaded the config looking fine indefinitely.
    if state_in.get(PSS_IN_FORCE_STATE_KEY) == pod_security_admission_digest():
        return True, None, state
    return (
        False,
        f"Could not verify that kube-apiserver enforces PodSecurity {PSS_ENFORCE_LEVEL}; "
        f"see the probe's reason in the plugin log",
        state,
    )


def _probe_due(local_state: dict) -> bool:
    last = local_state.get(PSS_PROBE_AT_STATE_KEY)
    if not isinstance(last, (int, float)):
        return True
    # A clock that moved backwards (restored state, NTP step) must not postpone the probe
    # indefinitely, so treat a future timestamp as due.
    elapsed = time.time() - last
    return elapsed >= PSS_PROBE_INTERVAL_SEC or elapsed < 0


_VERDICTS = {PSS_ENFORCED_TRUE_VERDICT: True, PSS_ENFORCED_FALSE: False}


def probe_or_cached(local_state: dict) -> tuple[bool | None, dict]:
    """The enforcement verdict, re-measured at most once per PSS_PROBE_INTERVAL_SEC.

    Returns `(verdict, local_state_fragment)`. The throttle covers every verdict, not just a
    confirmed one: an inconclusive probe left unthrottled would re-run on every 60-second
    health tick, and each run is a rejected mutating request in the audit log.
    """
    if not _probe_due(local_state):
        cached = local_state.get(PSS_PROBE_VERDICT_STATE_KEY)
        if isinstance(cached, str) and cached in _VERDICTS:
            return _VERDICTS[cached], {}
        if cached == PSS_ENFORCED_UNKNOWN:
            return None, {}

    enforced = pod_security_admission_enforced()
    verdict = (
        PSS_ENFORCED_TRUE_VERDICT
        if enforced is True
        else PSS_ENFORCED_FALSE
        if enforced is False
        else PSS_ENFORCED_UNKNOWN
    )
    return enforced, {
        PSS_PROBE_AT_STATE_KEY: time.time(),
        PSS_PROBE_VERDICT_STATE_KEY: verdict,
    }
