"""Unit tests for the pod-overlay datapath assertion in `health` (SUP-350/SUP-355).

A node whose flannel.1 was cascade-deleted with wg0 keeps reporting Ready, a
2/2 canal pod and a healthy `wg show`; these tests pin the one signal that does
see it, and pin that every unanswerable probe stays silent.
"""

from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"


def _load_main_module():
    for path in (str(RKE2_DIR), str(SDK_DIR)):
        if path not in sys.path:
            sys.path.insert(0, path)
    mod_path = RKE2_DIR / "main.py"
    spec = importlib.util.spec_from_file_location("rke2_main_flannel_datapath", mod_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load_main_module()
NODE_A = "node-a"
NODE_B = "node-b"
CNI_NOT_UP = Path("/nonexistent/sp-355/cni/10-canal.conflist")


def _conflist(tmp_path, age_sec: float) -> Path:
    """A canal conflist on the host whose mtime is `age_sec` in the past."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    path = tmp_path / "10-canal.conflist"
    path.write_text("{}")
    when = MODULE.time.time() - age_sec
    os.utime(path, (when, when))
    return path


def _uptime_file(tmp_path, uptime_sec: float) -> Path:
    tmp_path.mkdir(parents=True, exist_ok=True)
    path = tmp_path / "uptime"
    path.write_text(f"{uptime_sec} {uptime_sec}\n")
    return path


@pytest.fixture(autouse=True)
def cni_long_ready(tmp_path):
    """Default state: the CNI has been up far longer than the grace window.

    Pinned per test rather than read off the host, so a verdict never depends
    on the uptime of the machine running the suite.
    """
    conflist = _conflist(tmp_path / "cni-ready", age_sec=MODULE.CNI_GRACE_SEC + 600)
    with (
        patch.object(MODULE, "CNI_CONFLIST", conflist),
        patch.object(MODULE, "PROC_UPTIME", _uptime_file(tmp_path / "cni-ready", 86400)),
    ):
        yield


def _completed(returncode=0, stdout="", stderr=""):
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)


def _fake_ip(links: dict[str, bool], routes: str = "", route_rc: int = 0):
    """Stub `ip link show` / `ip route show dev` calls."""

    def runner(cmd, **kwargs):
        if cmd[1:3] == ["link", "show"]:
            dev = cmd[3]
            if links.get(dev):
                return _completed(stdout=f"5: {dev}: <BROADCAST,MULTICAST,UP>\n")
            return _completed(returncode=1, stderr=f'Device "{dev}" does not exist.\n')
        if cmd[1:3] == ["route", "show"]:
            return _completed(returncode=route_rc, stdout=routes)
        raise AssertionError(f"unexpected ip invocation: {cmd}")

    return runner


def _nodes_payload(*specs):
    return {
        "items": [
            {
                "metadata": {"name": name},
                "spec": {"podCIDR": cidr},
                "status": {"conditions": [{"type": "Ready", "status": ready}]},
            }
            for name, cidr, ready in specs
        ]
    }


def _state(*node_ids):
    return {"clusterNodes": [{"node_id": node_id} for node_id in node_ids]}


def test_iface_read_from_canal_config():
    assert MODULE.flannel_iface() == "wg0"


def test_healthy_node_passes():
    local = MODULE.hash_node_id(NODE_A)
    remote = MODULE.hash_node_id(NODE_B)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip(
            {"wg0": True, "flannel.1": True},
            routes="10.42.1.0/24 via 10.42.1.0 onlink\n",
        )),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload((remote, "10.42.1.0/24", "True"))),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)
    assert local != remote


def test_missing_vxlan_device_is_unhealthy():
    """The SUP-350 failure: wg0 was re-created, flannel.1 went with the old one."""
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
    ):
        ok, err = MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B))
    assert ok is False
    assert "flannel.1 is missing" in err


def test_missing_peer_route_is_unhealthy():
    remote = MODULE.hash_node_id(NODE_B)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip(
            {"wg0": True, "flannel.1": True}, routes="10.42.0.0/24 via 10.42.0.0 onlink\n")),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload((remote, "10.42.1.0/24", "True"))),
    ):
        ok, err = MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B))
    assert ok is False
    assert "10.42.1.0/24" in err


def test_single_node_cluster_needs_no_peer_routes():
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": True})),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload()),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A)) == (True, None)


def test_not_ready_peer_route_is_not_required():
    """A draining/NotReady peer may legitimately have no route yet."""
    remote = MODULE.hash_node_id(NODE_B)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": True})),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload((remote, "10.42.1.0/24", "False"))),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_foreign_node_route_is_not_required():
    """A Node that is not in this cluster's membership is none of our business."""
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": True})),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload(("stranger", "10.42.9.0/24", "True"))),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A)) == (True, None)


def test_bootstrap_window_is_silent():
    """The CNI has not been installed on this node yet, so there is no verdict.

    The gate must be a host-visible file: /run/flannel/subnet.env exists only
    inside the flannel container, so using it would silence the check forever.
    """
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
        patch.object(MODULE, "CNI_CONFLIST", CNI_NOT_UP),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_fresh_cni_bringup_is_silent(tmp_path):
    """The conflist lands ~25 s before flannel.1 on a join; stay quiet for it.

    Measured on the SUP-355 stand: conflist 14:50:22, flannel.1 14:51:16. A
    Node can already be Ready in that window, so without the grace every fresh
    join would report "the pod overlay is down" on a healthy node.
    """
    conflist = _conflist(tmp_path, age_sec=20)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
        patch.object(MODULE, "CNI_CONFLIST", conflist),
        patch.object(MODULE, "PROC_UPTIME", _uptime_file(tmp_path, 300)),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_broken_datapath_reported_once_the_window_passed(tmp_path):
    conflist = _conflist(tmp_path, age_sec=MODULE.CNI_GRACE_SEC + 60)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
        patch.object(MODULE, "CNI_CONFLIST", conflist),
        patch.object(MODULE, "PROC_UPTIME", _uptime_file(tmp_path, 86400)),
    ):
        ok, err = MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B))
    assert ok is False and "flannel.1 is missing" in err


def test_recent_boot_is_silent_even_with_an_old_conflist(tmp_path):
    """A conflist can outlive a reboot; flannel.1 cannot.

    Age must be measured from max(conflist mtime, boot time), or a node that
    just rebooted is called broken while its CNI is still coming back.
    """
    conflist = _conflist(tmp_path, age_sec=86400)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
        patch.object(MODULE, "CNI_CONFLIST", conflist),
        patch.object(MODULE, "PROC_UPTIME", _uptime_file(tmp_path, 30)),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_unreadable_uptime_falls_back_to_conflist_mtime(tmp_path):
    conflist = _conflist(tmp_path, age_sec=MODULE.CNI_GRACE_SEC + 60)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": False})),
        patch.object(MODULE, "CNI_CONFLIST", conflist),
        patch.object(MODULE, "PROC_UPTIME", tmp_path / "no-such-uptime"),
    ):
        ok, _ = MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B))
    assert ok is False


def test_cni_ready_age_is_none_when_the_cni_never_came_up(tmp_path):
    with patch.object(MODULE, "CNI_CONFLIST", tmp_path / "absent.conflist"):
        assert MODULE.cni_ready_age_sec() is None


def test_missing_wireguard_iface_is_silent():
    """No mesh on this node — the wireguard plugin's health owns that."""
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": False, "flannel.1": False})),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_unusable_ip_binary_is_silent():
    with (
        patch.object(MODULE.subprocess, "run", side_effect=OSError("no ip binary")),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_permission_error_on_link_show_is_not_a_missing_device():
    def runner(cmd, **kwargs):
        if cmd[1:3] == ["link", "show"] and cmd[3] == "wg0":
            return _completed(stdout="3: wg0: <POINTOPOINT,NOARP,UP>\n")
        return _completed(returncode=2, stderr="RTNETLINK answers: Operation not permitted\n")

    with (
        patch.object(MODULE.subprocess, "run", side_effect=runner),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_unreadable_route_table_is_silent():
    remote = MODULE.hash_node_id(NODE_B)
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip(
            {"wg0": True, "flannel.1": True}, route_rc=1)),
        patch.object(MODULE, "_kubectl_json", return_value=_nodes_payload((remote, "10.42.1.0/24", "True"))),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_unreachable_apiserver_is_silent():
    with (
        patch.object(MODULE.subprocess, "run", side_effect=_fake_ip({"wg0": True, "flannel.1": True})),
        patch.object(MODULE, "_kubectl_json", return_value=None),
    ):
        assert MODULE.check_flannel_datapath(NODE_A, _state(NODE_A, NODE_B)) == (True, None)


def test_health_postpones_on_broken_datapath():
    """The whole point: `health` must stop reporting completed on such a node."""
    from provision_plugin_sdk import PluginInput

    captured = {}

    def fake_check(local_node_id, state_json=None):
        captured["called"] = True
        return False, "flannel.1 is missing while wg0 is up"

    with (
        patch.object(MODULE, "is_rke2_running", return_value=(True, None)),
        patch.object(MODULE, "RKE2_KUBECONFIG", Path("/dev/null")),
        patch.object(MODULE.subprocess, "run", return_value=_completed(stdout="ok")),
        patch.object(MODULE, "check_node_ready", return_value=(True, None)),
        patch.object(MODULE, "check_flannel_datapath", side_effect=fake_check),
        patch.object(MODULE, "health_check_opa_authz_webhook", return_value=(True, None)) as opa,
    ):
        out = MODULE.handle_health(PluginInput(
            command="health",
            local_node_id=NODE_A,
            state={"clusterNodes": [{"node_id": NODE_A}], "cluster": {"leader_node": "someone-else"}},
            local_state={"is_bootstrap": False},
        ))

    assert captured.get("called") is True
    assert out.status == "postponed"
    assert "flannel.1 is missing" in (out.error_message or "")
    # The datapath assertion runs before the heavier OPA/credential probes.
    assert opa.call_count == 0
