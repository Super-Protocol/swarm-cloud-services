"""Unit tests for the RKE2 cluster join token (SUP-652).

The token used to be a hardcoded default in main.py. It now comes from the
`rke2_join_token` SwarmSecret, and a node that is already configured keeps the
token its etcd bootstrap data was sealed with.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

RKE2_DIR = Path(__file__).resolve().parents[1]
SDK_DIR = RKE2_DIR.parents[1] / "provision-plugin-sdk"

for _path in (str(RKE2_DIR), str(SDK_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from provision_plugin_sdk import PluginInput, PluginOutput  # noqa: E402  (needs the paths above)

# Stands in for whatever token a cluster was already bootstrapped with,
# including the hardcoded default this change removed.
BOOTSTRAPPED_TOKEN = "already-bootstrapped-with-this-one"
SECRET_TOKEN = "f0d1e2c3b4a5968778695a4b3c2d1e0ff0d1e2c3b4a5968778695a4b3c2d1e0f"


def _load_main_module():
    spec = importlib.util.spec_from_file_location("rke2_main_join_token", RKE2_DIR / "main.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    # Point the provider config at nothing by default: a test that asserts "no token
    # resolves" must not depend on whether the machine running it happens to have an
    # /sp/swarm/config.yaml. Tests that want one patch it to a file they wrote.
    module.RKE2_PROVIDER_CONFIG = Path("/nonexistent/sp/swarm/config.yaml")
    return module


def _state(*, with_secret: bool = True) -> dict:
    """Minimal state for one bootstrap node, shaped like the manifest projection."""
    secrets = [{"id": "base_domain", "value": "example.test"}]
    if with_secret:
        secrets.append({"id": "rke2_join_token", "value": SECRET_TOKEN})
    return {
        "globalId": "g1",
        "cluster": {"id": "cluster-1", "cluster_policy": "rke2", "leader_node": "node-1"},
        "clusterNodes": [{"id": "cluster-1:node-1", "node_id": "node-1", "cluster": "cluster-1"}],
        "rke2NodeProperties": [],
        "wgNodeProperties": [
            {"cluster_node": "wg-1:node-1", "name": "tunnel_ip", "value": "10.10.0.1", "node_id": "node-1"}
        ],
        "clusterProperties": [],
        "swarmSecrets": secrets,
    }


def _provider_config(tmp_path: Path, token: str | None) -> Path:
    """A provider config shaped like /sp/swarm/config.yaml, nested keys included."""
    config = tmp_path / "provider-config.yaml"
    body = ["github:", '  token: ""', "tags:", '  services: "develop"', 'base_domain: "example.test"']
    if token is not None:
        body.append(f'rke2_join_token: "{token}"')
    config.write_text("\n".join(body) + "\n")
    return config


def _config_file(tmp_path: Path, token: str | None) -> Path:
    config = tmp_path / "config.yaml"
    if token is not None:
        config.write_text(f"token: {token}\nnode-ip: 10.10.0.1\ncni: canal\n")
    return config


def test_no_hardcoded_default_token():
    """Nothing in the module stands in for a missing token."""
    module = _load_main_module()
    assert not hasattr(module, "RKE2_TOKEN")

    with (
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "read_existing_rke2_token", return_value=None),
    ):
        token, source = module.resolve_join_token(_state(with_secret=False))

    assert token is None
    assert source == "unavailable"


def test_token_from_swarm_secret_is_written_to_config(tmp_path):
    """Token present in shared state → it lands in the RKE2 config."""
    module = _load_main_module()
    config = _config_file(tmp_path, None)

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        token, source = module.resolve_join_token(_state())
        assert token == SECRET_TOKEN
        assert source == "SwarmSecrets.rke2_join_token"

        module.write_rke2_config(
            local_node_id="node-1",
            local_tunnel_ip="10.10.0.1",
            is_bootstrap=True,
            leader_tunnel_ip=None,
            all_tunnel_ips=["10.10.0.1"],
            join_token=token,
            k8s_domain=None,
        )

    assert config.read_text().splitlines()[0] == f"token: {SECRET_TOKEN}"


def test_missing_token_postpones_apply(tmp_path):
    """Token absent → postponed apply, never a fallback value."""
    module = _load_main_module()
    config = _config_file(tmp_path, None)

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        output = module.handle_apply(
            PluginInput(
                command="apply",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            )
        )

    assert output.status == "postponed"
    assert "rke2_join_token" in (output.error_message or "")
    assert not config.exists()


def test_existing_config_token_wins_and_keeps_install_hash_stable(tmp_path):
    """A configured node keeps its token, so moving to SwarmSecrets reinstalls nothing."""
    module = _load_main_module()
    config = _config_file(tmp_path, BOOTSTRAPPED_TOKEN)
    state = _state()

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        token, source = module.resolve_join_token(state)

    assert token == BOOTSTRAPPED_TOKEN
    assert source == "local config"
    assert module.compute_install_hash(state, module.RKE2_VERSION, token) == module.compute_install_hash(
        state, module.RKE2_VERSION, BOOTSTRAPPED_TOKEN
    )


def test_env_override_used_only_when_no_config_token(tmp_path):
    module = _load_main_module()
    config_with_token = _config_file(tmp_path, BOOTSTRAPPED_TOKEN)

    with (
        patch.object(module, "RKE2_CONFIG_FILE", config_with_token),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", "from-env"),
    ):
        assert module.resolve_join_token(_state())[0] == BOOTSTRAPPED_TOKEN

    with (
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "absent.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", "from-env"),
    ):
        token, source = module.resolve_join_token(_state())

    assert token == "from-env"
    assert source == "RKE2_TOKEN environment override"


def test_read_existing_rke2_token(tmp_path):
    module = _load_main_module()

    assert module.read_existing_rke2_token(tmp_path / "absent.yaml") is None
    assert module.read_existing_rke2_token(_config_file(tmp_path, BOOTSTRAPPED_TOKEN)) == BOOTSTRAPPED_TOKEN

    without_token = tmp_path / "no-token.yaml"
    without_token.write_text("node-ip: 10.10.0.1\ncni: canal\n")
    assert module.read_existing_rke2_token(without_token) is None

    # A token line with an empty value is as good as no token at all.
    blank = tmp_path / "blank.yaml"
    blank.write_text("token:\ncni: canal\n")
    assert module.read_existing_rke2_token(blank) is None


def test_write_rke2_config_refuses_an_empty_token(tmp_path):
    module = _load_main_module()
    config = tmp_path / "config.yaml"

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", config),
    ):
        try:
            module.write_rke2_config("node-1", "10.10.0.1", True, None, ["10.10.0.1"], join_token="")
        except ValueError as exc:
            assert "join token" in str(exc)
        else:  # pragma: no cover - the guard must fire
            raise AssertionError("write_rke2_config accepted an empty token")

    assert not config.exists()


# --- SUP-773: a cloud initialised before sp-vm build-476-release has no secret ---

# sp-vm wipes the state disk on every boot, so a rebooted node has no local token
# and the services payload it runs is the one just downloaded: new plugin code and
# a surviving local token never coexist. The operator's provider config is what
# reaches such a node, and a passing health check is what proves the value works.


def _passing_health(module, state: dict) -> object:
    return module.attach_join_token_write_back(
        module.PluginOutput(status="completed", local_state={}),
        PluginInput(command="health", local_node_id="node-1", state=state, local_state={}),
    )


def test_write_back_seeds_the_secret_the_cloud_never_had(tmp_path):
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        assert module.join_token_write_back(_state(with_secret=False)) == {
            "rke2_join_token": BOOTSTRAPPED_TOKEN
        }


def test_write_back_never_overwrites_an_existing_secret(tmp_path):
    """A row that disagrees with the local token is the operator's to settle."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        assert module.join_token_write_back(_state()) is None


def test_write_back_stays_silent_with_nothing_to_publish(tmp_path):
    """No token anywhere → nothing to seed, and no empty secret written."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "absent.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        assert module.join_token_write_back(_state(with_secret=False)) is None


def test_write_back_ignores_a_state_with_no_swarmsecrets_projection(tmp_path):
    """A missing projection is a gap in the input, not a cloud without the row."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        assert module.join_token_write_back({}) is None
        assert module.join_token_write_back({"swarmSecrets": None}) is None


def test_provider_config_token_is_the_last_resort(tmp_path):
    """The seed an operator can deliver to a node whose image never wrote the secret."""
    module = _load_main_module()
    seeded = "token-from-the-operators-archive"

    with (
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "absent.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "RKE2_PROVIDER_CONFIG", _provider_config(tmp_path, seeded)),
    ):
        # Nothing else to go on → the provider config answers.
        assert module.resolve_join_token(_state(with_secret=False)) == (seeded, "provider config")
        # Shared state is the cluster's own answer and still outranks it.
        assert module.resolve_join_token(_state()) == (SECRET_TOKEN, "SwarmSecrets.rke2_join_token")

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "RKE2_PROVIDER_CONFIG", _provider_config(tmp_path, seeded)),
    ):
        # As does a token this node's server is already sealed with.
        assert module.resolve_join_token(_state(with_secret=False))[0] == BOOTSTRAPPED_TOKEN


def test_health_seeds_the_provider_config_token_once_the_node_is_healthy(tmp_path):
    """The migration: one node boots with the operator's value, the cloud keeps it."""
    module = _load_main_module()
    seeded = "token-from-the-operators-archive"

    with (
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "absent.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "RKE2_PROVIDER_CONFIG", _provider_config(tmp_path, seeded)),
    ):
        assert _passing_health(module, _state(with_secret=False)).swarm_secrets == {
            "rke2_join_token": seeded
        }


def test_a_health_check_that_does_not_pass_seeds_nothing(tmp_path):
    """The token is a claim until this node is a working member of the cluster."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        for status in ("postponed", "error"):
            output = module.attach_join_token_write_back(
                module.PluginOutput(status=status, error_message="not ready", local_state={}),
                PluginInput(
                    command="health",
                    local_node_id="node-1",
                    state=_state(with_secret=False),
                    local_state={},
                ),
            )
            assert output.status == status
            assert output.swarm_secrets is None


def test_health_seeds_nothing_on_a_cloud_that_has_the_secret(tmp_path):
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        assert _passing_health(module, _state()).swarm_secrets is None


def test_a_timed_out_health_probe_seeds_nothing(tmp_path):
    """The SUP-354 guard turns a slow probe into a postpone; a postpone seeds nothing."""
    module = _load_main_module()
    timeout = subprocess.TimeoutExpired(cmd=["curl", "-fsS", "https://…/healthz"], timeout=10)

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "_check_rke2_health", side_effect=timeout),
    ):
        output = module.handle_health(
            PluginInput(
                command="health",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            )
        )

    assert output.status == "postponed"
    assert "timed out after 10s" in (output.error_message or "")
    assert output.swarm_secrets is None


def test_health_command_is_wired_to_the_write_back(tmp_path):
    """A failing health check runs through the wrapper and seeds nothing."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
        patch.object(module, "is_rke2_running", return_value=(False, None)),
    ):
        output = module.handle_health(
            PluginInput(
                command="health",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            )
        )

    assert output.status == "postponed"
    assert output.swarm_secrets is None


def test_apply_seeds_nothing_at_all(tmp_path):
    """Apply has no evidence that the token works, so it never writes the row."""
    module = _load_main_module()
    state = _state(with_secret=False)
    state["wgNodeProperties"] = []

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        output = module.handle_apply(
            PluginInput(command="apply", local_node_id="node-1", state=state, local_state={})
        )

    assert output.status == "postponed"
    assert output.swarm_secrets is None


def test_seeding_is_skipped_when_the_installed_sdk_has_no_channel(tmp_path):
    """sp-vm replaces the built-in SDK only when tags.sdk is set."""

    class OutputWithoutTheChannel:
        """A PluginOutput from provision-plugin-sdk older than 1.2.0."""

        def __init__(self):
            self.status = "completed"

    module = _load_main_module()
    output = OutputWithoutTheChannel()

    with (
        patch.object(module, "RKE2_CONFIG_FILE", _config_file(tmp_path, BOOTSTRAPPED_TOKEN)),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        returned = module.attach_join_token_write_back(
            output,
            PluginInput(
                command="health",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            ),
        )

    assert returned is output
    assert not hasattr(returned, "swarm_secrets")


def test_missing_token_names_the_provider_config_remedy(tmp_path):
    """The operator must learn this from the message, not from a reboot."""
    module = _load_main_module()

    with (
        patch.object(module, "RKE2_CONFIG_DIR", tmp_path),
        patch.object(module, "RKE2_CONFIG_FILE", tmp_path / "config.yaml"),
        patch.object(module, "RKE2_TOKEN_OVERRIDE", None),
    ):
        output = module.handle_apply(
            PluginInput(
                command="apply",
                local_node_id="node-1",
                state=_state(with_secret=False),
                local_state={},
            )
        )

    assert output.status == "postponed"
    message = output.error_message or ""
    assert module.RKE2_JOIN_TOKEN_SPVM_BUILD in message
    assert str(module.RKE2_PROVIDER_CONFIG) in message
    assert "refresh-configs" in message


def test_read_provider_config_join_token(tmp_path):
    module = _load_main_module()
    read = module.read_provider_config_join_token

    assert read(tmp_path / "absent.yaml") is None
    assert read(_provider_config(tmp_path, None)) is None
    assert read(_provider_config(tmp_path, "plain-value")) == "plain-value"

    # A nested key of the same name belongs to its own section, not to us.
    nested = tmp_path / "nested.yaml"
    nested.write_text("rke2:\n  rke2_join_token: nested\n")
    assert read(nested) is None

    quoted_with_comment = tmp_path / "commented.yaml"
    quoted_with_comment.write_text('rke2_join_token: "value"  # the cluster\'s existing token\n')
    assert read(quoted_with_comment) == "value"

    bare_with_comment = tmp_path / "bare-commented.yaml"
    bare_with_comment.write_text("rke2_join_token: value # trailing\n")
    assert read(bare_with_comment) == "value"

    single = tmp_path / "single.yaml"
    single.write_text("rke2_join_token: 'with''quote'\n")
    assert read(single) == "with'quote"

    for unusable_value in ('""', "'token with spaces'", "0", "[]"):
        unusable = tmp_path / "unusable.yaml"
        unusable.write_text(f"rke2_join_token: {unusable_value}\n")
        assert read(unusable) is None

    broken_yaml = tmp_path / "broken.yaml"
    broken_yaml.write_text("rke2_join_token: 'unterminated\n")
    assert read(broken_yaml) is None


def test_swarm_secrets_reach_the_worker_as_swarmsecrets():
    """The seeding is only worth anything if it survives the fd3 contract."""
    wire = PluginOutput(status="completed", swarm_secrets={"rke2_join_token": SECRET_TOKEN}).to_dict()

    assert wire["swarmSecrets"] == {"rke2_join_token": SECRET_TOKEN}
    assert "swarmSecrets" not in PluginOutput(status="completed").to_dict()
