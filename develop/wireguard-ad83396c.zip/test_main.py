#!/usr/bin/env python3
"""Unit tests for wireguard/main.py — SUP-344 peer endpoint durability."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            self.status = None
            self.error_message = None
            self.node_properties = None
            self.local_state = None
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

LOCAL_NODE = "node-1"
PEER_NODE = "node-2"
PEER_PUB_KEY = "cGVlcnB1YmtleXBlZXJwdWJrZXlwZWVycHVia2V5MDA="
LOCAL_ADDR = "20.163.10.155"
PEER_ADDR = "172.182.72.47"


def _plan(node_addrs, peer_props=None):
    """Build a wireguard stateExpr result for a two-node cluster.

    `node_addrs` is the `nodeAddrs` array, which the manifest derives from
    swarm-db's live memberlist view — the part that collapses to just the local
    node when gossip is lost.
    """
    props = {
        "pub_key": PEER_PUB_KEY,
        "port": "51820",
        "tunnel_ip": "10.13.7.9",
    }
    props.update(peer_props or {})
    return {
        "clusterNodes": [
            {"id": f"cluster-1:{LOCAL_NODE}", "node_id": LOCAL_NODE},
            {"id": f"cluster-1:{PEER_NODE}", "node_id": PEER_NODE},
        ],
        "nodeProperties": [
            {"cluster_node": f"cluster-1:{PEER_NODE}", "name": name, "value": value}
            for name, value in props.items()
        ],
        "nodeAddrs": node_addrs,
    }


BOTH_NODES_VISIBLE = [
    {"node_id": LOCAL_NODE, "addr": LOCAL_ADDR},
    {"node_id": PEER_NODE, "addr": PEER_ADDR},
]
# What an isolated node sees: memberlist only ever returns itself.
ONLY_SELF_VISIBLE = [{"node_id": LOCAL_NODE, "addr": LOCAL_ADDR}]


class ApplyHarness:
    """Run handle_apply against a temporary wg0.conf with wg tools faked out."""

    def __init__(self, test, conf_contents=None):
        self.test = test
        self.tmpdir = tempfile.TemporaryDirectory()
        self.conf_path = os.path.join(self.tmpdir.name, "wg0.conf")
        if conf_contents is not None:
            with open(self.conf_path, "w") as f:
                f.write(conf_contents)
        self.commands = []

        test.addCleanup(self.tmpdir.cleanup)
        self._patch()

    def _patch(self):
        test = self.test
        conf_path = self.conf_path

        original_conf = main.WG_CONF_PATH
        main.WG_CONF_PATH = conf_path
        test.addCleanup(lambda: setattr(main, "WG_CONF_PATH", original_conf))

        for name, replacement in (
            ("wg_available", lambda: True),
            ("generate_keypair", lambda existing=None: (existing or "privkey", "pubkey")),
            ("sync_wireguard_peers", self._record_sync),
            ("subprocess", _FakeSubprocess(self.commands)),
        ):
            original = getattr(main, name)
            setattr(main, name, replacement)
            test.addCleanup(lambda n=name, o=original: setattr(main, n, o))

    def _record_sync(self, conf_path):
        self.commands.append(("sync_wireguard_peers", conf_path))

    # Matches the [Interface] section of EXISTING_CONF, so `apply` takes the
    # hot-reload path (`wg syncconf`) rather than restarting wg-quick — the path
    # that silently removed peers from the live interface.
    DEFAULT_LOCAL_STATE = {
        "private_key": "privkey",
        "public_key": "pubkey",
        "address": "10.13.1.2",
    }

    def run(self, state, local_state=None):
        return main.handle_apply(
            main.PluginInput(
                local_node_id=LOCAL_NODE,
                state=state,
                local_state=dict(self.DEFAULT_LOCAL_STATE if local_state is None else local_state),
            )
        )

    def conf(self):
        if not os.path.exists(self.conf_path):
            return ""
        with open(self.conf_path) as f:
            return f.read()

    def synced(self):
        return any(cmd[0] == "sync_wireguard_peers" for cmd in self.commands)


class _FakeSubprocess:
    """Stand-in for the subprocess module: records calls, never runs anything."""

    DEVNULL = -3

    class _Result:
        def __init__(self, returncode=0, stdout=b"", stderr=b""):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    def __init__(self, sink):
        self.sink = sink

    def run(self, args, **_kwargs):
        self.sink.append(tuple(args))
        # `ip link show wg0` returning 0 means the interface is already up,
        # which is the state in which peers are hot-reloaded rather than
        # restarted — the path that wiped peers in production.
        return self._Result(returncode=0)


EXISTING_CONF = f"""[Interface]
PrivateKey = privkey
Address = 10.13.1.2/24
ListenPort = 51820

[Peer]
PublicKey = {PEER_PUB_KEY}
AllowedIPs = 10.13.7.9/32
Endpoint = {PEER_ADDR}:51820
PersistentKeepalive = 25
"""


class ReadPeerSectionsTests(unittest.TestCase):
    def test_parses_peer_stanzas_by_public_key(self):
        with tempfile.NamedTemporaryFile("w", suffix=".conf", delete=False) as f:
            f.write(EXISTING_CONF)
            path = f.name
        self.addCleanup(os.unlink, path)

        peers = main.read_peer_sections(path)
        self.assertEqual(list(peers), [PEER_PUB_KEY])
        self.assertEqual(peers[PEER_PUB_KEY]["Endpoint"], f"{PEER_ADDR}:51820")
        self.assertEqual(peers[PEER_PUB_KEY]["AllowedIPs"], "10.13.7.9/32")

    def test_missing_file_is_empty(self):
        self.assertEqual(main.read_peer_sections("/nonexistent/wg0.conf"), {})


class EndpointHostTests(unittest.TestCase):
    def test_splits_host_from_ipv4_endpoint(self):
        self.assertEqual(main.endpoint_host("172.182.72.47:51820"), "172.182.72.47")

    def test_keeps_bracketed_ipv6_literal(self):
        self.assertEqual(main.endpoint_host("[2001:db8::1]:51820"), "[2001:db8::1]")

    def test_no_endpoint(self):
        self.assertIsNone(main.endpoint_host(None))
        self.assertIsNone(main.endpoint_host(""))


class EndpointAddrPropertyTests(unittest.TestCase):
    """The node publishes its own address so peers keep a durable record."""

    def test_publishes_own_endpoint_addr(self):
        harness = ApplyHarness(self)
        result = harness.run(_plan(BOTH_NODES_VISIBLE))

        self.assertEqual(result.status, "completed")
        self.assertEqual(result.node_properties.get("endpoint_addr"), LOCAL_ADDR)

    def test_does_not_republish_unchanged_endpoint_addr(self):
        harness = ApplyHarness(self)
        state = _plan(BOTH_NODES_VISIBLE)
        state["nodeProperties"].append(
            {
                "cluster_node": f"cluster-1:{LOCAL_NODE}",
                "name": "endpoint_addr",
                "value": LOCAL_ADDR,
            }
        )

        result = harness.run(state)
        self.assertNotIn("endpoint_addr", result.node_properties or {})

    def test_destroy_clears_endpoint_addr(self):
        original = main.subprocess
        main.subprocess = _FakeSubprocess([])
        self.addCleanup(lambda: setattr(main, "subprocess", original))

        result = main.handle_destroy(main.PluginInput(local_state={}))
        self.assertIsNone(result.node_properties["endpoint_addr"])


class IsolatedNodeKeepsItsPeersTests(unittest.TestCase):
    """SUP-344: losing gossip must not make a node dismantle its own overlay.

    Before the fix, an isolated node saw `nodeAddrs` shrink to just itself,
    rendered a wg0.conf with zero [Peer] sections, and then `wg syncconf`
    removed every peer from the live interface and deleted their routes. The
    node stayed up, kept answering its public ports, and never rejoined.
    """

    def test_falls_back_to_the_endpoint_addr_property(self):
        harness = ApplyHarness(self, EXISTING_CONF)
        state = _plan(ONLY_SELF_VISIBLE, peer_props={"endpoint_addr": PEER_ADDR})

        result = harness.run(state)

        self.assertEqual(result.status, "completed")
        conf = harness.conf()
        self.assertIn(f"PublicKey = {PEER_PUB_KEY}", conf)
        self.assertIn(f"Endpoint = {PEER_ADDR}:51820", conf)
        self.assertTrue(harness.synced())

    def test_falls_back_to_the_endpoint_already_on_disk(self):
        # No endpoint_addr property yet (a node partitioned soon after joining),
        # so the last known Endpoint in wg0.conf is all we have.
        harness = ApplyHarness(self, EXISTING_CONF)

        result = harness.run(_plan(ONLY_SELF_VISIBLE))

        self.assertEqual(result.status, "completed")
        self.assertIn(f"Endpoint = {PEER_ADDR}:51820", harness.conf())

    def test_live_view_wins_over_the_durable_fallbacks(self):
        # A peer that genuinely moved must be followed, not pinned to history.
        moved = "172.182.72.99"
        harness = ApplyHarness(self, EXISTING_CONF)
        state = _plan(
            [
                {"node_id": LOCAL_NODE, "addr": LOCAL_ADDR},
                {"node_id": PEER_NODE, "addr": moved},
            ],
            peer_props={"endpoint_addr": PEER_ADDR},
        )

        harness.run(state)
        self.assertIn(f"Endpoint = {moved}:51820", harness.conf())

    def test_refuses_to_write_an_empty_peer_set_over_a_populated_one(self):
        # Nothing resolves this peer: no live addr, no property, and its
        # PublicKey is not the one in the config on disk.
        harness = ApplyHarness(self, EXISTING_CONF)
        state = _plan(ONLY_SELF_VISIBLE, peer_props={"pub_key": "dW5rbm93bmtleXVua25vd25rZXl1bmtub3dua2V5MA=="})

        result = harness.run(state)

        self.assertEqual(result.status, "postponed")
        self.assertIn("refusing to drop", result.error_message)
        # The running config and the live interface are left untouched.
        self.assertIn(f"Endpoint = {PEER_ADDR}:51820", harness.conf())
        self.assertFalse(harness.synced())

    def test_peer_removed_from_the_cluster_is_still_dropped(self):
        # The guard must not freeze a genuine scale-down: a node that left the
        # cluster is gone from clusterNodes, so there is nothing to preserve.
        harness = ApplyHarness(self, EXISTING_CONF)
        state = _plan(ONLY_SELF_VISIBLE)
        state["clusterNodes"] = [{"id": f"cluster-1:{LOCAL_NODE}", "node_id": LOCAL_NODE}]
        state["nodeProperties"] = []

        result = harness.run(state)

        self.assertEqual(result.status, "completed")
        self.assertNotIn("[Peer]", harness.conf())
        self.assertTrue(harness.synced())


class _HealthSubprocess(_FakeSubprocess):
    """subprocess stand-in that answers the three commands `health` runs."""

    def __init__(self, sink, peers, interface_up=True, peers_rc=0):
        super().__init__(sink)
        self.peers = peers
        self.interface_up = interface_up
        self.peers_rc = peers_rc

    def run(self, args, **kwargs):
        self.sink.append(tuple(args))
        if args[:3] == ["wg", "show", "wg0"] and len(args) == 3:
            return self._Result(returncode=0 if self.interface_up else 1)
        if args[:4] == ["wg", "show", "wg0", "peers"]:
            return self._Result(returncode=self.peers_rc, stdout="\n".join(self.peers) + "\n")
        if args[:4] == ["wg", "show", "wg0", "latest-handshakes"]:
            return self._Result(returncode=0, stdout=f"{PEER_PUB_KEY}\t1760000000\n")
        return self._Result(returncode=0)


class HealthPeerCountTests(unittest.TestCase):
    """SUP-344: a stripped overlay must not report Ready.

    QA found a node sitting at `wireguard / phase=Ready / "Apply completed"`
    with zero peers while rke2 failed around it: the old check only asserted
    that wg0 existed and local state was present. It also meant no re-apply was
    ever scheduled, so the empty peer set survived the heal. Reporting `error`
    is what drives the provision worker's consecutive-failure path into a
    re-apply; `postponed` would leave last_apply_status alone and change
    nothing.
    """

    HEALTHY_STATE = {"private_key": "privkey", "public_key": "pubkey"}

    def _health(self, peers, state=None, local_state=None, **kwargs):
        commands = []
        original = main.subprocess
        main.subprocess = _HealthSubprocess(commands, peers, **kwargs)
        self.addCleanup(lambda: setattr(main, "subprocess", original))

        return main.handle_health(
            main.PluginInput(
                local_node_id=LOCAL_NODE,
                state=_plan(BOTH_NODES_VISIBLE) if state is None else state,
                local_state=dict(self.HEALTHY_STATE if local_state is None else local_state),
            )
        )

    def test_healthy_when_every_expected_peer_is_present(self):
        result = self._health([PEER_PUB_KEY])
        self.assertEqual(result.status, "completed")

    def test_errors_when_the_interface_has_no_peers(self):
        result = self._health([])

        self.assertEqual(result.status, "error")
        self.assertIn("carries 0 peer(s)", result.error_message)
        self.assertIn("expects 1", result.error_message)

    def test_errors_when_only_some_peers_are_present(self):
        third_key = "dGhpcmRwdWJrZXl0aGlyZHB1YmtleXRoaXJkcHViMA=="
        state = _plan(BOTH_NODES_VISIBLE)
        state["clusterNodes"].append({"id": "cluster-1:node-3", "node_id": "node-3"})
        state["nodeProperties"].append(
            {"cluster_node": "cluster-1:node-3", "name": "pub_key", "value": third_key}
        )

        result = self._health([PEER_PUB_KEY], state=state)

        self.assertEqual(result.status, "error")
        self.assertIn("1 missing", result.error_message)

    def test_single_node_cluster_is_healthy_with_no_peers(self):
        state = _plan(ONLY_SELF_VISIBLE)
        state["clusterNodes"] = [{"id": f"cluster-1:{LOCAL_NODE}", "node_id": LOCAL_NODE}]
        state["nodeProperties"] = []

        self.assertEqual(self._health([], state=state).status, "completed")

    def test_peer_without_a_published_key_is_not_expected_yet(self):
        # A node that joined but has not run apply has no pub_key to match on,
        # so it must not make everyone else look unhealthy.
        state = _plan(BOTH_NODES_VISIBLE)
        state["nodeProperties"] = [p for p in state["nodeProperties"] if p["name"] != "pub_key"]

        self.assertEqual(self._health([], state=state).status, "completed")

    def test_unreadable_peer_list_does_not_raise_a_false_alarm(self):
        self.assertEqual(self._health([], peers_rc=1).status, "completed")

    def test_interface_down_still_postpones(self):
        result = self._health([PEER_PUB_KEY], interface_up=False)
        self.assertEqual(result.status, "postponed")
        self.assertEqual(result.error_message, "wg0 not ready")


class ExpectedPeerKeysTests(unittest.TestCase):
    def test_excludes_the_local_node(self):
        keys = main.expected_peer_keys(_plan(BOTH_NODES_VISIBLE), LOCAL_NODE)
        self.assertEqual(keys, {PEER_PUB_KEY})

    def test_tolerates_a_non_dict_plan(self):
        self.assertEqual(main.expected_peer_keys(None, LOCAL_NODE), set())
        self.assertEqual(main.expected_peer_keys([], LOCAL_NODE), set())


if __name__ == "__main__":
    unittest.main()
