#!/usr/bin/env python3
"""Unit tests for swarm-cloud-api/main.py — the rendered /etc/swarm-cloud-api/config.yaml.

A real node never reads `conf/api.yaml`; it reads what `create_config_file` renders here.
SUP-368: `kubeEventSync` was added to the compose config and to the Zod schema (whose
default is `enabled: false`) but not to this renderer, so the worker logged "disabled by
config" on every cluster and `clusterSpaceEvents` could only ever answer from the API
server's own 1h window. The drift test below is the guard: any worker the schema knows
about must appear in the rendered block.

    cd services/swarm-cloud-api && python3 -m unittest test_main -v
"""

import re
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent
WORKERS_CONFIG_TS = REPO_ROOT / "apps/swarm-cloud-api/src/app/workers/workers.config.ts"

sys.path.insert(0, str(HERE))

if "provision_plugin_sdk" not in sys.modules:
    # main.py imports the plugin SDK at module scope and instantiates a ProvisionPlugin.
    # None of the config rendering needs it, so a stub keeps the SDK off the test host.
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0-test"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402

LOCAL_NODE_ID = "node-1"
PEER_NODE_ID = "node-2"


def build_state(leader_node_id: str) -> dict:
    return {
        "cluster": {"leader_node": leader_node_id},
        "wgNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.1"},
            {"node_id": PEER_NODE_ID, "name": "tunnel_ip", "value": "10.10.0.2"},
        ],
        "cockroachClusterNodes": [{"node_id": LOCAL_NODE_ID}, {"node_id": PEER_NODE_ID}],
        "cockroachNodeProperties": [
            {"node_id": LOCAL_NODE_ID, "name": "cockroachdb_node_ready", "value": "true"},
        ],
        "globalId": "abc123",
        "baseDomain": "swarm.superprotocol.dev",
        "pkiAuthorityNodes": [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
        ],
        "swarmSecrets": [{"id": "pki_auth_token", "value": "tok"}],
        "evidenceTypeMeasurements": [
            {"node": LOCAL_NODE_ID, "value": "tdx"},
            {"node": PEER_NODE_ID, "value": "sev-snp"},
        ],
    }


def render_config(leader_node_id: str) -> dict:
    """Render config.yaml the way the plugin does on a node and parse it back."""
    with tempfile.TemporaryDirectory() as tmp:
        config_path = Path(tmp) / "swarm-cloud-api" / "config.yaml"
        original = main.API_CONFIG_FILE
        main.API_CONFIG_FILE = config_path
        try:
            main.create_config_file(
                LOCAL_NODE_ID, build_state(leader_node_id), "http://10.10.0.1:3002"
            )
            return yaml.safe_load(config_path.read_text())
        finally:
            main.API_CONFIG_FILE = original


def schema_worker_keys() -> set[str]:
    """The worker names WorkersConfigSchema declares, read straight off the Zod schema."""
    source = WORKERS_CONFIG_TS.read_text()
    body = re.search(
        r"export const WorkersConfigSchema = BaseConfigSchema\.extend\(\{(.*?)^\}\);",
        source,
        re.DOTALL | re.MULTILINE,
    )
    assert body, f"could not find WorkersConfigSchema in {WORKERS_CONFIG_TS}"
    return set(re.findall(r"^  (\w+):", body.group(1), re.MULTILINE))


class RenderedWorkersTest(unittest.TestCase):
    def test_every_worker_in_the_schema_is_rendered(self):
        """A worker the renderer forgets defaults to enabled:false and silently never runs."""
        rendered = render_config(LOCAL_NODE_ID)["workers"]
        missing = schema_worker_keys() - set(rendered)
        self.assertEqual(
            set(),
            missing,
            f"workers declared in workers.config.ts but absent from the rendered config: {sorted(missing)}",
        )

    def test_kube_event_sync_runs_on_the_leader(self):
        workers = render_config(LOCAL_NODE_ID)["workers"]
        self.assertEqual(
            {"enabled": True, "checkInterval": 30000, "retentionHours": 48},
            workers["kubeEventSync"],
        )

    def test_workers_are_leader_gated(self):
        """Every worker — kubeEventSync included — is off on a follower node."""
        workers = render_config(PEER_NODE_ID)["workers"]
        self.assertFalse(workers["kubeEventSync"]["enabled"])
        for name, worker in workers.items():
            self.assertFalse(worker["enabled"], f"{name} must not run on a follower")


class RenderedEvidenceSignerTest(unittest.TestCase):
    """SUP-636: without this block the API falls back to `http://127.0.0.1:8000`,
    which only resolves when the API node happens to co-host a PKI authority. On
    every other node each `sign()` throws, no host gets a
    `/.well-known/swarm-evidence` bundle, and a cluster-space publish rolls back.
    """

    def test_renders_the_pki_endpoints_the_api_can_actually_reach(self):
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual([f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], signer["pkiBaseUrls"])

    def test_renders_the_hardware_challenge_this_node_can_actually_produce(self):
        # SUP-660: the challenge follows the node's own sp_vm_evidence_type, so
        # the certificate binds the signing key to this guest's quote.
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertEqual("tdx", signer["challenge"])

    def test_renders_the_platform_variant_rather_than_the_family(self):
        # tdx-google and sev-snp-azure need different native calls; collapsing
        # them to `tdx` / `sev-snp` would produce evidence the authority rejects.
        for evidence_type in ("tdx-google", "tdx-azure", "sev-snp", "sev-snp-azure"):
            with self.subTest(evidence_type=evidence_type):
                state = build_state(LOCAL_NODE_ID)
                state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": evidence_type}]
                section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
                self.assertEqual(evidence_type, section["evidenceSigner"]["challenge"])

    def test_falls_back_to_token_only_on_a_node_with_no_tee(self):
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "untrusted"}]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual("token", section["evidenceSigner"]["challenge"])

    def test_renders_nothing_until_the_node_has_been_measured(self):
        # An unmeasured node that silently rendered `token` would come up with
        # the weaker binding and nothing would say so.
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_for_an_evidence_type_we_cannot_quote(self):
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "sgx"}]
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_reads_this_node_s_measurement_not_a_peer_s(self):
        state = build_state(LOCAL_NODE_ID)
        self.assertEqual("tdx", main.get_node_evidence_type(LOCAL_NODE_ID, state))
        self.assertEqual("sev-snp", main.get_node_evidence_type(PEER_NODE_ID, state))

    def test_the_rendered_challenge_is_one_the_authority_template_allows(self):
        template = yaml.safe_load(
            (REPO_ROOT / "services/pki-authority/pki-authority-template.yaml").read_text()
        )
        allowed = template["pki"]["allowedChallenges"]
        signer = render_config(LOCAL_NODE_ID)["evidenceSigner"]
        self.assertIn(signer["challenge"], allowed)

    def test_prefers_loopback_when_this_node_hosts_a_pki_authority(self):
        # Issuance must not depend on the WireGuard mesh being up at the moment a
        # leader comes back, so a co-hosted authority is tried first.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": "10.10.0.2", "ready": "true"},
            {"id": f"pki:{LOCAL_NODE_ID}", "node_id": LOCAL_NODE_ID, "ip": "10.10.0.1", "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://127.0.0.1:{main.PKI_API_HTTP_PORT}", f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"],
            section["evidenceSigner"]["pkiBaseUrls"],
        )

    def test_skips_an_authority_that_is_not_ready(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": "pki:node-3", "node_id": "node-3", "ip": "10.10.0.3", "ready": None},
        ]
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_on_a_cloud_with_no_pki_authority(self):
        # The legacy non-sp-vm shape: leave evidence signing unconfigured rather
        # than point it at an endpoint that does not exist.
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_renders_nothing_until_the_auth_token_secret_exists(self):
        # Only the token path needs the secret; a hardware challenge does not.
        state = build_state(LOCAL_NODE_ID)
        state["evidenceTypeMeasurements"] = [{"node": LOCAL_NODE_ID, "value": "untrusted"}]
        state["swarmSecrets"] = []
        self.assertEqual("", main._build_evidence_signer_section(LOCAL_NODE_ID, state))

    def test_a_hardware_challenge_does_not_need_the_shared_token(self):
        state = build_state(LOCAL_NODE_ID)
        state["swarmSecrets"] = []
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual("tdx", section["evidenceSigner"]["challenge"])

    def test_falls_back_to_wg_properties_when_the_node_carries_no_ip(self):
        state = build_state(LOCAL_NODE_ID)
        state["pkiAuthorityNodes"] = [
            {"id": f"pki:{PEER_NODE_ID}", "node_id": PEER_NODE_ID, "ip": None, "ready": "true"},
        ]
        section = yaml.safe_load(main._build_evidence_signer_section(LOCAL_NODE_ID, state))
        self.assertEqual(
            [f"http://10.10.0.2:{main.PKI_API_HTTP_PORT}"], section["evidenceSigner"]["pkiBaseUrls"]
        )


class AttestationDeviceTest(unittest.TestCase):
    """SUP-660: the quote comes from a character device, and the API container
    only sees the ones rendered here. Passing the wrong one — or `--privileged`
    — is the difference between a signer bound to this guest and a container
    with the run of the host."""

    def _render_unit(self, devices: list[str]) -> str:
        with tempfile.TemporaryDirectory() as tmp:
            unit_path = Path(tmp) / "swarm-cloud-api.service"
            original_write = main._write_file_if_changed
            captured = {}

            def capture(path, content, label):
                captured["content"] = content
                return original_write(unit_path, content, label)

            main._write_file_if_changed = capture
            original_run = main.subprocess.run
            main.subprocess.run = lambda *a, **k: None
            try:
                main.create_systemd_service("v1", "10.10.0.1", devices)
            finally:
                main._write_file_if_changed = original_write
                main.subprocess.run = original_run
            return captured["content"]

    def test_passes_through_only_the_device_the_evidence_type_needs(self):
        unit = self._render_unit(["/dev/tdx_guest"])
        self.assertIn("--device /dev/tdx_guest", unit)
        self.assertNotIn("/dev/sev-guest", unit)

    def test_never_renders_privileged(self):
        unit = self._render_unit(["/dev/sev-guest"])
        self.assertNotIn("--privileged", unit)

    def test_opens_the_device_to_the_container_uid_rather_than_running_as_root(self):
        # The API runs as uid 1001; the device is root-owned 0600 on a stock sp-vm.
        unit = self._render_unit(["/dev/tdx_guest"])
        self.assertIn(f"ExecStartPre=-/usr/bin/chgrp {main.API_CONTAINER_GID} /dev/tdx_guest", unit)
        self.assertIn("ExecStartPre=-/usr/bin/chmod 0660 /dev/tdx_guest", unit)

    def test_a_device_that_vanished_does_not_wedge_the_unit(self):
        # `-` prefix: the API then fails at startup naming the device, which is
        # diagnosable; a hard ExecStartPre failure is not.
        unit = self._render_unit(["/dev/tdx_guest"])
        for line in unit.splitlines():
            if "chgrp" in line or "chmod" in line:
                self.assertTrue(line.startswith("ExecStartPre=-"), line)

    def test_renders_the_unit_unchanged_when_there_is_no_device(self):
        self.assertNotIn("--device", self._render_unit([]))

    def test_both_tpm_nodes_are_offered_on_azure(self):
        unit = self._render_unit(main.ATTESTATION_DEVICES["tdx-azure"])
        self.assertIn("--device /dev/tpm0", unit)
        self.assertIn("--device /dev/tpmrm0", unit)

    def test_only_renders_devices_that_exist_on_this_host(self):
        # podman refuses to start the container at all for a missing --device,
        # which would take the API down on a merely mismeasured node.
        self.assertEqual([], main.get_attestation_devices("tdx"))
        self.assertEqual([], main.get_attestation_devices(None))
        self.assertEqual([], main.get_attestation_devices("untrusted"))

    def test_the_device_table_matches_the_one_the_api_enforces(self):
        """`EvidenceSignerService` refuses to start when none of its devices is
        openable, so these two tables drifting apart bricks the control plane."""
        source = (
            REPO_ROOT
            / "apps/swarm-cloud-api/src/app/evidence-signer/hardware-quote-challenge-provider.ts"
        ).read_text()
        body = re.search(
            r"ATTESTATION_DEVICES: Record<HardwareChallengeType, readonly string\[\]> = \{(.*?)^\};",
            source,
            re.DOTALL | re.MULTILINE,
        )
        self.assertIsNotNone(body, "could not find ATTESTATION_DEVICES in the provider")
        from_ts = {
            key.strip("'\""): re.findall(r"'([^']+)'", devices)
            for key, devices in re.findall(r"^\s*('?[\w-]+'?):\s*\[([^\]]*)\],", body.group(1), re.MULTILINE)
        }
        self.assertEqual(main.ATTESTATION_DEVICES, from_ts)


class EvidenceSignerManifestTest(unittest.TestCase):
    def test_the_manifest_supplies_what_the_renderer_reads(self):
        """The renderer reads `pkiAuthorityNodes` and the `pki_auth_token` secret; a
        stateExpr that does not select them renders an empty block on every node."""
        manifest = yaml.safe_load((HERE / "manifest.yaml").read_text())
        query = manifest["stateExpr"]["query"]
        self.assertIn("pkiAuthorityNodes:", query)
        self.assertIn('cluster_policy == "pki-authority"', query)
        self.assertIn("pki_authority_node_ready", query)
        self.assertIn("pki_auth_token", query)
        # SUP-660: the challenge is chosen from this measurement.
        self.assertIn("evidenceTypeMeasurements:", query)
        self.assertIn("sp_vm_evidence_type", query)


if __name__ == "__main__":
    unittest.main()
