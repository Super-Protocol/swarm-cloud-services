"""GPU attestation mode is taken from the node certificate extension."""

import base64

from test_gpu_labels import _load_main_module


def _extension(mode: int) -> bytes:
    oid = bytes((0x2B, 0x06, 0x01, 0x03, 0xC5, 0x38, 0x01, 0x04, 0x01))
    payload = bytes((0x10, mode))
    return oid + bytes((0x04, len(payload))) + payload


def test_local_and_remote_modes():
    m = _load_main_module()
    assert m.gpu_attest_mode_from_der(_extension(2)) == "proxy"
    assert m.gpu_attest_mode_from_der(_extension(1)) == "nras"
    assert m.gpu_attest_mode_from_der(_extension(0)) is None


def test_nested_gpu_fields_do_not_hide_the_mode():
    m = _load_main_module()
    nested = bytes((0x0A, 0x04, 0x12, 0x02, 0x61, 0x62, 0x10, 0x02))
    assert m.gpu_attest_mode_from_extension(nested) == "proxy"


def test_a_group_before_the_mode_is_skipped():
    m = _load_main_module()
    # field 1 start-group, inner varint, end-group, then field 2 = LOCAL/proxy
    payload = bytes((0x0B, 0x08, 0x01, 0x0C, 0x10, 0x02))
    assert m.gpu_attest_mode_from_extension(payload) == "proxy"


def test_unskippable_wire_type_does_not_invent_a_mode():
    m = _load_main_module()
    # field 1 wire type 6 has no length, so the following bytes are not a mode
    payload = bytes((0x0E, 0x10, 0x02))
    assert m.gpu_attest_mode_from_extension(payload) is None


def _pem(mode: int) -> str:
    return "-----BEGIN CERTIFICATE-----\n" + base64.b64encode(_extension(mode)).decode() + "\n-----END CERTIFICATE-----\n"


def test_read_gpu_attest_mode_from_pem(tmp_path):
    m = _load_main_module()
    cert = tmp_path / "node_cert.pem"
    cert.write_text(_pem(2))
    assert m.read_gpu_attest_mode([str(tmp_path)]) == "proxy"


def test_certificate_chain_uses_the_leaf(tmp_path):
    m = _load_main_module()
    cert = tmp_path / "vm_cert.pem"
    cert.write_text(_pem(2) + _pem(0))
    assert m.read_gpu_attest_mode([str(tmp_path)]) == "proxy"


def test_newest_certificate_wins_even_without_a_mode(tmp_path):
    m = _load_main_module()
    older = tmp_path / "a_cert.pem"
    newer = tmp_path / "z_cert.pem"
    older.write_text(_pem(2))
    newer.write_text(
        "-----BEGIN CERTIFICATE-----\n" + base64.b64encode(b"\x30\x00").decode() + "\n-----END CERTIFICATE-----\n"
    )
    os_utime = __import__("os").utime
    os_utime(older, (1, 1))
    os_utime(newer, (2, 2))
    assert m.read_gpu_attest_mode([str(tmp_path)]) is None
