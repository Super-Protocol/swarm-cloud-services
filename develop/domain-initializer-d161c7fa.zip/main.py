#!/usr/bin/env python3

from __future__ import annotations

from enum import Enum

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

plugin = ProvisionPlugin()


class DomainKind(str, Enum):
    SWARM = "swarm"
    PKI = "pki"


DOMAIN_PREFIX_BY_KIND: dict[DomainKind, str] = {
    DomainKind.SWARM: "app",
    DomainKind.PKI: "ca",
}


def _get_secret_from_swarmdb(state: dict, secret_id: str) -> str | None:
    secrets = state.get("swarmSecrets", [])
    for secret in secrets:
        if secret.get("id") == secret_id:
            return secret.get("value")
    return None


def _compute_domain_from_state(state: dict, domain_kind: DomainKind) -> str | None:
    global_id = state.get("globalId")
    if not isinstance(global_id, str) or not global_id.strip():
        return None

    base_domain = _get_secret_from_swarmdb(state, "base_domain")
    if not isinstance(base_domain, str) or not base_domain.strip():
        return None

    prefix = DOMAIN_PREFIX_BY_KIND.get(domain_kind)
    if not isinstance(prefix, str) or not prefix.strip():
        return None

    return f"{prefix}.{global_id.strip()}.{base_domain.strip()}"


@plugin.command("init")
def handle_init(input_data: PluginInput) -> PluginOutput:
    try:
        state = input_data.state or {}
        node_properties: dict[str, str] = {}

        domain_targets: list[tuple[str, DomainKind]] = [
            ("swarm_domain", DomainKind.SWARM),
            ("pki_domain", DomainKind.PKI),
        ]

        for domain_key, domain_kind in domain_targets:
            if isinstance(state, dict):
                existing_domain = state.get(domain_key)
                if isinstance(existing_domain, str) and existing_domain.strip():
                    node_properties[domain_key] = existing_domain.strip()
                    continue

            domain_secret = _get_secret_from_swarmdb(state, domain_key)
            if isinstance(domain_secret, str) and domain_secret.strip():
                node_properties[domain_key] = domain_secret.strip()
                continue

            computed_domain = _compute_domain_from_state(state, domain_kind)
            if computed_domain:
                node_properties[domain_key] = computed_domain

        if node_properties:
            return PluginOutput(
                status="completed",
                node_properties=node_properties,
                local_state=input_data.local_state,
            )

        return PluginOutput(
            status="postponed",
            error_message="Waiting for domain values in state/secrets or globalId and base_domain for fallback",
            local_state=input_data.local_state,
        )
    except Exception as e:
        return PluginOutput(
            status="error",
            error_message=str(e),
            local_state=input_data.local_state,
        )


if __name__ == "__main__":
    plugin.run()
