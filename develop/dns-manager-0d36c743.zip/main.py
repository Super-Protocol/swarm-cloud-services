#!/usr/bin/env python3
"""DNS manager provision plugin — parent-zone synchronisation only.

This plugin owns what lives *outside* the cluster's own zones: the NS + glue
delegation for ``<global_id>.<base_domain>`` and ``dyn.<global_id>.<base_domain>``
in the PowerDNS parent zone, the swarm/pki domain CNAMEs in that parent zone, and
the wildcard CNAME used by the custom-gateway mode.

Records *inside* the cluster zones (apex NS/glue, ``gw.dyn`` A records, service
CNAMEs) are rendered locally by the knot plugin on every node from SwarmDB state.
There is no nsupdate/RFC2136 path here any more, and no TSIG key to look up.
"""

from __future__ import annotations

import hashlib
import sys
from typing import Optional

import requests

from provision_plugin_sdk import ProvisionPlugin, PluginInput, PluginOutput

plugin = ProvisionPlugin()

# The parent zone tolerates no staleness at all: a write is only allowed when this
# node has merged peer state within the last signal bucket (age 0), or when there is
# no peer to merge with. There is deliberately no grace period here — see
# `parent_zone_writes_are_safe` for why this differs from the knot serving gate.
PEER_STATE_AGE_BUCKET_SECS = 30


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def log(msg: str) -> None:
    print(f"[dns-manager] {msg}", file=sys.stderr)


def get_swarm_secret(state: dict, secret_id: str) -> str | None:
    swarm_secrets = state.get("swarmSecrets", [])
    if not isinstance(swarm_secrets, list):
        return None
    for secret in swarm_secrets:
        if isinstance(secret, dict) and secret.get("id") == secret_id:
            value = secret.get("value")
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def resolve_global_id(state: dict) -> str | None:
    global_id = state.get("globalId")
    if isinstance(global_id, str) and global_id.strip():
        return global_id.strip()
    return None


def resolve_dynamic_gateway_hostname(state: dict) -> str | None:
    global_id = resolve_global_id(state)
    base_domain = get_swarm_secret(state, "base_domain")
    if global_id and base_domain:
        return f"gw.dyn.{global_id}.{base_domain.rstrip('.')}"
    return None


def resolve_static_gateway_hostname(state: dict) -> str | None:
    custom = get_swarm_secret(state, "gateway_hostname")
    if custom:
        return custom.rstrip(".")
    return None


def resolve_delegation_gateway_hostname(state: dict) -> str | None:
    """CNAME target for users: static gateway when configured, else dynamic."""
    static = resolve_static_gateway_hostname(state)
    if static:
        return static
    return resolve_dynamic_gateway_hostname(state)


def peer_state_age_secs(state: dict) -> int | None:
    """Age of the freshest peer-written state this node has merged, in seconds.

    ``None`` means there is no current peer to merge with (single-node swarm, or every
    other node removed) — not staleness, so it never gates.
    """
    age = state.get("peerStateAgeSecs")
    if isinstance(age, bool) or not isinstance(age, (int, float)):
        return None
    return max(0, int(age))


def parent_zone_writes_are_safe(state: dict) -> tuple[bool, str]:
    """Whether this node's view is current enough to rewrite the shared parent zone.

    The parent zone is the one piece of DNS state shared with every other cloud, and
    it is last-writer-wins. A partitioned node keeps full internet access — only its
    peers are unreachable — so it can still reach the PowerDNS API while its SwarmDB
    view decays to "I am the only ready knot node". Publishing that collapses the
    delegation onto a node that is about to stop answering, which takes the whole
    cloud off the public internet with no operator lever to undo it.

    So writes require *current* state, not merely state inside a grace period: a view
    decays to that wrong answer within a couple of minutes of a partition, well before
    any grace worth having would expire, and the damaging PATCH would land first. The
    serving gate in the knot plugin can afford a grace because holding stale answers
    is recoverable; poisoning shared last-writer-wins state is not.

    Refusing to write costs nothing: the parent zone keeps what the last node with a
    current view published, which is the correct set. On a healthy cluster the age is
    pinned at 0, so this never blocks normal operation.
    """
    age = peer_state_age_secs(state)
    if age is None:
        return True, "no peer to merge with"
    if age > 0:
        return False, f"peer state is {age}s old (writes need state merged within {PEER_STATE_AGE_BUCKET_SECS}s)"
    return True, "peer state is current"


def node_id_to_ns_name(node_id: str) -> str:
    """Convert node_id to DNS-compatible name using MD5 hash in base36 (mirrors knot logic)."""
    md5_hash = hashlib.md5(node_id.encode()).hexdigest()
    hash_int = int(md5_hash, 16)
    base36_chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    if hash_int == 0:
        return "0"
    base36 = []
    while hash_int:
        hash_int, remainder = divmod(hash_int, 36)
        base36.append(base36_chars[remainder])
    return "".join(reversed(base36))


# ---------------------------------------------------------------------------
# PowerDNS API helpers
# ---------------------------------------------------------------------------

def pdns_get_rrsets(api_url: str, api_key: str, zone: str) -> Optional[list]:
    zone_id = zone.rstrip(".") + "."
    log(f"PowerDNS: fetching rrsets for zone {zone_id}")
    try:
        resp = requests.get(
            f"{api_url}/api/v1/servers/localhost/zones/{zone_id}",
            headers={"X-API-Key": api_key},
            timeout=10,
        )
        if resp.status_code != 200:
            log(f"PowerDNS GET zone {zone} failed: HTTP {resp.status_code}: {resp.text}")
            return None
        rrsets = resp.json().get("rrsets", [])
        log(f"PowerDNS: got {len(rrsets)} rrsets from zone {zone_id}")
        return rrsets
    except requests.exceptions.RequestException as e:
        log(f"PowerDNS connection error (GET {zone_id}): {e}")
        return None


def pdns_patch_zone(api_url: str, api_key: str, zone: str, rrsets: list) -> bool:
    zone_id = zone.rstrip(".") + "."
    log(f"PowerDNS: patching zone {zone_id} with {len(rrsets)} rrset change(s)")
    for r in rrsets:
        log(f"  {r.get('changetype')} {r.get('type')} {r.get('name')} "
            f"{[rec.get('content') for rec in r.get('records', [])] or ''}")
    try:
        resp = requests.patch(
            f"{api_url}/api/v1/servers/localhost/zones/{zone_id}",
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            json={"rrsets": rrsets},
            timeout=10,
        )
        if resp.status_code not in (200, 204):
            log(f"PowerDNS PATCH zone {zone} failed: HTTP {resp.status_code}: {resp.text}")
            return False
        log(f"PowerDNS: zone {zone_id} patched successfully")
        return True
    except requests.exceptions.RequestException as e:
        log(f"PowerDNS connection error (PATCH {zone_id}): {e}")
        return False


# ---------------------------------------------------------------------------
# Sync operations
# ---------------------------------------------------------------------------

def uses_custom_gateway_dns(state: dict) -> bool:
    """Custom gateway + global_id: wildcard CNAME in PowerDNS, A records on Knot."""
    return bool(resolve_static_gateway_hostname(state) and resolve_global_id(state))


def is_under_cluster_zone(hostname: str, global_id: str, base_domain: str) -> bool:
    """True for labels under {global_id}.{base_domain}, excluding the zone apex."""
    cluster_zone = f"{global_id.strip()}.{base_domain.strip().rstrip('.')}"
    normalized = hostname.rstrip(".")
    if normalized == cluster_zone:
        return False
    return normalized.endswith(f".{cluster_zone}")


def _powerdns_delete_delegation_glue_patch(
    rrsets: list,
    delegated_zone: str,
    log_prefix: str,
) -> list[dict]:
    """Build DELETE patches for NS at zone apex and glue A records under delegated_zone."""
    delegated_zone_fqdn = f"{delegated_zone}."
    patch: list[dict] = []

    ns_rrset = next(
        (r for r in rrsets if r.get("name") == delegated_zone_fqdn and r.get("type") == "NS"),
        None,
    )
    if ns_rrset:
        patch.append({
            "name": delegated_zone_fqdn,
            "type": "NS",
            "changetype": "DELETE",
        })
        log(f"{log_prefix}: will remove NS at {delegated_zone_fqdn}")

    for rrset in rrsets:
        if rrset.get("type") != "A":
            continue
        if not rrset["name"].endswith(f".{delegated_zone}."):
            continue
        patch.append({
            "name": rrset["name"],
            "type": "A",
            "changetype": "DELETE",
        })
        log(f"{log_prefix}: will remove glue A {rrset['name']}")

    return patch


def sync_cluster_wildcard_gateway_in_powerdns(
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
    gateway_hostname: str,
) -> bool:
    """Set *.{global_id}.{base_domain} CNAME to gateway_hostname; remove knot NS/glue."""
    cluster_zone = f"{global_id}.{base_domain.rstrip('.')}"
    dyn_zone = f"dyn.{cluster_zone}"
    wildcard_fqdn = f"*.{cluster_zone}."
    cname_target_fqdn = gateway_hostname.rstrip(".") + "."

    log(
        "sync_wildcard_gateway: "
        f"want {wildcard_fqdn} CNAME -> {cname_target_fqdn}; "
        f"clear delegation glue for {cluster_zone} and {dyn_zone}"
    )

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    patch: list[dict] = []
    patch.extend(_powerdns_delete_delegation_glue_patch(rrsets, cluster_zone, "sync_wildcard_gateway"))
    patch.extend(_powerdns_delete_delegation_glue_patch(rrsets, dyn_zone, "sync_wildcard_gateway"))

    wildcard_correct = any(
        rrset.get("name") == wildcard_fqdn
        and rrset.get("type") == "CNAME"
        and any(r.get("content") == cname_target_fqdn for r in rrset.get("records", []))
        for rrset in rrsets
    )

    if not wildcard_correct:
        for rrset in rrsets:
            if rrset.get("name") == wildcard_fqdn and rrset.get("type") in ("A", "CNAME"):
                patch.append({
                    "name": rrset["name"],
                    "type": rrset["type"],
                    "changetype": "DELETE",
                })
        patch.append({
            "name": wildcard_fqdn,
            "type": "CNAME",
            "ttl": 300,
            "changetype": "REPLACE",
            "records": [{"content": cname_target_fqdn, "disabled": False}],
        })
    elif not patch:
        log("sync_wildcard_gateway: already correct, no changes needed")
        return True

    return pdns_patch_zone(api_url, api_key, base_domain, patch)


def sync_knot_delegation_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    base_domain: str,
    delegated_zone: str,
    log_prefix: str,
) -> bool:
    """Actualize NS and glue A records for delegated_zone in PowerDNS base_domain zone."""
    delegated_zone_fqdn = f"{delegated_zone}."

    log(f"{log_prefix}: delegated zone={delegated_zone_fqdn}")

    desired: dict[str, str] = {}
    for svc in state.get("knotServices", []):
        if svc.get("ready") == "true" and svc.get("external_ip"):
            ns_name = node_id_to_ns_name(svc["node_id"])
            ns_fqdn = f"{ns_name}.{delegated_zone}."
            desired[ns_fqdn] = svc["external_ip"]
            log(f"{log_prefix}: desired NS {ns_fqdn} -> {svc['external_ip']} (node={svc['node_id']})")

    if not desired:
        log(f"{log_prefix}: no ready knot nodes, skipping")
        return True

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    ns_rrset = next(
        (r for r in rrsets if r.get("name") == delegated_zone_fqdn and r.get("type") == "NS"),
        None,
    )
    current_ns_fqdns: set[str] = {
        r["content"] for r in (ns_rrset or {}).get("records", [])
    }
    log(f"{log_prefix}: current NS records: {sorted(current_ns_fqdns) or '(none)'}")

    current_a: dict[str, str] = {}
    for rrset in rrsets:
        if rrset.get("type") == "A" and rrset["name"].endswith(f".{delegated_zone}."):
            for rec in rrset.get("records", []):
                current_a[rrset["name"]] = rec["content"]
    log(f"{log_prefix}: current glue A records: {current_a or '(none)'}")

    desired_ns_fqdns = set(desired.keys())
    stale_ns_fqdns = current_ns_fqdns - desired_ns_fqdns
    new_ns_fqdns = desired_ns_fqdns - current_ns_fqdns
    if stale_ns_fqdns:
        log(f"{log_prefix}: stale NS to remove: {sorted(stale_ns_fqdns)}")
    if new_ns_fqdns:
        log(f"{log_prefix}: new NS to add: {sorted(new_ns_fqdns)}")

    if (
        current_ns_fqdns == desired_ns_fqdns
        and all(current_a.get(ns) == ip for ns, ip in desired.items())
    ):
        log(f"{log_prefix}: already up to date, no changes needed")
        return True

    patch = [{
        "name": delegated_zone_fqdn,
        "type": "NS",
        "ttl": 300,
        "changetype": "REPLACE",
        "records": [{"content": ns, "disabled": False} for ns in sorted(desired_ns_fqdns)],
    }]

    for stale_ns in stale_ns_fqdns:
        patch.append({"name": stale_ns, "type": "A", "changetype": "DELETE"})

    for ns_fqdn, ip in desired.items():
        patch.append({
            "name": ns_fqdn,
            "type": "A",
            "ttl": 300,
            "changetype": "REPLACE",
            "records": [{"content": ip, "disabled": False}],
        })

    log(f"{log_prefix}: applying patch ({len(desired)} nodes, {len(stale_ns_fqdns)} stale removed)")
    return pdns_patch_zone(api_url, api_key, base_domain, patch)


def sync_knot_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
) -> bool:
    """Actualize NS and glue A records for {global_id}.{base_domain} in PowerDNS."""
    return sync_knot_delegation_glue_in_powerdns(
        state,
        api_url,
        api_key,
        base_domain,
        f"{global_id}.{base_domain}",
        "sync_knot_glue",
    )


def sync_dyn_knot_glue_in_powerdns(
    state: dict,
    api_url: str,
    api_key: str,
    global_id: str,
    base_domain: str,
) -> bool:
    """Delegate dyn.{global_id}.{base_domain} to knot (required for public gw.dyn resolution)."""
    return sync_knot_delegation_glue_in_powerdns(
        state,
        api_url,
        api_key,
        base_domain,
        f"dyn.{global_id}.{base_domain}",
        "sync_dyn_glue",
    )


def sync_domain_cname(
    api_url: str,
    api_key: str,
    domain_name: str,
    base_domain: str,
    cname_target: str,
    domain_label: str,
) -> bool:
    """Ensure <domain_name> CNAME -> cname_target in PowerDNS."""
    log(f"sync_domain_cname[{domain_label}]: domain={domain_name}, base_domain={base_domain}")

    normalized_domain = domain_name.rstrip(".")
    normalized_base_domain = base_domain.rstrip(".")

    if normalized_domain == normalized_base_domain:
        log(
            f"sync_domain_cname[{domain_label}]: domain equals base_domain; "
            "skipping apex CNAME because the base zone apex already has SOA/NS, "
            "and Knot is authoritative only for delegated zones under base_domain"
        )
        return True

    if not normalized_domain.endswith(f".{normalized_base_domain}"):
        log(f"sync_domain_cname[{domain_label}]: {domain_name} is not under {base_domain}, skipping")
        return True

    cname_target_fqdn = cname_target.rstrip(".") + "."
    domain_fqdn = normalized_domain + "."
    log(f"sync_domain_cname[{domain_label}]: want {domain_fqdn} CNAME -> {cname_target_fqdn}")

    rrsets = pdns_get_rrsets(api_url, api_key, base_domain)
    if rrsets is None:
        return False

    # Already correct?
    for rrset in rrsets:
        if rrset.get("name") == domain_fqdn and rrset.get("type") == "CNAME":
            if any(r.get("content") == cname_target_fqdn for r in rrset.get("records", [])):
                log(f"sync_domain_cname[{domain_label}]: already correct, no changes needed")
                return True

    patch = [
        {"name": rrset["name"], "type": rrset["type"], "changetype": "DELETE"}
        for rrset in rrsets
        if rrset.get("name") == domain_fqdn and rrset.get("type") in ("A", "CNAME")
    ]
    if patch:
        log(f"sync_domain_cname[{domain_label}]: removing {len(patch)} conflicting record(s) for {domain_fqdn}")

    patch.append({
        "name": domain_fqdn,
        "type": "CNAME",
        "ttl": 300,
        "changetype": "REPLACE",
        "records": [{"content": cname_target_fqdn, "disabled": False}],
    })

    return pdns_patch_zone(api_url, api_key, base_domain, patch)


# ---------------------------------------------------------------------------
# Plugin commands
# ---------------------------------------------------------------------------

@plugin.command("apply")
def handle_apply(input_data: PluginInput) -> PluginOutput:
    state = input_data.state or {}
    local_state = input_data.local_state or {}

    global_id = resolve_global_id(state)
    base_domain = get_swarm_secret(state, "base_domain")
    api_url = get_swarm_secret(state, "powerdns_api_url")
    api_key = get_swarm_secret(state, "powerdns_api_key")
    full_zone = f"{global_id}.{base_domain}" if global_id and base_domain else None

    swarm_domain = get_swarm_secret(state, "swarm_domain") or state.get("swarmDomain")
    if not swarm_domain:
        swarm_domain = f"app.{global_id}.{base_domain}"
        log(f"apply: swarm_domain not set, using computed: {swarm_domain}")

    pki_domain = get_swarm_secret(state, "pki_domain") or state.get("pkiDomain")
    if not pki_domain:
        pki_domain = f"ca.{global_id}.{base_domain}"
        log(f"apply: pki_domain not set, using computed: {pki_domain}")

    log(f"apply: global_id={global_id}, base_domain={base_domain}, "
        f"powerdns={'yes' if api_url else 'no'}")
    log(f"apply: knot nodes={len(state.get('knotServices', []))}")

    if not global_id or not base_domain:
        log("apply: postponed — missing globalId or base_domain")
        return PluginOutput(
            status="postponed",
            error_message="Waiting for globalId and base_domain",
            local_state=local_state,
        )

    if not api_url or not api_key:
        log("apply: powerdns_api_url or powerdns_api_key missing, nothing to sync")
        return PluginOutput(status="completed", local_state=local_state)

    writes_safe, freshness = parent_zone_writes_are_safe(state)
    if not writes_safe:
        log(f"apply: postponed — {freshness}, refusing to rewrite the shared parent zone")
        return PluginOutput(
            status="postponed",
            error_message=(
                f"Cluster state is stale: {freshness}; leaving the parent zone as it is"
            ),
            local_state=local_state,
        )
    log(f"apply: {freshness}, parent-zone writes allowed")

    custom_gateway_dns = uses_custom_gateway_dns(state)
    static_gateway_hostname = resolve_static_gateway_hostname(state)
    delegation_gateway_hostname = resolve_delegation_gateway_hostname(state)

    if custom_gateway_dns:
        if not static_gateway_hostname:
            log("apply: postponed — custom gateway mode requires gateway_hostname")
            return PluginOutput(
                status="postponed",
                error_message="Waiting for gateway_hostname",
                local_state=local_state,
            )
        log(f"apply: custom gateway DNS mode, gateway_hostname={static_gateway_hostname}")

        if not sync_cluster_wildcard_gateway_in_powerdns(
            api_url, api_key, global_id, base_domain, static_gateway_hostname
        ):
            return PluginOutput(
                status="postponed",
                error_message="Failed to sync cluster wildcard gateway CNAME in PowerDNS",
                local_state=local_state,
            )

        for domain, label in ((swarm_domain, "swarm"), (pki_domain, "pki")):
            if is_under_cluster_zone(domain, global_id, base_domain):
                log(f"apply: {label}_domain {domain} covered by cluster wildcard, skipping")
                continue
            if not sync_domain_cname(
                api_url, api_key, domain, base_domain, static_gateway_hostname, label
            ):
                return PluginOutput(
                    status="postponed",
                    error_message=f"Failed to sync {label}_domain CNAME in PowerDNS",
                    local_state=local_state,
                )

        log("apply: completed successfully")
        return PluginOutput(status="completed", local_state=local_state)

    if not delegation_gateway_hostname:
        log("apply: postponed — unable to resolve delegation gateway hostname")
        return PluginOutput(
            status="postponed",
            error_message="Waiting for delegation gateway hostname",
            local_state=local_state,
        )
    log(f"apply: delegation_gateway_hostname={delegation_gateway_hostname}")

    if not sync_knot_glue_in_powerdns(state, api_url, api_key, global_id, base_domain):
        return PluginOutput(
            status="postponed",
            error_message="Failed to sync knot glue records in PowerDNS",
            local_state=local_state,
        )

    if not sync_dyn_knot_glue_in_powerdns(state, api_url, api_key, global_id, base_domain):
        return PluginOutput(
            status="postponed",
            error_message="Failed to sync dyn zone glue records in PowerDNS",
            local_state=local_state,
        )

    if not sync_domain_cname(
        api_url, api_key, swarm_domain, base_domain, delegation_gateway_hostname, "swarm"
    ):
        return PluginOutput(
            status="postponed",
            error_message="Failed to sync swarm_domain CNAME in PowerDNS",
            local_state=local_state,
        )

    # Names inside the delegated zone are served by Knot, which renders them locally
    # on every node; only names outside it need a parent-zone CNAME.
    pki_in_delegated_zone = (
        isinstance(full_zone, str)
        and (pki_domain == full_zone or pki_domain.endswith(f".{full_zone}"))
    )
    if pki_in_delegated_zone:
        log(f"apply: pki_domain is in delegated zone {full_zone}, rendered by knot")
    elif not sync_domain_cname(
        api_url, api_key, pki_domain, base_domain, delegation_gateway_hostname, "pki"
    ):
        return PluginOutput(
            status="postponed",
            error_message="Failed to sync pki_domain CNAME in PowerDNS",
            local_state=local_state,
        )

    log("apply: completed successfully")
    return PluginOutput(status="completed", local_state=local_state)


@plugin.command("destroy")
def handle_destroy(input_data: PluginInput) -> PluginOutput:
    log("destroy: completed")
    return PluginOutput(status="completed", local_state={})


if __name__ == "__main__":
    plugin.run()
