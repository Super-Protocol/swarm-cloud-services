#!/usr/bin/env python3
"""Unit tests for the dns-manager plugin's parent-zone freshness gate.

Run from the repository root:

    python3 -m unittest discover -s services/dns-manager -p 'test_main.py' -v
"""

import json
import shutil
import subprocess
import sys
import time
import unittest
import unittest.mock
from pathlib import Path

HERE = Path(__file__).resolve().parent
SDK_DIR = HERE.parents[1] / "provision-plugin-sdk"

for path in (str(HERE), str(SDK_DIR)):
    if path not in sys.path:
        sys.path.insert(0, path)

try:
    import yaml
except ImportError:  # pragma: no cover - the manifest tests skip without it
    yaml = None

if "provision_plugin_sdk" not in sys.modules:
    stub = type(sys)("provision_plugin_sdk")

    class _PluginInput:
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class _PluginOutput:
        def __init__(self, *args, **kwargs):
            self.status = kwargs.get("status")
            self.error_message = kwargs.get("error_message")
            self.local_state = kwargs.get("local_state")

    class _ProvisionPlugin:
        def command(self, _name):
            def decorator(fn):
                return fn

            return decorator

        def run(self):
            pass

    stub.PluginInput = _PluginInput
    stub.PluginOutput = _PluginOutput
    stub.ProvisionPlugin = _ProvisionPlugin
    stub.build_image_evidence_props = lambda *args, **kwargs: {}
    stub.read_manifest_version = lambda *args, **kwargs: "0.0.0"
    sys.modules["provision_plugin_sdk"] = stub

import main  # noqa: E402  (import after the SDK stub is installed)

BASE_DOMAIN = "example.test"
GLOBAL_ID = "gid1"
CLUSTER_ZONE = f"{GLOBAL_ID}.{BASE_DOMAIN}"


def make_state(**overrides) -> dict:
    state = {
        "globalId": GLOBAL_ID,
        "swarmDomain": f"app.{CLUSTER_ZONE}",
        "pkiDomain": f"ca.{CLUSTER_ZONE}",
        "knotServices": [
            {"node_id": "node-1", "ready": "true", "external_ip": "203.0.113.1"},
            {"node_id": "node-2", "ready": "true", "external_ip": "203.0.113.2"},
        ],
        "swarmSecrets": [
            {"id": "base_domain", "value": BASE_DOMAIN},
            {"id": "powerdns_api_url", "value": "http://pdns.invalid:8081"},
            {"id": "powerdns_api_key", "value": "secret"},
        ],
        "localNodeId": "node-1",
        "peerStateAgeSecs": 0,
    }
    state.update(overrides)
    return state


class FreshnessGateTests(unittest.TestCase):
    def test_current_state_allows_writes(self):
        safe, detail = main.parent_zone_writes_are_safe(make_state())
        self.assertTrue(safe)
        self.assertIn("current", detail)

    def test_any_staleness_at_all_blocks_writes(self):
        # Shared last-writer-wins state gets no grace period: a partitioned node's
        # view decays to "I am the only ready knot node" within a couple of minutes,
        # so any tolerance lets the poisoning PATCH land before the gate closes.
        for age in (main.PEER_STATE_AGE_BUCKET_SECS, 120, 300, 86400):
            state = make_state(peerStateAgeSecs=age)
            safe, detail = main.parent_zone_writes_are_safe(state)
            self.assertFalse(safe, age)
            self.assertIn(f"{age}s old", detail)

    def test_no_peer_to_merge_with_allows_writes(self):
        # Single-node swarm, or every other node removed: not staleness. The surviving
        # node must still be able to publish the delegation.
        safe, detail = main.parent_zone_writes_are_safe(make_state(peerStateAgeSecs=None))
        self.assertTrue(safe)
        self.assertIn("no peer", detail)

    def test_a_malformed_age_allows_writes(self):
        for value in ("soon", True, [], {}):
            self.assertIsNone(main.peer_state_age_secs(make_state(peerStateAgeSecs=value)))
            self.assertTrue(main.parent_zone_writes_are_safe(make_state(peerStateAgeSecs=value))[0])

    def test_negative_age_is_clamped(self):
        self.assertEqual(main.peer_state_age_secs(make_state(peerStateAgeSecs=-5)), 0)

    def test_the_knot_serving_grace_does_not_loosen_parent_zone_writes(self):
        # The knot plugin tolerates stale state for its grace period because holding
        # stale answers is recoverable; poisoning the shared parent zone is not. A
        # cluster that widened the serving grace must not widen this.
        knot_source = (HERE.parent / "knot" / "main.py").read_text()
        self.assertIn("DEFAULT_ISOLATION_GRACE_SECS = 300", knot_source)
        state = make_state(peerStateAgeSecs=60)
        self.assertFalse(main.parent_zone_writes_are_safe(state)[0])

    def test_the_bucket_width_matches_the_manifest(self):
        manifest_text = (HERE / "manifest.yaml").read_text()
        self.assertIn(f"/ {main.PEER_STATE_AGE_BUCKET_SECS * 1000})", manifest_text)


class ApplyTests(unittest.TestCase):
    """A stale node must not touch the parent zone — it is shared with every cloud."""

    def setUp(self):
        self.calls: list[str] = []
        for name in ("pdns_get_rrsets", "pdns_patch_zone"):
            patcher = unittest.mock.patch.object(main, name, self._record(name))
            patcher.start()
            self.addCleanup(patcher.stop)

    def _record(self, name):
        def fn(*args, **kwargs):
            self.calls.append(name)
            # Shape the reads so a run that is allowed to proceed does not crash.
            return [] if name == "pdns_get_rrsets" else True

        return fn

    def _apply(self, state):
        return main.handle_apply(
            main.PluginInput(command="apply", local_node_id="node-1", state=state, local_state={})
        )

    def test_a_fresh_node_syncs_the_parent_zone(self):
        out = self._apply(make_state())
        self.assertEqual(out.status, "completed")
        self.assertIn("pdns_patch_zone", self.calls)

    def test_a_stale_node_makes_no_powerdns_call_at_all(self):
        out = self._apply(make_state(peerStateAgeSecs=120))
        self.assertEqual(out.status, "postponed")
        self.assertIn("stale", out.error_message)
        self.assertEqual(self.calls, [])

    def test_a_stale_node_makes_no_call_in_custom_gateway_mode_either(self):
        state = make_state(peerStateAgeSecs=120)
        state["swarmSecrets"] = state["swarmSecrets"] + [
            {"id": "gateway_hostname", "value": "gw.customer.example"},
        ]
        out = self._apply(state)
        self.assertEqual(out.status, "postponed")
        self.assertEqual(self.calls, [])

    def test_a_single_node_swarm_still_syncs(self):
        out = self._apply(make_state(peerStateAgeSecs=None))
        self.assertEqual(out.status, "completed")
        self.assertIn("pdns_patch_zone", self.calls)

    def test_nothing_is_written_without_powerdns_credentials(self):
        state = make_state(swarmSecrets=[{"id": "base_domain", "value": BASE_DOMAIN}])
        out = self._apply(state)
        self.assertEqual(out.status, "completed")
        self.assertEqual(self.calls, [])


def _jq_available() -> bool:
    return shutil.which("jq") is not None and yaml is not None


@unittest.skipUnless(_jq_available(), "needs the jq binary and PyYAML")
class ManifestQueryTests(unittest.TestCase):
    """The freshness signal is computed in the manifest; cover it where it lives."""

    @staticmethod
    def _query() -> str:
        manifest = yaml.safe_load((HERE / "manifest.yaml").read_text())
        return manifest["stateExpr"]["query"].replace("{{ clusterId }}", "dns-c")

    @staticmethod
    def _ms_ago(seconds: float) -> int:
        return int(time.time() * 1000) - int(seconds * 1000)

    def _fixture(self, heartbeats, *, removed_nodes=()) -> dict:
        members = [n for n in dict.fromkeys(["node-1", *heartbeats]) if n not in removed_nodes]
        cluster_nodes = [
            {"id": f"knot-c:{node}", "cluster": "knot-c", "node": node, "deleted_ts": None}
            for node in members
        ]
        cluster_nodes += [
            {"id": f"knot-c:{node}", "cluster": "knot-c", "node": node, "deleted_ts": 1}
            for node in removed_nodes
        ]
        return {
            "clusters": [{"id": "knot-c", "cluster_policy": "knot", "deleted_ts": None}],
            "clusternodes": cluster_nodes,
            "clusternodeproperties": [],
            "clusterproperties": [
                {"cluster": "knot-c", "name": "knot_isolation_grace_secs", "value": "900",
                 "deleted_ts": None},
            ],
            "nodes": [{"node_id": "node-1", "addr": "203.0.113.1", "status": "alive"}],
            "swarmsecrets": [{"id": "base_domain", "value": BASE_DOMAIN}],
            "swarmidpointer": [{"id": "global_id", "value": GLOBAL_ID}],
            "localnodepointer": [{"node_id": "node-1"}],
            "clusterservicenodestatuses": [
                {
                    "id": f"knot-c:knot:{node}", "cluster_id": "knot-c", "service_name": "knot",
                    "node_id": node, "phase": "Ready", "last_heartbeat_ts": ts,
                }
                for node, ts in heartbeats.items()
            ],
        }

    def _run(self, fixture: dict) -> dict:
        result = subprocess.run(
            ["jq", "-n", "--argjson", "swarmdb", json.dumps(fixture), self._query()],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_a_fresh_peer_heartbeat_reads_as_zero(self):
        self.assertEqual(self._run(self._fixture({"node-2": self._ms_ago(8)}))["peerStateAgeSecs"], 0)

    def test_a_stale_peer_heartbeat_reads_as_its_bucketed_age(self):
        self.assertEqual(
            self._run(self._fixture({"node-2": self._ms_ago(200)}))["peerStateAgeSecs"], 180
        )

    def test_a_bigint_sent_as_a_string_is_coerced(self):
        self.assertEqual(
            self._run(self._fixture({"node-2": str(self._ms_ago(200))}))["peerStateAgeSecs"], 180
        )

    def test_a_removed_peers_frozen_heartbeat_is_ignored(self):
        fixture = self._fixture(
            {"node-1": self._ms_ago(8), "node-9": self._ms_ago(86400)},
            removed_nodes=("node-9",),
        )
        self.assertIsNone(self._run(fixture)["peerStateAgeSecs"])

    def test_a_single_node_swarm_reports_null(self):
        self.assertIsNone(self._run(self._fixture({"node-1": self._ms_ago(8)}))["peerStateAgeSecs"])

    def test_a_healthy_cluster_reports_a_current_view(self):
        # The write gate requires exactly 0, so the healthy-cluster value must be 0.
        self.assertEqual(self._run(self._fixture({"node-2": self._ms_ago(8)}))["peerStateAgeSecs"], 0)


if __name__ == "__main__":
    unittest.main()
